/* ======================================================
   | Copyright(c) by Departament Inorganic Chemistry of |
   | Kharkiv National University 1997-2023              |
   ====================================================== */
#include "mestream.h"
#include "df.h"
#include "all_particles.h"
#include "correl.h"
#include "globals.h"
#include "units.h"
#include "init.h"
#include "orient.h"
#include "md_exception.h"
using namespace mdnaes;

#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <limits>


const char* UnOpen = " Unable to open ";


// ======== Member functions for class SaveManager ========
void SaveManager::Actions ( bool touch_co_out ) const { // declared in globals.h
   // set saving complitness field to false
   if ( touch_co_out ) {
      std::ofstream out ( Co_outFileName, std::ios::binary | std::ios::out | std::ios::in );
      if ( out.good() ) {
         out.seekp ( 7*sizeof(int)+7*sizeof(double) ); // 84
         int i = 0;
         out.write ( (char*) &i, sizeof ( int ) );
      }
      out.close ( );
   }
   
   for ( auto p: Functions ) {
      p();
   }
   
   // set saving complitness field to true
   if ( touch_co_out ) {
      std::ofstream out ( Co_outFileName, std::ios::binary | std::ios::out | std::ios::in );
      if ( !out ) {
         raise_md_exception ( "SaveManager::Actions(): cannot open co_out file (secondary)" );
      }
      out.seekp ( 7*sizeof(int)+7*sizeof(double) ); // 84
      int i = 1;
      out.write ( (char*) &i, sizeof ( int ) );
      out.close ( );
   }
}

void SaveManager::AddFun ( SaveFun f ) { // declared in globals.h
   for ( auto p: Functions ) {
      if ( p == f )
         return;
   }
   Functions.emplace_back (f);
}


/*    =======================================================
      SUBROUTINE RIND
      =======================================================
      reads file fint.dat
      =======================================================
*/
// Search the character '#' in input file stream
void search_number ( std::istream &in ) {
   in.ignore(std::numeric_limits<int>::max(),'#');
   if ( !in.good() ) {
      raise_md_exception ( "Cannot read last data from fint file,\n possibly old version of fint file of file corrupted." );
   }
}

void read_fint () {
   std::ifstream in ( FintFileName );
   if ( !in ) {
      Error << UnOpen << FintFileName << std::endl;
      std::exit(1);
   }

   search_number ( in );    in >> NSTRUN;
   search_number ( in );    in >> NMOL1;
   search_number ( in );    in >> NMOL2;
   search_number ( in );    in >> NION_C;
   search_number ( in );    in >> NION_A;
   search_number ( in );    in >> NumInsIon[0];
   search_number ( in );    in >> NumInsIon[1];
   search_number ( in );    in >> KDBL;
   search_number ( in );    in >> SPRNT;
   search_number ( in );    in >> SWRIT;
   search_number ( in );    in >> KRS;
   search_number ( in );    in >> KStat;
   search_number ( in );    in >> RCut.LJ_init;
      RCut.LJ = RCut.LJ_init;
   //search_number ( in );    in >> RCut.Fs;
   //search_number ( in );    in >> RCut.Fs_switch;
   //search_number ( in );    in >> RCut.Nb_list;
      
   search_number ( in );    in >> KCoul;
   search_number ( in );    in >> KSV;
   search_number ( in );    in >> taw;
   search_number ( in );    in >> tawP;
   search_number ( in );    in >> Eps;
   search_number ( in );    in >> TMPR0;
   search_number ( in );    in >> extPRES;
   search_number ( in );    in >> DELT;
   search_number ( in );    in >> SubSteps;
   search_number ( in );    in >> DENS;

   search_number ( in );    in >> External_Field;
      // Convert it from V/m = J/C/m to internal units:
      //External_Field /= ENERGY_UNIT / CHARGE_UNIT / LENGTH_UNIT;
      External_Field = External_Field / (ENERGY_UNIT/CHARGE_UNIT/LENGTH_UNIT); 
   search_number ( in );    in >> KScrOut;
   search_number ( in );    in >> KCoorOut;

   search_number ( in );    in >> KLH;

   search_number ( in );    in >> KSTR;
   search_number ( in );    in >> KRDF;
   search_number ( in );    in >> StepRDF;
   search_number ( in );    in >> DELTR;
   search_number ( in );    in >> KCoorNum;
   search_number ( in );    in >> KMolOr;
   search_number ( in );    in >> KDSOR;
   search_number ( in );    in >> KDSHL;
   search_number ( in );    in >> StepRInShl;

   search_number ( in );    in >> KCF;
   search_number ( in );    in >> KLegendre;

   search_number ( in );    in >> KShortMolCF;
   search_number ( in );    in >> KMol_Cvv;
   search_number ( in );    in >> KMol_Cww;
   search_number ( in );    in >> KMol_Cff;
   search_number ( in );    in >> KMol_Cnn;
   search_number ( in );    in >> KMol_Cfc;
   search_number ( in );    in >> KMol_Cll;
   search_number ( in );    in >> KMol_Cwc;
   search_number ( in );    in >> KMol_Cvw;
   search_number ( in );    in >> KMol_WcWc;
   search_number ( in );    in >> KMol_VcVc;
   search_number ( in );    in >> KMol_VcWc;
   search_number ( in );    in >> KMol_Cii;  // new in 2.16.0

   search_number ( in );    in >> KLongMolCF;
   search_number ( in );    in >> KDipMom;
   search_number ( in );    in >> KMainVect;
   search_number ( in );    in >> KDipBox;
   search_number ( in );    in >> KMol_Axes;
   search_number ( in );    in >> KMol_RCM;

   search_number ( in );    in >> KShortIonCF;
   search_number ( in );    in >> KIon_Cvv;
   search_number ( in );    in >> KIon_Cww;
   search_number ( in );    in >> KIon_Cff;
   search_number ( in );    in >> KIon_Cnn;
   search_number ( in );    in >> KIon_Cfc;
   search_number ( in );    in >> KIon_Cll;
   search_number ( in );    in >> KIon_Cwc;
   search_number ( in );    in >> KIon_Cvw;
   search_number ( in );    in >> KIon_WcWc;
   search_number ( in );    in >> KIon_VcVc;
   search_number ( in );    in >> KIon_VcWc;
   search_number ( in );    in >> KIon_Cii;  // new in 2.16.0

   search_number ( in );    in >> KLongIonCF;
   search_number ( in );    in >> KIon_Axes;
   search_number ( in );    in >> KIon_RCM;

   search_number ( in );    in >> KTimeLife;
   search_number ( in );    in >> TimeLifeTSize;
   search_number ( in );    in >> TimeLifeMult;
   search_number ( in );    in >> KSVisc;
   search_number ( in );    in >> SViscTSize;
   search_number ( in );    in >> SViscMulT;
   if ( KSVisc && KCF )
      Kstress = 1;
   else
      Kstress = 0;
   search_number ( in );    in >> KConduct;
   search_number ( in );    in >> ConductTSize;
   search_number ( in );    in >> ConductMult;
   
   if ( NumInsIon[0] + NumInsIon[1] + NION_C + NION_A > 0 ) {
      KConduct_E = KConduct;
   }
   else {
      KConduct_E = 0;
   }
   ConductTSize_E = ConductTSize;
   ConductMult_E  = ConductMult * 5;

   search_number ( in );    in >> KAtomsCvv; // new in 16.1

   search_number ( in );    in >> KSTCF;
   search_number ( in );    in >> STCF_TSIZE;
   search_number ( in );    in >> StepSTCF;
   search_number ( in );    in >> STCF_DELTR;
   search_number ( in );    in >> PrintSTCFMode;

   search_number ( in );    in >> KFktInc;
   search_number ( in );    in >> StepFktInc;
   search_number ( in );    in >> FktInc_TSIZE;
   int FktInc_KSIZE = 0;
   search_number ( in );    in >> FktInc_KSIZE;

   search_number ( in );

   for ( int i = 0; i < FktInc_KSIZE; ++i ) {
      double k = 0.0;
      in >> k;
      
      if ( !in.good() ) {
         raise_md_exception ( "Cannot read k values from fint file,\n possibly old version of fint file of file corrupted." );
      }
      
      k_array_inc.push_back (k);
   }

   search_number ( in );    in >> StepShortCF;
   search_number ( in );    in >> StepLongCF;
   search_number ( in );    in >> CorrelSize;

   search_number ( in );    in >> RSHL[0];
   search_number ( in );    in >> RSHL[1];
   search_number ( in );    in >> RSHL[2];
   search_number ( in );    in >> RSHL[3];
   search_number ( in );    in >> RSHL[4];
   search_number ( in );    in >> RSHL[5];
   search_number ( in );    in >> RSHL[6];
   search_number ( in );    in >> RSHL[7];
   search_number ( in );    in >> RSHL[8];

   ReadParams(); // ReadParams() use information from fint.dat file (RCUT_LJ_init)

   // check for errors:
   if ( NMOL1 > 0 && SimSystem.molecule_types.size() < 1 ) {
      raise_md_exception ( "Absent molecule type in params.dat file" );
   }
   if ( NMOL2 > 0 && SimSystem.molecule_types.size() < 2 ) {
      raise_md_exception ( "Absent second molecule type in params.dat file" );
   }
   if ( NION_C > 0 && SimSystem.cation_types.size() < 1 ) {
      raise_md_exception ( "Absent cation type in params.dat file" );
   }
   if ( NION_A > 0 && SimSystem.anion_types.size() < 1 ) {
      raise_md_exception ( "Absent anion type in params.dat file" );
   }
   
   if ( (KDBL || NumInsIon[0] || NumInsIon[1]) && !NORUN ) {
      Error << "Options KDBL, NumInsKat and NumInsAn shoud be used only with -n command line option.\n";
      raise_md_exception ( "Options KDBL, NumInsKat and NumInsAn shoud be used only with -n command line option.\n" );
   }
   
   if ( RCut.Fs < RCut.Fs_switch ) {
      Error << "RCut.Fs shoud be larger or equal than RCut.Fs_switch.\n";
      raise_md_exception ( "RCut.Fs shoud be larger or equal than RCut.Fs_switch.\n" );
   }
   if ( RCut.Nb_list < RCut.Fs ) {
      Error << "RCut.Nb_list shoud be larger or equal than RCut.Fs.\n";
      raise_md_exception ( "RCut.Nb_list shoud be larger or equal than RCut.Fs.\n" );
   }
}

