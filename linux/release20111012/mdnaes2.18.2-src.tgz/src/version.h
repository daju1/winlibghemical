#ifndef VERSION_H
#define VERSION_H
#include <iosfwd>
#include <utility>

constexpr int MDNAES_VERSION = 2;
constexpr int MDNAES_SUBVERSION = 18;
constexpr int MDNAES_REVISION = 2;

class version {
public:
   enum { ok = 0, version_failure, sub_ver_failure };

   static int Version () { return MDNAES_VERSION; }
   static int SubVer ()  { return MDNAES_SUBVERSION; }
   static int Revision ()  { return MDNAES_REVISION; }

   static void out      ( std::ostream& );
   static int check_ver ( std::istream&, const char *filename );
   static int check_ver_as ( std::istream&, int ver, int sub_ver );
   static std::pair<int,int> read_ver ( std::istream& );
private:
   version ( ) { }
};

#endif
