#ifndef TCF_HPP
#define TCF_HPP

#include "HA.h"

#include <iostream>
#include <algorithm>
#include <complex>
#include <cstddef>

namespace mdnaes {
   
class TCF_exception {
public:
   TCF_exception() noexcept : message("") {}
   TCF_exception(const char *msg) noexcept : message(msg) {}
   TCF_exception(const TCF_exception& other) noexcept : message(other.message) {}
   TCF_exception& operator=(const TCF_exception& other) noexcept { message = other.message; return *this; }
   virtual ~TCF_exception() {}
   virtual const char* what() const noexcept { return this->message; }
private:
   const char *message;
};

namespace tcf {

class multiplies {
public:
   template <class restype, class arg1type, class arg2type>
   static void accumulate ( restype& sum, const arg1type& arg1, const arg2type& arg2 ) {
      sum += arg1 * arg2;
   }
   template <class T>
   static void accumulate ( std::complex<T>& sum,
                      const std::complex<T>& arg1,
                      const std::complex<T>& arg2 ) {
      sum += arg1 * std::conj(arg2);
   }
   enum { can_be_normated = 1 }; 
};

class Legendre1 {
public: // assumes, that arg1 and arg2 are properly normated (e.g. are vectors with |v| == 1)
   template <class restype, class arg1type, class arg2type>
   static void accumulate ( restype& sum, const arg1type& arg1, const arg2type& arg2 ) {
      sum += arg1 * arg2;
   }
   template <class T>
   static void accumulate ( std::complex<T>& sum,
                      const std::complex<T>& arg1,
                      const std::complex<T>& arg2 ) {
      sum += arg1 * std::conj(arg2);
   }
   enum { can_be_normated = 1 };
};

class Legendre2 {
public: // assumes, that arg1 and arg2 are properly normated (e.g. are vectors with |v| == 1)
   template <class restype, class arg1type, class arg2type>
   static void accumulate ( restype& sum, const arg1type& arg1, const arg2type& arg2 ) {
      const restype x = arg1 * arg2;
      sum += 1.5*(x*x) - 0.5;
   }
   template <class T>
   static void accumulate ( std::complex<T>& sum,
                      const std::complex<T>& arg1,
                      const std::complex<T>& arg2 ) {
      const std::complex<T> x = arg1 * std::conj(arg2);
      sum += 1.5*(x*x) - 0.5;
   }
   enum { can_be_normated = 1 };
};

class R1 {
public:
   template<class argtype>
   static void accumulate ( double& sum, const argtype& arg1, const argtype& arg2 ) {
      const argtype x = arg1 - arg2;
      sum += sqrt(x*x); // need cmath header!
   }
   enum { can_be_normated = 0 };
};

class R2 {
public:
   template<class argtype>
   static void accumulate ( double& sum, const argtype& arg1, const argtype& arg2 ) {
      const argtype x = arg1-arg2;
      sum += x*x;
   }
   enum { can_be_normated = 0 };
};
} // end of namespace mdnaes::tcf

template <class restype>
class TCF { // Time Correlation Function
public:
   using value_type = restype;
   using reference = restype&;
   using const_reference = const restype&;
   using size_type = std::size_t;

   virtual ~TCF () { delete[] histogram; delete[] counts; }

   void swap ( TCF<restype>& );

   size_type size () const { return t_size; }
   bool empty () const; // is empty?
   void clear ();       // makes empty.
   bool test_overflow () const;

   bool is_at ( size_type idx ) const { return counts[idx] != 0; }

   value_type at ( size_type idx ) const {
      if ( idx >= size() )
         throw TCF_exception ("invalid index in TCF::at(int) function");
      return operator [] (idx);
   }

   value_type operator [] ( size_type idx ) const {
      if ( counts[idx] )
         return histogram[idx]/counts[idx];
      else
         return 0;
   }

   void save ( std::ostream& ) const;
   void read ( std::istream& );
   
   TCF<restype>& operator += ( const TCF<restype>& );
protected:
   const size_type t_size;
   restype *histogram;
   int *counts;

   explicit TCF ( size_type tsize );
   TCF ( const TCF<restype>& );
   TCF<restype>& operator = ( const TCF<restype>& );
};

template<> inline // specialize for std::complex classes
TCF<std::complex<float> >::value_type
TCF<std::complex<float> >::operator [] ( size_type idx ) const {
   if ( counts[idx] ) return histogram[idx]/static_cast<float>(counts[idx]);
   else               return 0;
}
template<> inline // specialize for std::complex classes
TCF<std::complex<double> >::value_type
TCF<std::complex<double> >::operator [] ( size_type idx ) const {
   if ( counts[idx] ) return histogram[idx]/static_cast<double>(counts[idx]);
   else               return 0;
}
template<> inline // specialize for std::complex classes
TCF<std::complex<long double> >::value_type
TCF<std::complex<long double> >::operator [] ( size_type idx ) const {
   if ( counts[idx] ) return histogram[idx]/static_cast<long double>(counts[idx]);
   else               return 0;
}

template <class restype>
TCF<restype>::TCF ( size_type tsize )
      : t_size ( tsize ),
        histogram ( new restype[t_size] ),
        counts ( new int[t_size] )
{
   
   for ( size_type i = 0; i < t_size; ++i ) {
      histogram[i] = 0;
      counts[i] = 0;
   }
}

template <class restype>
TCF<restype>::TCF ( const TCF<restype>& src )
      : t_size ( src.t_size ),
        histogram ( new restype[t_size] ),
        counts ( new int[t_size] )
{
   std::copy ( src.histogram, src.histogram + t_size, histogram );
   std::copy ( src.counts, src.counts + t_size, counts );
}

template <class restype>
TCF<restype>& TCF<restype>::operator = ( const TCF<restype>& src ) {
   const_cast<size_type&>(t_size) = src.t_size;
   delete[] histogram;
   histogram = new restype[t_size];
   delete[] counts;
   counts = new int[t_size];
   std::copy ( src.histogram, src.histogram + t_size, histogram );
   std::copy ( src.counts, src.counts + t_size, counts );
   return (*this);
}

template <class restype>
void TCF<restype>::swap ( TCF<restype>& other ) {
   std::swap ( const_cast<size_type&>(t_size), const_cast<size_type&>(other.t_size) );
   std::swap ( histogram, other.histogram );
   std::swap ( counts, other.counts );
}

template <class restype>
void swap ( TCF<restype>& left_, TCF<restype>& right_ ) {
   left_.swap ( right_ );
}

template <class restype>
bool TCF<restype>::empty () const {
   for ( size_type i = 0; i < t_size; ++i )
      if ( counts[i] != 0 ) return false;
   return true;
}

template <class restype>
void TCF<restype>::clear () {
   for ( int i = 0; i < t_size; ++i ) {
      histogram[i] = 0;
      counts[i] = 0;
   }
}

template <class restype>
bool TCF<restype>::test_overflow () const {
   for ( int i = 0; i < t_size; ++i )
      if ( counts[i] < 0 ) return true;
   return false;
}

// I/O operations:
template <class restype>
void TCF<restype>::save ( std::ostream& out ) const {
   out.write ( (const char*)&t_size, sizeof(size_type) );
   out.write ( (const char*)histogram, sizeof(*histogram)*t_size );
   out.write ( (const char*)counts, sizeof(*counts)*t_size );
}

template <class restype>
void TCF<restype>::read ( std::istream& in ) {
   if ( !in )
      throw TCF_exception ("TCF::read (): cannot read data from the input");

   size_type tmp_t_size = 0;
   in.read ( (char*)&tmp_t_size, sizeof(size_type) );

   if ( !in )
      throw TCF_exception ("TCF::read (): cannot read data from the input");
   if ( tmp_t_size != t_size )
      throw TCF_exception ("TCF::read (): illegal t_size in the input");

   in.read ( (char*)histogram, sizeof(*histogram)*t_size );

   if ( !in )
      throw TCF_exception ("TCF::read (): cannot read data from the input, data are now invalid!");

   in.read ( (char*)counts, sizeof(*counts)*t_size );

   if ( !in )
      throw TCF_exception ("TCF::read (): cannot read data from the input, data are now invalid!");
}

template <class restype>
TCF<restype>& TCF<restype>::operator += ( const TCF<restype>& src ) {
//    if ( this->t_size != src.t_size ) {
//       throw TCF_exception ("TCF::operator += (): different t_size in other object!");
//    }
   for ( int i = 0; i < t_size; ++i ) {
      histogram[i] += src.histogram[i];
      counts[i] += src.counts[i];
   }
   return (*this);
}


// ============================================================================
// =================================== TACF ===================================
template <class restype, class argtype, class op = tcf::multiplies>
class TACF : public TCF<restype> {
public:
   using Base = TCF<restype>;
   using value_type = typename Base::value_type;
   using reference = typename Base::reference;
   using const_reference = typename Base::const_reference;
   using size_type = typename Base::size_type;

   explicit TACF ( size_type tsize ): Base(tsize) {}
   TACF ( const TACF<restype, argtype, op>& src ): Base( src ) {}
   ~TACF () {}

   TACF<restype, argtype, op>& operator = ( const TACF<restype, argtype, op>& src ) {
      this->Base::operator = (src);
      return (*this);
   }

   void add ( const HA<argtype>& );
};

template <class restype, class argtype, class op>
void TACF<restype, argtype, op>::add ( const HA<argtype>& src ) {
   const size_type size = std::min ( this->t_size, src.size () );
   
   for ( size_type i = 0; i < size; ++i ) {
      op::accumulate(this->histogram[i], src[0], src[i]);
      this->counts[i]++;
   }
}


// ============================================================================
// =================================== TCCF ===================================
template <class restype, class arg1type, class arg2type = arg1type, class op = tcf::multiplies>
class TCCF : public TCF<restype> {
public:
   using Base = TCF<restype>;
   using value_type = typename Base::value_type;
   using reference = typename Base::reference;
   using const_reference = typename Base::const_reference;
   using size_type = typename Base::size_type;

   explicit TCCF ( size_type tsize ): Base(tsize) {}
   TCCF ( const TCCF<restype, arg1type, arg2type, op>& src ): Base( src ) {}
   ~TCCF () {}

   TCCF<restype, arg1type, arg2type, op>& operator = ( const TCCF<restype, arg1type, arg2type, op>& src ) {
      this->Base::operator = (src);
      return (*this);
   }

   void add ( const HA<arg1type>&, const HA<arg2type>& );
};

template <class restype, class arg1type, class arg2type, class op>
void TCCF<restype, arg1type, arg2type, op>::add ( const HA<arg1type>& src1, const HA<arg2type>& src2 ) {
   if ( src1.empty () )
      return;
   const size_type size = std::min ( this->t_size, src2.size () );
   
   for ( size_type i = 0; i < size; ++i ) {
      op::accumulate(this->histogram[i], src1[0], src2[i]);
      this->counts[i]++;
   }
}

} // end namespace mdnaes

#endif
