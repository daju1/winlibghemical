#include "version.h"
#include "globals.h"
#include "utils.h"
#include "md_exception.h"

#include <iostream>
#include <cstdint>

void version::out ( std::ostream& out ) {
   write_as<int32_t> ( out, MDNAES_VERSION );
   write_as<int32_t> ( out, MDNAES_SUBVERSION );
}

int version::check_ver ( std::istream& in, const char* file_name ) {
   const auto saved_ver = read_as<int32_t> ( in );
   if ( saved_ver != MDNAES_VERSION ) {
      Error <<   " Version of " << file_name << " is " << saved_ver;
      Error << "\n Version of program is " << MDNAES_VERSION << std::endl;
      return version_failure;
   }

   const auto saved_subver = read_as<int32_t> ( in );
   if ( saved_subver != MDNAES_SUBVERSION ) {
      Error <<   " Subversion of " << file_name << " is " << saved_subver;
      Error << "\n Subversion of program is " << MDNAES_SUBVERSION << std::endl;
      return sub_ver_failure;
   }

   return ok;
}

int version::check_ver_as ( std::istream& in, int ver, int sub_ver ) {
   const auto saved_ver = read_as<int32_t> ( in );
   if ( saved_ver != ver ) {
      return version_failure;
   }

   const auto saved_subver = read_as<int32_t> ( in );
   if ( saved_subver != sub_ver ) {
      return sub_ver_failure;
   }

   return ok;
}

std::pair<int,int> version::read_ver ( std::istream& in ) {
   const auto saved_ver = read_as<int32_t> ( in );
   if ( !in.good() ) {
      return {0,0};
   }

   const auto saved_subver = read_as<int32_t> ( in );
   if ( !in.good() ) {
      return {0,0};
   }

   return {saved_ver,saved_subver};
}
