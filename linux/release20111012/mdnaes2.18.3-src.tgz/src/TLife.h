#ifndef TLife_H
#define TLife_H

extern int TimeLifeTSize;
extern int TimeLifeMult;

extern void TimeLife_Calc ();
extern void TLifeACF_Calc ();

#endif
