/* Tuckerman M., Berne B. J., Martyna G. J. Reversible multiple time scale molecular dynamics
 * J.Chem.Phys. 97(3), 1992. -P. 1990-2001
 */
#include "all_particles.h"
#include "interactions.h"
#include "globals.h"
#include "md_exception.h"
#include "units.h"
#include "correl.h"
#include "disp_corr.h"
#include "lib/constsi.h"
#include "lib/vectf.h"
#include "task_pool.h"

#include <cmath>
#include <iomanip>
#include <thread>

// ============================================================================
namespace {
std::pair<real,real> calc_rfld () {
   double kappa = 0.0;
   if ( KCoul == 3 ) { // we have solution of finit concentration
      double total_charge = 0.0;
      
      for ( const auto p: SimSystem.all_particles ) {
         total_charge += p->charge();
      }
      // Assume here, that total_charge == 0.
      for ( const auto p: SimSystem.all_particles ) {
         kappa += sqr(p->charge());
      }
      kappa /= 2*VOLBOX;
      kappa *= 8*SI_PI /(Eps*SI_Kbol*TMPR0/ENERGY_UNIT);
      kappa *= SI_CPROD / CPROD_UNIT;
      kappa = std::sqrt(kappa);

      /*static int firsttime = 1;
      if ( firsttime ) {
         Message << "\nkappa = " << kappa << std::endl;
         firsttime = 0;
      }*/
   }
   //const double rfld2 = (Eps-1) / ((2*Eps + 1) * RCUT_Coul * RCUT_Coul * RCUT_Coul );
   //const double rfld1 = 1 / RCUT_Coul + rfld2 * RCUT_Coul2;

   // Tironi I.G., Sperb R., Smith P.E., van Gunsteren W.F.  A generalized
   // reaction field method for molecular dynamics simulations // J. Chem. Phys.
   // -1995. -Vol. 102, No. 13. -P. 5451-5459.

   //const double B0 = (1-2*Eps*(1+kappa*RCUT_Coul))/Eps/(1+kappa*RCUT_Coul);
   const double B1 = ((1-4*Eps)*(1+kappa*RCut.Coul) - 2*Eps*sqr(kappa*RCut.Coul))/
                     ((1+2*Eps)*(1+kappa*RCut.Coul) +   Eps*sqr(kappa*RCut.Coul));

   const real rfld2 = -(1+B1) / 2 / ( RCut.Coul * RCut.Coul * RCut.Coul );
   const real rfld1 = 1 / RCut.Coul + rfld2 * RCut.Coul*RCut.Coul; // For shifted potential form
   
   //std::cout << "rfld1 = " << rfld1 << ", rfld2 = " << rfld2 << ", B1 = " << B1 << ", kappa = " << kappa << std::endl;
   
   return {rfld1,rfld2};
}

} // end of namespace

// ============================================================================
static task_pool tpool;

template <bool isStress>
void nb_forces_rfield ( std::size_t thread_no ) {
   System_therm_values_t& Therm_values = TL_Therm_values[thread_no];
   
   Therm_values.zero_general_components ();
   Therm_values.zero_short_components ();
   Therm_values.zero_far_components ();
   
   const auto [rfld1,rfld2] = calc_rfld ();
   
   const real RCUT_LJ2 = sqr(RCut.LJ);
   const real RCUT_Coul2 = sqr(RCut.Coul);

#ifdef STATIC_WORK_BALANCING
   for ( std::size_t i = thread_no; i < SimSystem.all_particles.size()-1; i += NTHREADS ) {
#else
   for ( std::size_t i = tpool(); i < SimSystem.all_particles.size(); i = tpool() ) {
#endif
      particle& part1 = *SimSystem.all_particles[i];
      
      for ( basic_particle::reference atom1: part1 ) {
         if ( atom1.isdummy() ) continue;
         
         const real Q1 = atom1.q() * (SI_CPROD / CPROD_UNIT);
         
         for ( std::size_t j = i+1; j < SimSystem.all_particles.size(); ++j ) {
            particle& part2 = *SimSystem.all_particles[j];
           
            for ( basic_particle::reference atom2: part2 )
            {
               if ( atom2.isdummy() ) continue;
               
               //vect dr = atom2.r() - atom1.r();
               //PBC ( dr );
               
               vect dr;
               dr.x = atom2.r().x - atom1.r().x;
               dr.y = atom2.r().y - atom1.r().y;
               dr.z = atom2.r().z - atom1.r().z;
               
               if ( dr.x > LBOX2 ) dr.x -= LBOX;
               else if ( dr.x < -LBOX2 ) dr.x += LBOX;
               
               if ( dr.y > LBOX2 ) dr.y -= LBOX;
               else if ( dr.y < -LBOX2 ) dr.y += LBOX;
               
               if ( dr.z > LBOX2 ) dr.z -= LBOX;
               else if ( dr.z < -LBOX2 ) dr.z += LBOX;
               
               const real r2 = dr*dr;
               
               if ( r2 < RCUT_Coul2 ) {
                  const real r2i = 1/r2;
                  const real ri  = std::sqrt( r2i );
                  const real r = r2 * ri;
                  
                  const real rfld2r2 = rfld2 * r2;
                  const real Qij = Q1 * atom2.q() ;
                  
                  const real cUij   = Qij * (ri+rfld2r2-rfld1); // shifted
                  const real cVIRij = Qij * (ri-2*rfld2r2);
                  
                  const vect cFij = (cVIRij * r2i) * dr;
                  
                  atom1.f(thread_no).far -= cFij;
                  atom2.f(thread_no).far += cFij;
                  
                  Therm_values.cU[part1.id()][part2.id()]   += cUij;
                  Therm_values.cVIR[part1.id()][part2.id()] += cVIRij;
                  
                  if ( isStress ) {
                     Therm_values.stressPotC[0][0] += dr.x * cFij.x;
                     Therm_values.stressPotC[0][1] += dr.y * cFij.x;
                     Therm_values.stressPotC[0][2] += dr.z * cFij.x;
                     Therm_values.stressPotC[1][1] += dr.y * cFij.y;
                     Therm_values.stressPotC[1][2] += dr.z * cFij.y;
                     Therm_values.stressPotC[2][2] += dr.z * cFij.z;
                  }
                  
                  if ( r2 < RCUT_LJ2 ) {
                     const int IJ = atom1.id()*Atom_types.size() + atom2.id ();
                     
                     const auto [sUij,sVIRij] = (*(all_interactions[IJ])) ( r, ri );
                     
                     const vect sFij = (sVIRij * r2i) * dr;
                     
                     atom1.f(thread_no).far -= sFij;
                     atom2.f(thread_no).far += sFij;
                     
                     Therm_values.sU[part1.id()][part2.id()]   += sUij;
                     Therm_values.sVIR[part1.id()][part2.id()] += sVIRij;
                     
                     if ( isStress ) {
                        Therm_values.stressPotS[0][0] += dr.x * cFij.x;
                        Therm_values.stressPotS[0][1] += dr.y * cFij.x;
                        Therm_values.stressPotS[0][2] += dr.z * cFij.x;
                        Therm_values.stressPotS[1][1] += dr.y * cFij.y;
                        Therm_values.stressPotS[1][2] += dr.z * cFij.y;
                        Therm_values.stressPotS[2][2] += dr.z * cFij.z;
                     }
                  }
               }
            }
         }
      }
#ifdef STATIC_WORK_BALANCING
   }

   // intramolecular nonbonded interactions
   for ( std::size_t i = thread_no; i < SimSystem.all_particles.size(); i += NTHREADS ) {
#endif
      particle& p = *SimSystem.all_particles[i];
      
      for ( basic_particle::size_type a = 0; a < p.natoms(); ++a ) {
         basic_particle::reference atom1 = p[a];
         
         if ( atom1.isdummy() ) continue;
         
         const real Q1 = atom1.q() * (SI_CPROD / CPROD_UNIT);
         
         for ( basic_particle::size_type b = a+1; b < p.natoms(); ++b ) {
            if ( p.is_bonded(a,b) ) continue;
            
            basic_particle::reference atom2 = p[b];
            
            if ( atom2.isdummy() ) continue;
            
            //vect dr = atom2.r() - atom1.r();
            //PBC ( dr );
            
            vect dr;
            dr.x = atom2.r().x - atom1.r().x;
            dr.y = atom2.r().y - atom1.r().y;
            dr.z = atom2.r().z - atom1.r().z;
            
            if ( dr.x > LBOX2 ) dr.x -= LBOX;
            else if ( dr.x < -LBOX2 ) dr.x += LBOX;
            
            if ( dr.y > LBOX2 ) dr.y -= LBOX;
            else if ( dr.y < -LBOX2 ) dr.y += LBOX;
            
            if ( dr.z > LBOX2 ) dr.z -= LBOX;
            else if ( dr.z < -LBOX2 ) dr.z += LBOX;
            
            const real r2 = dr*dr;
            
            if ( r2 < RCUT_Coul2 ) {
               const real r2i = 1/r2;
               const real ri  = std::sqrt( r2i );
               const real r = r2 * ri;
               
               const real rfld2r2 = rfld2 * r2;
               const real Qij = Q1 * atom2.q() ;
               
               const real cUij   = Qij * (ri+rfld2r2-rfld1); // shifted
               const real cVIRij = Qij * (ri-2*rfld2r2);
               
               const vect cFij = (cVIRij * r2i) * dr;
               
               atom1.f(thread_no).far -= cFij;
               atom2.f(thread_no).far += cFij;
               
               Therm_values.Unb_intra += cUij;
               Therm_values.VIRnb_intra += cVIRij;
               
               if ( isStress ) {
                  Therm_values.stressPotC[0][0] += dr.x * cFij.x;
                  Therm_values.stressPotC[0][1] += dr.y * cFij.x;
                  Therm_values.stressPotC[0][2] += dr.z * cFij.x;
                  Therm_values.stressPotC[1][1] += dr.y * cFij.y;
                  Therm_values.stressPotC[1][2] += dr.z * cFij.y;
                  Therm_values.stressPotC[2][2] += dr.z * cFij.z;
               }
               
               if ( r2 < RCUT_LJ2 ) {
                  const int IJ = atom1.id()*Atom_types.size() + atom2.id ();
                  
                  const auto [sUij,sVIRij] = (*(all_interactions[IJ])) ( r, ri );
                  
                  const vect sFij = (sVIRij * r2i) * dr;
                  
                  atom1.f(thread_no).far -= sFij;
                  atom2.f(thread_no).far += sFij;
                  
                  Therm_values.Unb_intra += sUij;
                  Therm_values.VIRnb_intra += sVIRij;
                  
                  if ( isStress ) {
                     Therm_values.stressPotS[0][0] += dr.x * cFij.x;
                     Therm_values.stressPotS[0][1] += dr.y * cFij.x;
                     Therm_values.stressPotS[0][2] += dr.z * cFij.x;
                     Therm_values.stressPotS[1][1] += dr.y * cFij.y;
                     Therm_values.stressPotS[1][2] += dr.z * cFij.y;
                     Therm_values.stressPotS[2][2] += dr.z * cFij.z;
                  }
               }
            }
         }
      }
   }
   
   if ( isStress ) {
      Therm_values.stressPotS[1][0] = Therm_values.stressPotS[0][1];
      Therm_values.stressPotS[2][0] = Therm_values.stressPotS[0][2];
      Therm_values.stressPotS[2][1] = Therm_values.stressPotS[1][2];
      
      Therm_values.stressPotC[1][0] = Therm_values.stressPotC[0][1];
      Therm_values.stressPotC[2][0] = Therm_values.stressPotC[0][2];
      Therm_values.stressPotC[2][1] = Therm_values.stressPotC[1][2];
   }
}


// ====================================================================
namespace {
void sync_forces () {
   for ( auto p: SimSystem.all_particles ) {
      p->sync_far_forces ();
   }
   
   Therm_values.zero_all ();
   for ( const auto& t: TL_Therm_values ) {
      Therm_values += t;
   }
}


void rfield () {
   void (*all_forces)  ( std::size_t ) = nullptr;
   
   if ( Kstress && NSTTOT % SViscMulT == 0 ) {
      all_forces =  nb_forces_rfield<true>;
   }
   else {
      all_forces =  nb_forces_rfield<false>;
   }
   
   tpool.reset ();

   exec_parallel (all_forces, NTHREADS);
   
   sync_forces ();
}

} // end of namespace

// ============================================================================
void FORCE ( ) {
   for ( auto p: SimSystem.all_particles ) {
      p->reset_far_forces ();
   }
   
   switch ( KCoul ) {
   case 0: // assume no charges
   case 2: // Reaction field
   case 3: // Reaction field with ionic strength
      rfield ();
      break;
   default:
      raise_md_exception ( "usupported value for KCoul.\n" );
   }

   // apply external electric field (in z-direction)
   for ( auto p: SimSystem.all_particles ) {
      for ( basic_particle::reference a: *p ) {
         a.f().far += External_Field * a.q();
      }
   }
   
   // calculate dispersion corrections
   calc_disp_corrections ();
}


