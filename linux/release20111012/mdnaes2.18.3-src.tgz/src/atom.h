#ifndef ATOM_H
#define ATOM_H

#include <cstddef>
#include <vector>
#include <string>
#include <iosfwd>
#include <cstdint>

#include "lib/vect.h"
#include "lib/vectf.h"
#include "real.h"
using namespace mdnaes;

struct force_t {
   vect near = 0; // nonbonded forces
   vect far = 0;  // bonded forces
   
   force_t ( vect n, vect f ) : near(n), far(f) {}
};

class atom_type;
class atom_ref;

class configuration_space {
public:
   using size_type = std::size_t;
public:
   explicit configuration_space ( size_type numthreads ) : m_nthreads(numthreads), m_thread_local_forces(numthreads) {}
   
   //size_type allocate_atoms ( const std::vector<atom_type*>& , size_type part_id  );
   size_type allocate_atoms ( const std::vector<int>& , size_type part_id  );
   
   size_type nthreads () const { return m_nthreads; }
   void set_nthreads ( size_type numthreads );
   
public:
   vect& r ( size_type i ) { return m_coordinates[i]; }
   const vect& r ( size_type i ) const { return m_coordinates[i]; }
   
   vect& v ( size_type i ) { return m_velocities[i]; }
   const vect& v ( size_type i ) const { return m_velocities[i]; }
   
   force_t& f ( size_type i, size_type thread_no = 0 ) { return m_thread_local_forces[thread_no][i]; }
   const force_t& f ( size_type i, size_type thread_no = 0 ) const { return m_thread_local_forces[thread_no][i]; }
   
   double& q ( size_type i ) { return m_charges[i]; }
   double q ( size_type i ) const { return m_charges[i]; }
   
   auto particle_id ( size_type i ) const { return m_particle_ids[i]; }
   
   //const atom_type& type ( size_type i ) const { return *m_types[i]; }
   int id ( size_type i ) const { return m_atom_ids[i]; }
   
   const std::vector<size_type>& neighbours_list ( size_type i ) const { return m_neighbours_lists[i]; }
   std::vector<size_type>& neighbours_list ( size_type i ) { return m_neighbours_lists[i]; }
   
private:
   std::vector<vect> m_coordinates;
   std::vector<vect> m_velocities;
   std::vector<std::vector<force_t> > m_thread_local_forces; // .size() == m_nthreads
   std::vector<double> m_charges;
   //std::vector<const atom_type *> m_types;
   std::vector<int> m_atom_ids;
   std::vector<size_type> m_particle_ids;
   
   std::vector<std::vector<size_type> > m_neighbours_lists;
   
private:
   size_type m_nthreads;
};

extern configuration_space global_cspace;

// ============================================================================
class atom_type {
public:
   using size_type = configuration_space::size_type;
   
   atom_type ( std::string at_name, size_type at_id, double m, double q, bool dummy = false )
   : m_atom_name(at_name), m_atom_id(at_id), m_atom_mass(m), m_atom_charge(q), m_is_dummy(dummy)
   {
   }
   atom_type ( const atom_type& ) = default;
   
   const std::string& name () const { return m_atom_name; }
   size_type id () const { return m_atom_id; }
   
   double mass   () const { return m_atom_mass; }
   double charge () const { return m_atom_charge; }
   
   bool isdummy () const { return m_is_dummy; }
   
private:
   std::string m_atom_name;
   size_type m_atom_id;
   double m_atom_mass;
   double m_atom_charge;
   const bool m_is_dummy;
};

extern std::vector<atom_type> Atom_types;

inline int find_id ( const std::vector<atom_type>& types, const std::string& name ) {
   for ( int i = 0; i < types.size(); ++i ) {
      if ( types[i].name() == name )
         return i;
   }
   return -1;
}

// ============================================================================
class atom_ref { // reference semantics
public:
   using size_type = configuration_space::size_type;
   
   explicit atom_ref ( size_type i ) : index(i) {}
   
   vect& r () const { return global_cspace.r(index); }
   //const vect& r () const { return global_cspace.r(index); }
   
   vect& v () const { return global_cspace.v(index); }
   //const vect& v () const { return global_cspace.v(index); }
   
   force_t& f ( size_type thread_no = 0 ) const { return global_cspace.f(index,thread_no); }
   //const force_t& f ( size_type thread_no = 0 ) const { return global_cspace.f(index,thread_no); }
   
   double& q () const { return global_cspace.q(index); }
   //double q () const { return global_cspace.q(index); }
   
   
   //const std::string& name () const { return global_cspace.type(index).name(); }
   //auto mass () const { return global_cspace.type(index).mass(); }
   //size_type id () const { return global_cspace.type(index).id(); }
   //bool isdummy () const { return global_cspace.type(index).isdummy(); }
   //auto orig_charge () const { return global_cspace.type(index).charge(); }
   
   auto id () const { return global_cspace.id(index); }
   
   const std::string& name () const { return Atom_types[id()].name(); }
   auto mass () const { return Atom_types[id()].mass(); }
   bool isdummy () const { return Atom_types[id()].isdummy(); }
   auto orig_charge () const { return Atom_types[id()].charge(); }
   
   auto particle_id () const { return global_cspace.particle_id(index); }
   auto get_index () const { return index; }
   
   void reset_near_forces () const;
   void reset_far_forces () const;
   void sync_near_forces () const;
   void sync_far_forces () const;
   
   void swap ( atom_ref other );
   
   std::vector<size_type>& neighbours_list () { return global_cspace.neighbours_list(index); }
   void add_neighbour ( atom_ref other ) { global_cspace.neighbours_list(index).push_back(other.index); }
   
public:
   void save_v2_0 ( std::ostream& ) const;
   void read_v2_0 ( std::istream& ) const;
   
private:
   friend class const_atom_ref;
   size_type index;
};

class const_atom_ref { // const reference semantics
public:
   using size_type = configuration_space::size_type;
   
   explicit const_atom_ref ( size_type i ) : index(i) {}
   const_atom_ref ( atom_ref src ) : index(src.index) {}
   
   const vect& r () const { return global_cspace.r(index); }
   
   const vect& v () const { return global_cspace.v(index); }
   
   const force_t& f ( size_type thread_no = 0 ) const { return global_cspace.f(index,thread_no); }
   
   double q () const { return global_cspace.q(index); }
   
   //const std::string& name () const { return global_cspace.type(index).name(); }
   //double mass () const { return global_cspace.type(index).mass(); }
   //size_type id () const { return global_cspace.type(index).id(); }
   //bool isdummy () const { return global_cspace.type(index).isdummy(); }
   //double orig_charge () const { return global_cspace.type(index).charge(); }
   
   auto id () const { return global_cspace.id(index); }
   
   const std::string& name () const { return Atom_types[id()].name(); }
   auto mass () const { return Atom_types[id()].mass(); }
   bool isdummy () const { return Atom_types[id()].isdummy(); }
   auto orig_charge () const { return Atom_types[id()].charge(); }
   
   auto particle_id () const { return global_cspace.particle_id(index); }
   auto get_index () const { return index; }
   
   const std::vector<size_type>& neighbours_list () const { return global_cspace.neighbours_list(index); }
   
public:
   void save_v2_0 ( std::ostream& ) const;
   
private:
   size_type index;
};

#endif
