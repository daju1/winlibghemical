#ifndef STCF_H
#define STCF_H

extern int STCF_TSIZE;
extern int StepSTCF;
extern double STCF_DELTR;
extern int PrintSTCFMode; // 0 - multiple files, 1 - single file

void STCF_Calc ();

#endif
