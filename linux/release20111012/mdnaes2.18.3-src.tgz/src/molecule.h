#ifndef MOLECULE_H
#define MOLECULE_H

#include "particle.h"

#include <vector>
#include <memory>

// ============================================================================
class molecule;

class molecule_type : public particle_type {
protected:
   double *mainVectCoefs;
   std::vector<std::vector<double> > cationCoordinationCenterCoefs;
   std::vector<std::vector<double> > anionCoordinationCenterCoefs;

   vect calcMainVect ( const basic_particle& atoms ) const;

   int numberOfCationCoordinationCenters () const;
   vect calcCationCoordinationCenter ( const basic_particle& atoms, int c ) const;
   int numberOfAnionCoordinationCenters () const;
   vect calcAnionCoordinationCenter  ( const basic_particle& atoms, int c ) const;

   molecule_type ( mylist_const_iterator& );

   friend class molecule;
public:
   virtual ~molecule_type ();

   virtual std::unique_ptr<molecule> create ( vect origin ) const = 0;
   virtual std::unique_ptr<molecule> create ( const molecule *src, vect cmpos ) const = 0;
   //virtual p_array<molecule> new_array () const = 0;

   virtual void print ( std::ostream& ) const;
};

// ============================================================================
class molecule : public particle {
public:
   using type_t = molecule_type;
protected:
   molecule ( const molecule_type *t, vect origin )
   : particle(t,origin), type(t) {}
   
   molecule ( const molecule &src, vect cmpos )
   : particle(src,cmpos), type(src.type) {}
   
public:
   virtual vect getDipolMomentum () const;

   vect getMainVect () const;
   vect getCationCoordinationCenter () const;
   vect getAnionCoordinationCenter  () const;

   double getMinCationCoordinationCenterDistance ( const std::vector<vect>& ) const;
   double getMinAnionCoordinationCenterDistance  ( const std::vector<vect>& ) const;

private:
   const molecule_type *type;
};

#endif
