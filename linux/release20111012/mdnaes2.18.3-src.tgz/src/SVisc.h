#ifndef SVisc_H
#define SVisc_H

extern int SViscTSize;
extern int SViscMulT;

extern void SVisc_Calc ();

#endif
