#ifndef LMolCF_H
#define LMolCF_H

extern int KDipMom;
extern int KMainVect;
extern int KDipBox;

extern int KMol_Axes; // Ex, Ey and Ez
extern int KMol_RCM;  // <|R(t)|> and <|R(t)|^2>

void LongMolCF_Calc ();

#endif
