/* ======================================================
   | Copyright(c) by Departament of Inorganic Chemistry |
   | Kharkiv State University 1997-99                   |
   | Kolesnyk Yaroslav Valentinovich 2000-2024          |
   ====================================================== */
#include <cstdlib>
#include <cmath>
#include <limits>
#include <cstring>
#include <cctype>
#include <string>
#include <algorithm>
#include <functional>
#include <cstdint>
#include <iomanip>

#include "all_particles.h"
#include "globals.h"
#include "init.h"
#include "insion.h"
#include "version.h"
#include "units.h"
#include "md_exception.h"
using namespace mdnaes;

static void PHEAD ();
static void print_help ();

void MAXWELL () {
   extern void SetPBoxToZero ();

   for ( auto p: SimSystem.all_particles ) {
      p->randomize_velocities ();
   }
   
   SetPBoxToZero ();

   double Ekin = 0.0;
   for ( auto p: SimSystem.all_particles ) {
      Ekin += p->getEkin ();
   }

   int NDegFree  = 0;
   for ( int i = 0; i < SimSystem.molecule_types.size(); ++i ) {
      NDegFree  += SimSystem.molecules[i].size() * SimSystem.molecule_types[i]->nDegFree();
   }
   for ( int i = 0; i < SimSystem.cation_types.size(); ++i ) {
      NDegFree  += SimSystem.cations[i].size() * SimSystem.cation_types[i]->nDegFree();
   }
   for ( int i = 0; i < SimSystem.anion_types.size(); ++i ) {
      NDegFree  += SimSystem.anions[i].size() * SimSystem.anion_types[i]->nDegFree();
   }
   NDegFree -= 3; // Total system velocity (3 degrees of freedom) is fixed to be zero!

   const double TMPR = 2 * Ekin * ENERGY_UNIT / ( SI_Kbol * NDegFree );

   const double TS = sqrt(TMPR0/TMPR);

   for ( auto p: SimSystem.all_particles ) {
      p->scalv ( TS );
   }
}

               /*     GLOBALS     */
const char *LogFileName    = "report.log";
const char *Co_inFileName  = "co_in.dat";
const char *Co_outFileName = "co_out.dat";
const char *ResFileName    = "result.dat";
const char *FintFileName   = "fint.dat";
const char *ParamsFileName = "params.dat";

int CO_IN_VERSION =  0; // 0 - means that value must be taken from co_in file
int CO_IN_SUBVER  = -1;

int DLPOLY_levcfg = -1;
             /*   END OF GLOBALS   */


// ============================================================================
static void readShortOption ( char const * const arg ) {
   switch ( *arg ) {
      case 's':
      {
         const auto seed = strtoul ( arg+1, NULL, 0 );
         if ( seed == 0 || seed > std::numeric_limits<int32_t>::max() ) {
            std::cerr << "\n seed must be between 1 and " << std::numeric_limits<int32_t>::max() << "\n";
            Error     << "\n seed must be between 1 and " << std::numeric_limits<int32_t>::max() << "\n";
         }
         else {
            CURRENT_SEED = seed;
            srand ( CURRENT_SEED );
            global_random_engine.seed ( CURRENT_SEED );
         }
      }
         break;
      case 'l':
         LogFileName   = arg+1;
         break;
      case 'i':
         Co_inFileName = arg+1;
         break;
      case 'o':
         Co_outFileName = arg+1;
         break;
      case 'r':
         ResFileName   = arg+1;
         break;
      case 'f':
         FintFileName  = arg+1;
         break;
      case 'p':
         ParamsFileName = arg+1;
         break;
      case 'h':
      case '?':
      {
         PHEAD ();
         print_help ();
         exit ( EXIT_SUCCESS );
      }
      case 'n':
      {
         NORUN = 1;
         const std::string mode { arg+1 };

         if ( mode == "0" || mode == "" ) {
            NORUN_MODE = 0;
         } else
         if ( mode == "1" ) {
            NORUN_MODE = 1;
         } else {
            std::cerr << "Illegal option -n" << mode << std::endl;
            Error << "Illegal option -n" << mode << std::endl;
            Error << "Should be one of -n  -n0  -n1" << std::endl;
            raise_md_exception ( "Error in [init.cpp]readShortOption()\n" );
         }
      }
         break;
      case 'v':
      {
         char *p1 = nullptr;
         const int version = strtol ( arg+1, &p1, 10 );
         if ( p1 == arg+1 ) {
            std::cerr << "cannot read co_in version in -v option.\n";
            Error << "cannot read co_in version in -v option.\n";
            raise_md_exception ( "Error in [init.cpp]readShortOption()\n" );
         }
         if ( *p1 != '.' ) {
            std::cerr << "cannot find . separator in -v option.\n";
            Error << "cannot find . separator in -v option.\n";
            raise_md_exception ( "Error in [init.cpp]readShortOption()\n" );
         }

         char *p2 = nullptr;
         const int subver = strtol ( p1+1, &p2, 10 );
         if ( p2 == p1+1 ) {
            std::cerr << "cannot read co_in subversion in -v option.\n";
            Error << "cannot read co_in subversion in -v option.\n";
            raise_md_exception ( "Error in [init.cpp]readShortOption()\n" );
         }

         std::cerr << "" << version << "." << subver << "\n";

         CO_IN_VERSION = version;
         CO_IN_SUBVER = subver;

         break;
      }
      case 'd':
      {
         DLPOLY_levcfg = 0;
         switch ( *(arg+1) ) {
            case '0':
               break;
            case '1':
               DLPOLY_levcfg = 1;
               break;
            default:
               std::cout << "unsupported levcfg value for DLPOLY config file\n" \
               "in option -d[<levcfg>] levcfg\n" \
               "must be 0 or absent to print only atomic coordinates\n" \
               "or 1 to print coordinates and velocities\n" \
               "levcfg is set to 0" << std::endl;
         }

         break;
      }
      default:
         Error << "Unrecognized option: -" << arg << "\n";
   }
}

void ReadCommandLine ( char *argv[] ) {
   // argv[0] is program name!
   for ( char const * const * arg = argv+1; *arg != nullptr; ++arg ) {
      char const * const op = *arg;
      if ( op[0] == '-' ) {
         if ( op[1] == '-' ) { // long option
            const std::string option (op+2);
            if ( option == "help" ) {
               PHEAD ();
               print_help ();
               exit ( EXIT_SUCCESS );
            }
            else if ( option == "vbox" ) {
               K_PrintVbox = true;
            }
            else if ( option == "noscr" ) {
               NOSCRPRINT = true;
            }
            else if ( option == "gro" ) {
               K_PrintGRO = true;
            }
            else if ( option == "import-gro" ) {
               K_ImportGRO = true;
            }
            else if ( option == "start" ) {
               K_StartRUN = true;
            }
            else if ( option == "nthreads" ) {
               if ( nullptr == *(arg+1) ) {
                  Error << "number of thread is missing in \"--nthreads <n>\" option. Default to 1";
                  std::cerr << "number of thread is missing in \"--nthreads <n>\" option. Default to 1";
                  NTHREADS = 1;
               }
               else {
                  ++arg;
                  const auto n = strtol ( *arg, nullptr, 0 );
                  if ( n < 1 || n > 64 ) {
                     Error << "specified number of threads in \"--nthreads <n>\" option is too large or negative. Default to 1";
                     std::cerr << "specified number of threads in \"--nthreads <n>\" option is too large or negative. Default to 1";
                     NTHREADS = 1;
                  }
                  else {
                     NTHREADS = n;
                  }
               }
            }
            else {
               Error << "Unrecognized long option: " << option << "\n";
               std::cerr << "Unrecognized long option: " << option << "\n";
            }
         }
         else { // short option
            readShortOption (op+1);
         }
      }
      else {
         Error << "Unrecognized option: " << op << "\n";
      }
   }
}


/*    =======================================================
      SUBROUTINE PHEAD
      =======================================================
      header
      ======================================================= */
void PHEAD () {
   std::cout << "\t               M D N A E S " << version::Version() << '.' << version::SubVer() << '.' << version::Revision() << '\n';
   std::cout << "\t   Copyright:  Department of Inorganic chemistry\n"\
           "\t               Kharkiv National University, Kharkiv, Ukraine\n"\
           "\t   MD TEAM:    Oleg N. Kalugin ( team leader )          1994-2005\n"\
           "\t               Alexey V. Ishenko    Diploma project     1995-1996\n"\
           "\t               Maxim N. Volobuev ( FORTRAN->C++ translation )\n"\
           "\t                                    Diploma project     1996-1997\n"\
           "\t                                    PhD project         1997-2000\n"\
           "\t               Yaroslav V. Kolesnyk Diploma project     1998-1999\n"\
           "\t                                    PhD project         1999-2004\n"\
           "\t                                    MDNAES2 development 2000-2023\n"\
           "\t   FORTRAN original code: program MODYS by\n"\
           "\t               Iosif I. Vaisman, Michael G. Kiselev,\n"\
           "\t               Yury P. Puhovski, Yury M. Kessler\n"\
           "\t               Institute of Non-Aqueous Solutions Chemistry\n"\
           "\t               USSR Academy of Science, Ivanovo, 1985-1991\n";
}

void print_help () {
   std::cout << " options : \n"\
                " -l<log file name>     default: report.log   \n"\
                " -i<co_in file name>   default: co_in.dat    \n"\
                " -o<co_out file name>  default: co_out.dat   \n"\
                " -r<results file name> default: result.dat   \n"\
                " -f<fint file name>    default: fint.dat     \n"\
                " -p<params file name>  default: params.dat   \n"\
                " -s<seed>              sets seed for random number generator\n"\
                " -n0                   not run, print some useful properties\n"\
                " -n1                   as -n0, but prints DVS.dat and MVS.dat files\n"\
                " -n                    same as -n0 option\n"\
                " -d[<levcfg>]          create DLPOLY config file named \"config\"\n" \
                " -v<ver>.<subver>      read co_in.dat as version ver.subver\n" \
                " -h\n"\
                " -?\n"\
                " --help                display this help\n";
   std::cout << " --vbox                print VBox.log file\n"\
                " --noscr               disable printing of steps left to stdout\n"\
                " --gro                 print GROMACS gro file named conf.gro\n"\
                " --start               displacement of atoms limited by 0.001 nm.\n"\
                " --nthreads <n>        number of threads to use. Default is 1.\n";
}

/*    ===========================================================
      SUBROUTINE DUBL
      ===========================================================
      multiplies the initial simulation box
      ===========================================================
*/
void DUBL ( int N ) {
   for ( std::size_t i = 0; i < SimSystem.molecules.size(); ++i ) {
      auto& array = SimSystem.molecules[i];
      const int npart_orig = array.size();
      
      for ( int k = 0; k < npart_orig; ++k ) {
         auto p_orig = array[k].get();
         
         for ( int ix = 0; ix < N; ++ix ) {
            for ( int iy = 0; iy < N; ++iy ) {
               for ( int iz = 0; iz < N; ++iz ) {
                  if ( 0 == ix && 0 == iy && 0 == iz )
                     continue;
                  
                  const vect cmpos = p_orig->getCMPos() + vect( LBOX*ix, LBOX*iy, LBOX*iz );
                  //because we dont use any iterators dont worry about their invalidation.
                  array.emplace_back ( SimSystem.molecule_types[i]->create(p_orig,cmpos) );
               }
            }
         }
      }
   }
   
   for ( std::size_t i = 0; i < SimSystem.cations.size(); ++i ) {
      auto& array = SimSystem.cations[i];
      const int npart_orig = array.size();
      
      for ( int k = 0; k < npart_orig; ++k ) {
         auto p_orig = array[k].get();
         
         for ( int ix = 0; ix < N; ++ix ) {
            for ( int iy = 0; iy < N; ++iy ) {
               for ( int iz = 0; iz < N; ++iz ) {
                  if ( 0 == ix && 0 == iy && 0 == iz )
                     continue;
                  
                  const vect cmpos = p_orig->getCMPos() + vect( LBOX*ix, LBOX*iy, LBOX*iz );
                  //because we dont use any iterators dont worry about their invalidation.
                  array.emplace_back ( SimSystem.cation_types[i]->create(p_orig,cmpos) );
               }
            }
         }
      }
   }

   for ( std::size_t i = 0; i < SimSystem.anions.size(); ++i ) {
      auto& array = SimSystem.anions[i];
      const int npart_orig = array.size();
      
      for ( int k = 0; k < npart_orig; ++k ) {
         auto p_orig = array[k].get();
         
         for ( int ix = 0; ix < N; ++ix ) {
            for ( int iy = 0; iy < N; ++iy ) {
               for ( int iz = 0; iz < N; ++iz ) {
                  if ( 0 == ix && 0 == iy && 0 == iz )
                     continue;
                  
                  const vect cmpos = p_orig->getCMPos() + vect( LBOX*ix, LBOX*iy, LBOX*iz );
                  //because we dont use any iterators dont worry about their invalidation.
                  array.emplace_back ( SimSystem.anion_types[i]->create(p_orig,cmpos) );
               }
            }
         }
      }
   }

   SimSystem.syncronize_particle_arrays ();

   LBOX *= N;
   LBOX2  = LBOX / 2;
   VOLBOX = LBOX*LBOX*LBOX;
   
   MAXWELL ();
}

// ============================================================================
void CONFIG ( ) { // create new simulated system
   global_cspace.set_nthreads ( NTHREADS );
   
   if ( NMOL1 > 0 && SimSystem.molecule_types.size() < 1 ) {
      raise_md_exception ( "Cannot insert molecules. No molecule types in params.dat file.\n" );
   }
   if ( NMOL2 > 0 && SimSystem.molecule_types.size() < 2 ) {
      raise_md_exception ( "Cannot insert molecules of second sort. No second molecule type in params.dat file.\n" );
   }
   if ( NION_C > 0 && SimSystem.cation_types.size() == 0 ) {
      raise_md_exception ( "Cannot insert cations. No cation types in params.dat file.\n" );
   }
   if ( NION_A > 0 && SimSystem.anion_types.size() == 0 ) {
      raise_md_exception ( "Cannot insert anions. No anion types in params.dat file.\n" );
   }
   
   const std::size_t NPART = NMOL1 + NMOL2 + NION_C + NION_A;
   
   // calculate LBOX:
   double BoxMass = 0.0;
   if ( NMOL1 > 0 )
      BoxMass += NMOL1 * SimSystem.molecule_types[0]->mass();
   if ( NMOL2 > 0 )
      BoxMass += NMOL2 * SimSystem.molecule_types[1]->mass();
   if ( NION_C > 0 )
      BoxMass += NION_C * SimSystem.cation_types[0]->mass();
   if ( NION_A > 0 )
      BoxMass += NION_A * SimSystem.anion_types[0]->mass();
   
   LBOX = pow ( BoxMass * MASS_UNIT / DENS, 1/3.0 ) / LENGTH_UNIT;
   LBOX2 = LBOX * 0.5;
   RCut.Coul = LBOX2;
   RCut.LJ = RCut.LJ_init;
   if ( RCut.LJ > LBOX2 )
      RCut.LJ = LBOX2;
   VOLBOX = LBOX * LBOX * LBOX;

   LBOXinit = LBOX;
   DENSinit = DENS;
   
   const Pcubic_grid PCC {NPART,LBOX};
   const FCC_grid    FCC {NPART,LBOX};
   const crystal_grid& grid = (PCC.size() > FCC.size()) ? static_cast<const crystal_grid&>(FCC)
                                                        : static_cast<const crystal_grid&>(PCC);
   
   std::vector<crystal_grid::size_type> all_indices;
   for ( std::size_t i = 0; i < grid.size(); ++i ) {
      all_indices.push_back (i);
   }
   
   const auto [cation_indices,anion_indices] = select_ions_positions ( grid, NION_C, NION_A );
   
   std::vector<crystal_grid::size_type> ions_indices;
   std::copy ( cation_indices.begin(), cation_indices.end(), std::back_inserter(ions_indices) );
   std::copy ( anion_indices.begin(), anion_indices.end(), std::back_inserter(ions_indices) );
   std::sort ( ions_indices.begin(), ions_indices.end() );
   
   std::vector<crystal_grid::size_type> molecules_indices;
   std::set_difference ( all_indices.begin(), all_indices.end(),
                         ions_indices.begin(), ions_indices.end(),
                         std::back_inserter(molecules_indices) );
   std::shuffle ( molecules_indices.begin(), molecules_indices.end(), global_random_engine );
   
   for ( std::size_t i = 0; i < NMOL1; ++i ) {
      const vect origin = grid[molecules_indices[i]];
      SimSystem.molecules[0].emplace_back ( SimSystem.molecule_types[0]->create(origin) );
   }
   
   for ( std::size_t i = 0; i < NMOL2; ++i ) {
      const vect origin = grid[molecules_indices[i+NMOL1]];
      SimSystem.molecules[1].emplace_back ( SimSystem.molecule_types[1]->create(origin) );
   }
   
   for ( std::size_t i = 0; i < NION_C; ++i ) {
      const vect origin = grid[cation_indices[i]];
      SimSystem.cations[0].emplace_back ( SimSystem.cation_types[0]->create(origin) );
   }
   
   for ( std::size_t i = 0; i < NION_A; ++i ) {
      const vect origin = grid[anion_indices[i]];
      SimSystem.anions[0].emplace_back ( SimSystem.anion_types[0]->create(origin) );
   }
   
   SimSystem.syncronize_particle_arrays ();
   
   MAXWELL ();
}
