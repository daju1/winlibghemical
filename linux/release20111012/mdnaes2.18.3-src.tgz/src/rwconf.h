void ReadConf ();
void WriteConf ();
