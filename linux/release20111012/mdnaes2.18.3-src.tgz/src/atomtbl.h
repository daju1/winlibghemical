#ifndef ATOMTBL_H
#define ATOMTBL_H

#include <string>

#include "atom.h"
#include "interactions.h"
#include "mylist.h"

class atom_types_table;

class interactions_table {
public:
   static constexpr int MAX_ATOM_TYPES = 128;

   interactions_table ( atom_types_table& );
   ~interactions_table () { }

   int natom_types () const;
   bool is_OK () const;
   bool is_present ( int id1, int id2 ) const;

   interaction* get_interaction ( int id1, int id2 ) const;

   void clear ();
   void add_interaction ( int id1, int id2, interaction * );
   void read_interaction ( mylist_const_iterator& );
   int expand ();
private:
   atom_types_table& m_AtomTypes;
   interaction *m_Interactions[MAX_ATOM_TYPES][MAX_ATOM_TYPES];
   int n_atom_types;

   void operator = ( const interactions_table& ) { }
};

class atom_types_table { // use with global object Atom_types from atom.cpp
public:
   atom_types_table ( std::vector<atom_type>& types_holder ) : m_Atom_types(types_holder) {}
   ~atom_types_table () {}

   int natom_types () const { return m_Atom_types.size(); }
   bool is_present ( int ID ) const;
   bool is_present ( const char * Name ) const;
   bool is_present ( const std::string& Name ) const;

   int id ( const std::string& at_name ) const;
   const std::string& name ( int ID ) const;

   const atom_type& get_atom_type ( int ID ) const;

   void read_atom_type ( mylist_const_iterator&, int use_shifted_force, int LJ_default_combining_rule );
   
private:
   enum {Null_defaults = 0, LJ_defaults};
   
   std::vector<atom_type>& m_Atom_types;
   
   std::vector<double> sigmas;
   std::vector<double> epsilons;
   std::vector<int> has_defaults;
   
   interactions_table *m_InteractionsTable = nullptr;

   void register_interactions_table ( interactions_table * itbl ) { m_InteractionsTable = itbl; }
   friend class interactions_table;

   void operator = ( const atom_types_table& ) = delete;
};

#endif
