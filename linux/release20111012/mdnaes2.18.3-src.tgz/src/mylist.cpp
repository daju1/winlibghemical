#include "mylist.h"
#include "md_exception.h"


mylist::mylist ( const std::string& str ) : value(str), root(nullptr), end(nullptr), numelems(0) {
}

mylist::mylist ( const mylist& lst ) : value(lst.value), root(nullptr), end(nullptr), numelems(0) {
   mylist_item *index = lst.root;
   while ( index != nullptr ) {
      add ( index->sublist );
      index = index->next;
   }
}

mylist::~mylist () {
   release ();
}

mylist& mylist::operator = ( const mylist& lst ) {
   release ();
   value = lst.value;
   mylist_item *index = lst.root;
   while ( index != nullptr ) {
      add ( index->sublist );
      index = index->next;
   }
   return (*this);
}

const mylist& mylist::get_elem ( int i ) const {
   mylist_item *index = root;
   while ( i ) {
      index = index->next;
      if ( index == nullptr ) {
         raise_md_exception ( "out of range index in mylist::get_elem" );
         //return end->sublist;// error!!!
      }
      i--;
   }
   return index->sublist;
}

mylist& mylist::add ( const mylist& el ) {
   numelems++;
   if ( numelems == 1 ) {
      root = end = new mylist_item ( el );
   }
   else {
      end->next = new mylist_item ( el );
      end = end->next;
   }
   return (*this);
}

void mylist::release () {
   numelems = 0;
   while ( root != nullptr ) {
      mylist_item *t = root;
      root = root->next;
      delete t;
   }
}

// ============================ class mylist_const_iterator ===============================

mylist_const_iterator::mylist_const_iterator ( const mylist& lst ) : repList(&lst), index(0) {
}

mylist_const_iterator::mylist_const_iterator ( const mylist_const_iterator& i ) :
   repList(i.repList), index(i.index) {
}

mylist_const_iterator& mylist_const_iterator::operator = ( const mylist_const_iterator& i ) {
   repList = i.repList;
   index = i.index;
   return (*this);
}

bool mylist_const_iterator::is_on_end () const {
   if ( index == repList->num_elems() )
      return true;
   else
      return false;
}

bool mylist_const_iterator::is_on_start () const {
   if ( index == 0 )
      return true;
   else
      return false;
}

mylist_const_iterator& mylist_const_iterator::operator ++ () {
   if ( !is_on_end() )
      index++;
   return (*this);
}

mylist_const_iterator& mylist_const_iterator::operator -- () {
   if ( !is_on_start() )
      index--;
   return (*this);
}

void mylist_const_iterator::reset ( int i ) {
   index = i;
}

int mylist_const_iterator::get_int () const {
   if ( is_on_end() )
      raise_md_exception ( "Cannot read value. Position is beyond the end of list in mylist_const_iterator::get_int()" );
   return std::strtol(repList->get_elem(index).getval().c_str(), 0, 10);
}

std::size_t mylist_const_iterator::get_size_t () const {
   if ( is_on_end() )
      raise_md_exception ( "Cannot read value. Position is beyond the end of list in mylist_const_iterator::get_size_t()" );
   return std::strtoul(repList->get_elem(index).getval().c_str(), 0, 10);
}

double mylist_const_iterator::get_double () const {
   if ( is_on_end() )
      raise_md_exception ( "Cannot read value. Position is beyond the end of list in mylist_const_iterator::get_double()" );
   return std::strtod(repList->get_elem(index).getval().c_str(), 0);
}

bool mylist_const_iterator::find ( const char *str ) {
   while ( !this->is_on_end () && this->item_name () != str )
      ++(*this);
   if ( this->is_on_end () ) // not found
      return false;
   return true;
}
