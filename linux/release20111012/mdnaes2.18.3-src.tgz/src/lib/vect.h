#ifndef VECT_H
#define VECT_H

#include <iosfwd>

namespace mdnaes {

class vect {
public:
   double x, y, z;

   vect () { }
   vect ( double a ) : x(a), y(a), z(a) { }
   vect ( double a, double b, double c ) : x(a), y(b), z(c) { }
   vect ( const vect& v  ) : x(v.x), y(v.y), z(v.z) { }

   vect& operator = ( const vect& v ) {
                      x = v.x; y = v.y; z = v.z;
                      return (*this); }

   vect& operator += ( const vect& v ) {
                       x += v.x; y += v.y; z += v.z; 
                       return (*this); }
   vect& operator -= ( const vect& v ) {
                       x -= v.x; y -= v.y; z -= v.z;
                       return (*this); }

   vect& operator *= ( double d ) {
                       x *= d; y *= d; z *= d;
                       return (*this); }
   vect& operator /= ( double d ) {
                       const double di = 1/d;
                       x *= di; y *= di; z *= di;
                       return (*this); }

   vect& normate ( );
};


inline vect operator - ( const vect& v ) {
   return vect ( -v.x, -v.y, -v.z );
}

inline vect operator + ( const vect& a, const vect& b ) {
   return vect ( a.x + b.x, a.y + b.y, a.z + b.z );
}

inline vect operator - ( const vect& a, const vect& b ) {
   return vect ( a.x - b.x, a.y - b.y, a.z - b.z );
}

inline vect operator * ( const vect& v, double d ) {
   return vect ( v.x * d, v.y * d, v.z * d );
}

inline vect operator * ( double d, const vect& v ) {
   return vect ( v.x * d, v.y * d, v.z * d );
}

inline vect operator / ( const vect& v, double d ) {
   const double di = 1/d;
   return vect ( v.x * di, v.y * di, v.z * di );
}

double norm ( const vect& );

vect vecmul ( const vect&, const vect& );
vect normated_vecmul ( const vect&, const vect& );

inline double operator * ( const vect& a, const vect& b ) {
   return ( a.x*b.x + a.y*b.y + a.z*b.z );
}

std::ostream& operator << ( std::ostream& out, const vect& v );
std::istream& operator >> ( std::istream& in, vect& v );

vect operator * ( const double A[3][3], const vect& v );
vect operator * ( const vect& v, const double A[3][3] );

void direct_product_accumulate ( const vect& a, const vect& b, double Res[3][3] );

inline double sqr ( const vect& x ) {
   return x*x;
}

} // end namespace mdnaes

#endif
