#ifndef HA_HPP
#define HA_HPP

#include <iostream>
#include <algorithm>
#include <limits>
#include <cstddef>

namespace mdnaes {
   
class HA_exception {
public:
   HA_exception() noexcept : message("") {}
   HA_exception(const char *msg) noexcept : message(msg) {}
   HA_exception(const HA_exception& other) noexcept : message(other.message) {}
   HA_exception& operator=(const HA_exception& other) noexcept { message = other.message; return *this; }
   virtual ~HA_exception() {}
   virtual const char* what() const noexcept { return this->message; }
private:
   const char *message;
};


template <class data_type>
class HA {
public:
   using value_type = data_type;
   using reference = data_type&;
   using const_reference = const data_type&;
   using const_iterator = const data_type*; // nonconstant iterator type for this container is undefined!
   using size_type = std::size_t;
   typedef int difference_type;

   explicit HA ( size_type maxsz, size_type gr = 16 );
   HA ( const HA<data_type>& );
   HA ( const HA<data_type>&, size_type gr );
   ~HA () { delete[] array; }

   HA<data_type>& operator = ( const HA<data_type>& );

   void swap ( HA<data_type>& );

   size_type size () const { return cursize; }
   size_type max_size () const { return maxsize; }

   bool empty () const { return cursize == 0; }

   void clear () {
      cursize = 0;
      data = array+granularity-1;
   }

   const_reference at ( size_type idx ) const {
      if ( idx >= size() )
         throw HA_exception ("invalid index in HA::at(int) function");
      return data[idx];
   }

   const_reference operator [] ( size_type idx ) const {
      return data[idx];
   }

   const_iterator begin () const { return data; }
   const_iterator end ()   const { return data+size(); }

   void push_front ( const_reference value ) { add (value); }
   void add ( const_reference ); // invalidates all iterators!

   void save ( std::ostream& ) const;
   void read ( std::istream& );
   
private:
   const size_type granularity;
   const size_type maxsize;
   size_type cursize;
   data_type* const array;// buffer for data array, it's size is maxsize + granularity - 1.
   data_type *data; // current begin of data array.
};


// Constructors:
template <class data_type>
HA<data_type>::HA ( size_type maxsz, size_type gr )
      : granularity(gr), maxsize (maxsz), cursize (0),
        array (new data_type[maxsize+granularity-1]),
        data (array+granularity-1)
{
}

template <class data_type>
HA<data_type>::HA ( const HA<data_type>& other )
      : granularity(other.granularity), maxsize (other.maxsize), cursize (other.cursize),
        array (new data_type[maxsize+granularity-1]),
        data (array+granularity-1)
{
   std::copy ( other.begin(), other.end(), data );
}

template <class data_type>
HA<data_type>::HA ( const HA<data_type>& other, size_type gr )
      : granularity(gr), maxsize (other.maxsize), cursize (other.cursize),
        array (new data_type[maxsize+granularity-1]),
        data (array+granularity-1)
{
   std::copy ( other.begin(), other.end(), data );
}

// Copy operator
template <class data_type>
HA<data_type>& HA<data_type>::operator = ( const HA<data_type>& other ) {
   const_cast<size_type&>(granularity) = other.granularity;
   const_cast<size_type&>(maxsize)  = other.maxsize;
   cursize  = other.cursize;
   delete[] array;
   const_cast<data_type*&>(array) = new data_type[maxsize+granularity-1];
   data  = array+granularity-1;
   std::copy ( other.begin(), other.end(), data );
   return (*this);
}

/* ---------------------------------------------------- *
 * data points to frame of the size cursize.            *
 * If we need to push new element we try to shift frame *
 * pointer and when it is impossible, we shift all ele- *
 * ments to make enough room for the next insertions.   *
 * ---------------------------------------------------- */
template <class data_type>
void HA<data_type>::add ( const_reference val ) {
   // pre: *data is latest pushed element
   // array <= data < array+granularity
   if ( data == array ) { // need to shift all elements
      data_type *i = array+maxsize-2;
      while ( i >= array ) {
        *(i+granularity) = *i;
        --i;
      }
      data = array+granularity;
   }
   // post: *data is latest pushed element
   // insert new element:
   *--data = val;
   if ( cursize < maxsize )
      ++cursize;
}

template <class data_type>
void HA<data_type>::swap ( HA<data_type>& other ) {
   std::swap ( const_cast<size_type&>(granularity), const_cast<size_type&>(other.granularity) );
   std::swap ( const_cast<size_type&>(maxsize), const_cast<size_type&>(other.maxsize) );
   std::swap ( cursize, other.cursize );
   std::swap ( const_cast<data_type*&>(array), const_cast<data_type*&>(other.array) );
   std::swap ( data, other.data );
}

template <class data_type>
void swap ( HA<data_type>& left_, HA<data_type>& right_ ) {
   left_.swap ( right_ );
}

template<class data_type>
bool operator == ( const HA<data_type>& left_, const HA<data_type>& right_ ) {
   return left_.max_size() == right_.max_size();
}

// I/O operations:
template <class data_type>
void HA<data_type>::save ( std::ostream& out ) const {
   out.write ( (const char*)&maxsize, sizeof(size_type) );
   out.write ( (const char*)data, sizeof(*data)*maxsize );
   out.write ( (const char*)&cursize, sizeof(size_type) );
}

template <class data_type>
void HA<data_type>::read ( std::istream& in ) {
   // if this function throws, HA object is in good state, but its data may be invalid
   if ( !in )
      throw HA_exception ("HA::read (): cannot read data from the input");

   size_type tmp_maxsize = 0;
   in.read ( (char*)&tmp_maxsize, sizeof(size_type) );

   if ( !in )
      throw HA_exception ("HA::read (): cannot read data from the input");
   if ( tmp_maxsize != maxsize )
      throw HA_exception ("HA::read (): illegal maxsize in the input");

   data = array+granularity-1; // set new frame position
   in.read ( (char*)data, sizeof(*data)*maxsize );

   if ( !in )
      throw HA_exception ("HA::read (): cannot read data from the input, data are now invalid!");

   size_type tmp_cursize = std::numeric_limits<size_type>::max();
   in.read ( (char*)&tmp_cursize, sizeof (size_type) );

   if ( tmp_cursize > maxsize )
      throw HA_exception ("HA::read (): illegal cursize in the input, data are now invalid!");
   cursize = tmp_cursize;
}

} // end namespace mdnaes

#endif
