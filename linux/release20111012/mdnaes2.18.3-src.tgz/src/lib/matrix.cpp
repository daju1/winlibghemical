#include <iostream>
#include <cerrno>
#include <cmath>

#include "matrix.h"

void MatAdd( double *dst, double *src1, double *src2, int n ) {
   for ( short i = 0; i < n*n; ++i )
      dst[i] = src1[i] + src2[i];
}

void MatSub( double *dst, double *src1, double *src2, int n ) {
   for ( short i = 0; i < n*n; ++i )
      dst[i] = src1[i] - src2[i];
}

void MatMul( double *dst, double *src1, double *src2, int n ) {
short i, j, k;
   for ( i = 0; i < n; ++i )
      for ( j = 0; j < n; ++j ) {
         dst[i*n+j] = 0.0;
         for ( k = 0; k < n; ++k )
            dst[i*n+j] += src1[i*n + k] * src2[k*n + j];
      }
}

void MatCpy( double *dst, double *src, int n ) {
   for ( short i = 0; i < n*n; ++i )
      dst[i] = src[i];
}


void MatTranspose( double *m, int n ) {
int i, j;
double t;
   for ( i = 0; i < n; ++i )
      for ( j = i+1; j < n; ++j ) {
         t = m[i*n+j];
         m[i*n+j] = m[j*n+i];
         m[j*n+i] = t; }
}

void MatMulDbl( double *m, double d, int n ) {
   for ( short i = 0; i < n*n; ++i )
      m[i] *= d;
}

void MatPrint( double *m, int n, std::ostream& o ) {
short i, j;
   for ( i = 0; i < n; ++i ) {
      for ( j = 0; j < n; ++j )
         o << m[i*n+j] << "  ";
      o << std::endl;
   }
}

int MatInv( double *A, int n ) {
   int *indxc, *indxr, *ipiv;
   int i, icol, irow, j, k, l, ll;
   double big, dum, pivinv, temp;

   int indxc_[5];
   int indxr_[5];
   int ipiv_[5];

   if ( n <= 5 ) {
      indxc = indxc_;
      indxr = indxr_;
      ipiv  = ipiv_;
   }
   else {
      indxc = new int[n];
      indxr = new int[n];
      ipiv  = new int[n];
   }

   for ( j = 0; j < n; ++j )
      ipiv[j] = 0;

   for ( i = 0; i < n; ++i ) {
      big = 0.0;
      for ( j = 0; j < n; ++j ) {
         if ( ipiv[j] != 1 ) {
            for ( k = 0; k < n; ++k ) {
               if ( ipiv[k] == 0 ) {
                  if ( fabs( A[j*n+k] ) >= big ) {
                     big = fabs( A[j*n+k] );
                     irow = j;
                     icol = k;
                  }
               }
               else {
                  if ( ipiv[k] > 1 ) {
                     errno = EDOM;
                     return 1;
                  }
               }
            }
         }
      }

      ++(ipiv[icol]);

      if ( irow != icol ) {
         for ( l = 0; l < n; ++l ) {
            temp = A[irow*n+l];
            A[irow*n+l] = A[icol*n+l];
            A[icol*n+l] = temp;
         }
      }
      indxr[i] = irow;
      indxc[i] = icol;
      if ( A[icol*n+icol] == 0.0 ) {
         errno = EDOM;
         return 2;
      }
      pivinv = 1.0 / A[icol*n+icol];
      A[icol*n+icol] = 1.0;
      for ( l = 0; l < n; ++l )
         A[icol*n+l] *= pivinv;

      for ( ll = 0; ll < n; ++ll ) {
         if ( ll != icol ) {
            dum = A[ll*n+icol];
            A[ll*n+icol] = 0.0;
            for ( l = 0; l < n; ++l )
               A[ll*n+l] -= A[icol*n+l] * dum;
         }
      }
   }

   for ( l = n-1; l >= 0; --l ) {
      if ( indxr[l] != indxc[l] )
         for ( k = 0; k < n; ++k ) {
            temp = A[k*n+indxr[l]];
            A[k*n+indxr[l]] = A[k*n+indxc[l]];
            A[k*n+indxc[l]] = temp;
         }
   }

   if ( n > 5 ) {
      delete[] ipiv;
      delete[] indxr;
      delete[] indxc;
   }

   return 0;
}

void MatSet( double *dst, double *src, int n, int op ) {
int i, j;
   if ( op & Mat_Zero )
      for ( i = 0; i < n; ++i ) {
         for ( j = 0; j < i; ++j ) {
            *dst = op & Mat_Under ? *src : 0.0;
            dst++; src++;
         }
         *dst = op & Mat_Diag ? *src : 0.0;
         dst++; src++;
         for ( ++ j ; j < n; ++j ) {
            *dst = op & Mat_Above ? *src : 0.0;
            dst++; src++;
         }
      }
   else
      for ( i = 0; i < n; ++i ) {
         if ( op & Mat_Under )
            for ( j = 0; j < i; ++j )
               dst[j] = src[j];
         if ( op & Mat_Diag )
            dst[i] = src[i];
         if ( op & Mat_Above )
            for ( j = i+1; j < n; ++j )
               dst[j] = src[j];
         dst += n;
         src += n;
      }
}
