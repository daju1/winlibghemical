#ifndef MDFORMAT_H
#define MDFORMAT_H

#include <iostream>

namespace mdnaes {

class mdformat {
public:
   explicit mdformat ( int w, int p = 0,
      std::ios::fmtflags f = std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec )
   : width (w), precision (p), flags (f) {}

   void set_fmt ( std::ostream& out ) const {
      out.flags ( flags );
      out.precision ( precision );
      out.width ( width );
   }
private:
   int width;
   int precision;
   std::ios::fmtflags flags;
};


inline std::ostream& operator << ( std::ostream& out, const mdformat& format ) {
   format.set_fmt ( out );
   return out;
}

} // end of namespace mdnaes

#endif
