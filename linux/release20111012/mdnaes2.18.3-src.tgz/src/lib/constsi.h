#ifndef CONSTSI_H
#define CONSTSI_H
/* ============= PHYSICAL CONSTANTS ============= */
/* Constants bibliography
   Source of the CODATA internationally recommended values

   The values of the constants provided at this site are recommended for
   international use by CODATA and are the latest available. Termed the
   "1998 CODATA recommended values," they are generally recognized
   worldwide for use in all fields of science and technology. The values
   became available in July 1999 and replaced the 1986 CODATA set.
   They are based on all of the data available through 31 December 1998.
   A detailed description of the data and the analysis that led to these
   values may be found in the Journal of Physical and Chemical Reference
   Data, Vol. 28, No. 6, pp. 1713-1852, 1999 and in the Reviews of Modern
   Physics, Vol. 72, No. 2, pp. 351-495, 2000. That paper (abstract below)
   was prepared under the auspices of the CODATA Task Group on Fundamental
   Constants. Also available is an Introduction to the constants for
   nonexperts.

   Publication of the 1998 CODATA recommended values


   CODATA Recommended Values of the Fundamental Physical Constants: 1998
   Peter J. Mohr and Barry N. Taylor
   National Institute of standards and Technology, Gaithersburg,
   MD 20899-8401


   This paper gives the 1998 self-consistent set of values of the basic
   constants and conversion factors of physics and chemistry recommended
   by the Committee on Data for Science and Technology (CODATA) for
   international use. Further, it describes in detail the adjustment of
   the values of the subset of constants on which the complete 1998 set of
   recommended values is based. The 1998 set replaces its immediate
   predecessor recommended by CODATA in 1986. The new adjustment, which
   takes into account all of the data available through 31 December 1998,
   is a significant advance over its 1986 counterpart. The standard
   uncertainties (i.e., estimated standard deviations) of the new
   recommended values are in most cases about 1/5 to 1/12 and in some cases
   1/160 times the standard uncertainties of the corresponding 1986 values.
   Moreover, in almost all cases the absolute values of the differences
   between the 1998 values and the corresponding 1986 values are less than
   twice the standard uncertainties of the 1986 values. The new set of
   recommended values is available on the World Wide Web at physics.nist.gov/constants.

   Searchable bibliography on the constants

   This bibliography gives citations for the most important theoretical
   and experimental publications relevant to the fundamental constants and
   closely related precision measurements published since the mid 1980s,
   but also including many older papers of particular interest, some of
   which date back to the 1800s.
*/
constexpr double  SI_C    = 299792458;        /* m/s          lite velocity         */
constexpr double  SI_EPS0 = 8.854187817e-12;  /* F/m                                */
constexpr double  SI_H    = 6.62606876e-34;   /* J*s          Plank constant        */
constexpr double  SI_E    = 1.602176462e-19;  /* coul         elementary charge     */
constexpr double  SI_Na   = 6.02214199e+23;   /* 1/mol        Avogadro number       */
constexpr double  SI_F    = 96485.3415;       /* coul/mol                           */
constexpr double  SI_R    = 8.314472;         /* J/(mol*K)                          */
constexpr double  SI_Kbol = 1.3806503e-23;    /* J/K                                */
constexpr double  SI_AMU  = 1.66053873e-27;   /* kg                                 */

/* ============= PI number ============= */
constexpr double SI_PI = 3.141592653589793;   /* this is not physical constant.     */

/* ========= COMPLEX CONSTANTS ========= */
constexpr double  SI_CPROD = SI_E*SI_E / (4*SI_PI*SI_EPS0); /* J*m, e^2/(4*pi*EPS0) */
constexpr double  SI_D     = 0.33333e-29;     /* coul * m     Debye                 */

#endif
