#ifndef VECTF_H
#define VECTF_H

#include <iosfwd>

namespace mdnaes {

class vectf {
public:
   float x, y, z;

   vectf () { }
   vectf ( float a ) : x(a), y(a), z(a) { }
   vectf ( float a, float b, float c ) : x(a), y(b), z(c) { }
   vectf ( const vectf& v  ) : x(v.x), y(v.y), z(v.z) { }

   vectf& operator = ( const vectf& v ) {
                      x = v.x; y = v.y; z = v.z;
                      return (*this); }

   vectf& operator += ( const vectf& v ) {
                       x += v.x; y += v.y; z += v.z; 
                       return (*this); }
   vectf& operator -= ( const vectf& v ) {
                       x -= v.x; y -= v.y; z -= v.z;
                       return (*this); }

   vectf& operator *= ( float d ) {
                       x *= d; y *= d; z *= d;
                       return (*this); }
   vectf& operator /= ( float d ) {
                       const float di = 1/d;
                       x *= di; y *= di; z *= di;
                       return (*this); }

   vectf& normate ( );
};


inline vectf operator - ( const vectf& v ) {
   return vectf ( -v.x, -v.y, -v.z );
}

inline vectf operator + ( const vectf& a, const vectf& b ) {
   return vectf ( a.x + b.x, a.y + b.y, a.z + b.z );
}

inline vectf operator - ( const vectf& a, const vectf& b ) {
   return vectf ( a.x - b.x, a.y - b.y, a.z - b.z );
}

inline vectf operator * ( const vectf& v, float d ) {
   return vectf ( v.x * d, v.y * d, v.z * d );
}

inline vectf operator * ( float d, const vectf& v ) {
   return vectf ( v.x * d, v.y * d, v.z * d );
}

inline vectf operator / ( const vectf& v, float d ) {
   const float di = 1/d;
   return vectf ( v.x * di, v.y * di, v.z * di );
}

float norm ( const vectf& );

vectf vecmul ( const vectf&, const vectf& );
vectf normated_vecmul ( const vectf&, const vectf& );

inline float operator * ( const vectf& a, const vectf& b ) {
   return ( a.x*b.x + a.y*b.y + a.z*b.z );
}

std::ostream& operator << ( std::ostream& out, const vectf& v );
std::istream& operator >> ( std::istream& in, vectf& v );

vectf operator * ( const float A[3][3], const vectf& v );
vectf operator * ( const vectf& v, const float A[3][3] );

void direct_product_accumulate ( const vectf& a, const vectf& b, float Res[3][3] );

inline float sqr ( const vectf& x ) {
   return x*x;
}

} // end namespace mdnaes

#endif
