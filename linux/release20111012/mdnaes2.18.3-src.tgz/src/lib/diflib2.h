#ifndef DIFLIB2_H
#define DIFLIB2_H

#include <cstddef>
#include <valarray>

namespace diflib2 {
   template <typename T, size_t n> class differential;

   namespace Private_ {
      template <typename T>
      class differential_traits {
      public:
         typedef T base_type;
      };
      template <typename T, size_t n>
      class differential_traits<differential<T,n> > {
      public:
         typedef typename differential_traits<T>::base_type base_type;
      };
   } // end of namespace Private_

template <typename T, size_t n>
class differential {
public:
   typedef typename Private_::differential_traits<T>::base_type base_type;
public:
   differential () : val(0), deriv(static_cast<T>(0),n) {}
   differential ( const T& x ) : val(x), deriv(static_cast<T>(0),n) {}
   differential ( const T& v, const std::valarray<T>& d ) : val(v), deriv(d) {}
   differential ( const differential<T,n>& x ) : val(x.value()), deriv(x.derivative()) {}
   ~differential () {}

   const T& value() const { return val; }
   const std::valarray<T>& derivative() const { return deriv; }

   differential<T,n>& operator = ( const differential<T,n>& x ) {
      val = x.val; deriv = x.deriv; return (*this);
   }
   
   differential<T,n>  operator - () const { return differential<T,n>(-val, -deriv); }
   differential<T,n>& operator += ( const differential<T,n>& x );
   differential<T,n>& operator += ( const base_type& x );
   differential<T,n>& operator -= ( const differential<T,n>& x );
   differential<T,n>& operator -= ( const base_type& x );
   differential<T,n>& operator *= ( const differential<T,n>& x );
   differential<T,n>& operator *= ( const base_type& x );
   differential<T,n>& operator /= ( const differential<T,n>& x );
   differential<T,n>& operator /= ( const base_type& x );

private:
   T val;
   std::valarray<T> deriv;
};

// ============================================================================
template <typename T, size_t n> inline
differential<T,n> make_dx ( const T& x, size_t var_index ) {
   std::valarray<T> tmp (static_cast<T>(0),n);
   tmp[var_index] = static_cast<T>(1);
   return differential<T,n>(x, tmp);
}

template <typename T, size_t n> inline
differential<differential<T,n>,n> make_d2x ( const T& x, size_t var_index ) {
   std::valarray<differential<T,n> > tmp (static_cast<differential<T,n> >(0),n);
   tmp[var_index] = static_cast<T>(1);
   return differential<differential<T,n>,n>( make_dx<T,n>( x, var_index ), tmp );
}

template <typename T, size_t n> inline
const T& value ( const differential<T,n>& x ) {
   return x.value();
}

template <typename T, size_t n> inline
const T& value ( const differential<differential<T,n>,n>& x ) {
   return x.value().value();
}

template <typename T, size_t n> inline
const T derivative ( const differential<T,n>& x, size_t i ) {
   return x.derivative()[i];
}

template <typename T, size_t n> inline
const T derivative ( const differential<differential<T,n>,n>& x, size_t i ) {
   return x.value().derivative()[i];
}

template <typename T, size_t n> inline
const T derivative2 ( const differential<differential<T,n>,n>& x, size_t i, size_t j ) {
   return x.derivative()[i].derivative()[j];
}


// ============================================================================
template <typename T, size_t n> inline
differential<T,n>& differential<T,n>::operator += ( const differential<T,n>& x ) {
   val += x.value();
   deriv += x.derivative();
   return (*this);
}

template <typename T, size_t n> inline
differential<T,n>& differential<T,n>::operator += ( const typename differential<T,n>::base_type& x ) {
   val += x;
   return (*this);
}

template <typename T, size_t n> inline
differential<T,n>& differential<T,n>::operator -= ( const differential<T,n>& x ) {
   val -= x.value();
   deriv -= x.derivative();
   return (*this);
}

template <typename T, size_t n> inline
differential<T,n>& differential<T,n>::operator -= ( const typename differential<T,n>::base_type& x ) {
   val -= x;
   return (*this);
}

template <typename T, size_t n> inline
differential<T,n>& differential<T,n>::operator *= ( const differential<T,n>& x ) {
   val *= x.value();
   deriv = deriv*x.value() + val*x.derivative();
   return (*this);
}

template <typename T, size_t n> inline
differential<T,n>& differential<T,n>::operator *= ( const typename differential<T,n>::base_type& x ) {
   val *= x;
   deriv *= x;
   return (*this);
}

template <typename T, size_t n> inline
differential<T,n>& differential<T,n>::operator /= ( const differential<T,n>& x ) {
   val /= x.value();
   deriv = (deriv*x.value() - val*x.derivative()) / (x.value()*x.value());
   return (*this);
}

template <typename T, size_t n> inline
differential<T,n>& differential<T,n>::operator /= ( const typename differential<T,n>::base_type& x ) {
   val /= x;
   deriv /= x;
   return (*this);
}

// ============================================================================
template <typename T, size_t n> inline
differential<T,n> operator + (const differential<T,n>& x, const differential<T,n>& y) {
   return differential<T,n>( x.value()+y.value(), x.derivative()+y.derivative() );
}
template <typename T, size_t n> inline
differential<T,n> operator + (const differential<T,n>& x, const typename differential<T,n>::base_type& y) {
   return differential<T,n>( x.value()+y, x.derivative() );
}
template <typename T, size_t n> inline
differential<T,n> operator + (const typename differential<T,n>::base_type& x, const differential<T,n>& y) {
   return differential<T,n>( x+y.value(), y.derivative() );
}

template <typename T, size_t n> inline
differential<T,n> operator - (const differential<T,n>& x, const differential<T,n>& y) {
   return differential<T,n>( x.value()-y.value(), x.derivative()-y.derivative() );
}
template <typename T, size_t n> inline
differential<T,n> operator - (const differential<T,n>& x, const typename differential<T,n>::base_type& y) {
   return differential<T,n>( x.value()-y, x.derivative() );
}
template <typename T, size_t n> inline
differential<T,n> operator - (const typename differential<T,n>::base_type& x, const differential<T,n>& y) {
   return differential<T,n>( x-y.value(), -y.derivative() );
}

template <typename T, size_t n> inline
differential<T,n> operator * (const differential<T,n>& x, const differential<T,n>& y) {
   return differential<T,n>( x.value()*y.value(), x.derivative()*y.value()+x.value()*y.derivative() );
}
template <typename T, size_t n> inline
differential<T,n> operator * (const differential<T,n>& x, const typename differential<T,n>::base_type& y) {
   return differential<T,n>( x.value()*y, x.derivative()*static_cast<T>(y) );
}
template <typename T, size_t n> inline
differential<T,n> operator * (const typename differential<T,n>::base_type& x, const differential<T,n>& y) {
   return differential<T,n>( x*y.value(), static_cast<T>(x)*y.derivative() );
}

template <typename T, size_t n> inline
differential<T,n> operator / (const differential<T,n>& x, const differential<T,n>& y) {
   return differential<T,n>( x.value()/y.value(),
                          (x.derivative()*y.value() - x.value()*y.derivative()) / (y.value()*y.value()) );
}
template <typename T, size_t n> inline
differential<T,n> operator / (const differential<T,n>& x, const typename differential<T,n>::base_type& y) {
   return differential<T,n>( x.value()/y, x.derivative()/static_cast<T>(y) );
}
template <typename T, size_t n> inline
differential<T,n> operator / (const typename differential<T,n>::base_type& x, const differential<T,n>& y) {
   return differential<T,n>( x/y.value(),
                             -static_cast<T>(x)*y.derivative()/(y.value()*y.value()) );
}

// ============================================================================
template <typename T, size_t n> inline
bool operator < ( const differential<T,n>& x, const differential<T,n>& y ) {
   return x.value() < y.value();
}
template <typename T, size_t n> inline
bool operator < ( const typename differential<T,n>::base_type& x, const differential<T,n>& y ) {
   return x < y.value();
}
template <typename T, size_t n> inline
bool operator < ( const differential<T,n>& x, const typename differential<T,n>::base_type& y ) {
   return x.value() < y;
}

template <typename T, size_t n> inline
bool operator <= ( const differential<T,n>& x, const differential<T,n>& y ) {
   return x.value() <= y.value();
}
template <typename T, size_t n> inline
bool operator <= ( const typename differential<T,n>::base_type& x, const differential<T,n>& y ) {
   return x <= y.value();
}
template <typename T, size_t n> inline
bool operator <= ( const differential<T,n>& x, const typename differential<T,n>::base_type& y ) {
   return x.value() <= y;
}

template <typename T, size_t n> inline
bool operator > ( const differential<T,n>& x, const differential<T,n>& y ) {
   return x.value() > y.value();
}
template <typename T, size_t n> inline
bool operator > ( const typename differential<T,n>::base_type& x, const differential<T,n>& y ) {
   return x > y.value();
}
template <typename T, size_t n> inline
bool operator > ( const differential<T,n>& x, const typename differential<T,n>::base_type& y ) {
   return x.value() > y;
}

template <typename T, size_t n> inline
bool operator >= ( const differential<T,n>& x, const differential<T,n>& y ) {
   return x.value() >= y.value();
}
template <typename T, size_t n> inline
bool operator >= ( const typename differential<T,n>::base_type& x, const differential<T,n>& y ) {
   return x >= y.value();
}
template <typename T, size_t n> inline
bool operator >= ( const differential<T,n>& x, const typename differential<T,n>::base_type& y ) {
   return x.value() >= y;
}


} // end of namespace diflib2


// ============================================================================
// function overloads with names, present in standart C++98/03 <cmath> header
template <typename T, size_t n> inline
diflib2::differential<T,n> acos ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( acos(x.value()), -x.derivative()/sqrt(1-x.value()*x.value()) );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> asin ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( asin(x.value()), x.derivative()/sqrt(1-x.value()*x.value()) );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> atan ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( atan(x.value()), x.derivative()/(1+x.value()*x.value()) );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> atan2 ( const diflib2::differential<T,n>& y,
                                   const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( atan2( y.value(), x.value() ),
                           (x.value()*y.derivative() - y.value()*x.derivative()) /
                           (x.value()*x.value() + y.value()*y.value()) );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> atan2 ( const diflib2::differential<T,n>& y,
                                   const typename diflib2::differential<T,n>::base_type& x ) {
   return diflib2::differential<T,n>( atan2( y.value(), x ),
                       static_cast<T>(x)*y.derivative()/(x*x + y.value()*y.value()) );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> atan2 ( const typename diflib2::differential<T,n>::base_type& y,
                                   const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( atan2( y, x.value() ),
                      -static_cast<T>(y)*x.derivative()/(x.value()*x.value() + y*y) );
}

/* ceil */
template <typename T, size_t n> inline
diflib2::differential<T,n> cos ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( cos(x.value()), -sin(x.value())*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> cosh ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( cosh(x.value()), sinh(x.value())*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> exp ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( exp(x.value()), exp(x.value())*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> fabs ( const diflib2::differential<T,n>& x ) {
   if ( x.value() >= 0 )
      return diflib2::differential<T,n>( x.value(), x.derivative() );
   else
      return diflib2::differential<T,n>( -x.value(), -x.derivative() );
}

/* floor */
/* fmod  */
/* frexp */
/* ldexp */
template <typename T, size_t n> inline
diflib2::differential<T,n> log ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( log(x.value()), x.derivative()/x.value() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> log10 ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( log10(x.value()), x.derivative()/(log(10.0)*x.value()) );
}
/* modf */

template <typename T, size_t n> inline
diflib2::differential<T,n> pow ( const diflib2::differential<T,n>& x,
                                 const diflib2::differential<T,n>& y ) {
   return diflib2::differential<T,n>( pow( x.value(), y.value() ),
                           ((y==0) ? 0
                                   : pow(x.value(), y.value()-1)*x.derivative()) +
                           pow( x.value(), y.value() )*log(x.value())*y.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> pow ( const diflib2::differential<T,n>& x,
                                 const typename diflib2::differential<T,n>::base_type& y ) {
   return diflib2::differential<T,n>( pow( x.value(), y ),
                           (y==0) ? 0
                                  : pow(x.value(), y-1)*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> pow ( const typename diflib2::differential<T,n>::base_type& x,
                                 const diflib2::differential<T,n>& y ) {
   return diflib2::differential<T,n>( pow( x, y.value() ),
                           pow( x, y.value() )*log(x)*y.derivative() );
}

template <typename T, size_t n> inline
diflib2::differential<T,n> sin ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( sin(x.value()), cos(x.value())*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> sinh ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( sinh(x.value()), cosh(x.value())*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> sqrt ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( sqrt(x.value()), x.derivative()/(2*sqrt(x.value())) );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> tan ( const diflib2::differential<T,n>& x );
template <typename T, size_t n> inline
diflib2::differential<T,n> tanh ( const diflib2::differential<T,n>& x );


// ============================================================================
// other function overloads with names, present in standart C99 <math.h> header
template <typename T, size_t n> inline
diflib2::differential<T,n> exp2 ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( exp2(x.value()), log(2.0)*exp2(x.value())*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> expm1 ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( expm1(x.value()), exp(x.value())*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> log1p ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( log1p(x.value()), x.derivative()/(1+x.value()) );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> log2 ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( log2(x.value()), x.derivative()/(log(2.0)*x.value()) );
}
/* double scalbn(double x, size_t n); */
/* double scalbln(double x, long size_t n); */
template <typename T, size_t n> inline
diflib2::differential<T,n> cbrt ( const diflib2::differential<T,n>& x ) {
   const T croot (cbrt(x.value()));
   return diflib2::differential<T,n>( croot, x.derivative()/(3*croot*croot) );
}

template <typename T, size_t n> inline
diflib2::differential<T,n> hypot ( const diflib2::differential<T,n>& x,
                                   const diflib2::differential<T,n>& y ) {
   return diflib2::differential<T,n>( hypot( y.value(), x.value() ),
      (x.value()*x.derivative() + y.value()*y.derivative())/hypot(y.value(),x.value())  );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> hypot ( const diflib2::differential<T,n>& x,
                                   const typename diflib2::differential<T,n>::base_type& y ) {
   return diflib2::differential<T,n>( hypot(x.value(),y), x.value()/hypot(x.value(),y)*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> hypot ( const typename diflib2::differential<T,n>::base_type& x,
                                   const diflib2::differential<T,n>& y ) {
   return diflib2::differential<T,n>( hypot(x,y.value()), y.value()/hypot(x,y.value())*y.derivative() );
}

template <typename T, size_t n> inline
diflib2::differential<T,n> erf ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( erf(x.value()),
      1.1283791670955126*exp(-x.value()*x.value())*x.derivative() );
}
template <typename T, size_t n> inline
diflib2::differential<T,n> erfc ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( erfc(x.value()),
      -1.1283791670955126*exp(-x.value()*x.value())*x.derivative() );
}
/* double lgamma(double x); */
/* double tgamma(double x); */

// ============================================================================
// other functions
namespace diflib2 {
template <typename T, size_t n> inline
diflib2::differential<T,n> sqr ( const diflib2::differential<T,n>& x ) {
   return diflib2::differential<T,n>( x.value()*x.value(), static_cast<T>(2)*x.derivative() );
}

} // end of namespace diflib2

#endif
