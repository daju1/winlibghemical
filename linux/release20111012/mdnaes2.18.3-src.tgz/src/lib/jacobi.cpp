#include <cmath>

inline void ROTATE( int n, double *a, int i, int j, int k, int l, double s, double tau) {
   double g=a[i*n + j];
   double h=a[k*n + l];
   a[i*n + j]=g-s*(h+g*tau);
   a[k*n + l]=h+s*(g-h*tau);
}

int jacobi( int n, double *a, double *d, double *v)
{
/* n - dimension of matrixes,
   a - pointer to [n][n] symmetric matrix (data of this matrix will been destroyed!),
   d - pointer to [n] array for eigenvalues storage,
   v - pointer to [n][n] matrix for eigenvectors storage (e.g. vector v[n]).
*/
	int j,iq,ip,i;
	double tresh,theta,tau,t,sm,s,h,g,c,*b,*z;
   int nrot = 0;

	b=new double[n];
	z=new double[n];
	for (ip=0; ip<n; ++ip) {
		for (iq=0; iq<n; ++iq)
         v[ip*n + iq]=0.0;
		v[ip*n + ip]=1.0;
	}
	for (ip=0; ip<n; ++ip) {
		b[ip]=d[ip]=a[ip*n + ip];
		z[ip]=0.0;
	}
	nrot=0;
	for (i=1;i<=50;i++) {
		sm=0.0;
		for (ip=0; ip<n-1; ++ip) {
			for (iq=ip+1; iq<n; ++iq)
				sm += fabs(a[ip*n + iq]);
		}
		if (sm == 0.0) {
			delete [] z;
			delete [] b;
			return nrot;
		}
		if (i < 4)
			tresh=0.2*sm/(n*n);
		else
			tresh=0.0;
		for (ip=0; ip<n-1; ++ip) {
			for (iq=ip+1; iq<n; ++iq) {
				g=100.0*fabs(a[ip*n + iq]);
				if (i > 4 && double(fabs(d[ip])+g) == double(fabs(d[ip]))
					&& double(fabs(d[iq])+g) == double(fabs(d[iq])))
					a[ip*n + iq]=0.0;
				else if (fabs(a[ip*n + iq]) > tresh) {
					h=d[iq]-d[ip];
					if (double(fabs(h)+g) == double(fabs(h)))
						t=(a[ip*n + iq])/h;
					else {
						theta=0.5*h/(a[ip*n + iq]);
						t=1.0/(fabs(theta)+sqrt(1.0+theta*theta));
						if (theta < 0.0) t = -t;
					}
					c=1.0/sqrt(1+t*t);
					s=t*c;
					tau=s/(1.0+c);
					h=t*a[ip*n + iq];
					z[ip] -= h;
					z[iq] += h;
					d[ip] -= h;
					d[iq] += h;
					a[ip*n + iq]=0.0;
					for (j=0; j<=ip-1; j++) {
						ROTATE(n, a,j,ip,j,iq, s,tau);
					}
					for (j=ip+1; j<=iq-1; j++) {
						ROTATE(n, a,ip,j,j,iq, s,tau);
					}
					for (j=iq+1; j<n; j++) {
						ROTATE(n, a,ip,j,iq,j, s,tau);
					}
					for (j=0; j<n; j++) {
						ROTATE(n, v,j,ip,j,iq, s,tau);
					}
					++nrot;
				}
			}
		}
		for (ip=0; ip<n; ip++) {
			b[ip] += z[ip];
			d[ip]=b[ip];
			z[ip]=0.0;
		}
	}
   delete [] z;
	delete [] b;
   return nrot;
}
