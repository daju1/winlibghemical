#ifndef MATRIX_3x3
#define MATRIX_3x3

#include <iosfwd>

class matrix_3x3 {
private:
   double m_data[3][3];
   
public:
   using row_t = double[3];
   
   row_t& operator [] (int i) { return m_data[i]; }
   
   matrix_3x3& operator += ( const matrix_3x3& other );
   
   void set_to_zero ();
   
   void print ( std::ostream& out ) const;
   
   using array_t = double (*) [3];
   array_t data() { return m_data; }
};

inline
matrix_3x3 operator + ( const matrix_3x3& A, const matrix_3x3& B ) {
   auto tmp = A;
   tmp += B;
   return tmp;
}

#endif
