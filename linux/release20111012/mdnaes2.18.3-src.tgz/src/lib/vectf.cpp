#include <cmath>
#include <iostream>

#include "vectf.h"

namespace mdnaes {

vectf& vectf::normate ( ) {
   float f = 1.0 / norm ( *this );
   x *= f;
   y *= f;
   z *= f;
   return (*this);
}

float norm ( const vectf& v ) {
   return std::sqrt ( v.x*v.x + v.y*v.y + v.z*v.z );
}

vectf vecmul ( const vectf& a, const vectf& b ) {
   return vectf ( a.y*b.z - a.z*b.y,
                 a.z*b.x - a.x*b.z,
                 a.x*b.y - a.y*b.x );
}

vectf normated_vecmul ( const vectf& a, const vectf& b ) {
   // return unit vector in direction of the vector product [a,b]
   vectf res ( a.y*b.z - a.z*b.y,
              a.z*b.x - a.x*b.z,
              a.x*b.y - a.y*b.x );
   res.normate ();
   return res;
}

vectf operator * ( const float A[3][3], const vectf& v ) {
   return vectf ( A[0][0]*v.x + A[0][1]*v.y + A[0][2]*v.z,
                 A[1][0]*v.x + A[1][1]*v.y + A[1][2]*v.z,
                 A[2][0]*v.x + A[2][1]*v.y + A[2][2]*v.z );
}

vectf operator * ( const vectf& v, const float A[3][3] ) {
   return vectf ( A[0][0]*v.x + A[1][0]*v.y + A[2][0]*v.z,
                 A[0][1]*v.x + A[1][1]*v.y + A[2][1]*v.z,
                 A[0][2]*v.x + A[1][2]*v.y + A[2][2]*v.z );
}

void direct_product_accumulate ( const vectf& a, const vectf& b, float Res[3][3] ) {
   Res[0][0] += a.x * b.x;
   Res[0][1] += a.x * b.y;
   Res[0][2] += a.x * b.z;
   Res[1][0] += a.y * b.x;
   Res[1][1] += a.y * b.y;
   Res[1][2] += a.y * b.z;
   Res[2][0] += a.z * b.x;
   Res[2][1] += a.z * b.y;
   Res[2][2] += a.z * b.z;
}

std::ostream& operator << ( std::ostream& out, const vectf& v ) {
   const std::streamsize w = out.width();
   out << v.x;
   if ( w == 0 )
      out.put (' ');
   else 
      out.width ( w );
   out << v.y;
   if ( w == 0 )
      out.put (' ');
   else 
      out.width ( w );
   out << v.z;
   return out;
}

std::istream& operator >> ( std::istream& in, vectf& v ) {
   in >> v.x >> v.y >> v.z;
   return in;
}

} // end namespace mdnaes
