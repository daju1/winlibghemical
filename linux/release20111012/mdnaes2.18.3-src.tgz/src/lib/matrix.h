#ifndef MATRIX_H
#define MATRIX_H

#include <iosfwd>

enum { Mat_Zero = 0x1, Mat_Diag = 0x2, Mat_Above = 0x4, Mat_Under = 0x8 };

// double* means matrix, for example : A[n][n] transforms to (double*)
void MatAdd( double *dst, double *src1, double *src2, int n );
void MatSub( double *dst, double *src1, double *src2, int n );
void MatMul( double *dst, double *src1, double *src2, int n );
void MatCpy( double *dst, double *src, int n );
int  MatInv( double *m, int n);
void MatTranspose( double *m, int n );
void MatMulDbl( double *m, double d, int n );
void MatPrint( double *m, int n, std::ostream& o );
void MatSet( double *dst, double *src, int n, int op = 0xf );

#endif
