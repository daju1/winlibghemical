#include "matrix_3x3.h"

#include <iostream>

#include "mdformat.h"

matrix_3x3& matrix_3x3::operator += ( const matrix_3x3& other ) {
   for ( int i = 0; i < 3; ++i ) {
      for ( int j = 0; j < 3; ++j ) {
         m_data[i][j] += other.m_data[i][j];
      }
   }
   return *this;
}


void matrix_3x3::print ( std::ostream& out ) const {
   out << '[';
   for ( int i = 0; i < 3; ++i ) {
      out << '[';
      for ( int j = 0; j < 3; ++j ) {
         out  << mdnaes::mdformat(4,1) << m_data[i][j];
      }
      out << ']';
   }
   out << ']';
}

void matrix_3x3::set_to_zero () {
   for ( int i = 0; i < 3; ++i ) {
      for ( int j = 0; j < 3; ++j ) {
         m_data[i][j] = 0.0;
      }
   }
}
