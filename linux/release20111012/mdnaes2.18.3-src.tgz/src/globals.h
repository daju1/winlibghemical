#ifndef GLOBALS_H
#define GLOBALS_H

#include <cmath>
#include <fstream>
#include <cstdint>
#include <cstddef>
#include <vector>
#include <random>

#include "lib/vect.h"
#include "lib/vectf.h"
#include "lib/matrix_3x3.h"
#include "real.h"
using namespace mdnaes;


#include <iostream>
extern std::ofstream Message;

extern std::mt19937_64 global_random_engine;

// Some global switches:
extern int NORUN;
extern int NORUN_MODE;
extern bool NOSCRPRINT;
extern bool K_PrintVbox;
extern bool K_PrintGRO;
extern bool K_StartRUN;
extern bool K_ImportGRO;

extern int32_t ORIGINAL_SEED;
extern int32_t CURRENT_SEED;

extern int NSTTOT;
extern int SubSteps;

// ============================================================================
struct cutt_off_t {
   real Coul;
   real LJ;
   real LJ_init;
   
   real Fs;
   real Fs_switch;
   
   real Nb_list;
};

extern cutt_off_t RCut;

// ============================================================================
void setBoxSizeVariables(); // Using current LBOX value calculate correct LBOX2,
                            // VOLBOX, RCUT_Coul, RCUT_LJ and DENS values.
extern double LBOX, LBOX2;  // Box side length and a half of it
extern double LBOXinit;     // Box side length calculated from fint.dat file data

extern double VOLBOX;        // Volume of cubic box
extern double DENS;          // Density of system
extern double DENSinit;      // initial density of system
extern double DELTR;         // r step for RDF
extern double TIME;          // Total time of simulation, including previous runs (in picoseconds)
extern double DELT;          // Time step
extern double TMPR0;         // Temperature of thermostat
extern double TMPR;          // Temperature of system
extern double PRES;          // pressure
extern double taw;           // Berendsen's thermostat parameter
extern double External_Field;// External (?) electric field.
extern double Eps; // solvent DP

extern double extPRES;
extern double tawP;          // Berendsen's barostat parameter

// ============================================================================
extern int NTHREADS;

#include <thread>
template <class Fun = void(*)(int)>
inline void exec_parallel ( Fun f, int nthreads ) {
   std::vector<std::thread> threads;
   for ( int thread_no = 1; thread_no < nthreads; ++thread_no ) {
      threads.emplace_back ( f,  thread_no );
   }
   f(0);
   for ( auto& th : threads ) {
      th.join();
   }
}

// ============================================================================
constexpr std::size_t MAX_PARTICLE_TYPES = 8;

struct System_therm_values_t {
public:
   // general. Calculated separately from forces.
   double UT;
   double Enthalpy;
   
   double EkinM, EkinC, EkinA;
   double Ekin;
   
   double Uinter, Uintra;
   double Upot;
   double VIRtot;
   
   double dcUpot;
   double dcVIRtot;
   
   double dcUmm, dcUmc, dcUma, dcUcc, dcUca, dcUaa;
   double dcVIRmm, dcVIRmc, dcVIRma, dcVIRcc, dcVIRca, dcVIRaa;
   
   double dcU[MAX_PARTICLE_TYPES][MAX_PARTICLE_TYPES];
   double dcVIR[MAX_PARTICLE_TYPES][MAX_PARTICLE_TYPES];
   
   matrix_3x3 stressKin;
   matrix_3x3 stress;
   
   // bonded forces
   double Ubond, Uangle, Udihedral, Udihedral_2, Uharmonic_dihedral;
   
   matrix_3x3 stressInt;
   
   // near forces. Can be thread local.
   double sUpot;
   double sVIRtot;
   double sUmm, sUmc, sUma, sUcc, sUca, sUaa;
   double sVIRmm, sVIRmc, sVIRma, sVIRcc, sVIRca, sVIRaa;
   
   double sU[MAX_PARTICLE_TYPES][MAX_PARTICLE_TYPES];    // intermolecular part only
   double sVIR[MAX_PARTICLE_TYPES][MAX_PARTICLE_TYPES];  // intermolecular part only
   
   double Unb_intra;    // electrostatic and LJ
   double VIRnb_intra;  // electrostatic and LJ
   
   matrix_3x3 stressPotS;
   
   // far forces. Can be thread local.
   double cUpot;
   double cVIRtot;
   double cUmm, cUmc, cUma, cUcc, cUca, cUaa;
   double cVIRmm, cVIRmc, cVIRma, cVIRcc, cVIRca, cVIRaa;
   
   double cU[MAX_PARTICLE_TYPES][MAX_PARTICLE_TYPES];    // intermolecular part only
   double cVIR[MAX_PARTICLE_TYPES][MAX_PARTICLE_TYPES];  // intermolecular part only
   
   matrix_3x3 stressPotC;
   
public:
   void zero_bonded_components ();
   void zero_short_components ();
   void zero_far_components ();
   void zero_general_components ();
   
   void zero_all ();
   
   void zero_ab_components ();
   
   System_therm_values_t& operator += ( const System_therm_values_t& other );
};

extern System_therm_values_t Therm_values;
extern std::vector<System_therm_values_t> TL_Therm_values; // thread local

// ============================================================================
extern int Kstress; // key for stress calculation

// ============================================================================
extern int  NSTRUN;        // Number of steps for this run

extern int StepRDF;            // Interval for RDF calculations
extern int SPRNT;              // Interval for energy printing
extern int SWRIT;              // Interval for saving configuration to co_out file

extern int KRS;
extern int KCF;
extern int KSTR;
extern int KLH;
extern int KLK;
extern int KStat;
extern int KScrOut;
extern int KCoorOut;
extern int KSV;
extern int KCoul;

extern int NMOL1, NMOL2, NION_C, NION_A;

extern int KDBL;   // System: Number of atoms *= KDBL*KDBL*KDBL
                   // KDBL is integer >= 2 or 0.
extern int NumInsIon[2]; // [0] - NumInsIon for cation; [1] - for anion

extern double RSHL[9];

// ============================================================================
inline void PBC ( vect& r ) {
   if ( r.x > LBOX2 ) r.x -= LBOX;
   else if ( r.x < -LBOX2 ) r.x += LBOX;

   if ( r.y > LBOX2 ) r.y -= LBOX;
   else if ( r.y < -LBOX2 ) r.y += LBOX;

   if ( r.z > LBOX2 ) r.z -= LBOX;
   else if ( r.z < -LBOX2 ) r.z += LBOX;
}

inline void PBC ( vectf& r ) {
   if ( r.x > LBOX2 ) r.x -= LBOX;
   else if ( r.x < -LBOX2 ) r.x += LBOX;

   if ( r.y > LBOX2 ) r.y -= LBOX;
   else if ( r.y < -LBOX2 ) r.y += LBOX;

   if ( r.z > LBOX2 ) r.z -= LBOX;
   else if ( r.z < -LBOX2 ) r.z += LBOX;
}

// ========================================================================
extern const char* UnOpen; // "Unable to open ";


class SaveManager {
public:
   using SaveFun = void (*) ();
   // Register (add) "saving" function
   void AddFun ( SaveFun f ); // defined in Mestream.cpp
   
   // Call of all "saving" functions
   void Actions ( bool touch_co_out = true ) const; // defined in Mestream.cpp
private:
   std::vector<SaveFun> Functions {};
};

extern SaveManager SMan;
extern SaveManager ShowRes;

extern double *Wiy98_AdvancedCationCoordinationCenter_coefs;
extern double *Wiy98_AdvancedAnionCoordinationCenter_coefs;

inline double sqr ( double x ) {
   return x*x;
}

inline float sqr ( float x ) {
   return x*x;
}

void printSimulatedSystemMessage ( std::ostream& out );

#endif
