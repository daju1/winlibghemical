#include "distr_func.h"
#include "md_exception.h"
#include <iostream>

using namespace mdnaes;

// ======================= 2D distribution helper class =======================
// =========================== members definitions ============================
distrib_2D::distrib_2D ( int Xdim, int Ydim )
: X_dimension(Xdim), Y_dimension(Ydim), histogram(new unsigned long[Xdim*Ydim]), total_count(0) {
   for ( int i = 0; i < X_dimension*Y_dimension; ++i )
      histogram[i] = 0;
}

void distrib_2D::save ( std::ostream& out ) const {
   out.write ( (char*)&X_dimension, sizeof (X_dimension) );
   out.write ( (char*)&Y_dimension, sizeof (Y_dimension) );
   out.write ( (char*)histogram, X_dimension*Y_dimension*sizeof(*histogram) );
   out.write ( (char*)&total_count, sizeof (total_count) );
}

void distrib_2D::read ( std::istream& in ) {
   int Xdim = -1;
   int Ydim = -1;
   in.read ( (char*)&Xdim, sizeof (int) );
   in.read ( (char*)&Ydim, sizeof (int) );
   if ( Xdim != X_dimension || Ydim != Y_dimension )
      throw md_io_error ( "histogram_2D::read : cannot read data from input!" );
   
   in.read ( (char*)histogram, X_dimension*Y_dimension*sizeof(*histogram) );
   in.read ( (char*)&total_count, sizeof (total_count) );
}

void distrib_2D::add ( int x, int y ) {
   if ( x >= 0 && x < X_dimension && y >= 0 && y < Y_dimension)
      histogram[x*Y_dimension+y]++;
   ++total_count;
}

double distrib_2D::get_value ( int x, int y ) const {
   if ( 0 == total_count ) return 0.0;
   if ( x >= 0 && x < X_dimension && y >= 0 && y < Y_dimension )
      return static_cast<double>(histogram[x*Y_dimension+y])/static_cast<double>(total_count);
   return 0.0;
}

double distrib_2D::get_aveX () const {
   double s = 0.0;
   for ( int x = 0; x < X_dimension; ++x )
      for ( int y = 0; y < Y_dimension; ++y )
         s += static_cast<double>(x) * static_cast<double>(histogram[x*Y_dimension+y]);
   return s / static_cast<double>(total_count);
}

double distrib_2D::get_aveY () const {
   double s = 0.0;
   for ( int x = 0; x < X_dimension; ++x )
      for ( int y = 0; y < Y_dimension; ++y )
         s += static_cast<double>(y) * static_cast<double>(histogram[x*Y_dimension+y]);
   return s / static_cast<double>(total_count);
}
// ============================================================================

// ======================= 1D distribution helper class =======================
// =========================== members definitions ============================
distrib_1D::distrib_1D ( int Xdim )
: X_dimension(Xdim), histogram(new unsigned long[Xdim]), total_count(0) {
   for ( int i = 0; i < X_dimension; ++i )
      histogram[i] = 0;
}

void distrib_1D::save ( std::ostream& out ) const {
   out.write ( (char*)&X_dimension, sizeof (X_dimension) );
   out.write ( (char*)histogram, X_dimension*sizeof(*histogram) );
   out.write ( (char*)&total_count, sizeof (total_count) );
}

void distrib_1D::read ( std::istream& in ) {
   int Xdim = -1;
   in.read ( (char*)&Xdim, sizeof (int) );
   if ( Xdim != X_dimension )
      throw md_io_error ( "histogram_1D::read : cannot read data from input!" );
   
   in.read ( (char*)histogram, X_dimension*sizeof(*histogram) );
   in.read ( (char*)&total_count, sizeof (total_count) );
}

void distrib_1D::add ( int x ) {
   if ( x >= 0 && x < X_dimension )
      histogram[x]++;
   ++total_count;
}

double distrib_1D::get_value ( int x ) const {
   if ( 0 == total_count )
      return 0.0;
   if ( x >= 0 && x < X_dimension )
      return static_cast<double>(histogram[x])/static_cast<double>(total_count);
   return 0.0;
}

double distrib_1D::get_aveX () const {
   double s = 0.0;
   for ( int x = 0; x < X_dimension; ++x )
      s += static_cast<double>(x) * static_cast<double>(histogram[x]);
   return s / static_cast<double>(total_count);
}
// ============================================================================

// ========================== aver_func helper class ==========================
// =========================== members definitions ============================
aver_func::aver_func ( int nElem )
: n_elements(nElem), data(new double[nElem]), count(new unsigned long[nElem])  {
   for ( int i = 0; i < n_elements; ++i ) {
      data[i] = 0.0;
      count[i] = 0;
   }
}

void aver_func::save ( std::ostream& out ) const {
   out.write ( (char*)&n_elements, sizeof (n_elements) );
   out.write ( (char*)data,  n_elements*sizeof(*data) );
   out.write ( (char*)count, n_elements*sizeof(*count) );
}

void aver_func::read ( std::istream& in ) {
   int nElem = -1;
   in.read ( (char*)&nElem, sizeof (int) );
   if ( nElem != n_elements )
      throw md_io_error ( "aver_func::read : cannot read data from input!" );
   
   in.read ( (char*)data,  n_elements*sizeof(*data) );
   in.read ( (char*)count, n_elements*sizeof(*count) );
}

void aver_func::add ( int i, double val ) {
   if ( i >= 0 && i < n_elements ) {
      data[i] += val;
      count[i]++;
   }
}

double aver_func::get_value ( int i ) const {
   if ( i >= 0 && i < n_elements )
      return data[i] / count[i];
   return 0.0;
}

bool aver_func::has_value ( int i ) const {
   if ( i >= 0 && i < n_elements )
      return count[i] > 0;
   return false;
}
// ============================================================================
