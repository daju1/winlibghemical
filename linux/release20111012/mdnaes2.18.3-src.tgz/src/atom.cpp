#include <string>
#include <iostream>

#include "atom.h"
#include "utils.h"
#include "md_exception.h"

// ============================================================================
std::vector<atom_type> Atom_types;
// ============================================================================
void configuration_space::set_nthreads ( size_type numthreads ) {
   if ( m_coordinates.size() > 0 ) {
      raise_md_exception ( "cannot change number of threads at work\n" );
   }
   
   m_nthreads = numthreads;
   
   while ( m_thread_local_forces.size() < m_nthreads ) {
      m_thread_local_forces.emplace_back ();
   }
}

configuration_space::size_type configuration_space::allocate_atoms ( const std::vector<int>& atom_ids, size_type part_id )
{
   const size_type first_index = m_coordinates.size();
   
   for ( int a: atom_ids ) {
      //m_types.emplace_back ( t );
      m_atom_ids.emplace_back ( a );
      
      m_coordinates.emplace_back ( 0.0 );
      m_velocities.emplace_back ( 0.0 );
      
      //m_charges.emplace_back ( t->charge() );
      m_charges.emplace_back ( Atom_types.at(a).charge() );
      
      m_particle_ids.emplace_back ( part_id );
      
      for ( size_type i = 0; i < nthreads(); ++i ) {
         m_thread_local_forces.at(i).emplace_back ( 0.0, 0.0 );
      }
      
      m_neighbours_lists.emplace_back ();
   }
   
   return first_index;
}

configuration_space global_cspace {0};

// ============================================================================
void atom_ref::reset_near_forces () const {
   for ( size_type t = 0; t < global_cspace.nthreads(); ++t ) {
      f(t).near = 0.0;
   }
}

void atom_ref::reset_far_forces () const {
   for ( size_type t = 0; t < global_cspace.nthreads(); ++t ) {
      f(t).far  = 0.0;
   }
}

void atom_ref::sync_near_forces () const {
   for ( size_type t = 1; t < global_cspace.nthreads(); ++t ) {
      f(0).near += f(t).near;
   }
}

void atom_ref::sync_far_forces () const {
   for ( size_type t = 1; t < global_cspace.nthreads(); ++t ) {
      f(0).far  += f(t).far;
   }
}

void atom_ref::swap ( atom_ref other ) {
   std::swap(r(),other.r());
   std::swap(v(),other.v());
   std::swap(q(),other.q());
   // dont need to swap other data (types are the same, forces are irrelevant during initialization.
}


void atom_ref::save_v2_0 ( std::ostream& out ) const {
   const_atom_ref{index}.save_v2_0 ( out );
}

void atom_ref::read_v2_0 ( std::istream& in ) const {
   r() = read_as<vect> ( in );
   v() = read_as<vect> ( in );
   (void) read_as<vect> ( in );
   q() = read_as<double> ( in );
}

void const_atom_ref::save_v2_0 ( std::ostream& out ) const {
   write_as<vect> ( out, r() );
   write_as<vect> ( out, v() );
   write_as<vect> ( out, 0 );
   write_as<double> ( out, q() );
}
