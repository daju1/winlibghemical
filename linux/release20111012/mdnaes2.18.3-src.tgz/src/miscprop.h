#ifndef MISC_PROP_H
#define MISC_PROP_H

#include <iosfwd>

void OutMiscProp ( int mode = 0); // called by '-n' command-line parameter
void Out_DLPOLY_Config ( const char *filename, int mode );
void PrintClusters ();
void Print_trajectory ( std::ostream& );
void Print_trajectory4Mol ( std::ostream& );

#endif
