#include <cmath>
#include <cassert>
#include "lib/vect.h"
using namespace mdnaes;

extern int jacobi ( int n, double *A, double *d, double *V );

void eigenval ( double I[3][3], double d[3], vect V[3] ) {
   double A[3][3];
   double VV[3][3];
   int i, j;
   for ( i = 0; i < 3; ++i )
      for ( j = 0; j < 3; ++j )
         A[i][j] = I[i][j];
   jacobi ( 3, (double*)A, d, (double*)VV );
   for ( i = 0; i < 3; ++i ) {
      V[i].x = VV[0][i];
      V[i].y = VV[1][i];
      V[i].z = VV[2][i];
   }
   for ( i = 0; i < 2; ++i )
      for ( j = i+1; j < 3; ++j )
         if ( d[i] > d[j] ) {
            const double t = d[i];
            d[i] = d[j]; d[j] = t;
            const vect v = V[i];
            V[i] = V[j]; V[j] = v;
         }
   return;
}

inline void swap ( int n, double A[], double B[] ) {
   int i;
   for ( i = 0; i < n; ++i ) {
      const double t = A[i];
      A[i] = B[i];
      B[i] = t;
   }
}

inline void swap ( double& A, double& B ) {
   const double t = A;
   A = B;
   B = t;
}

void vector_expansion ( vect v, int n, const vect basis[], double coefs[] ) {
   double XX = 0;
   double XY = 0;
   double XZ = 0;
   double XN = 0;
   double YY = 0;
   double YZ = 0;
   double YN = 0;
   double ZZ = 0;
   double ZN = 0;
   double NN = n;

   int i, j;
   for ( i = 0; i < n; ++i ) {
      XX += basis[i].x * basis[i].x;
      XY += basis[i].x * basis[i].y;
      XZ += basis[i].x * basis[i].z;
      XN += basis[i].x;
      YY += basis[i].y * basis[i].y;
      YZ += basis[i].y * basis[i].z;
      YN += basis[i].y;
      ZZ += basis[i].z * basis[i].z;
      ZN += basis[i].z;
   }
   double B[4][4];
   double L[4];
   B[0][0] = XX;
   B[0][1] = B[1][0] = XY;
   B[0][2] = B[2][0] = XZ;
   B[0][3] = B[3][0] = XN;
   B[1][1] = YY;
   B[1][2] = B[2][1] = YZ;
   B[1][3] = B[3][1] = YN;
   B[2][2] = ZZ;
   B[2][3] = B[3][2] = ZN;
   B[3][3] = NN;
   L[0] = v.x;
   L[1] = v.y;
   L[2] = v.z;
   L[3] = 0.0;

   double res[4] = { 0.0, 0.0, 0.0, 0.0 };

   int col, row = 0;
   for ( col = 0; col < 4; ++col ) {
      {
         int maxrow = row;
         for ( j = row+1; j < 4; ++j ) // find row with maximum B[j][i]
            if ( fabs(B[j][col]) > fabs(B[maxrow][col]) )
               maxrow = j;
         swap ( 4, B[row], B[maxrow] );
         swap ( L[row], L[maxrow] );
      }  // now |B[col][row]| >= |B[col][j]| with j > row.
      if ( fabs(B[row][col]) < 1.0e-10 ) {
         for ( j = row; j < 4; ++j )
            B[j][col] = 0.0;
         continue;
      }
      for ( i = col+1; i < 4; ++i )
         B[row][i] /= B[row][col];
      L[row] /= B[row][col];
      B[row][col] = 1.0;
      
      for ( j = row+1; j < 4; ++j ) {
         for ( i = col+1; i < 4; ++i )
            B[j][i] -= B[j][col]*B[row][i];
         L[j] -= B[j][col]*L[row];
         B[j][col] = 0.0;
      }
      row++;
   }
   assert ( col == 4 );
   assert ( row <= 4 );

   int calced = 4;
   row = 3;
   col = 3;
   while ( B[row][3] == 0.0 )
      row--;
   while ( row >= 0 ) {
      col = 0;
      while ( B[row][col] == 0.0 )
         col++;

      assert ( B[row][col] == 1.0 );

      for ( i = calced - 1; i > col; --i )
         res[i] = 0.0;
      double sum = 0;
      for ( i = col+1; i < 4; ++i )
         sum += B[row][i] * res[i];
      res[col] = L[row] - sum;
      --row;
      calced = col;
      if ( calced == 0 )
         assert ( col == 0 );
   }

   for ( i = 0; i < n; ++i )
      coefs[i] = basis[i].x * res[0] +
                 basis[i].y * res[1] +
                 basis[i].z * res[2] +
                 res[3];
   {
      vect R = 0.0;
      for ( i = 0; i < n; ++i )
         R += coefs[i] * basis[i];
   }
}
