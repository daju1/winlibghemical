#ifndef MYMATH_H
#define MYMATH_H

#include "lib/vect.h"
using namespace mdnaes;

void eigenval ( double I[3][3], double d[3], vect V[3] );

void vector_expansion ( vect v, int n, const vect basis[], double coefs[] );

// ============================================================================
// ================================= integral =================================
template <class Arr>
double integral(const Arr& f, int n, const double dr)
{	//	Trapetions method for step = 3*dr, 2*dr and dr and romberg extrapolation.
	static double s1, s2, s3;
	double temp;
	int i;

	s3 = s2 = s1 = 0.0;
	temp = 0.0;

	i = (n - 1) % 6;
	if (i) {
		i %= 2;
		if (i) {
			temp = dr * (0.375 * f[n-1] + (19.0 * f[n-2] - 5.0 * f[n-3] + f[n-4]) / 24.0) ;
			--n;	//	integral from n-2 to n-1, exact for x^3;
		}
		else {
			temp = dr * (f[n-1] + 4 * f[n-2] + f[n-3]) / 3;
			n -= 2;
		}
		temp += integral(f,n,dr) ;
		return (temp) ;
	}

	for (i = 1; i < n-1; i += 2)
		s1 += f[i] ;
	for (i = 2; i < n-1; i += 2)
		s2 += f[i] ;
	for (i = 3; i < n-1; i += 3)
		s3 += f[i] ;
	temp = (f[0] + f[n-1]) / 2;
	s1 += s2;
	s2 *= 2;
	s3 *= 3;
	temp = 1.5 * s1 - 0.6 * s2 + 0.1 * s3 + 0.6 * temp;
	return (dr * temp) ;
}

//  ======================= P R O C E D U R E  LMNK1X =============================
//               least squares method for equispased x values
//  x0 - initial value of x, dx - x step, start - initial index for Y[i],
//  n - number of points: start <= i < start + n; Y = a*x + b

template <typename Arr>
void lmnk1x ( const Arr& Y, int start, int n, double x0, double dx, double *a, double *b ) {
double Sx, Sxx, D;
double Sy, Sxy;
   if ( n < 2 )
      return; // error!
   Sx = n*(n-1)/2;
   Sxx = Sx*(n+n-1)/3;

   Sxy = 0.0;
   Sy  = 0.0;
   for ( int i = n-1; i; --i ) {
      Sy += Y[start+i];
      Sxy += Sy;
   }
   Sy += Y[start+0];

   D = Sx*n*(n+1)/6;
   if ( a )
      *a = (n*Sxy-Sx*Sy) / (D*dx);
   if ( b )
      *b = (Sxx*Sy-Sx*Sxy) / D - x0*(*a);
}

#endif
