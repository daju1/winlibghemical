#include "SMolCF.h"

#include <vector>
#include <memory>
#include <thread>

#include "corr_aux.h"
#include "corclass.h"
#include "corclass_utils.h"
#include "correl.h"
#include "globals.h"
#include "iomanager.h"
#include "lib/mdformat.h"
using namespace mdnaes;

// ==================================== Short Molecular CF ====================================
const char *ShortMolCFFileName    = "SMolCF.cf";
const char *ShortMolCFResFileName = "SMolCF.dat";
const char *ShortMolCrossCFResFileName = "SCMolCF.dat";

int KMol_Cvv;
int KMol_Cww;
int KMol_Cff;
int KMol_Cnn;
int KMol_Cll;

int KMol_Cfc;
int KMol_Cnc;

int KMol_Cwc;
int KMol_Cvw;

int KMol_WcWc;
int KMol_VcVc;
int KMol_VcWc;

int KMol_Cii;


static vect VCM_calc ( molecule* part ) {
   return part->getCMVel ();
}

static vect FCM_calc ( molecule* part ) {
   return part->getForce ();
}

static vect ShortF_calc ( molecule* part ) {
   return part->getShortForce ();
}

static vect CoulF_calc ( molecule* part ) {
   return part->getLongForce ();
}

static vect N_calc ( molecule* part ) {
   return part->getTorque ();
}

static vect ShortN_calc ( molecule* part ) {
   return part->getShortTorque ();
}

static vect CoulN_calc ( molecule* part ) {
   return part->getLongTorque ();
}

static vect L_calc ( molecule* part ) {
   return part->getAngleMomentumInBoxAxes ();
}

static vect W_calc ( molecule* part ) {
   return part->getAngleVelInBoxAxes ();
}

static vect Wc_calc ( molecule* part ) {
   return part->getAngleVelInMolAxes ();
}

static double Wx_calc ( molecule* part ) {
   return (part->getAngleVelInMolAxes ()).x;
}

static double Wy_calc ( molecule* part ) {
   return (part->getAngleVelInMolAxes ()).y;
}

static double Wz_calc ( molecule* part ) {
   return (part->getAngleVelInMolAxes ()).z;
}

static double Vx_calc ( molecule* part ) {
   return (part->toMolAxes(part->getCMVel ())).x;
}

static double Vy_calc ( molecule* part ) {
   return (part->toMolAxes(part->getCMVel ())).y;
}

static double Vz_calc ( molecule* part ) {
   return (part->toMolAxes(part->getCMVel ())).z;
}

static vect Vl_calc ( molecule* part ) {
   const vect n = (*part)[1].r() - (*part)[0].r();
   const double nn = n * n;
   return ((part->getCMVel ()*n)/nn) * n;
}

static vect Vt_calc ( molecule* part ) {
   return part->getCMVel () - Vl_calc (part);
}

static vect Current_calc ( molecule* part ) {
   return part->getCurrent ();
}

static void SaveShortMolCF ();
static void ResultShortMolCF ();
static void ReleaseShortMolCF ();

static std::unique_ptr<HA_Allocator<double> > dbl_HA_allocator;
static std::unique_ptr<HA_Allocator<vect> >  vect_HA_allocator;

static iomanager ShortMolCF_IOManager ( ShortMolCFFileName );

static std::vector<std::unique_ptr<base_history_array> > shortMolCF_history_arrays;
static std::vector<std::unique_ptr<TDF> > shortMolCF_Cvvs;
static std::vector<std::unique_ptr<TDF> > shortMolCF_TDFs;

static int smolcf_nthreads = 1;

static void ShortMolCF_init () {
   dbl_HA_allocator  = std::make_unique<HA_Allocator<double> > (CorrelSize, 200);
   vect_HA_allocator = std::make_unique<HA_Allocator<vect> >   (CorrelSize, 300);
   
   if ( NTHREADS > 1 ) {
      smolcf_nthreads = std::max(2,NTHREADS/2);
   }
   else {
      smolcf_nthreads = 1;
   }
   
   const mdformat format(11,5);

   multiple_value_history_array_creator<vect,molecule*> VCM ( "VCM", *vect_HA_allocator, VCM_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> FCM ( "FCM", *vect_HA_allocator, FCM_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> SF ( "SF", *vect_HA_allocator, ShortF_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> CF ( "CF", *vect_HA_allocator, CoulF_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> L   ( "L", *vect_HA_allocator,     L_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> N   ( "N", *vect_HA_allocator,     N_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> SN ( "SN", *vect_HA_allocator, ShortN_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> CN ( "CN", *vect_HA_allocator, CoulN_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> W   ( "W", *vect_HA_allocator,     W_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> Wc  ( "Wc", *vect_HA_allocator,   Wc_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> Vl  ( "Vl", *vect_HA_allocator,   Vl_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> Vt  ( "Vt", *vect_HA_allocator,   Vt_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> Cur ( "Cur",*vect_HA_allocator, Current_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<double,molecule*> Wx  ( "Wx", *dbl_HA_allocator,   Wx_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<double,molecule*> Wy  ( "Wy", *dbl_HA_allocator,   Wy_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<double,molecule*> Wz  ( "Wz", *dbl_HA_allocator,   Wz_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<double,molecule*> Vx  ( "Vx", *dbl_HA_allocator,   Vx_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<double,molecule*> Vy  ( "Vy", *dbl_HA_allocator,   Vy_calc, shortMolCF_history_arrays );
   multiple_value_history_array_creator<double,molecule*> Vz  ( "Vz", *dbl_HA_allocator,   Vz_calc, shortMolCF_history_arrays );
   
   single_molecule_ACF_creator<double,vect,molecule*> Cvv ( "Cvv", VCM, format );
   single_molecule_ACF_creator<double,vect,molecule*> Cff ( "Cff", FCM, format );
   single_molecule_ACF_creator<double,vect,molecule*> Cll ( "Cll",   L, format );
   single_molecule_ACF_creator<double,vect,molecule*> Cnn ( "Cnn",   N, format );
   single_molecule_ACF_creator<double,vect,molecule*> Cww ( "Cww",   W, format );
   single_molecule_ACF_creator<double,vect,molecule*> Cwc ( "WcWc", Wc, format );

   single_molecule_ACF_creator<double,double,molecule*> WxWx ( "WxWx", Wx, format );
   single_molecule_ACF_creator<double,double,molecule*> WyWy ( "WyWy", Wy, format );
   single_molecule_ACF_creator<double,double,molecule*> WzWz ( "WzWz", Wz, format );
   single_molecule_ACF_creator<double,double,molecule*> VxVx ( "VxVx", Vx, format );
   single_molecule_ACF_creator<double,double,molecule*> VyVy ( "VyVy", Vy, format );
   single_molecule_ACF_creator<double,double,molecule*> VzVz ( "VzVz", Vz, format );

   single_molecule_CCF_creator<double,double,double,molecule*> WxWy ( "WxWy", Wx, Wy, format );
   single_molecule_CCF_creator<double,double,double,molecule*> WxWz ( "WxWz", Wx, Wz, format );
   single_molecule_CCF_creator<double,double,double,molecule*> WyWz ( "WyWz", Wy, Wz, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VxVy ( "VxVy", Vx, Vy, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VxVz ( "VxVz", Vx, Vz, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VyVz ( "VyVz", Vy, Vz, format );

   single_molecule_CCF_creator<double,double,double,molecule*> VxWx ( "VxWx", Vx, Wx, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VxWy ( "VxWy", Vx, Wy, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VxWz ( "VxWz", Vx, Wz, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VyWx ( "VyWx", Vy, Wx, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VyWy ( "VyWy", Vy, Wy, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VyWz ( "VyWz", Vy, Wz, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VzWx ( "VzWx", Vz, Wx, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VzWy ( "VzWy", Vz, Wy, format );
   single_molecule_CCF_creator<double,double,double,molecule*> VzWz ( "VzWz", Vz, Wz, format );

   single_molecule_ACF_creator<double,vect,molecule*> VlVl ( "VlVl", Vl, format );
   single_molecule_ACF_creator<double,vect,molecule*> VtVt ( "VtVt", Vt, format );
   single_molecule_CCF_creator<double,vect,vect,molecule*> VlVt ( "VlVt", Vl, Vt, format );
   single_molecule_CCF_creator<double,vect,vect,molecule*> VlW ( "VlW", Vl, W, format );
   single_molecule_CCF_creator<double,vect,vect,molecule*> VtW ( "VtW", Vt, W, format );

   single_molecule_ACF_creator<double,vect,molecule*> SFSF ( "SFSF", SF, format );
   single_molecule_ACF_creator<double,vect,molecule*> CFCF ( "CFCF", CF, format );
   single_molecule_CCF_creator<double,vect,vect, molecule*> SFCF ( "SFCF", SF, CF, format );
   single_molecule_ACF_creator<double,vect,molecule*> SNSN ( "SNSN", SN, format );
   single_molecule_ACF_creator<double,vect,molecule*> CNCN ( "CNCN", CN, format );
   single_molecule_CCF_creator<double,vect,vect,molecule*> SNCN ( "SNCN", SN, CN, format );

   single_molecule_CCF_creator<double,vect,vect,molecule*> Cvw ( "Cvw", VCM, W, format );

   single_molecule_ACF_creator<double,vect,molecule*> Cii ( "Cii", Cur, format );


   Message << "starting short CF calculation for molecules by shells" << std::endl;

   create_from_shells (KMol_Cvv, Cvv, shortMolCF_Cvvs, smolcf_nthreads);
   
   create_from_shells (KMol_Cww, Cww, shortMolCF_TDFs, smolcf_nthreads);
   create_from_shells (KMol_Cff, Cff, shortMolCF_TDFs, smolcf_nthreads);
   create_from_shells (KMol_Cnn, Cnn, shortMolCF_TDFs, smolcf_nthreads);
   
   create_from_shells (KMol_Cfc, SFSF, shortMolCF_TDFs, smolcf_nthreads);
   create_from_shells (KMol_Cfc, CFCF, shortMolCF_TDFs, smolcf_nthreads);
   create_from_shells (KMol_Cfc, SFCF, shortMolCF_TDFs, smolcf_nthreads);
   create_from_shells_if (KMol_Cfc, SNSN, shortMolCF_TDFs, shape_notpoint<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_Cfc, CNCN, shortMolCF_TDFs, shape_notpoint<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_Cfc, SNCN, shortMolCF_TDFs, shape_notpoint<molecule>, smolcf_nthreads);

   create_from_shells (KMol_Cll, Cll, shortMolCF_TDFs, smolcf_nthreads);
   create_from_shells (KMol_Cwc, Cwc, shortMolCF_TDFs, smolcf_nthreads);
   create_from_shells (KMol_Cvw, Cvw, shortMolCF_TDFs, smolcf_nthreads);

   create_from_shells_if (KMol_WcWc, WxWx, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_WcWc, WxWy, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_WcWc, WxWz, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_WcWc, WyWy, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_WcWc, WyWz, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_WcWc, WzWz, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   
   create_from_shells_if (KMol_VcVc, VxVx, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcVc, VxVy, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcVc, VxVz, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcVc, VyVy, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcVc, VyVz, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcVc, VzVz, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   
   create_from_shells_if (KMol_VcVc, VlVl, shortMolCF_TDFs, shape_linear<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcVc, VtVt, shortMolCF_TDFs, shape_linear<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcVc, VlVt, shortMolCF_TDFs, shape_linear<molecule>, smolcf_nthreads);

   create_from_shells_if (KMol_VcWc, VxWx, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcWc, VxWy, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcWc, VxWz, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcWc, VyWx, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcWc, VyWy, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcWc, VyWz, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcWc, VzWx, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcWc, VzWy, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcWc, VzWz, shortMolCF_TDFs, shape_general<molecule>, smolcf_nthreads);
   
   create_from_shells_if (KMol_VcWc, VlW, shortMolCF_TDFs, shape_linear<molecule>, smolcf_nthreads);
   create_from_shells_if (KMol_VcWc, VtW, shortMolCF_TDFs, shape_linear<molecule>, smolcf_nthreads);

   create_from_shells (KMol_Cii, Cii, shortMolCF_TDFs, smolcf_nthreads);

// ---------------------------------------------------------------------------
   for ( const auto& p: shortMolCF_history_arrays ) {
      ShortMolCF_IOManager.add ( p.get() );
   }

   for ( const auto& p: shortMolCF_TDFs ) {
      ShortMolCF_IOManager.add ( p.get() );
   }

   for ( const auto& p: shortMolCF_Cvvs ) {
      ShortMolCF_IOManager.add ( p.get() );
   }

   if ( KLH ) {
      Message << "reading short molecular CF from file...";
      ShortMolCF_IOManager.read ();
      Message << " done" << std::endl;
   }

   SMan.AddFun ( &SaveShortMolCF );
   ShowRes.AddFun ( &ResultShortMolCF );
}

static void do_update_CF ( int thread_no ) {
   for ( const auto& p: shortMolCF_history_arrays ) {
      p->update ( thread_no, smolcf_nthreads );
   }
   
   for ( const auto& p: shortMolCF_TDFs ) {
      p->update ( thread_no, smolcf_nthreads );
   }
   for ( const auto& p: shortMolCF_Cvvs ) {
      p->update ( thread_no, smolcf_nthreads );
   }
}


void ShortMolCF_Calc () {
   static int init = 1;
   if ( init ) {
      ShortMolCF_init ();
      init = 0;
   }
   
   exec_parallel ( do_update_CF, smolcf_nthreads );
}

static void SaveShortMolCF () {
   for ( const auto& p: shortMolCF_TDFs ) {
      p->sync ( );
   }
   for ( const auto& p: shortMolCF_Cvvs ) {
      p->sync ( );
   }
   
   ShortMolCF_IOManager.save ();
}

static void ResultShortMolCF () {
   for ( const auto& p: shortMolCF_TDFs ) {
      p->sync ( );
   }
   for ( const auto& p: shortMolCF_Cvvs ) {
      p->sync ( );
   }
   
   Message << "Diffusion coefficients, obtained by integrating of Cvv(t) by shells:" << std::endl;
   for ( const auto& p: shortMolCF_Cvvs ) {
      p->print_header ( Message );
      if ( !p->empty() ) {
         Message << mdformat(12,5) << 1e9*LENGTH_UNIT*LENGTH_UNIT/(3*TIME_UNIT)*
            integral(*dynamic_cast<TTDF<double>*>(p.get()), p->size(), StepShortCF*DELT);
      }
      else {
         Message << mdformat(12,5) << "--";
      }
      Message << " * 1.0e-9 m^2/s" << std::endl;
   }
   
   std::vector<TDF*> AllTDFs;
   for ( const auto& p: shortMolCF_Cvvs )
      AllTDFs.push_back ( p.get() );
   for ( const auto& p: shortMolCF_TDFs )
      AllTDFs.push_back ( p.get() );
   
   PrintTDFRes ( AllTDFs, ShortMolCFResFileName, StepShortCF );
}
