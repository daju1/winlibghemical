#include "insion.h"
#include "crystal_grids.h"
#include "md_exception.h"
#include "globals.h"
#include "all_particles.h"
using namespace mdnaes;

#include <algorithm>
#include <utility>
#include <cstdlib>
#include <memory>

namespace {

   template <class PartT>
   std::size_t find_nearest ( std::vector<std::unique_ptr<PartT> >& array, vect position ) {
      double rmin = std::numeric_limits<double>::max();
      std::size_t index = array.size();
      
      for ( std::size_t i = 0; i < array.size(); ++i ) {
         const double r = norm( position - array[i]->getCMPos() );
         if ( r < rmin ) {
            index = i;
            rmin = r;
         }
      }
      
      return index;
   }
   
   void insert_cation ( vect position ) {
      for ( auto& array: SimSystem.molecules ) {
         if ( array.size() > 0 ) {
            auto index = find_nearest ( array, position );
            
            vect pos = array[index]->getCMPos ();
            
            array[index]->swap(*array[array.size()-1]);
            array.pop_back ();
            
            SimSystem.cations[0].emplace_back ( SimSystem.cation_types[0]->create(pos) );
            
            return;
         }
      }
      
      raise_md_exception ( "No molecules in system. Cannot replace them with ions.\n" );
   }
   
   void insert_anion ( vect position ) {
      for ( auto& array: SimSystem.molecules ) {
         if ( array.size() > 0 ) {
            auto index = find_nearest ( array, position );
            
            vect pos = array[index]->getCMPos ();
            
            array[index]->swap(*array[array.size()-1]);
            array.pop_back ();
            
            SimSystem.anions[0].emplace_back ( SimSystem.anion_types[0]->create(pos) );
            
            return;
         }
      }
      
      raise_md_exception ( "No molecules in system. Cannot replace them with ions.\n" );
   }

} // end of namespace

void ins_ions ( int numkat, int numan ) { // replace molecules with ions
   if ( numkat == 1 && numan == 0 ) {
      insert_cation ( vect{0.5,0.5,0.5} * LBOX );
      return;
   }
   
   if ( numkat == 0 && numan == 1 ) {
      insert_anion ( vect{0.5,0.5,0.5} * LBOX );
      return;
   }
   
   if ( numkat == 1 && numan == 1 ) {
      insert_cation ( vect{0.25,0.25,0.25} * LBOX );
      insert_anion  ( vect{0.75,0.75,0.75} * LBOX );
      return;
   }
   
   if ( numkat == 1 && numan == 2 ) {
      insert_cation ( vect{0.50,0.50,0.50} * LBOX );
      insert_anion  ( vect{0.167,0.167,0.167} * LBOX );
      insert_anion  ( vect{0.833,0.833,0.833} * LBOX );
      return;
   }
   
   if ( numkat == 2 && numan == 1 ) {
      insert_anion  ( vect{0.50,0.50,0.50} * LBOX );
      insert_cation ( vect{0.167,0.167,0.167} * LBOX );
      insert_cation ( vect{0.833,0.833,0.833} * LBOX );
      return;
   }
   
   if ( numkat == 4 && numan == 4 ) {
      insert_cation ( vect{0.25,0.25,0.25} * LBOX );
      insert_cation ( vect{0.75,0.75,0.25} * LBOX );
      insert_cation ( vect{0.75,0.25,0.75} * LBOX );
      insert_cation ( vect{0.25,0.75,0.75} * LBOX );
      
      insert_anion ( vect{0.75,0.75,0.75} * LBOX );
      insert_anion ( vect{0.75,0.25,0.25} * LBOX );
      insert_anion ( vect{0.25,0.75,0.25} * LBOX );
      insert_anion ( vect{0.25,0.25,0.75} * LBOX );
      
      return;
   }
   
   if ( SimSystem.molecules.size() == 0 ) {
      raise_md_exception ( "No molecules in system. Cannot replace them with ions.\n" );
   }
   
   for ( int i = 0; i < numkat; ++i ) {
      bool succeeded = false;
      for ( auto& array: SimSystem.molecules ) {
         if ( array.size() > 0 ) {
            // replace random molecule in array
            std::uniform_int_distribution<size_t> random_indices (0,array.size());
            auto index = random_indices(global_random_engine);
            //const auto index = std::uniform_int_distribution<size_t>{0,array.size()}(global_random_engine);

            vect pos = array[index]->getCMPos ();
            
            array[index]->swap(*array[array.size()-1]);
            array.pop_back ();
            
            SimSystem.cations[0].emplace_back ( SimSystem.cation_types[0]->create(pos) );
            
            succeeded = true;
            break;
         }
      }
      
      if ( !succeeded ) {
         raise_md_exception ( "No molecules left in system. Cannot replace them with ions.\n" );
      }
   }
   
   for ( int i = 0; i < numan; ++i ) {
      bool succeeded = false;
      for ( auto& array: SimSystem.molecules ) {
         if ( array.size() > 0 ) {
            // replace random molecule in array
            std::uniform_int_distribution<size_t> random_indices (0,array.size());
            auto index = random_indices(global_random_engine);
            
            vect pos = array[index]->getCMPos ();
            
            array[index]->swap(*array[array.size()-1]);
            array.pop_back ();
            
            SimSystem.anions[0].emplace_back ( SimSystem.anion_types[0]->create(pos) );
            
            succeeded = true;
            break;
         }
      }
      
      if ( !succeeded ) {
         raise_md_exception ( "No molecules left in system. Cannot replace them with ions.\n" );
      }
   }
   
   SimSystem.syncronize_particle_arrays ();
}

std::pair<std::vector<crystal_grid::size_type>, std::vector<crystal_grid::size_type> >
select_ions_positions ( const crystal_grid& grid, int numkat, int numan ) {
   // assume that there is new system to construct
   // return lists of indexes in the grid for cations and anions
   if ( numkat+numan > grid.size() ) {
      raise_md_exception ( "total number of ions exseeds grid size\n" );
   }

   std::vector<crystal_grid::size_type> cations;
   std::vector<crystal_grid::size_type> anions;
   vect r = 0.0;

   if ( numkat == 1 && numan == 0 ) {
      cations.push_back ( 0 );
      return {cations,anions};
   }
   if ( numkat == 0 && numan == 1 ) {
      anions.push_back ( 0 );
      return {cations,anions};
   }

   if ( numkat == 1 && numan == 1 ) {
      r = vect (0.25,0.25,0.25) * grid.lbox();
      auto cation_index = grid.find_nearest ( r );
      r = vect (0.75,0.75,0.75) * grid.lbox();
      auto anion_index = grid.find_nearest ( r );
      
      if ( cation_index == anion_index ) {
         cation_index = 0;
         anion_index  = 1;
      }
      
      cations.push_back ( cation_index );
      anions.push_back ( anion_index );
      return {cations,anions};
   }

   if ( numkat == 1 && numan == 2 ) {
      r = vect (0.50,0.50,0.50) * grid.lbox();
      auto c = grid.find_nearest ( r );
      r = vect (0.167,0.167,0.167) * grid.lbox();
      auto a1 = grid.find_nearest ( r );
      r = vect (0.833,0.833,0.833) * grid.lbox();
      auto a2 = grid.find_nearest ( r );
      
      if ( c == a1 || c == a2 || a1 == a2 ) {
         c  = 0;
         a1 = 1;
         a2 = 2;
      }
      
      cations.push_back ( c );
      anions.push_back ( a1 );
      anions.push_back ( a2 );
      
      return {cations,anions};
   }
   
   if ( numkat == 2 && numan == 1 ) {
      r = vect (0.50,0.50,0.50) * grid.lbox();
      auto a = grid.find_nearest ( r );
      r = vect (0.167,0.167,0.167) * grid.lbox();
      auto c1 = grid.find_nearest ( r );
      r = vect (0.833,0.833,0.833) * grid.lbox();
      auto c2 = grid.find_nearest ( r );
      
      if ( a == c1 || a == c2 || c1 == c2 ) {
         a = 0;
         c1 = 1;
         c2 = 2;
      }
      
      cations.push_back ( c1 );
      cations.push_back ( c2 );
      anions.push_back ( a );
      
      return {cations,anions};
   }
   
   if ( numkat == 4 && numan == 4 ) {
      auto c1 = grid.find_nearest ( vect (0.25,0.25,0.25)*grid.lbox() );
      auto c2 = grid.find_nearest ( vect (0.75,0.75,0.25)*grid.lbox() );
      auto c3 = grid.find_nearest ( vect (0.75,0.25,0.75)*grid.lbox() );
      auto c4 = grid.find_nearest ( vect (0.25,0.75,0.75)*grid.lbox() );
      
      auto a1 = grid.find_nearest ( vect (0.75,0.75,0.75)*grid.lbox() );
      auto a2 = grid.find_nearest ( vect (0.75,0.25,0.25)*grid.lbox() );
      auto a3 = grid.find_nearest ( vect (0.25,0.75,0.25)*grid.lbox() );
      auto a4 = grid.find_nearest ( vect (0.25,0.25,0.75)*grid.lbox() );
      
      cations.push_back ( c1 );
      cations.push_back ( c2 );
      cations.push_back ( c3 );
      cations.push_back ( c4 );
      
      anions.push_back ( a1 );
      anions.push_back ( a2 );
      anions.push_back ( a3 );
      anions.push_back ( a4 );
      
      return {cations,anions};
   }

   // choose positions randomly:
   std::vector<crystal_grid::size_type> indices;
   for ( std::size_t i = 0; i < grid.size(); ++i ) {
      indices.push_back ( i );
   }
   std::shuffle ( indices.begin(), indices.end(), global_random_engine );
   
   for ( std::size_t i = 0; i < numkat; ++i ) {
      cations.push_back ( indices[i] );
   }
   for ( std::size_t i = 0; i < numan; ++i ) {
      anions.push_back ( indices[i+numkat] );
   }
   
   return {cations,anions};
}

