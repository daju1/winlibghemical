#ifndef RIGID_PARTICLE_H
#define RIGID_PARTICLE_H

#include <memory>

#include "basic_particle.h"
#include "molecule.h"
#include "ion.h"

#include "lib/matrix_3x3.h"

// Base_part must be derived from class particle
// actually it should be molecule or ion
template <class Base_part>
class rigid_particle_type;

// Base must be derived from class particle
// actually it should be molecule or ion
template <class Base>
class rigid_particle : public Base {
public:
   using type_t = rigid_particle_type<Base>;
private:
   const type_t *type;
public:
   rigid_particle ( const type_t *t, vect origin );
   rigid_particle ( const rigid_particle &src, vect cmpos );

   virtual ~rigid_particle () override {}
   
   virtual void swap ( rigid_particle<Base>& other );
   
   virtual void move ( double tstep, int substeps, std::size_t thread_no = 0 ) override;
   virtual void correctorStep ( double tstep ) override;

   virtual void randomize_velocities () override;
   virtual void getMolAxes ( vect [3] ) const override;
   
   virtual vect getAngleAcceleration () const override;
   virtual vect getShortAngleAcceleration () const override;
   virtual vect getLongAngleAcceleration () const override;
   
   virtual vect getAngleVelInBoxAxes () const override;

   virtual double getEkinRot () const override;
   virtual double getEkinVibr () const override;

   virtual void scalPos ( double factor ) override;

   virtual matrix_3x3 getInternalStress () const override;

   virtual int is_bonded ( int atom1, int atom2 ) const override;
   // if atoms i and j are bonded, then we shoud not calculate forces between them

   virtual vect getCMPos () const override; // version with caching of CM value
   
   virtual void read_v2_0 ( std::istream& ) override; // version with caching of CM value
   
private:
   vect CMPosCache;
};

// Base_part must be derived from class particle
// actually it should be molecule or ion
template <class Base_part>
class rigid_particle_type : public Base_part::type_t {
public:
   using Base = typename Base_part::type_t;
protected:
   double *molXAxesCoefs;
   double *molYAxesCoefs;
   virtual void molAxesCalc ( const basic_particle& atoms, vect [3] ) const;

   double ixx, iyy, izz;

   friend class rigid_particle<Base_part>;

   int particle_shape;
   
   double Ixx () const { return ixx; }
   double Iyy () const { return iyy; }
   double Izz () const { return izz; }
public:
   rigid_particle_type ( mylist_const_iterator& );
   virtual ~rigid_particle_type ();

   virtual std::unique_ptr<Base_part> create ( vect origin ) const;
   virtual std::unique_ptr<Base_part> create ( const Base_part *src, vect cmpos ) const;
   //virtual p_array<Base_part> new_array () const;
   
   virtual int shape () const;
   virtual int nRotDegFree () const;
   virtual int nVibrDegFree () const;
   virtual void print ( std::ostream& ) const;
};

// ===========================================================================
using rigid_molecule = rigid_particle<molecule>;
using rigid_ion = rigid_particle<ion>;
using rigid_molecule_type = rigid_particle_type<molecule>;
using rigid_ion_type = rigid_particle_type<ion>;

#endif
