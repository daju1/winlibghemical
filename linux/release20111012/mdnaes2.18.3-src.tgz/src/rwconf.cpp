#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <vector>

#include "rwconf.h"
#include "globals.h"
#include "init.h"
#include "all_particles.h"
#include "version.h"
#include "utils.h"


/* Some constants for co_in.dat file format */
constexpr int MolNameLen = 10;
constexpr int MolNameLen_v1_0 = 10;

constexpr int32_t MASK = 0xE0AB0431; // taken from /dev/urandom


/*    =======================================================
      SUBROUTINE READ
      =======================================================
      reads the data file co_in.dat
      =======================================================
*/
static void ReadConf_v2_13 ( int ver, int sver ) {
   const char InchekWarn[] = " Warning - old ";
   // Variables for verify
   
   int NA2W  = 0;
   int saved_NMOL1  = 0;
   int saved_NMOL2  = 0;
   int saved_NION_C = 0;
   int saved_NION_A = 0;
   double saved_DELT = 0;
   double saved_TMPR0 = 0;
   double saved_RCUT_LJ = 0;
   double saved_LBOX = 0;
   
   // End var
   
   char buffer[MolNameLen];
   char buf1[sizeof(double)];
   std::ifstream in ( Co_inFileName, std::ios::binary | std::ios::in );
   if ( !in ) {
      Error << UnOpen << Co_inFileName << std::endl;
      std::exit ( EXIT_FAILURE );
   }
   switch ( version::check_ver_as ( in, ver, sver ) ) {
      case version::ok:
         break;
      case version::version_failure:
      case version::sub_ver_failure:
         std::cerr << '\a' << "input file version error, try to use -v option\n";
         Error << "input file version error, try to use -v option\n";
      default:
         std::exit ( EXIT_FAILURE );
   }
   
   NSTTOT =       read_as<int32_t> ( in );   // int              8
   saved_NMOL1 =  read_as<int32_t> ( in );   // int             12
   saved_NION_C = read_as<int32_t> ( in );   // int             16
   saved_NION_A = read_as<int32_t> ( in );   // int             20
   NA2W =         read_as<int32_t> ( in );   // int             24
   TIME =         read_as<double>  ( in );   // double          28
   saved_DELT =   read_as<double>  ( in );   // double          36
   saved_TMPR0 =  read_as<double>  ( in );   // double          44
   saved_LBOX =   read_as<double>  ( in );   // double          52
   saved_RCUT_LJ =read_as<double>  ( in );   // double          60
   (void)   read_as<double>  ( in );         // Not used        68
   (void)   read_as<double>  ( in );         // Not used        76
   (void)   read_as<int32_t> ( in );         // int             84 // Successful saving flag, used by mdconfig
   saved_NMOL2 =  read_as<int32_t> ( in );   // int             88

   if ( saved_NMOL1 != SimSystem.all_molecules1.size() ) {
      std::cout << InchekWarn << " saved NMOL1 = " << saved_NMOL1 << " new NMOL1 = " << SimSystem.all_molecules1.size() << std::endl;
      Error     << InchekWarn << " saved NMOL1 = " << saved_NMOL1 << " new NMOL1 = " << SimSystem.all_molecules1.size() << std::endl;
      exit ( EXIT_FAILURE );
   }
   if ( saved_NMOL2 != SimSystem.all_molecules2.size() ) {
      std::cout << InchekWarn << " saved NMOL2 = " << saved_NMOL2 << " new NMOL2 = " << SimSystem.all_molecules2.size() << std::endl;
      Error     << InchekWarn << " saved NMOL2 = " << saved_NMOL2 << " new NMOL2 = " << SimSystem.all_molecules2.size() << std::endl;
      exit ( EXIT_FAILURE );
   }
   if ( saved_NION_A != SimSystem.all_anions.size() ) {
      std::cout << InchekWarn << " saved NION_A = " << saved_NION_A << " new NION_A = " << SimSystem.all_anions.size() << std::endl;
      Error     << InchekWarn << " saved NION_A = " << saved_NION_A << " new NION_A = " << SimSystem.all_anions.size() << std::endl;
      exit ( EXIT_FAILURE );
   }
   if ( saved_NION_C != SimSystem.all_cations.size() ) {
      std::cout << InchekWarn << " saved NION_C = " << saved_NION_C << " new NION_K = " << SimSystem.all_cations.size() << std::endl;
      Error     << InchekWarn << " saved NION_C = " << saved_NION_C << " new NION_K = " << SimSystem.all_cations.size() << std::endl;
      std::exit ( EXIT_FAILURE );
   }
   if ( fabs(saved_DELT - DELT)/DELT > 0.0001 ) {
      std::cout << InchekWarn << " DELT = " << DELT << " saved DELT = " << saved_DELT << std::endl;
      Message << InchekWarn << " DELT = " << DELT << " saved DELT = " << saved_DELT << std::endl;
   }

   if ( fabs(saved_TMPR0 - TMPR0) > 0.001 ) {
      std::cout << InchekWarn << " TMPR0 = " << TMPR0 << " saved TMPR0 = " << saved_TMPR0 << std::endl;
      Message << InchekWarn << " TMPR0 = " << TMPR0 << " saved TMPR0 = " << saved_TMPR0 << std::endl;
   }

   if ( fabs(saved_RCUT_LJ - RCut.LJ) > 0.0001) {
      std::cout << InchekWarn << " RCUT_LJ = " << RCut.LJ << " saved RCUT_LJ = " << saved_RCUT_LJ << std::endl;
      Message << InchekWarn << " RCUT_LJ = " << RCut.LJ << " saved RCUT_LJ = " << saved_RCUT_LJ << std::endl;
   }

   if ( fabs(saved_LBOX - LBOX) > 0.0001 ) {
      if ( KSV != 2 ) { // not NPT simulation, use LBOX from fint.dat
         Message << "Warning: saved LBOX = " << saved_LBOX << ", new LBOX = " << LBOX;
         Message << ", but simulation type is not NPT" << std::endl;
         LBOX = LBOXinit;
         setBoxSizeVariables();
         Message << "Using LBOX = LBOXinit = " << LBOX << ", DENS = " << DENS << std::endl;
      }
      if ( KSV == 2 ) { // NPT, use LBOX from co_in.dat file
         LBOX = saved_LBOX;
         setBoxSizeVariables();
      }
   }
  
   for ( int f = 0; f < 3; f++ )
      in.read ( buffer, sizeof(char) * MolNameLen );
   
   for ( auto p: SimSystem.all_particles ) {
      p->read_v2_0 ( in );
   }
}

static void ReadConf_v2_17 ( int ver, int sver ) {
   const char *InchekWarn = " Warning - old ";
   // Save some variables to check if they differes from saved in co_in.dat file
   int saved_NMOL1  = 0;
   int saved_NMOL2  = 0;
   int saved_NION_C = 0;
   int saved_NION_A = 0;
   double saved_DELT = 0;
   double saved_TMPR0 = 0;
   double saved_RCUT_LJ = 0;
   double saved_LBOX = 0;
   
   int32_t SEED = 0;
   
   std::ifstream in ( Co_inFileName, std::ios::binary | std::ios::in );
   if ( !in ) {
      Error << UnOpen << Co_inFileName << std::endl;
      std::exit ( EXIT_FAILURE );
   }
   
   switch ( version::check_ver_as ( in, ver, sver ) ) {
      case version::ok:
         break;
      case version::version_failure:
      case version::sub_ver_failure:
         std::cerr << '\a' << "input file version error, try to use -v option\n";
         Error << "input file version error, try to use -v option\n";
      default:
         std::exit ( EXIT_FAILURE );
   }
   
                                             // type      position
   NSTTOT =       read_as<int32_t> ( in );   // int              8
   saved_NMOL1 =  read_as<int32_t> ( in );   // int             12
   saved_NION_C = read_as<int32_t> ( in );   // int             16
   saved_NION_A = read_as<int32_t> ( in );   // int             20
   SEED =         read_as<int32_t> ( in );   // int             24
   TIME =         read_as<double>  ( in );   // double          28
   saved_DELT =   read_as<double>  ( in );   // double          36
   saved_TMPR0 =  read_as<double>  ( in );   // double          44
   saved_LBOX =   read_as<double>  ( in );   // double          52
   saved_RCUT_LJ =read_as<double>  ( in );   // double          60
   (void)   read_as<double>  ( in );         // Not used        68
   (void)   read_as<double>  ( in );         // Not used        76
   (void)   read_as<int32_t> ( in );         // int             84 // Successful saving flag, used by mdconfig
   saved_NMOL2 =  read_as<int32_t> ( in );   // int             88
   
   ORIGINAL_SEED = SEED ^ MASK;
   

   if ( saved_NMOL1 != SimSystem.all_molecules1.size() ) {
      std::cout << InchekWarn << " saved NMOL1 = " << saved_NMOL1 << " new NMOL1 = " << SimSystem.all_molecules1.size() << std::endl;
      Error     << InchekWarn << " saved NMOL1 = " << saved_NMOL1 << " new NMOL1 = " << SimSystem.all_molecules1.size() << std::endl;
      exit ( EXIT_FAILURE );
   }
   if ( saved_NMOL2 != SimSystem.all_molecules2.size() ) {
      std::cout << InchekWarn << " saved NMOL2 = " << saved_NMOL2 << " new NMOL2 = " << SimSystem.all_molecules2.size() << std::endl;
      Error     << InchekWarn << " saved NMOL2 = " << saved_NMOL2 << " new NMOL2 = " << SimSystem.all_molecules2.size() << std::endl;
      exit ( EXIT_FAILURE );
   }
   if ( saved_NION_A != SimSystem.all_anions.size() ) {
      std::cout << InchekWarn << " saved NION_A = " << saved_NION_A << " new NION_A = " << SimSystem.all_anions.size() << std::endl;
      Error     << InchekWarn << " saved NION_A = " << saved_NION_A << " new NION_A = " << SimSystem.all_anions.size() << std::endl;
      exit ( EXIT_FAILURE );
   }
   if ( saved_NION_C != SimSystem.all_cations.size() ) {
      std::cout << InchekWarn << " saved NION_C = " << saved_NION_C << " new NION_C = " << SimSystem.all_cations.size() << std::endl;
      Error     << InchekWarn << " saved NION_C = " << saved_NION_C << " new NION_C = " << SimSystem.all_cations.size() << std::endl;
      std::exit ( EXIT_FAILURE );
   }
   if ( fabs(saved_DELT - DELT)/DELT > 0.0001 ) {
      std::cout << " Warning - current DELT = " << DELT << " saved DELT = " << saved_DELT << std::endl;
      Message   << " Warning - current DELT = " << DELT << " saved DELT = " << saved_DELT << std::endl;
   }

   if ( fabs(saved_TMPR0 - TMPR0) > 0.001 ) {
      std::cout << " Warning - current TMPR0 = " << TMPR0 << " saved TMPR0 = " << saved_TMPR0 << std::endl;
      Message   << " Warning - current TMPR0 = " << TMPR0 << " saved TMPR0 = " << saved_TMPR0 << std::endl;
   }

   if ( fabs(saved_RCUT_LJ - RCut.LJ) > 0.0001) {
      std::cout << " Warning - current RCut.LJ = " << RCut.LJ << " saved RCUT_LJ = " << saved_RCUT_LJ << std::endl;
      Message   << " Warning - current RCut.LJ = " << RCut.LJ << " saved RCUT_LJ = " << saved_RCUT_LJ << std::endl;
   }

   if ( fabs(saved_LBOX - LBOX) > 0.0001 ) {
      if ( KSV != 2 ) { // not NPT simulation, use LBOX from fint.dat
         Message << "Warning: saved LBOX = " << saved_LBOX << ", new LBOX = " << LBOX;
         Message << ", but simulation type is not NPT" << std::endl;
         LBOX = LBOXinit;
         setBoxSizeVariables();
         Message << "Using LBOX = LBOXinit = " << LBOX << ", DENS = " << DENS << std::endl;
      }
      if ( KSV == 2 ) { // NPT, use LBOX from co_in.dat file
         LBOX = saved_LBOX;
         setBoxSizeVariables();
      }
   }
    
   char buffer[MolNameLen+1];
   for ( int f = 0; f < 3; f++ ) { // ignore particles names
      in.read ( buffer, sizeof(char) * MolNameLen );
   }
   
   for ( auto p: SimSystem.all_particles ) {
      p->read_v2_0 ( in );
   }
}

static void ReadConf_v2_18 ( int ver, int sver ) {
   int saved_NMOL1  = 0;
   int saved_NMOL2  = 0;
   int saved_NION_C = 0;
   int saved_NION_A = 0;
   double saved_DELT = 0;
   double saved_TMPR0 = 0;
   double saved_RCUT_LJ = 0;
   double saved_LBOX = 0;
   
   int32_t SEED = 0;
   
   std::ifstream in ( Co_inFileName, std::ios::binary | std::ios::in );
   if ( !in ) {
      Error << UnOpen << Co_inFileName << std::endl;
      std::exit ( EXIT_FAILURE );
   }
   
   switch ( version::check_ver_as ( in, ver, sver ) ) {
      case version::ok:
         break;
      case version::version_failure:
      case version::sub_ver_failure:
         std::cerr << '\a' << "input file version error, try to use -v option\n";
         Error << "input file version error, try to use -v option\n";
      default:
         std::exit ( EXIT_FAILURE );
   }
   
                                             // type      position
   NSTTOT =       read_as<int32_t> ( in );   // int              8
   saved_NMOL1 =  read_as<int32_t> ( in );   // int             12
   saved_NION_C = read_as<int32_t> ( in );   // int             16
   saved_NION_A = read_as<int32_t> ( in );   // int             20
   SEED =         read_as<int32_t> ( in );   // int             24
   TIME =         read_as<double>  ( in );   // double          28
   saved_DELT =   read_as<double>  ( in );   // double          36
   saved_TMPR0 =  read_as<double>  ( in );   // double          44
   saved_LBOX =   read_as<double>  ( in );   // double          52
   saved_RCUT_LJ =read_as<double>  ( in );   // double          60
   (void)   read_as<double>  ( in );         // Not used        68
   (void)   read_as<double>  ( in );         // Not used        76
   (void)   read_as<int32_t> ( in );         // int             84 // Successful saving flag, used by mdconfig
   saved_NMOL2 =  read_as<int32_t> ( in );   // int             88
   
   ORIGINAL_SEED = SEED ^ MASK;
   

   if ( saved_NMOL1 != SimSystem.all_molecules1.size() ) {
      std::cout << "Error: saved NMOL1 = " << saved_NMOL1 << " new NMOL1 = " << SimSystem.all_molecules1.size() << std::endl;
      Error     << "Error: saved NMOL1 = " << saved_NMOL1 << " new NMOL1 = " << SimSystem.all_molecules1.size() << std::endl;
      exit ( EXIT_FAILURE );
   }
   if ( saved_NMOL2 != SimSystem.all_molecules2.size() ) {
      std::cout << "Error: saved NMOL2 = " << saved_NMOL2 << " new NMOL2 = " << SimSystem.all_molecules2.size() << std::endl;
      Error     << "Error: saved NMOL2 = " << saved_NMOL2 << " new NMOL2 = " << SimSystem.all_molecules2.size() << std::endl;
      exit ( EXIT_FAILURE );
   }
   if ( saved_NION_A != SimSystem.all_anions.size() ) {
      std::cout << "Error: saved NION_A = " << saved_NION_A << " new NION_A = " << SimSystem.all_anions.size() << std::endl;
      Error     << "Error: saved NION_A = " << saved_NION_A << " new NION_A = " << SimSystem.all_anions.size() << std::endl;
      exit ( EXIT_FAILURE );
   }
   if ( saved_NION_C != SimSystem.all_cations.size() ) {
      std::cout << "Error: saved NION_C = " << saved_NION_C << " new NION_C = " << SimSystem.all_cations.size() << std::endl;
      Error     << "Error: saved NION_C = " << saved_NION_C << " new NION_C = " << SimSystem.all_cations.size() << std::endl;
      std::exit ( EXIT_FAILURE );
   }
   
   if ( fabs(saved_DELT - DELT)/DELT > 0.0001 ) {
      std::cout << " Warning - current DELT = " << DELT << " saved DELT = " << saved_DELT << std::endl;
      Message   << " Warning - current DELT = " << DELT << " saved DELT = " << saved_DELT << std::endl;
   }

   if ( fabs(saved_TMPR0 - TMPR0) > 0.001 ) {
      std::cout << " Warning - current TMPR0 = " << TMPR0 << " saved TMPR0 = " << saved_TMPR0 << std::endl;
      Message   << " Warning - current TMPR0 = " << TMPR0 << " saved TMPR0 = " << saved_TMPR0 << std::endl;
   }

   if ( fabs(saved_RCUT_LJ - RCut.LJ) > 0.0001) {
      std::cout << " Warning - current RCut.LJ = " << RCut.LJ << " saved RCUT_LJ = " << saved_RCUT_LJ << std::endl;
      Message   << " Warning - current RCut.LJ = " << RCut.LJ << " saved RCUT_LJ = " << saved_RCUT_LJ << std::endl;
   }

   if ( fabs(saved_LBOX - LBOX) > 0.0001 ) {
      if ( KSV != 2 ) { // not NPT simulation, use LBOX from fint.dat
         Message << "Warning: saved LBOX = " << saved_LBOX << ", new LBOX = " << LBOX;
         Message << ", but simulation type is not NPT" << std::endl;
         LBOX = LBOXinit;
         setBoxSizeVariables();
         Message << "Using LBOX = LBOXinit = " << LBOX << ", DENS = " << DENS << std::endl;
      }
      if ( KSV == 2 ) { // NPT, use LBOX from co_in.dat file
         LBOX = saved_LBOX;
         setBoxSizeVariables();
      }
   }
    
   char buffer[MolNameLen+1];
   for ( int f = 0; f < 3; f++ ) { // ignore particles names
      in.read ( buffer, sizeof(char) * MolNameLen );
   }
   
   for ( auto p: SimSystem.all_particles ) {
      p->read_v2_0 ( in );
   }
}


/*    =======================================================
      SUBROUTINE WRITE(nt,t)
      =======================================================
      writes in file co_out.dat
      =======================================================
*/
static void WriteConf_v2_18 ( ) {
   const int32_t SEED = ORIGINAL_SEED ^ MASK;
   
   std::ofstream out ( Co_outFileName, std::ios::binary | std::ios::out | std::ios::trunc );
   if ( !out ) {
       Error << UnOpen  << Co_outFileName << std::endl;
       std::exit ( EXIT_FAILURE );
   }
   
                                       // type      position
   version::out ( out );               // 2*int32_t        0
   write_as<int32_t> ( out, NSTTOT );  // int              8
   write_as<int32_t> ( out, SimSystem.all_molecules1.size() ); // int             12
   write_as<int32_t> ( out, SimSystem.all_cations.size() );    // int             16
   write_as<int32_t> ( out, SimSystem.all_anions.size() );     // int             20
   write_as<int32_t> ( out, SEED );    // int             24
   write_as<double>  ( out, TIME );    // double          28
   write_as<double>  ( out, DELT );    // double          36
   write_as<double>  ( out, TMPR0 );   // double          44
   write_as<double>  ( out, LBOX );    // double          52
   write_as<double>  ( out, RCut.LJ ); // double          60
   write_as<double>  ( out, 0.0 );     // Not used        68
   write_as<double>  ( out, 0.0 );     // Not used        76
   write_as<int32_t> ( out, 0 );       // int             84 // set saving completeness flag to false
   write_as<int32_t> ( out, SimSystem.all_molecules2.size() );  // int             88
   
   static const char empty_name[MolNameLen] = "";
   static char name_buffer[MolNameLen];
   
   if ( SimSystem.molecule_types.size() > 0 ) {
      strncpy (name_buffer, SimSystem.molecule_types[0]->name().c_str(), MolNameLen);
      out.write ( name_buffer, sizeof(name_buffer) );
   } else {
      out.write ( empty_name, sizeof(char) * MolNameLen );
   }
   if ( SimSystem.cation_types.size() > 0 ) {
      strncpy (name_buffer, SimSystem.cation_types[0]->name().c_str(), MolNameLen);
      out.write ( name_buffer, sizeof(name_buffer) );
   } else {
      out.write ( empty_name, sizeof(char) * MolNameLen );
   }
   if ( SimSystem.anion_types.size() > 0 ) {
      strncpy (name_buffer, SimSystem.anion_types[0]->name().c_str(), MolNameLen);
      out.write ( name_buffer, sizeof(name_buffer) );
   } else {
      out.write ( empty_name, sizeof(char) * MolNameLen );
   }

   for ( auto p: SimSystem.all_particles ) {
      p->save_v2_0 ( out );
   }
}



struct version_association {
   int major_version;
   int minor_version;
   void (*legal_read_function) ( int, int );
};

void ReadConf () {
   static const std::vector<version_association> read_functions_table = {
      { 2,13, &ReadConf_v2_13 },
      { 2,14, &ReadConf_v2_13 },
      { 2,15, &ReadConf_v2_13 },
      { 2,16, &ReadConf_v2_13 },
      { 2,17, &ReadConf_v2_17 },
      { 2,18, &ReadConf_v2_18 },
   };

   if ( CO_IN_VERSION == 0 ) {
      std::ifstream in ( Co_inFileName, std::ios::binary | std::ios::in );
      if ( !in ) {
         Error << UnOpen << Co_inFileName << std::endl;
         std::exit ( EXIT_FAILURE );
      }

      const auto [v,sv] = version::read_ver ( in );

      if ( v == 0 && sv == 0 ) {
         Error << "cannot read version information from file " << Co_inFileName << std::endl;
         std::exit ( EXIT_FAILURE );
      }

      CO_IN_VERSION = v;
      CO_IN_SUBVER  = sv;
   }

   if ( CO_IN_VERSION != version::Version() || CO_IN_SUBVER != version::SubVer() ) {
      Message   << " Reading co_in file of version " << CO_IN_VERSION << "." << CO_IN_SUBVER << "\n";
      std::cout << " Reading co_in file of version " << CO_IN_VERSION << "." << CO_IN_SUBVER << "\n";
   }

   for ( const auto& elem: read_functions_table ) {
      if ( elem.major_version == CO_IN_VERSION && elem.minor_version == CO_IN_SUBVER ) {
         elem.legal_read_function ( CO_IN_VERSION, CO_IN_SUBVER );
         return;
      }
   }

   Error << "cannot find legal function for reading input config file\nof version, specified by -v option as ";
   Error << CO_IN_VERSION << "." << CO_IN_SUBVER << std::endl;
   std::cerr << "\ncannot find legal function for reading config file";
   std::exit ( EXIT_FAILURE );
}

void WriteConf () {
   WriteConf_v2_18 ();
}
