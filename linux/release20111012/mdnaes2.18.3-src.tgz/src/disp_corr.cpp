#include "globals.h"
#include "all_particles.h"
#include "interactions.h"

void calc_disp_corrections () {
   size_t i, j; // particle id's
   int a, b; // atom indexes

   for ( i = 0; i < MAX_PARTICLE_TYPES; ++i ) {
      for ( j = 0; j < MAX_PARTICLE_TYPES; ++j ) {
         Therm_values.dcU[i][j] = 0.0;
         Therm_values.dcVIR[i][j] = 0.0;
      }
   }

   std::vector<std::pair<const particle_type*,std::size_t> > all_types;
   for ( std::size_t i = 0;  i < SimSystem.molecules.size(); ++i ) {
      const std::size_t npart = SimSystem.molecules[i].size();
      if ( npart > 0 ) {
         const particle_type *t = SimSystem.molecule_types[i].get();
         all_types.emplace_back ( std::pair{t,npart} );
      }
   }
   for ( std::size_t i = 0;  i < SimSystem.cations.size(); ++i ) {
      const std::size_t npart = SimSystem.cations[i].size();
      if ( npart > 0 ) {
         const particle_type *t = SimSystem.cation_types[i].get();
         all_types.emplace_back ( std::pair{t,npart} );
      }
   }
   for ( std::size_t i = 0;  i < SimSystem.anions.size(); ++i ) {
      const std::size_t npart = SimSystem.anions[i].size();
      if ( npart > 0 ) {
         const particle_type *t = SimSystem.anion_types[i].get();
         all_types.emplace_back ( std::pair{t,npart} );
      }
   }
   
   /* For every particle type pair (i,j) with i<j,
    * dispersion correction is
    * Ni*Nj/V * 1/2*Sum_a*Sum_b(integral for atoms a and b: int(4*Pi*r*r*U(r)dr);
    */

   for ( std::size_t i = 0; i < all_types.size(); ++i ) {
      const particle_type *t1 = all_types[i].first;
      const std::size_t N1 = all_types[i].second;
      for ( std::size_t j = i; j < all_types.size(); ++j ) {
         const particle_type *t2 = all_types[j].first;
         const std::size_t N2 = all_types[j].second;

         double U = 0.0, VIR = 0.0;
         for ( std::size_t a = 0; a < t1->natoms(); ++a ) {
            const int at1id = t1->get_atom_type(a).id();
            for ( std::size_t b = 0; b < t2->natoms(); ++b ) {
               const int at2id = t2->get_atom_type(b).id();

               const int IJ = at1id*Atom_types.size() + at2id;
               U += N1*N2/VOLBOX/2.0 * all_interactions[IJ]->DC_energy(RCut.LJ);
               VIR += N1*N2/VOLBOX/2.0 * all_interactions[IJ]->DC_virial(RCut.LJ);
            }
         }

         // to obtain dispersion correction for par (i,j) with i!=j use dcU[i][j]+dcU[j][i];
         Therm_values.dcU[t1->id()][t2->id()] = U;
         Therm_values.dcVIR[t1->id()][t2->id()] = VIR;
      }
   }
}
