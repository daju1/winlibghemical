#include "LMolCF.h"

#include <vector>
#include <memory>

#include "corr_aux.h"
#include "corclass.h"
#include "corclass_utils.h"
#include "correl.h"
#include "globals.h"
#include "iomanager.h"
#include "lib/mdformat.h"
using namespace mdnaes;

// ==================================== Long Molecular CF ====================================
static const char *LongMolCFFileName    = "LMolCF.cf";
static const char *LongMolCFResFileName = "LMolCF.dat";
static const char *CDifMolCFResFileName = "R(t)Mol.dat";

int KDipMom;
int KMainVect;
int KDipBox;

int KMol_Axes; // Ex, Ey and Ez
int KMol_RCM;  // <|R(t)|> and <|R(t)|^2>

static iomanager LongMolCF_IOManager ( LongMolCFFileName );


static vect DipMom_calc ( molecule* part ) {
   vect res = part->getDipolMomentum ();
   res.normate();
   return res;
}

static vect MainVect_calc ( molecule* part ) {
   vect res = part->getMainVect ();
   res.normate();
   return res;
}

static vect DipBox_calc () {
   const double Rmax2 = LBOX*LBOX/4;
   vect M ( 0.0 );

   for ( auto p_mol: SimSystem.all_molecules ) {
      vect RCM = p_mol->getCMPos();
      PBC (RCM);
      if ( RCM*RCM < Rmax2 )
         M += p_mol->getDipolMomentum ();
   }

   return M;
}

static vect eX_calc ( molecule* part ) {
   vect axes[3];
   part->getMolAxes ( axes );
   return axes[0];
}

static vect eY_calc ( molecule* part ) {
   vect axes[3];
   part->getMolAxes ( axes );
   return axes[1];
}

static vect eZ_calc ( molecule* part ) {
   vect axes[3];
   part->getMolAxes ( axes );
   return axes[2];
}

static vect CMPos_calc ( molecule* part ) {
   return part->getUnPBC_CMPos ();
}

static void SaveLongMolCF ();
static void ResultLongMolCF ();

static std::unique_ptr<HA_Allocator<double> > dbl_HA_allocator;
static std::unique_ptr<HA_Allocator<vect> >  vect_HA_allocator;

static std::vector<std::unique_ptr<base_history_array> > longMolCF_history_arrays;
static std::vector<std::unique_ptr<TDF> > longMolCF_TDFs;
static std::vector<std::unique_ptr<TDF> > longMolABSDispl;
static std::vector<std::unique_ptr<TDF> > longMolSQRDispl;

static std::unique_ptr<TDF> longMolCF_MM;

static int lmolcf_nthreads = 1;

static void LongMolCF_init () {
   dbl_HA_allocator  = std::make_unique<HA_Allocator<double> > (CorrelSize, 200);
   vect_HA_allocator = std::make_unique<HA_Allocator<vect> >   (CorrelSize, 300);
   
   const mdformat format(11,5);

   multiple_value_history_array_creator<vect,molecule*> DipMom   ( "DipMom",   *vect_HA_allocator, DipMom_calc,   longMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> MainVect ( "MainVect", *vect_HA_allocator, MainVect_calc, longMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> eX ( "eX", *vect_HA_allocator, eX_calc, longMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> eY ( "eY", *vect_HA_allocator, eY_calc, longMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> eZ ( "eZ", *vect_HA_allocator, eZ_calc, longMolCF_history_arrays );
   multiple_value_history_array_creator<vect,molecule*> CMPos ( "CMPos", *vect_HA_allocator, CMPos_calc, longMolCF_history_arrays );
   single_value_history_array_creator<vect> DipBox   ( "DipBox", *vect_HA_allocator, DipBox_calc, longMolCF_history_arrays );

   using mol_ABS_Displ_creator = single_molecule_ACF_creator<double,vect,molecule*,tcf::R1>;
   using mol_SQR_Displ_creator = single_molecule_ACF_creator<double,vect,molecule*,tcf::R2>;
   using mol_ACFP1_creator = single_molecule_ACF_creator<double,vect,molecule*,tcf::Legendre1>;
   using mol_ACFP2_creator = single_molecule_ACF_creator<double,vect,molecule*,tcf::Legendre2>;
   
   mol_ACFP1_creator Cmm ( "Cmm", DipMom,   format );
   mol_ACFP1_creator Cab ( "Cab", MainVect, format );
   mol_ACFP1_creator CeX ( "CeX", eX, format );
   mol_ACFP1_creator CeY ( "CeY", eY, format );
   mol_ACFP1_creator CeZ ( "CeZ", eZ, format );
   mol_ACFP2_creator CmmP2 ( "CmmP2", DipMom,   format );
   mol_ACFP2_creator CabP2 ( "CabP2", MainVect, format );
   mol_ACFP2_creator CeXP2 ( "CeXP2", eX, format );
   mol_ACFP2_creator CeYP2 ( "CeYP2", eY, format );
   mol_ACFP2_creator CeZP2 ( "CeZP2", eZ, format );

   mol_ABS_Displ_creator R1 ( "R1(t)", CMPos, mdformat(14,5) );
   mol_SQR_Displ_creator R2 ( "R2(t)", CMPos, mdformat(14,5) );

   single_value_ACF_creator<double,vect> CMM ( "MM", DipBox, format );


   Message << "starting long CF calculation for molecules by shells" << std::endl;

   create_from_shells (KDipMom, Cmm, longMolCF_TDFs, lmolcf_nthreads);
   create_from_shells (KDipMom && KLegendre, CmmP2, longMolCF_TDFs, lmolcf_nthreads);
   
   create_from_shells (KMainVect, Cab, longMolCF_TDFs, lmolcf_nthreads);
   create_from_shells (KMainVect && KLegendre, CabP2, longMolCF_TDFs, lmolcf_nthreads);
   
   create_from_shells_if (KMol_Axes, CeX, longMolCF_TDFs, shape_general<molecule>, lmolcf_nthreads);
   create_from_shells_if (KMol_Axes, CeY, longMolCF_TDFs, shape_general<molecule>, lmolcf_nthreads);
   create_from_shells_if (KMol_Axes, CeZ, longMolCF_TDFs, shape_general<molecule>, lmolcf_nthreads);
   create_from_shells_if (KMol_Axes && KLegendre, CeXP2, longMolCF_TDFs, shape_general<molecule>, lmolcf_nthreads);
   create_from_shells_if (KMol_Axes && KLegendre, CeYP2, longMolCF_TDFs, shape_general<molecule>, lmolcf_nthreads);
   create_from_shells_if (KMol_Axes && KLegendre, CeZP2, longMolCF_TDFs, shape_general<molecule>, lmolcf_nthreads);

   if ( KDipBox ) {
      longMolCF_MM = CMM.create();
   }

   create_from_shells (KMol_RCM, R1, longMolABSDispl, lmolcf_nthreads);
   create_from_shells (KMol_RCM, R2, longMolSQRDispl, lmolcf_nthreads);


   for ( const auto& p: longMolCF_history_arrays ) {
      LongMolCF_IOManager.add ( p.get() );
   }

   for ( const auto& p: longMolCF_TDFs ) {
      LongMolCF_IOManager.add ( p.get() );
   }

   for ( const auto& p: longMolABSDispl ) {
      LongMolCF_IOManager.add ( p.get() );
   }
   for ( const auto& p: longMolSQRDispl ) {
      LongMolCF_IOManager.add ( p.get() );
   }
   
   if ( longMolCF_MM ) {
      LongMolCF_IOManager.add ( longMolCF_MM.get() );
   }

   if ( KLH ) {
      Message << "reading long molecular CF from file...";
      LongMolCF_IOManager.read ();
      Message << " done" << std::endl;
   }

   SMan.AddFun ( &SaveLongMolCF );
   ShowRes.AddFun ( &ResultLongMolCF );

}

void LongMolCF_Calc () {
   static int init = 1;
   if ( init ) {
      LongMolCF_init ();
      init = 0;
   }

   for ( const auto& p: longMolCF_history_arrays ) {
      p->update ( );
   }

   for ( const auto& p: longMolCF_TDFs ) {
      p->update ( );
   }
   for ( const auto& p: longMolABSDispl ) {
      p->update ( );
   }
   for ( const auto& p: longMolSQRDispl ) {
      p->update ( );
   }

   if ( longMolCF_MM ) {
      longMolCF_MM->update ();
   }
}

static void SaveLongMolCF () {
   LongMolCF_IOManager.save ();
}

static void ResultLongMolCF () {
   if ( longMolSQRDispl.size() > 0 )
      Message << "Diffusion coefficients, obtained from CM displacements by shells:" << std::endl;
   
   for ( const auto& p: longMolSQRDispl ) {
      p->print_header ( Message );
      if ( !p->empty() ) {
         Message << mdformat(12,5) << calc_CDif_SQR( dynamic_cast<TTDF<double>*>(p.get()), DELT*StepLongCF );
      }
      else {
         Message << mdformat(12,5) << "--";
      }
      Message << " * 1e-9 m^2/s" << std::endl;
   }
   
   for ( const auto& p: longMolABSDispl ) {
      p->print_header ( Message );
      if ( !p->empty() ) {
         Message << mdformat(12,5) << calc_CDif_ABS( dynamic_cast<TTDF<double>*>(p.get()), DELT*StepLongCF );
      }
      else {
         Message << mdformat(12,5) << "--";
      }
      Message << " * 1e-9 m^2/s" << std::endl;
   }

   if ( longMolCF_MM ) {
      longMolCF_TDFs.emplace_back (std::move(longMolCF_MM));
   }
   PrintTDFRes ( longMolCF_TDFs, LongMolCFResFileName, StepLongCF );

   std::vector<TDF*> AllDispl;
   for ( const auto& p: longMolABSDispl )
      AllDispl.push_back ( p.get() );
   for ( const auto& p: longMolSQRDispl )
      AllDispl.push_back ( p.get() );
   
   PrintTDFRes ( AllDispl, CDifMolCFResFileName, StepLongCF );
}
