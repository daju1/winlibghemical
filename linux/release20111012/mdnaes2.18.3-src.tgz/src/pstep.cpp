#include "pstep.h"
#include "globals.h"
#include "all_particles.h"
#include "units.h"
#include "init.h"

#include <iostream>
#include <iomanip>
#include <cmath>
#include <vector>
#include <cstddef>
#include <string>

namespace mdnaes {
// ============================================================================
class averager {
   const std::string name;
   const int width;
   const int precision;
   int tot_step = 0;
   int cur_step = 0;
   double tot_sum = 0;
   double tot_sqr_sum = 0;
   double cur_sum = 0;
   double cur_val = 0;
public:
   averager ( const char *nm, int w, int p ) : name(nm), width(w), precision(p) {}
  ~averager ( ) {}

   void save ( std::ostream& out ) const;
   void read ( std::istream& in );

   void add_val ( double val );
   void reset_cur_mean ( );

   void print_name     ( std::ostream& );
   void print_val      ( std::ostream& );
   void print_cur_mean ( std::ostream& );
   void print_tot_mean ( std::ostream& );
   void print_sigma    ( std::ostream& );
};

// ============================================================================
class mean_val_collection {
   std::vector<averager*> data;
public:
   mean_val_collection ( );
  ~mean_val_collection ( ) { }

   void add_elem ( averager * );

   void save ( std::ostream& ) const;
   void read ( std::istream& );

   void print_res ( std::ostream& , void (averager::*) ( std::ostream& ) );
   void reset_cur_mean ( );
};

} // end of namespace mdnaes


namespace mdnaes {
// ============================================================================
void averager::save ( std::ostream& out ) const {
   out.write ( (char*)&tot_step, sizeof (tot_step) );
   out.write ( (char*)&cur_step, sizeof (cur_step) );
   out.write ( (char*)&tot_sum,  sizeof (tot_sum)  );
   out.write ( (char*)&cur_sum,  sizeof (cur_sum)  );
   out.write ( (char*)&cur_val,  sizeof (cur_val)  );
   out.write ( (char*)&tot_sqr_sum,  sizeof (tot_sqr_sum)  );
}

void averager::read ( std::istream& in ) {
   in.read ( (char*)&tot_step, sizeof (tot_step) );
   in.read ( (char*)&cur_step, sizeof (cur_step) );
   in.read ( (char*)&tot_sum,  sizeof (tot_sum)  );
   in.read ( (char*)&cur_sum,  sizeof (cur_sum)  );
   in.read ( (char*)&cur_val,  sizeof (cur_val)  );
   in.read ( (char*)&tot_sqr_sum,  sizeof (tot_sqr_sum)  );
}

void averager::add_val ( double val ) {
   cur_val = val;
   cur_sum += cur_val;
   tot_sum += cur_val;
   tot_sqr_sum += cur_val * cur_val;

   cur_step++;
   tot_step++;
}

void averager::reset_cur_mean ( ) {
   cur_sum = 0.0;
   cur_step = 0;
}

void averager::print_name ( std::ostream& out ) {
   out << std::setw ( width ) << std::setprecision ( precision ) << name;
}
void averager::print_val ( std::ostream& out ) {
   out << std::setw ( width ) << std::setprecision ( precision ) << cur_val;
}
void averager::print_cur_mean ( std::ostream& out ) {
   out << std::setw ( width ) << std::setprecision ( precision ) << cur_sum / cur_step;
}
void averager::print_tot_mean ( std::ostream& out ) {
   out << std::setw ( width ) << std::setprecision ( precision ) << tot_sum / tot_step;
}
void averager::print_sigma ( std::ostream& out ) {
   double sqr_mean = tot_sqr_sum / tot_step;
   double tot_mean = tot_sum / tot_step;
   out << std::setw ( width ) << std::setprecision ( precision ) << std::sqrt ( sqr_mean - tot_mean*tot_mean );
}

// ===========================================================================
mean_val_collection::mean_val_collection ( ) : data() {
}

void mean_val_collection::add_elem ( averager *obj ) {
   data.push_back ( obj );
}

void mean_val_collection::save  ( std::ostream& out ) const {
   for ( auto p: this->data )
      p->save ( out );
}

void mean_val_collection::read ( std::istream& in ) {
   for ( auto p: this->data )
      p->read ( in );
}

void mean_val_collection::print_res ( std::ostream& out, void (averager::*fun) ( std::ostream& ) ) {
   for ( auto p: this->data )
      (p->*fun) ( out );
}

void mean_val_collection::reset_cur_mean ( ) {
   for ( auto p: this->data )
      p->reset_cur_mean ( );
}

} // end of namespace mdnaes


/* =================================================================================== *
 * ====================================== PSTEP ====================================== *
 * =================================================================================== */
using namespace mdnaes;

static const char *StatFileName = "stat.sav";

static mean_val_collection P_Res;
static mean_val_collection C_Res;

static void SaveStat ( ) {
   std::ofstream out ( StatFileName, std::ios::binary | std::ios::out | std::ios::trunc );
   P_Res.save ( out );
}

void PSTEP ( int step ) {
   static bool init = true;
   static int EndStep = NSTTOT + NSTRUN - 1;

   static averager Utot_m   ("Utot", 10, 1);
   static averager Tmpr_m   ("Tmpr",  9, 3);
   static averager Ttrans_m ("Ttrans",9, 3);
   static averager Trot_m   ("Trot",  9, 3);
   static averager Pres_m   ("Pres",  9, 3);
   static averager Umol_m   ("Umol",  9, 3); // Potential energy of intermolecular interactions for dHvap calculations
   static averager Usolv_m  ("Usolv", 9, 3);
   static averager Ekin_m   ("Ekin",  7, 3);
   static averager MM_m     ("M^2/V", 9, 1);
   static averager UpotKat_m ("UpotKat", 9, 3);
   static averager EkinKat_m ("EkinKat", 8, 3);
   static averager UpotAn_m  ("UpotAn",  9, 3);
   static averager EkinAn_m  ("EkinAn",  7, 3);
   static averager UpotKA_m  ("UpotKA", 12, 3);

   static averager Dens_m    ("d,kg/m3",  10, 2);
   static averager current_m  ("J,A/m^2", 15, 1);
   static averager DipMom_m   ("DipMom",  10, 3);

   static averager Unb_intra_m ("Unb_in",9,1);
   static averager Ubond_m ("Ubond",8,1);
   static averager Uangle_m ("Uangle",8,1);
   static averager Udihedral_m ("Udih",8,1);
   static averager Udihedral_2_m ("Udih2",8,1);
   static averager Uharmonic_dihedral_m ("Uharmdih",9,1);
   static averager H_m ("H", 10, 1);
   
   static averager UpotInter_m   ("UInter",  10, 2);
   static averager UpotIntra_m   ("UIntra",  10, 2);

   // dispersion corrections
   static averager PresDC_m   ("PresDC",  9, 3);
   static averager UpotDC_m   ("UpotDC",  8, 2);
   
   static averager sUpot_m   ("sUpot",  10, 3);
   static averager cUpot_m   ("cUpot",  11, 3);
   static averager Ekintot_m ("Ekintot",  10, 3);

   if ( init ) {
      P_Res.add_elem ( &Utot_m );
      P_Res.add_elem ( &Tmpr_m );
      P_Res.add_elem ( &Pres_m );
      P_Res.add_elem ( &MM_m );

      C_Res.add_elem ( &Utot_m );
      C_Res.add_elem ( &Tmpr_m );
      C_Res.add_elem ( &Pres_m );
      if ( SimSystem.nion_c() == 0 || SimSystem.nion_a() == 0 )
         C_Res.add_elem ( &MM_m );
      
      P_Res.add_elem ( &Dens_m );

      P_Res.add_elem ( &Ttrans_m );
      P_Res.add_elem ( &Trot_m );
      
      if ( SimSystem.nions() == 0 ) {
         P_Res.add_elem ( &Umol_m );
         //P_Res.add_elem ( &Ekin_m );

         C_Res.add_elem ( &Umol_m );
         //C_Res.add_elem ( &Ekin_m );
      }
      else {
         P_Res.add_elem ( &Usolv_m );
         C_Res.add_elem ( &Usolv_m );
      }

      if ( SimSystem.nion_c() > 0 && SimSystem.nion_a() > 0 ) {
         P_Res.add_elem ( &UpotKA_m );
         C_Res.add_elem ( &UpotKA_m );
      }
      
      if ( SimSystem.nion_c() > 0 ) {
         P_Res.add_elem ( &UpotKat_m );
         P_Res.add_elem ( &EkinKat_m );

         C_Res.add_elem ( &UpotKat_m );
         C_Res.add_elem ( &EkinKat_m );
      }
      if ( SimSystem.nion_a() > 0 ) {
         P_Res.add_elem ( &UpotAn_m );
         P_Res.add_elem ( &EkinAn_m );

         C_Res.add_elem ( &UpotAn_m );
         C_Res.add_elem ( &EkinAn_m );
      }
      
      P_Res.add_elem ( &DipMom_m );
      P_Res.add_elem ( &current_m );

      // !!!
      P_Res.add_elem ( &Unb_intra_m );
      P_Res.add_elem ( &Ubond_m );
      P_Res.add_elem ( &Uangle_m );
      P_Res.add_elem ( &Udihedral_m );
      P_Res.add_elem ( &Udihedral_2_m );
      P_Res.add_elem ( &Uharmonic_dihedral_m );
      P_Res.add_elem ( &UpotIntra_m );
      P_Res.add_elem ( &UpotInter_m );
      P_Res.add_elem ( &UpotDC_m );
      P_Res.add_elem ( &PresDC_m );
      // P_Res.add_elem ( &Upot_m );
      //P_Res.add_elem ( &Ekin_m );
      //P_Res.add_elem ( &H_m );
      // !!!
      P_Res.add_elem ( &sUpot_m );
      P_Res.add_elem ( &cUpot_m );
      P_Res.add_elem ( &Ekintot_m );

      if ( KStat ) {
         std::ifstream in ( StatFileName, std::ios::binary | std::ios::in );
         if ( in.good() )
            P_Res.read ( in );
         else
            Message << UnOpen << StatFileName << ", starting new statistics" << std::endl;
      }

      std::ofstream out ( ResFileName, std::ios::ate | std::ios::out | std::ios::app );
      out.flags ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
      out.precision ( 3 );

      printSimulatedSystemMessage ( out );

      out << std::setw ( 8 ) << "Step";
      P_Res.print_res ( out, &averager::print_name );
      out << std::endl;

      if ( !KScrOut && !NOSCRPRINT )
         std::cout << "Steps before the end of calculations: ";
      else {
         if ( !NOSCRPRINT ) {
            std::cout.flags ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
            std::cout.precision ( 3 );
            std::cout << " RCUT_LJ = " << RCut.LJ << ", Temperature = " << TMPR0;
            std::cout << "\n NMOL = " << SimSystem.nmol() << ", NION = " << SimSystem.nions() << std::endl;

            std::cout << std::setw ( 7 ) << "Step";
            C_Res.print_res ( std::cout, &averager::print_name );
            std::cout << std::endl;
         }
      }

      if ( KStat )
         SMan.AddFun ( &SaveStat );
      init = 0;
   }

   // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   double EkinTrans = 0, EkinRot = 0, MM = 0, Ttrans = 0, Trot = 0;

   for ( auto p: SimSystem.all_particles ) {
      EkinTrans += p->getEkinTrans ();
      EkinRot   += p->getEkinRot ();
   }

   int NDegFreeTrans = (SimSystem.npart() - 1) * 3;

   int NDegFreeRot = 0;
   for ( const auto& array: SimSystem.molecules ) {
      if ( array.size() > 0 ) {
         NDegFreeRot += array.size() * array[0]->nRotDegFree();
      }
   }
   for ( const auto& array: SimSystem.cations ) {
      if ( array.size() > 0 ) {
         NDegFreeRot += array.size() * array[0]->nRotDegFree();
      }
   }
   for ( const auto& array: SimSystem.anions ) {
      if ( array.size() > 0 ) {
         NDegFreeRot += array.size() * array[0]->nRotDegFree();
      }
   }

   if ( NDegFreeTrans == 0 ) NDegFreeTrans = 1; // test version
   if ( NDegFreeRot == 0 ) NDegFreeRot = 1;     // test version

   Ttrans = 2 * EkinTrans * ENERGY_UNIT / ( SI_Kbol * NDegFreeTrans );
   Trot   = 2 * EkinRot   * ENERGY_UNIT / ( SI_Kbol * NDegFreeRot );

   // calculate dipole momentum square for spherical cavity:
   const double Rmax2 = LBOX*LBOX/4;
   const vect O1 ( 0.0,      0.0,      0.0 );
   const vect O2 ( 0.5*LBOX, 0.5*LBOX, 0.5*LBOX );

   vect M1 (0.0), M2 (0.0);
   
   for ( auto p: SimSystem.all_molecules ) {
      vect r;
      r = p->getCMPos() - O1;
      PBC (r);
      if ( r*r < Rmax2 )
         M1 += p->getDipolMomentum ();
      
      r = p->getCMPos() - O2;
      PBC (r);
      if ( r*r < Rmax2 )
         M2 += p->getDipolMomentum ();
   }
   M1 *= DIPOLE_MOMENTUM_UNIT / SI_D; // Debye
   M2 *= DIPOLE_MOMENTUM_UNIT / SI_D; // Debye
   const vect M = 0.5*(M1+M2);
   MM = 0.5 * (M1*M1 + M2*M2);
   MM /= (4.0/3.0) * SI_PI * LBOX*LBOX*LBOX / 8.0; // in D^2/nm^3
   

   // calculate current density in Z-direction
   double Iz = 0.0;
   for ( auto p: SimSystem.all_ions )
      Iz += p->getCurrent().z;
   
   Iz /= VOLBOX; // current density
   Iz *= CHARGE_UNIT / TIME_UNIT / LENGTH_UNIT / LENGTH_UNIT; // to A/m^2
   // +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

   if ( true /*NSTTOT%LongStep == 0 || SPRNT == 1*/ ) {
      Utot_m.add_val   ( Therm_values.UT );
      Tmpr_m.add_val   ( TMPR );
      Ttrans_m.add_val ( Ttrans );
      Trot_m.add_val   ( Trot );
      Pres_m.add_val   ( PRES );
      MM_m.add_val     ( MM );
      Umol_m.add_val   ( (SimSystem.nions() == 0) ? Therm_values.Uinter / SimSystem.nmol() : 0.0 );
      Usolv_m.add_val   ( (SimSystem.nmol() == 0) ? 0.0 : (Therm_values.sUmm + Therm_values.cUmm) / SimSystem.nmol() );
      Ekin_m.add_val    ( (SimSystem.nmol() == 0) ? Therm_values.Ekin : Therm_values.EkinM / SimSystem.nmol() );
      UpotKat_m.add_val ( (SimSystem.nion_c() == 0) ? 0.0 :
      (Therm_values.sUmc + Therm_values.sUcc + Therm_values.sUca + Therm_values.cUmc + Therm_values.cUcc
      + Therm_values.cUca + Therm_values.dcUmc + Therm_values.dcUcc + Therm_values.dcUca) / SimSystem.nion_c() );
      EkinKat_m.add_val ( (SimSystem.nion_c() == 0) ? 0.0 : Therm_values.EkinC / SimSystem.nion_c() );
      UpotAn_m.add_val  ( (SimSystem.nion_a() == 0) ? 0.0 :
      (Therm_values.sUma + Therm_values.sUaa + Therm_values.sUca + Therm_values.cUma + Therm_values.cUaa
      + Therm_values.cUca + Therm_values.dcUma + Therm_values.dcUaa + Therm_values.dcUca) / SimSystem.nion_a() );
      EkinAn_m.add_val  ( (SimSystem.nion_a() == 0) ? 0.0 : Therm_values.EkinA / SimSystem.nion_a() );
      UpotKA_m.add_val  ( Therm_values.sUca + Therm_values.cUca + Therm_values.dcUca );
      
      Dens_m.add_val ( DENS );
      
      DipMom_m.add_val  ( M.z ); // Dipole momentum in Z-direction, D.
      current_m.add_val ( Iz );  // Current density in Z-direction, A/m^2.
      
      Unb_intra_m.add_val ( Therm_values.Unb_intra );
      Ubond_m.add_val ( Therm_values.Ubond ); 
      Uangle_m.add_val ( Therm_values.Uangle ); 
      Udihedral_m.add_val ( Therm_values.Udihedral ); 
      Udihedral_2_m.add_val ( Therm_values.Udihedral_2 ); 
      Uharmonic_dihedral_m.add_val ( Therm_values.Uharmonic_dihedral );
      
      UpotIntra_m.add_val ( Therm_values.Uintra );
      UpotInter_m.add_val ( Therm_values.Uinter );
      UpotDC_m.add_val ( Therm_values.dcUpot );
      PresDC_m.add_val ( (PRESSURE_UNIT / EXTERNAL_PRESSURE_UNIT) * Therm_values.dcVIRtot / (3*VOLBOX) );
      
      H_m.add_val ( Therm_values.Enthalpy );
      
      sUpot_m.add_val   ( Therm_values.sUpot );
      cUpot_m.add_val   ( Therm_values.cUpot );
      Ekintot_m.add_val   ( Therm_values.Ekin );
   }

   if ( !(step % SPRNT ) || step == EndStep ) {
      std::ofstream out ( ResFileName, std::ios::ate | std::ios::out | std::ios::app );
      out.flags ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );

      out << std::setw ( 8 ) << step;
      P_Res.print_res ( out, &averager::print_cur_mean );
      if ( KScrOut && !NOSCRPRINT ) {
         std::cout << std::setw ( 7 ) << step;
         C_Res.print_res ( std::cout, &averager::print_cur_mean );
         std::cout << std::endl;
      }
      P_Res.reset_cur_mean ( );
      out << std::endl;

      if ( step == EndStep ) {
         out << '\n' << std::setw ( 8 ) << "<X>";
         P_Res.print_res ( out, &averager::print_tot_mean );
         out << '\n' << std::setw ( 8 ) << "Sigma";
         P_Res.print_res ( out, &averager::print_sigma );
         out << std::endl;
         if ( KScrOut && !NOSCRPRINT ) {
            std::cout << '\n' << std::setw ( 7 ) << "<X>";
            C_Res.print_res ( std::cout, &averager::print_tot_mean );
            std::cout << '\n' << std::setw ( 7 ) << "Sigma";
            C_Res.print_res ( std::cout, &averager::print_sigma );
            std::cout << std::endl;
         }
      }
   }

   if ( !KScrOut && !NOSCRPRINT )
     std::cout << std::setw ( 8 ) << (EndStep-step) << "\b\b\b\b\b\b\b\b" << std::flush;
}
