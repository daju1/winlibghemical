#ifndef ALL_PARTICLES_H
#define ALL_PARTICLES_H

#include <vector>
#include <memory>

#include "molecule.h"
#include "ion.h"

struct simulated_system_t {
public:
   std::vector<std::unique_ptr<molecule_type> > molecule_types;
   std::vector<std::unique_ptr<ion_type> > cation_types;
   std::vector<std::unique_ptr<ion_type> > anion_types;
   
   std::vector<std::vector<std::unique_ptr<molecule> > > molecules;
   std::vector<std::vector<std::unique_ptr<ion> > > cations;
   std::vector<std::vector<std::unique_ptr<ion> > > anions;
   
public:
   std::vector<particle*> all_particles;
   
   std::vector<ion*> all_cations;
   std::vector<ion*> all_anions;
   std::vector<ion*> all_ions;
   
   std::vector<molecule*> all_molecules1;
   std::vector<molecule*> all_molecules2;
   std::vector<molecule*> all_molecules;
   
public:
   auto npart () const { return all_particles.size(); }
   auto nmol  () const { return all_molecules.size(); }
   auto nmol1 () const { return all_molecules1.size(); }
   auto nmol2 () const { return all_molecules2.size(); }
   auto nions () const { return all_ions.size(); }
   auto nion_c () const { return all_cations.size(); }
   auto nion_a () const { return all_anions.size(); }
   
   void print_atoms () const;
   void print_atoms ( int part_no ) const;
   
public:
   void add_molecule_type ( std::unique_ptr<molecule_type>&& typ );
   void add_cation_type   ( std::unique_ptr<ion_type>&& typ );
   void add_anion_type    ( std::unique_ptr<ion_type>&& typ );
   
   void syncronize_particle_arrays ();
   
public:
   double total_mass () const;
};

extern simulated_system_t SimSystem;

// ============================================================================

void ReadParams ();

#endif
