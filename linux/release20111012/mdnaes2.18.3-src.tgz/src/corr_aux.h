#ifndef COR_AUX_H
#define COR_AUX_H

#include "corclass.h"

#include <memory>

void PrintTDFRes ( const std::vector<std::unique_ptr<TDF> >& TDFs,
                   const char *filename,
                   int CorStep,
                   double factor = 1.0,
                   const std::string comment = "" );

void PrintTDFRes ( const std::vector<TDF*>& TDFs,
                   const char *filename,
                   int CorStep,
                   double factor = 1.0,
                   const std::string comment = "" );

#endif
