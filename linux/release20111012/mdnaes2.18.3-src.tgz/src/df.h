#if !defined M_DF
#define M_DF

extern int
    KRDF,      // Calculate RDF
    KDSHL,
    KCoorNum;

void StructFunctions ();

#endif
