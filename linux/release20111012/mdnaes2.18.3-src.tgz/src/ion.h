#ifndef ION_H
#define ION_H

#include <vector>
#include <memory>

#include "particle.h"

class ion;

class ion_type : public particle_type {
private:
   std::vector<std::vector<double> > coordinationCenterCoefs;

protected:
   ion_type ( mylist_const_iterator& );

public:
   virtual ~ion_type ();
   
   virtual std::unique_ptr<ion> create ( vect origin ) const = 0;
   virtual std::unique_ptr<ion> create ( const ion *src, vect cmpos ) const = 0;

   virtual std::vector<vect> calcCoordinationCenters ( const basic_particle& atoms ) const;
   virtual void print ( std::ostream& ) const;
};

// ============================================================================
class ion : public particle {
public:
   using type_t = ion_type;
protected:
   ion ( const ion_type *t, vect origin )
   : particle(t,origin), type(t) {}
   
   ion ( const ion &src, vect cmpos )
   : particle(src,cmpos), type(src.type) {}
   
public:
   std::vector<vect> getCoordinationCenters () const;

private:
   const ion_type *type;
};


#endif
