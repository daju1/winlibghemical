#ifndef DISTR_FUNC_H
#define DISTR_FUNC_H

#include <iosfwd>
#include <limits>
#include <cstdint>

// ======================= 2D distribution helper class =======================
class distrib_2D {
public:
   distrib_2D ( int Xdim, int Ydim );
   ~distrib_2D () { delete[] histogram; }

   void read ( std::istream& );
   void save ( std::ostream& ) const;

   int getXdim () const { return X_dimension; }
   int getYdim () const { return Y_dimension; }

   void add ( int x, int y );

   double get_value ( int x, int y ) const;
   double get_aveX () const; // average argument x value
   double get_aveY () const; // average argument y value
private:
   const int X_dimension;
   const int Y_dimension;
   unsigned long *histogram;
   uint_fast64_t total_count = 0;
};
// ============================================================================

// ======================= 1D distribution helper class =======================
class distrib_1D {
public:
   distrib_1D ( int Xdim );
   ~distrib_1D () { delete[] histogram; }

   void read ( std::istream& );
   void save ( std::ostream& ) const;

   int getXdim () const { return X_dimension; }

   void add ( int x );

   double get_value ( int x ) const;
   double get_aveX () const; // average argument x value
private:
   const int X_dimension;
   unsigned long *histogram;
   uint_fast64_t total_count = 0;
};
// ============================================================================

// ========================== aver_func helper class ==========================
class aver_func {
public:
   aver_func ( int nElem );
   ~aver_func () { delete[] data; delete[] count; }

   void read ( std::istream& );
   void save ( std::ostream& ) const;

   void add ( int i, double val );
   double get_value ( int i ) const;
   double operator [] ( int i ) const { return get_value(i); }
   bool has_value ( int i ) const;
private:
   const int n_elements;
   double *data;
   unsigned long *count;
};
// ============================================================================

#endif
