#include <cstring>

#include "iomanager.h"
#include "version.h"
#include "globals.h"

#include <fstream>

void iomanager::save () {
   const int numheaders = this->objects.size();
   head *header = new head[numheaders];

   std::ofstream out ( fname, std::ios::binary | std::ios::out | std::ios::in | std::ios::trunc );

   version::out ( out );

   out.write ( (char*)&numheaders, sizeof (int) );
   std::ofstream::pos_type headerpos = out.tellp ();

   out.write ( (char*)header, sizeof (head) * numheaders );

   for ( size_t i = 0; i < objects.size(); ++i ) {
      strncpy ( header[i].key, (objects[i]->getkey()).c_str(), 63 );
      header[i].pos = out.tellp ();
      objects[i]->save ( out );
   }

   out.seekp ( headerpos );
   out.write ( (char*)header, sizeof (head) * numheaders );

   out.close ();
   delete[] header;
}

void iomanager::read () {
   std::ifstream in ( fname, std::ios::binary | std::ios::in );
   if ( !in ) {
      Error << "Cannot open file " << fname << "\n";
      raise_md_exception ( "error in readmanager::read ()" );
   }

   version::check_ver ( in, "void readmanager::read ()" );

   int numheaders = -1;
   in.read ( (char*)&numheaders, sizeof (int) );
   if ( numheaders == -1 ) {
      Error << "Cannot read file " << fname << "\n";
      raise_md_exception ( "error in readmanager::read ()" );
   }

   head *header = new head[numheaders];

   in.read ( (char*)header, sizeof (head) * numheaders );

   for ( auto p: objects ) {
      int j;
      for ( j = 0; j < numheaders; ++j ) {
         if ( header[j].key == p->getkey () ) {
            in.seekg ( header[j].pos );
            p->read ( in );
            break;
         }
      }
      if ( j == numheaders )
         Error << "void readmanager::read () cannot find object " << p->getkey () << " in file " << fname << std::endl;
   }
   
   in.close ();
   delete[] header;
}
