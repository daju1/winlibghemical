#ifndef MOLECULAR_GEOMETRY_H
#define MOLECULAR_GEOMETRY_H

#include "lib/vect.h"

namespace mdnaes {

class dihedral {
public:
   dihedral ( const vect& r1, const vect& r2, const vect& r3, const vect& r4 );
   ~dihedral () {}

   double beta() const { return this->Beta; }
   double cosb() const { return this->CosB; }
   double sinb() const { return this->SinB; }

   const vect& grad1 () const { return this->g1; } // diff(beta,r1)
   const vect& grad2 () const { return this->g2; } // diff(beta,r2)
   const vect& grad3 () const { return this->g3; } // diff(beta,r3)
   const vect& grad4 () const { return this->g4; } // diff(beta,r4)

private:
   double CosB;
   double SinB;
   double Beta;

   // Beta gradients:
   vect g1;
   vect g2;
   vect g3;
   vect g4;
};

class angle {
public:
   angle ( const vect& r1, const vect& r2, const vect& r3 );
   ~angle () {}

   double alpha() const { return this->Alpha; }
   double cosa() const  { return this->CosA; }

   const vect& grad1 () const { return this->g1; } // diff(alpha,r1)
   const vect& grad2 () const { return this->g2; } // diff(alpha,r2)
   const vect& grad3 () const { return this->g3; } // diff(alpha,r3)

private:
   double CosA;
   double Alpha;

   // Alpha gradients:
   vect g1;
   vect g2;
   vect g3;
};

class distance {
public:
   distance ( const vect& r1, const vect& r2 );
   ~distance () {}

   double r()  const { return this->Dist; }
   double r2() const { return this->sqr_Dist; }

   const vect& grad1 () const { return this->g1; } // diff(r,r1)
   const vect& grad2 () const { return this->g2; } // diff(r,r2)

private:
   double Dist;
   double sqr_Dist;

   // Alpha gradients:
   vect g1;
   vect g2;
};

} // end of namespace mdnaes

#endif
