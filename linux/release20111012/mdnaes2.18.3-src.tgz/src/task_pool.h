#ifndef TASK_POOL_H
#define TASK_POOL_H

#include <mutex>

class task_pool {
public:
   int operator () () {
      std::lock_guard lock {this->m_guard};
      return index++;
   }

   void reset () { index = 0; }
private:
   std::mutex m_guard;
   int index = 0;
};

#endif
