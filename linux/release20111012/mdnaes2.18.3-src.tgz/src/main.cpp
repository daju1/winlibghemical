/* ======================================================
   | Copyright(c) by Departament Inorganic Chemistry of |
   | Kharkov National University 1997-2022              |
   ====================================================== */
#include "df.h"
#include "correl.h"
#include "insion.h"
#include "mestream.h"
#include "rwconf.h"
#include "init.h"
#include "globals.h"
#include "all_particles.h"
#include "force.h"
#include "units.h"
#include "lib/mdformat.h"
#include "miscprop.h"
#include "version.h"
#include "pstep.h"
#include "gro.h"
#include "task_pool.h"

using namespace mdnaes;

#include <cassert>
#include <cstring>
#include <cstdlib>
//#include <ctime>
#include <chrono>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cmath>
#include <thread>

// Define CC_SIGNAL_INCLUDE to include keyboard program terminator
//#define CC_SIGNAL_INCLUDE

static int BREAK_PROGRAM = 0;    // If you need to breake the program
                                 // in end of iteration of CYCLE
                                 // set this key to TRUE
static int NDegFree;             // Number of degrees of freedom


/* Other variables.
   This variable is defined here, because in "variable.h"
   they are declared as external.
*/

std::ofstream Message;

/* End other variables */

static void CSIZE   ();
static void Cycle   ();
static void THERM   ();
static void SCALV   ();
static void Barostat ();
static void IsoThermalBarostat ();
void SetPBoxToZero ();

// ============================================================================
int main ( int, char* argv[] ) {
   std::cout.flags ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
   std::cout.precision ( 3 );
   
   ReadCommandLine ( argv );
   
   Message.open ( LogFileName, std::ios::out | std::ios::trunc );
   Message.flags ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
   Message.precision ( 3 );
   Message << "         <<< MDNAES ";
   Message << version::Version () << '.' << version::SubVer () << '.' << version::Revision () << " >>>\n";
   Message << " Compiled: " << __DATE__ << "  " << __TIME__ << std::endl;
   
   read_fint ();
   
   for ( int i = 0; i < NTHREADS; ++i ) {
      TL_Therm_values.emplace_back ();
   }
   
   CONFIG ();
   if ( KRS ) {
      ReadConf ();
   }
   else {
      SetPBoxToZero ();
      ORIGINAL_SEED = CURRENT_SEED;
   }
   if ( KDBL ) {
      DUBL ( KDBL );
      SetPBoxToZero ();
   }
   
   if ( NumInsIon[0] || NumInsIon[1] ) {
      ins_ions ( NumInsIon[0], NumInsIon[1] );
      SetPBoxToZero ();
   }
   
   CSIZE ();
   for ( const auto& p: SimSystem.molecule_types )
      p->print ( Message );
   for ( const auto& p: SimSystem.cation_types )
      p->print ( Message );
   for ( const auto& p: SimSystem.anion_types )
      p->print ( Message );
   
   Message << "\nLBOX = " << LBOX << "\nLBOX/2 = " << LBOX2 << std::endl;

   
   if ( K_ImportGRO ) {
      const char *GRO_FileName = "conf.gro";
      
      std::ifstream gro_file ( GRO_FileName );
      
      if ( !gro_file ) {
         Error << "Cannot open gro file: " << GRO_FileName << "\n";
         std::cerr << "Cannot open gro file: " << GRO_FileName << "\n";
         std::exit ( EXIT_FAILURE );
      }
      
      std::cout << "Importing gro file: " << GRO_FileName << "\n";
      const int res = Import_gro ( gro_file );
      
      if ( 0 != res ) {
         Error << "Cannot read gro file: " << GRO_FileName << "\n";
         std::cerr << "Cannot read gro file: " << GRO_FileName << "\n";
         std::exit ( EXIT_FAILURE );
      }
      SetPBoxToZero ();
   }
   
   NDegFree  = 0;
   for ( int i = 0; i < SimSystem.molecule_types.size(); ++i ) {
      NDegFree  += SimSystem.molecules[i].size() * SimSystem.molecule_types[i]->nDegFree();
   }
   for ( int i = 0; i < SimSystem.cation_types.size(); ++i ) {
      NDegFree  += SimSystem.cations[i].size() * SimSystem.cation_types[i]->nDegFree();
   }
   for ( int i = 0; i < SimSystem.anion_types.size(); ++i ) {
      NDegFree  += SimSystem.anions[i].size() * SimSystem.anion_types[i]->nDegFree();
   }
   NDegFree -= 3; // Total system velocity (3 degrees of freedom) is fixed to be zero!
   
   if ( NDegFree == 0 )
      NDegFree = 1; // for testing usage!
      
      SMan.AddFun ( &WriteConf );
   
   {
      void Out_DLPOLY_Config ( const char *filename, int mode ); // declaration
      extern int DLPOLY_levcfg;
      if ( DLPOLY_levcfg != -1 )
         Out_DLPOLY_Config ( "config", DLPOLY_levcfg );
   }
   
   if ( NORUN )
      OutMiscProp ( NORUN_MODE );
   
   Cycle ();
   
   return 0;
}

/*   =======================================================
      SUBROUTINE CSIZE
     =======================================================
      definition of system and size parameters
     =======================================================
*/
void CSIZE () {
   double charge = 0;
   for ( const auto& array: SimSystem.molecules ) {
      if ( array.size() > 0 )
         charge += array.size() * array[0]->charge();
   }
   for ( const auto& array: SimSystem.cations ) {
      if ( array.size() > 0 )
         charge += array.size() * array[0]->charge();
   }
   for ( const auto& array: SimSystem.anions ) {
      if ( array.size() > 0 )
         charge += array.size() * array[0]->charge();
   }

   printSimulatedSystemMessage ( Message );
   
   Message << \
      " Number of molecules " << SimSystem.all_molecules.size() << " = " << SimSystem.all_molecules1.size() << " + " << SimSystem.all_molecules2.size()  << \
      "\n" " Number of ions      " << SimSystem.all_ions.size() << ": " << SimSystem.all_cations.size() << " + " << SimSystem.all_anions.size() << \
      "\n" " Size of the box " <<  mdformat(0,4) << LBOX << " nm" \
      "\n" " Total charge of system " << mdformat(0,5) << charge << \
      "\n" " Dielectric constant of solvent is " << mdformat(0,2) << Eps << \
      "\n" " Cut off radius " << mdformat(0,4) << RCut.LJ << " nm" \
      "\n" " Temperature of system " << mdformat(0,2) << TMPR0 << " K" \
      "\n" " Time Step = " << mdformat(0,4) << DELT << " ps" \
      "\n" " Thermostat parameter = " << mdformat(0,3) << taw  << " ps" \
      "\n" " Barostat parameter = "   << mdformat(0,1) << tawP << " atm*ps" \
      "\n" " External pressure = "    << mdformat(0,2) << extPRES << " atm" \
      "\n" "Box volume = " << mdformat(0,5) << VOLBOX << " nm^3" \
      "\n" "Box molar volume = " << mdformat(0,5) << VOLBOX*VOLUME_UNIT*SI_Na*1000 << " dm^3/mol" << std::endl;
}


/*    =======================================================
      SUBROUTINE CYCLE
      =======================================================
      main cycle
      =======================================================
*/

namespace {
static task_pool move_tpool;

void move_particles ( std::size_t thread_no ) {
#ifdef STATIC_WORK_BALANCING
   for ( std::size_t i = thread_no; i < SimSystem.all_particles.size(); i += NTHREADS )
#else
   for ( std::size_t i = move_tpool(); i < SimSystem.all_particles.size(); i = move_tpool() )
#endif
   {
      SimSystem.all_particles[i]->move( DELT, SubSteps, thread_no );
   }
}
}

static void Cycle () {
   //clock_t StartTime = clock ();
   const auto start_time = std::chrono::steady_clock::now();

   // Output miscellaneous information
   printSimulatedSystemMessage ( std::cout );

   switch ( KCoul ) {
      case 0:
         Message << " Ignore atomic charges\n";
         break;
      case 1:
         Message << " Using shifted force method\n";
         break;
      case 2:
         Message << " Using Reaction field method\n";
         break;
      case 3:
         Message << " Using Generalized Reaction field method with ionic contributions\n";

         double total_charge = 0.0;
         for ( auto p: SimSystem.all_particles ) {
            total_charge += p->charge();
         }
         if ( std::fabs(total_charge) > 1.0e-5 ) {
            Error << "Using Generalized Reaction field method with ionic contributions\n";
            Error << "but total charge is nonzero: " << total_charge << std::endl;
         }
         break;
   }
   
   if ( KRS )
      Message << " Run from restart file\n";
   else
      Message << " Run from new initial configuration\n";

   Message.precision ( 4 );
   std::cout << " Run from " << TIME << "ps until " << (TIME + NSTRUN * DELT) << "ps\n" << std::flush;
   Message   << " Run from " << TIME << "ps until " << (TIME + NSTRUN * DELT) << "ps\n" << std::flush;

   std::ofstream traj_out;
   std::ofstream traj4mol_out;
   if ( KCoorOut ) {
      traj_out.open ( "trajectory.dat", std::ios::ate | std::ios::out | std::ios::app );
      traj4mol_out.open ( "trajec4mol.dat", std::ios::ate | std::ios::out | std::ios::app );
   }

   std::ofstream out ( ResFileName, std::ios::ate | std::ios::out | std::ios::app );
   {
      time_t ltime;
      time ( &ltime );
      out << asctime ( localtime ( &ltime ) );
   }
   out.close ();

   Message.close ( );
   Message.open ( LogFileName, std::ios::ate | std::ios::out | std::ios::app );
   Message.flags ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
   Message.precision ( 4 );

   Error.reopen ( );

   if ( NORUN ) {      // -n key from kommand line.
      SMan.Actions (); // writing "co_out.dat" file
      return;
   }

   //                      --- THIS IS A MAIN LOOP ---

   // we have r(t), v(t) - positions & velocities at current time

   // calculate forces for starting configuration.
   FORCE ();
   for ( auto p: SimSystem.all_particles ) {
      p->reset_near_forces ();
      p->bonded_forces ();
      p->sync_near_forces ();
   }

   // now we have r(t), v(t), f(t) - positions, velocities and forces at current time

   // --- Starting main loop ---
   const double Start_TIME = TIME;
   for ( int step = 0; step < NSTRUN; ++step ) {
      NSTTOT++;     // incremeting time (in steps)
      TIME = Start_TIME + DELT*(step+1); // incremeting time (in ps)

      move_tpool.reset ();
      exec_parallel (move_particles,  NTHREADS);

      FORCE ();

      for ( auto p: SimSystem.all_particles ) {
         p->correctorStep ( DELT ); // adds some internal stress from constraints
      }
      
      if ( !(NSTTOT%1000) ) { // correcting box velocity every 1000 time steps
         SetPBoxToZero ();
      }
      
      THERM (); // calculating thermodynamic properties

      switch ( KSV ) {  // applying thermostat
         case 0:        // NVE ensemble;
            break;
         case 1:        // NVT ensemble;
            SCALV ();   // Berendsen's thermostat;
            break;
         case 2:        // NPT ensemble;
            Barostat(); // Berendsen's barostat;
            SCALV ();   // Berendsen's thermostat;
            break;
         case 3:        // ;
            IsoThermalBarostat();
            SCALV ();
            break;
         case 4:        // ;
            IsoThermalBarostat();
            break;
         default:
            Error << " Invalid KSV value";
            std::cout << '\a';
            std::exit ( EXIT_FAILURE );
      }

      // calculating structure and dynamic properties
      if ( KCF )
         DynamFunctions ();
      
      if ( KSTR )
         StructFunctions ();

      
      PSTEP ( NSTTOT ); // writing "result.dat" file

      if ( SimSystem.all_ions.size() > 1 && NSTTOT%SWRIT == 0 ) {
         PrintClusters ();
      }

      if ( KCoorOut && NSTTOT%KCoorOut == 0 ) {
         Print_trajectory ( traj_out );
         Print_trajectory4Mol ( traj4mol_out );
      }

      /*if ( BREAK_PROGRAM ) {
         std::cout << " saving configuration..." << std::endl;
         break; // terminating the main loop because of user request (maybe Ctrl+C)
      }*/
      
      if ( NSTTOT % SWRIT == 0 ) { // it is a good idea to periodically save your data
         SMan.Actions ();        // to have ability to restart calculations
      }
   } // end of main loop

   SMan.Actions (); // saving configuration
   if ( !BREAK_PROGRAM )
      ShowRes.Actions ( false ); // finalising calculations and output results

   // printing elapsed time
   //double elapsed_seconds = static_cast<double>(clock() - StartTime)/CLOCKS_PER_SEC;
   const auto end_time = std::chrono::steady_clock::now();
   const auto elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);
   const auto elapsed_seconds = static_cast<double>(elapsed_time.count())/1000.0;
   int hours   =  static_cast<int>(elapsed_seconds)/3600;
   int minutes = (static_cast<int>(elapsed_seconds)%3600)/60;
   double seconds =  elapsed_seconds - minutes*60 - hours*3600;
   out.open ( ResFileName, std::ios::ate | std::ios::out | std::ios::app );
   out << "Elapsed time: " << hours << ":" << minutes << ":" << mdformat(0,2) << seconds;
   out << " (" << mdformat(0,2) << elapsed_seconds << " seconds)" << std::endl;
   Message << "Elapsed time: " << hours << ":" << minutes << ":" << mdformat(0,2) << seconds;
   Message << " (" << mdformat(0,2) << elapsed_seconds << " seconds)" << std::endl;
   out.close ();
   

   std::cout << std::endl;
}

// ============================================================================
void SetPBoxToZero () {
   vect VBox = 0.0;
   double BoxMass = 0.0;

   for ( auto p: SimSystem.all_particles ) {
      for ( basic_particle::const_reference a: *p ) {
         VBox += a.v() * a.mass();
         BoxMass += a.mass();
      }
   }
   VBox /= BoxMass;

   for ( auto p: SimSystem.all_particles ) {
      for ( basic_particle::reference a: *p ) {
         a.v() -= VBox;
      }
   }
   if ( K_PrintVbox ) {
      std::ofstream out ( "VBox.log", std::ios::ate | std::ios::out | std::ios::app );
      out << mdformat(9,0) << NSTTOT << "  E, kJ/mol:";
      out << mdformat(11,4,std::ios::right) << 0.5 * (VBox*VBox) * BoxMass*ENERGY_UNIT/EXTERNAL_ENERGY_UNIT;
      out << "  V: " << mdformat(18,15) << VBox << std::endl;
   }
}

/*    =======================================================
      SUBROUTINE THERM
      =======================================================
      calculation of thermodynamic properties
      =======================================================
*/
void THERM () {
   Therm_values.EkinM = 0.0;
   for ( auto p: SimSystem.all_molecules )
      Therm_values.EkinM += p->getEkin ();
   
   Therm_values.EkinC = 0.0;
   for ( auto p: SimSystem.all_cations )
      Therm_values.EkinC += p->getEkin ();
   
   Therm_values.EkinA = 0.0;
   for ( auto p: SimSystem.all_anions )
      Therm_values.EkinA += p->getEkin ();

   assert ( Therm_values.EkinM >= 0.0 );
   assert ( Therm_values.EkinC >= 0.0 );
   assert ( Therm_values.EkinA >= 0.0 );

   Therm_values.stressKin.set_to_zero ();
   
   for ( auto p: SimSystem.all_particles ) {
      for ( basic_particle::const_reference a: *p ) {
         const vect   velocity = a.v();
         const double mass = a.mass ();

         Therm_values.stressKin[0][0] += velocity.x * velocity.x * mass;
         Therm_values.stressKin[0][1] += velocity.x * velocity.y * mass;
         Therm_values.stressKin[0][2] += velocity.x * velocity.z * mass;
         Therm_values.stressKin[1][1] += velocity.y * velocity.y * mass;
         Therm_values.stressKin[1][2] += velocity.y * velocity.z * mass;
         Therm_values.stressKin[2][2] += velocity.z * velocity.z * mass;
      }
   }
   Therm_values.stressKin[1][0] = Therm_values.stressKin[0][1];
   Therm_values.stressKin[2][0] = Therm_values.stressKin[0][2];
   Therm_values.stressKin[2][1] = Therm_values.stressKin[1][2];

   
   Therm_values.zero_bonded_components ();
   
   for ( auto p: SimSystem.all_particles ) {
      Therm_values.Ubond += p->Ubond();
      Therm_values.Uangle += p->Uangle();
      Therm_values.Udihedral += p->Udihedral();
      Therm_values.Udihedral_2 += p->Udihedral_2();
      Therm_values.Uharmonic_dihedral += p->Uharmonic_dihedral();
   }
   
   // Calculate the contribution to the stress tenzor from intramolecular forces
   // Therm_values.stressInt has being reset by call to Therm_values.zero_bonded_components ()
   for ( auto p: SimSystem.all_particles ) {
      Therm_values.stressInt += p->getInternalStress ();
   }
   
   Therm_values.stress = Therm_values.stressPotS + Therm_values.stressPotC + Therm_values.stressKin + Therm_values.stressInt;

   Therm_values.Ekin = Therm_values.EkinM + Therm_values.EkinC + Therm_values.EkinA;
   
   TMPR = 2 * Therm_values.Ekin * ENERGY_UNIT / ( SI_Kbol * NDegFree );

   {
      Therm_values.zero_ab_components ();

      
      for ( const auto& p1: SimSystem.molecule_types ) {
         for ( const auto& p2: SimSystem.molecule_types ) {
            Therm_values.sUmm += Therm_values.sU[p1->id()][p2->id()];
            Therm_values.cUmm += Therm_values.cU[p1->id()][p2->id()];
            Therm_values.sVIRmm += Therm_values.sVIR[p1->id()][p2->id()];
            Therm_values.cVIRmm += Therm_values.cVIR[p1->id()][p2->id()];
            Therm_values.dcUmm += Therm_values.dcU[p1->id()][p2->id()];
            Therm_values.dcVIRmm += Therm_values.dcVIR[p1->id()][p2->id()];
         }
         for ( const auto& p2: SimSystem.cation_types ) {
            Therm_values.sUmc += Therm_values.sU[p1->id()][p2->id()];
            Therm_values.sUmc += Therm_values.sU[p2->id()][p1->id()];
            Therm_values.cUmc += Therm_values.cU[p1->id()][p2->id()];
            Therm_values.cUmc += Therm_values.cU[p2->id()][p1->id()];
            Therm_values.sVIRmc += Therm_values.sVIR[p1->id()][p2->id()];
            Therm_values.sVIRmc += Therm_values.sVIR[p2->id()][p1->id()];
            Therm_values.cVIRmc += Therm_values.cVIR[p1->id()][p2->id()];
            Therm_values.cVIRmc += Therm_values.cVIR[p2->id()][p1->id()];
            Therm_values.dcUmc += Therm_values.dcU[p1->id()][p2->id()];
            Therm_values.dcUmc += Therm_values.dcU[p2->id()][p1->id()];
            Therm_values.dcVIRmc += Therm_values.dcVIR[p1->id()][p2->id()];
            Therm_values.dcVIRmc += Therm_values.dcVIR[p2->id()][p1->id()];
         }
         for ( const auto& p2: SimSystem.anion_types ) {
            Therm_values.sUma += Therm_values.sU[p1->id()][p2->id()];
            Therm_values.sUma += Therm_values.sU[p2->id()][p1->id()];
            Therm_values.cUma += Therm_values.cU[p1->id()][p2->id()];
            Therm_values.cUma += Therm_values.cU[p2->id()][p1->id()];
            Therm_values.sVIRma += Therm_values.sVIR[p1->id()][p2->id()];
            Therm_values.sVIRma += Therm_values.sVIR[p2->id()][p1->id()];
            Therm_values.cVIRma += Therm_values.cVIR[p1->id()][p2->id()];
            Therm_values.cVIRma += Therm_values.cVIR[p2->id()][p1->id()];
            Therm_values.dcUma += Therm_values.dcU[p1->id()][p2->id()];
            Therm_values.dcUma += Therm_values.dcU[p2->id()][p1->id()];
            Therm_values.dcVIRma += Therm_values.dcVIR[p1->id()][p2->id()];
            Therm_values.dcVIRma += Therm_values.dcVIR[p2->id()][p1->id()];
         }
      }
      for ( const auto& c1: SimSystem.cation_types ) {
         for ( const auto& c2: SimSystem.cation_types ) {
            Therm_values.sUcc += Therm_values.sU[c1->id()][c2->id()];
            Therm_values.cUcc += Therm_values.cU[c1->id()][c2->id()];
            Therm_values.sVIRcc += Therm_values.sVIR[c1->id()][c2->id()];
            Therm_values.cVIRcc += Therm_values.cVIR[c1->id()][c2->id()];
            Therm_values.dcUcc += Therm_values.dcU[c1->id()][c2->id()];
            Therm_values.dcVIRcc += Therm_values.dcVIR[c1->id()][c2->id()];
         }
         for ( const auto& a2: SimSystem.anion_types ) {
            Therm_values.sUca += Therm_values.sU[c1->id()][a2->id()];
            Therm_values.sUca += Therm_values.sU[a2->id()][c1->id()];
            Therm_values.cUca += Therm_values.cU[c1->id()][a2->id()];
            Therm_values.cUca += Therm_values.cU[a2->id()][c1->id()];
            Therm_values.sVIRca += Therm_values.sVIR[c1->id()][a2->id()];
            Therm_values.sVIRca += Therm_values.sVIR[a2->id()][c1->id()];
            Therm_values.cVIRca += Therm_values.cVIR[c1->id()][a2->id()];
            Therm_values.cVIRca += Therm_values.cVIR[a2->id()][c1->id()];
            Therm_values.dcUca += Therm_values.dcU[c1->id()][a2->id()];
            Therm_values.dcUca += Therm_values.dcU[a2->id()][c1->id()];
            Therm_values.dcVIRca += Therm_values.dcVIR[c1->id()][a2->id()];
            Therm_values.dcVIRca += Therm_values.dcVIR[a2->id()][c1->id()];
         }
      }
      for ( const auto& a1: SimSystem.anion_types ) {
         for ( const auto& a2: SimSystem.anion_types ) {
            Therm_values.sUaa += Therm_values.sU[a1->id()][a2->id()];
            Therm_values.cUaa += Therm_values.cU[a1->id()][a2->id()];
            Therm_values.sVIRaa += Therm_values.sVIR[a1->id()][a2->id()];
            Therm_values.cVIRaa += Therm_values.cVIR[a1->id()][a2->id()];
            Therm_values.dcUaa += Therm_values.dcU[a1->id()][a2->id()];
            Therm_values.dcVIRaa += Therm_values.dcVIR[a1->id()][a2->id()];
         }
      }
   }
   
   

   Therm_values.sVIRtot = Therm_values.sVIRmm + Therm_values.sVIRmc + Therm_values.sVIRma + Therm_values.sVIRcc + Therm_values.sVIRca + Therm_values.sVIRaa;
   Therm_values.cVIRtot = Therm_values.cVIRmm + Therm_values.cVIRmc + Therm_values.cVIRma + Therm_values.cVIRcc + Therm_values.cVIRca + Therm_values.cVIRaa;
   Therm_values.dcVIRtot = Therm_values.dcVIRmm + Therm_values.dcVIRmc + Therm_values.dcVIRma
                         + Therm_values.dcVIRcc + Therm_values.dcVIRca + Therm_values.dcVIRaa;
   Therm_values.VIRtot = Therm_values.sVIRtot + Therm_values.cVIRtot + Therm_values.dcVIRtot + Therm_values.VIRnb_intra;

   // adding intramolecular bonded virial (this also cancells an excess kinetic energy in pressure calculations).
   Therm_values.VIRtot += Therm_values.stressInt[0][0] + Therm_values.stressInt[1][1] + Therm_values.stressInt[2][2];

   // Pressure calculation. We don't use stress tenzor here,
   // because stress is calculated only for viscosity calculations
   PRES = (PRESSURE_UNIT / EXTERNAL_PRESSURE_UNIT) * (2*Therm_values.Ekin + Therm_values.VIRtot) / (3*VOLBOX); // in atm.

   Therm_values.sUpot = Therm_values.sUmm + Therm_values.sUmc + Therm_values.sUma + Therm_values.sUcc + Therm_values.sUca + Therm_values.sUaa;
   Therm_values.cUpot = Therm_values.cUmm + Therm_values.cUmc + Therm_values.cUma + Therm_values.cUcc + Therm_values.cUca + Therm_values.cUaa;
   Therm_values.dcUpot = Therm_values.dcUmm + Therm_values.dcUmc + Therm_values.dcUma + Therm_values.dcUcc + Therm_values.dcUca + Therm_values.dcUaa;
   
   
   Therm_values.Uinter = Therm_values.sUpot + Therm_values.cUpot + Therm_values.dcUpot;
   Therm_values.Uintra = Therm_values.Unb_intra + Therm_values.Ubond + Therm_values.Uangle
                       + Therm_values.Udihedral + Therm_values.Udihedral_2 + Therm_values.Uharmonic_dihedral;
   Therm_values.Upot = Therm_values.Uinter + Therm_values.Uintra;
   Therm_values.UT = Therm_values.Upot + Therm_values.Ekin;
   //Enthalpy = UT + extPRES * EXTERNAL_PRESSURE_UNIT / PRESSURE_UNIT * VOLBOX;
   Therm_values.Enthalpy = Therm_values.UT + (2*Therm_values.Ekin + Therm_values.VIRtot) / 3;
}

// ========================== Berendsen's thermostat ==========================
static void SCALV () {
   double factor;
   if ( TMPR > TMPR0*50 ) {
      std::cout << "Temperature of system is too high: " << TMPR << std::endl;
   }
   if ( TMPR > 0.0 )
      factor = std::sqrt(1.0 + DELT*(TMPR0/TMPR - 1.0) / taw );
   else
      factor = 1.0;

   for ( auto p: SimSystem.all_particles ) {
      p->scalv ( factor );
   }
}

// =========================== Berendsen's barostat ===========================
static void Barostat () {
   double a = -DELT*(extPRES-PRES)/tawP;
   if ( a < -0.001 )
      a = -0.001;
   if ( a >  0.001 )
      a =  0.001;
   const double factor = 1 + a/3; // this is approximately (1+a)^(1/3)

   for ( auto p: SimSystem.all_particles ) {
      p->scalPos ( factor );
   }

   LBOX *= factor;
   setBoxSizeVariables();
}

static void IsoThermalBarostat () {
   double a = -DELT*(extPRES-PRES)/tawP;
   if ( a < -0.001 )
      a = -0.001;
   if ( a >  0.001 )
      a =  0.001;
   const double factor = 1 + a/3; // this is approximately (1+a)^(1/3)

   for ( auto p: SimSystem.all_particles ) {
      p->scalPos ( factor );
   }

   // After applying of coordinates scaling:
   // Delta Upot = -(factor-1)*VIRtot
   // Delta Ekin = 0.0
   // Delta external PV = extP*DeltaV = extPRES*EXTERNAL_PRESSURE_UNIT/PRESSURE_UNIT * VOLBOX*a

   // to conserve value of internal energy + external PV we change Ekin
   // new Ekin = old Ekin - Delta Upot - Delta external PV

   const double dPV = extPRES*EXTERNAL_PRESSURE_UNIT/PRESSURE_UNIT * VOLBOX*a;
   const double dUpot = -(factor-1)*Therm_values.VIRtot;
   //const double vfactor = std::sqrt( (Ekin-dUpot-dPV)/Ekin );
   const double vfactor = 1 - 0.5 * (dUpot+dPV)/Therm_values.Ekin; // 0.5 is for square root
   for ( auto p: SimSystem.all_particles ) {
      p->scalv ( vfactor );
   }
   
   TMPR *= vfactor*vfactor;

   LBOX *= factor;
   setBoxSizeVariables();
}
