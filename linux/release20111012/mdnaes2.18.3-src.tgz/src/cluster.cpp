#include "cluster.h"
#include "utils.h"
#include "md_exception.h"

#include <iostream>
#include <algorithm>

void cluster::save ( std::ostream& out ) const {
   write_as<int> ( out, cations.size() );
   for ( int i: cations ) {
      write_as<int> ( out, i );
   }

   write_as<int> ( out, anions.size() );
   for ( int i: anions ) {
      write_as<int> ( out, i );
   }
}

void cluster::read ( std::istream& in ) {
   this->clear ();

   const int n_cat = read_as<int> ( in );
   if ( !in.good() || n_cat < 0 ) {
      raise_md_exception ( "cluster::read(): cannot read number of cations in cluster." );
   }
   for ( int i = 0; i < n_cat; ++ i ) {
      const int index = read_as<int> ( in );
      if ( !in.good() || index < 0 ) {
         raise_md_exception ( "cluster::read(): cannot read cation index in cluster." );
      }
      cations.insert (index);
   }

   const int n_an = read_as<int> ( in );
   if ( !in.good() || n_an < 0 ) {
      raise_md_exception ( "cluster::read(): cannot read number of anions in cluster." );
   }
   for ( int i = 0; i < n_an; ++ i ) {
      const int index = read_as<int> ( in );
      if ( !in.good() || index < 0 ) {
         raise_md_exception ( "cluster::read(): cannot read anion index in cluster." );
      }
      anions.insert (index);
   }
}

cluster& cluster::merge ( const cluster& other ) {
   cations.insert ( other.cations.begin(), other.cations.end() );
   anions.insert ( other.anions.begin(), other.anions.end() );
   return *this;
}

cluster merge ( const cluster& cl1, const cluster& cl2 ) {
   cluster temp ( cl1 );
   temp.cations.insert ( cl2.cations.begin(), cl2.cations.end() );
   temp.anions.insert ( cl2.anions.begin(), cl2.anions.end() );

   return temp;
}

cluster intersect ( const cluster& cl1, const cluster& cl2 ) {
   cluster res;

   for ( int i: cl1.cations ) {
      if ( cl2.has_cat(i) ) {
         res.addCat (i);
      }
   }
   for ( int i: cl1.anions ) {
      if ( cl2.has_an(i) ) {
         res.addAn (i);
      }
   }

   return res;
}

bool has_intersection ( const cluster& cl1, const cluster& cl2 ) {
   for ( int i: cl1.cations ) {
      if ( cl2.has_cat(i) ) {
         return true;
      }
   }
   for ( int i: cl1.anions ) {
      if ( cl2.has_an(i) ) {
         return true;
      }
   }

   return false;
}

// =============== cluster_collection ===============
void cluster_collection::save ( std::ostream& out ) const {
   write_as<int> ( out, m_clusters.size() );

   for ( const auto& c: m_clusters ) {
      c.save ( out );
   }
}

void cluster_collection::read ( std::istream& in ) {
   this->clear ();

   const int nc = read_as<int> ( in );
   if ( !in.good() || nc < 0 ) {
      raise_md_exception ( "cluster_collection::read(): cannot read number of clusters." );
   }

   for ( int i = 0; i < nc; ++i ) {
      cluster t;
      t.read ( in );
      m_clusters.emplace_back ( t );
   }
}

void cluster_collection::proceed () {
   for ( int cur = 0; cur < m_clusters.size()-1; ++cur ) {
      bool done = false;
      while ( !done ) {
         done = true;
         for ( int i = cur+1; i < m_clusters.size(); ++i ) {
            if ( has_intersection(m_clusters[cur], m_clusters[i]) ) {
               m_clusters[cur].merge ( m_clusters[i] );
               m_clusters[i].clear ();
               done = false;
            }
         }
      }
   }
   auto empties = std::remove_if ( m_clusters.begin(), m_clusters.end(), [](const cluster& c) { return c.empty(); } );
   m_clusters.erase ( empties, m_clusters.end() );
}
