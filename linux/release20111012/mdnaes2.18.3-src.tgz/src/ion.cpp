#include <cstdlib>

#include "ion.h"
#include "lib/mdformat.h"
#include "globals.h"

std::vector<vect> ion::getCoordinationCenters () const {
   return type->calcCoordinationCenters ( *this );
}

// ==========================================================================================
ion_type::ion_type ( mylist_const_iterator& in ) : particle_type(in) {
   in.reset();
   while ( in.find( "coordinationCenter" ) ) {
      mylist_const_iterator iter ( in.get_item() );
      
      std::vector<double> coefs;
      
      int i;
      for ( i = 0; i < this->natoms(); ++i ) {
         const double c = iter.get_double();
         coefs.push_back ( c );
         ++iter;
      }
      
      if ( coefs.size() < this->natoms() ) {
          Error << "Too few coordination centercoefficients for ion ";
          Error << this->name() << " in params file\n";
          raise_md_exception ( "Error constructing ion_type" );
      }
      
      coordinationCenterCoefs.push_back ( coefs );
      
      ++in;
   }
   
   if ( coordinationCenterCoefs.size() == 0 ) {
      Error << "Cannot find \"coordinationCenter\" pararmeter for ion ";
      Error << this->name() << " in params file\n";
      raise_md_exception ( "Error constructing ion_type" );
   }
}

ion_type::~ion_type () {}

std::vector<vect> ion_type::calcCoordinationCenters ( const basic_particle& atoms ) const {
   std::vector<vect> res;
   
   for ( const auto& coefs: coordinationCenterCoefs ) {
      vect c = 0;
      for ( int i = 0; i < this->natoms (); ++i )
         c += coefs[i] * atoms[i].r();
      res.push_back (c);
   }
   return res;
}

void ion_type::print ( std::ostream& out ) const {
}
