#ifndef DISP_CORR_H
#define DISP_CORR_H

void calc_disp_corrections ();

#endif
