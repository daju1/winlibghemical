#ifndef MD_EXCEPTION_H
#define MD_EXCEPTION_H

#include <fstream>

namespace mdnaes {

class md_exception {
public:
   md_exception ( const char *str ) noexcept : message(str) { }
   md_exception ( const md_exception& other ) noexcept : message(other.message) { }
   virtual ~md_exception () { }

   virtual const char *what () const noexcept;
private:
   const char *message;
};

class md_io_error : public md_exception {
public:
   md_io_error ( const char *str ) noexcept : md_exception(str) { }
   md_io_error ( const md_io_error& other ) noexcept : md_exception(other) { }
   virtual ~md_io_error () { }
};

} // end of namespace mdnaes

void raise_md_exception ( const char * );

class error_logger {
public:
   error_logger ( const char *fname ): out(), file_opened(false), file_name(fname) {}
   ~error_logger () {}

   template <class X>
   error_logger& operator << ( const X x ) {
      if ( !file_opened ) {
         out.open ( file_name, std::ios::out | std::ios::trunc );
         file_opened = true;
      }
      out << x;
      out.flush ();
      return (*this);
   }

   error_logger& operator << ( std::ostream& x( std::ostream& ) ) {
      if ( !file_opened ) {
         out.open ( file_name, std::ios::out | std::ios::trunc );
         file_opened = true;
      }
      x( out );
      return (*this);
   }

   error_logger& reopen () {
      if ( file_opened ) {
         out.close ();
         out.open ( file_name, std::ios::ate | std::ios::out | std::ios::app );
      }
      return (*this);
   }
private:
   std::ofstream out;
   bool file_opened;
   const char *file_name;
};

extern error_logger Error;


#endif
