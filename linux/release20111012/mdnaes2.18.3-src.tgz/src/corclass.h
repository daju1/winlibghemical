#ifndef CORCLASS_H
#define CORCLASS_H

#include "lib/HA.h"
#include "lib/TCF.h"
#include "subsystem.h"
#include "ha_allocator.h"
using namespace mdnaes;

#include <algorithm>
#include <vector>
#include <string>

// ============================================================================
struct base_history_array : public identified_saveable, public updateable {
   base_history_array ( const std::string& key ) : identified_saveable(key), updateable() {}
};

// ============================================================================
// ==================== base_multiple_value_history_array =====================
template <class data_type>
class base_multiple_value_history_array : public base_history_array {
public:
   virtual ~base_multiple_value_history_array ();

   void read ( std::istream& ) override;
   void save ( std::ostream& ) const override;

   const HA<data_type>& operator [] ( int i ) const { return *data[i]; }

   int maxelements () const { return data_size; }
   bool has ( int i ) const { return data[i] != nullptr; }
   int HA_size () const { return alloc.HA_size(); }
protected:
   base_multiple_value_history_array ( const std::string& key, HA_Allocator<data_type>& Alloc, int size );

   HA_Allocator<data_type>& alloc;
   const int data_size;
   HA<data_type>* *data;
};

template <class data_type>
base_multiple_value_history_array<data_type>::base_multiple_value_history_array (
   const std::string& key, HA_Allocator<data_type>& Alloc, int size
   ): base_history_array(key), alloc(Alloc),
      data_size(size), data(new HA<data_type>*[data_size])
{
   for ( int i = 0; i < maxelements(); ++i )
      data[i] = nullptr;
}

template <class data_type>
base_multiple_value_history_array<data_type>::~base_multiple_value_history_array () {
   for ( int i = 0; i < maxelements(); ++i )
      if ( has(i) ) alloc.Deallocate ( data[i] );
   delete[] data;
}

template <class data_type>
void base_multiple_value_history_array<data_type>::read ( std::istream& in ) {
   int saved_maxelems = -1;

   in.read ( (char*)&saved_maxelems, sizeof (int) );
   if ( saved_maxelems != maxelements() ) {
      throw md_io_error ("base_multiple_value_history_array::read (): cannot read data from the input");
   }

   for ( int j = 0; j < maxelements(); ++j )
      if ( data[j] ) alloc.Deallocate ( data[j] );

   int i = -1, iold = -1;
   for ( ; ; ) {
      in.read ( (char*)&i, sizeof (int) );
      if ( i <= iold || i > maxelements() ) //read operation failed
         throw md_io_error ("base_multiple_value_history_array::read (): cannot read data from the input");
      if ( i == maxelements() )
         break;
      data[i] = alloc.Allocate ();
      data[i]->read ( in );

      iold = i;
   }
}

template <class data_type>
void base_multiple_value_history_array<data_type>::save ( std::ostream& out ) const {
   int maxelems = maxelements();
   out.write ( (char*)&maxelems, sizeof (int) );
   
   for ( int i = 0; i < maxelements(); ++i ) {
      if ( data[i] ) {
         out.write ( (char*)&i, sizeof (int) );
         data[i]->save ( out );
      }
   }
   out.write ( (char*)&maxelems, sizeof (int) );
}

// ====================== multiple_value_history_array ========================
template <class data_type, class part_t, typename data_source = data_type (*)(const part_t&)>
class multiple_value_history_array : public base_multiple_value_history_array<data_type> {
public:
   multiple_value_history_array ( const std::string& key,
                                  HA_Allocator<data_type>& Alloc,
                                  const subsystem<part_t>& Shell,
                                  data_source CalcFun );
   ~multiple_value_history_array () {}

   virtual void update ( ) override;
   virtual void update ( int thread_no, int nthreads ) override;
private:
   const subsystem<part_t>& shell;
   data_source calc_fun;
};

template <class data_type, class part_t, typename data_source>
multiple_value_history_array<data_type,part_t,data_source>::multiple_value_history_array (
   const std::string& key, HA_Allocator<data_type>& Alloc, const subsystem<part_t>& Shell, data_source CalcFun
   ): base_multiple_value_history_array<data_type>(key, Alloc, Shell.maxelements()),
      shell(Shell), calc_fun(CalcFun)
{
}

template <class data_type, class part_t, typename data_source>
inline
void multiple_value_history_array<data_type,part_t,data_source>::update ( ) {
   for ( int i = 0; i < this->maxelements(); ++i ) {
      if ( this->data[i] ) {
         if ( shell.has(i) )
            this->data[i]->add ( calc_fun (shell.element(i)) );
         else
            this->alloc.Deallocate ( this->data[i] );
      }
      else if ( shell.has(i) ) {
         this->data[i] = this->alloc.Allocate ();
         this->data[i]->add ( calc_fun (shell.element(i)) );
      }
   }
}

template <class data_type, class part_t, typename data_source>
inline
void multiple_value_history_array<data_type,part_t,data_source>::update ( int thread_no, int nthreads ) {
   for ( int i = thread_no; i < this->maxelements(); i += nthreads ) {
      if ( this->data[i] ) {
         if ( shell.has(i) )
            this->data[i]->add ( calc_fun (shell.element(i)) );
         else
            this->alloc.Deallocate ( this->data[i] ); // protected with mutex
      }
      else if ( shell.has(i) ) {
         this->data[i] = this->alloc.Allocate (); // protected with mutex
         this->data[i]->add ( calc_fun (shell.element(i)) );
      }
   }
}


// ============================================================================
// ====================== base_single_value_history_array =====================
template <class data_type>
class base_single_value_history_array : public base_history_array {
public:
   virtual ~base_single_value_history_array () {}

   void read ( std::istream& in ) override { data.read(in); }
   void save ( std::ostream& out ) const override { data.save(out); }

   const data_type& operator [] ( int i ) const { return data[i]; }
   const HA<data_type>& getHA () const { return data; }
   int size () const { return data.size(); }
   int HA_size () const { return data.max_size(); }
protected:
   base_single_value_history_array ( const std::string& key, int Size )
      : base_history_array(key), data(Size) {}
   HA<data_type> data;
};
// ======================= single_value_history_array =========================
template <class data_type, class data_source = data_type (*)()>
class single_value_history_array : public base_single_value_history_array<data_type> {
public:
   single_value_history_array ( const std::string& key, int Size, data_source CalcFun )
      : base_single_value_history_array<data_type>(key, Size), calc_fun(CalcFun) {}
   ~single_value_history_array () {}

   void update ( ) override;
private:
   data_source calc_fun;
};

template <class data_type, class data_source>
void single_value_history_array<data_type,data_source>::update ( ) {
   this->data.add (calc_fun());
}

// ============================================================================
// This is binder of function and is used as data_source parameter 
// in the single_value_history_array class
// Here data_type may be, for example,  vect  or  const vect&
template <class data_type, class part_t>
class shellable_single_value_data_source {
public:
   shellable_single_value_data_source ( const subsystem<part_t>& Shell, data_type (*CalcFun) ( const subsystem<part_t>& ) )
      : shell(Shell), calc_fun(CalcFun) {}
   ~shellable_single_value_data_source () {}
   data_type operator () () {
      return calc_fun(shell);
   }
private:
   const subsystem<part_t>& shell;
   data_type (*calc_fun) ( const subsystem<part_t>& );
};
// ============================================================================

// =================================== TDF ====================================
//             Interface, needed to print functions to the file
class TDF : public identified_saveable, public updateable {
public:
   TDF ( const std::string& key ) : identified_saveable (key), updateable () { }
   virtual ~TDF () { }

   virtual int size () const = 0;
   virtual bool empty () const = 0; // return true if there are no data in it
                                    // this is a case when there are no molecules in shell

   virtual void print_header ( std::ostream& ) const = 0;
   virtual void print_value  ( std::ostream&, int, double factor = 1.0 ) const = 0;
   virtual void print_value_normated  ( std::ostream&, int, double factor = 1.0 ) const = 0;
   
   virtual void sync () {}
};
// ============================================================================
// =================================== TTDF ===================================
template <class restype>
class TTDF : public TDF {
public:
   virtual const restype operator [] ( int ) const = 0;
   virtual ~TTDF () {}
protected:
   TTDF ( const std::string& key ) : TDF(key) {}
};

// ============================================================================
// ================================= base_CCF =================================
template <class restype, class arg1type, class arg2type, class op = tcf::multiplies>
class base_CCF : public TTDF<restype> {
protected:
   base_CCF ( const std::string& key, int t_size, const mdformat& fmt, int nthreads = 1 )
      : TTDF<restype>(key), format(fmt), results()
   {
      for ( int i = 0; i < nthreads; ++i ) {
         results.emplace_back (t_size);
      }
   }
public:
   virtual ~base_CCF () {}

   void read ( std::istream& in ) override { results[0].read(in); }
   void save ( std::ostream& out ) const override { results[0].save(out); }

   bool empty () const override { return results[0].empty(); }

   void print_header ( std::ostream& out ) const override { out << format << this->getkey(); }
   void print_value  ( std::ostream& out, int i, double factor = 1.0 ) const override {
      if ( results[0].is_at(i) ) {
         out << format << factor*results[0][i];
      }
      else {
         out << format << "--";
      }
   }
   void print_value_normated  ( std::ostream& out, int i, double factor = 1.0 ) const override {
      this->print_value ( out, i, factor ); // CCF cannot be normated to unit at 0 time
   }

   const restype operator [] ( int i ) const override { return results[0][i]; }
   int size () const override { return results[0].size(); }
   
   virtual void sync () override {
      for ( int i = 1; i < results.size(); ++i ) {
         results[0] += results[i];
         results[i].clear ();
      }
   }
protected:
   const mdformat format;
   //TCCF<restype,arg1type,arg2type,op> result;
   std::vector<TCCF<restype,arg1type,arg2type,op> > results;
};

// ============================================================================
// ================================= base_ACF =================================
template <class restype, class argtype, class op = tcf::multiplies>
class base_ACF : public TTDF<restype> {
protected:
   base_ACF ( const std::string& key, int t_size, const mdformat& fmt, int nthreads = 1 )
      : TTDF<restype>(key), format(fmt), results()
   {
      for ( int i = 0; i < nthreads; ++i ) {
         //results.emplace_back (t_size);
         results.emplace_back (new TACF<restype,argtype,op>(t_size));
      }
   }
public:
   virtual ~base_ACF () {
      for ( auto p: this->results )
         delete p;
   }

   //void read ( std::istream& in ) override { results[0].read(in); }
   void read ( std::istream& in ) override { results[0]->read(in); }
   //void save ( std::ostream& out ) const override { results[0].save(out); }
   void save ( std::ostream& out ) const override { results[0]->save(out); }

   //bool empty () const override { return results[0].empty(); }
   bool empty () const override { return results[0]->empty(); }

   void print_header ( std::ostream& out ) const override { out << format << this->getkey(); }
   void print_value  ( std::ostream& out, int i, double factor = 1.0 ) const override {
      if ( results[0]->is_at(i) ) {
         out << format << factor*(*results[0])[i];
      }
      else {
         out << format << "--";
      }
   }
   void print_value_normated  ( std::ostream& out, int i, double factor = 1.0 ) const override {
      const auto& res = *(this->results[0]);
      if ( res.is_at(i) ) {
         out << format << ((op::can_be_normated) ? 
                           ((res[0] == static_cast<restype>(0)) ? static_cast<restype>(0) 
                                                                   : factor*res[i]/res[0])
                           : factor*res[i]);
      }
      else {
         out << format << "--";
      }
   }

   //const restype operator [] ( int i ) const override { return results[0][i]; }
   const restype operator [] ( int i ) const override { return (*results[0])[i]; }
   //int size () const override { return results[0].size(); }
   int size () const override { return results[0]->size(); }
   
   virtual void sync () override {
      for ( int i = 1; i < results.size(); ++i ) {
         (*results[0]) += (*results[i]);
         results[i]->clear ();
      }
   }
protected:
   const mdformat format;
   //TACF<restype,argtype,op> result;
   //std::vector<TACF<restype,argtype,op> > results;
   std::vector<TACF<restype,argtype,op>* > results;
};

// ============================================================================
// ============================ single_molecule_CCF ===========================
template <class restype, class arg1type, class arg2type, class op = tcf::multiplies>
class single_molecule_CCF : public base_CCF<restype,arg1type,arg2type,op> {
public:
   single_molecule_CCF ( const std::string& key,
                         int t_size,
                         const mdformat& fmt,
                         const base_multiple_value_history_array<arg1type>& a,
                         const base_multiple_value_history_array<arg2type>& b,
                         int nthreads = 1
                       )
      : base_CCF<restype,arg1type,arg2type,op>(key, t_size, fmt, nthreads), arg1(a), arg2(b) {}
   virtual ~single_molecule_CCF () {}

   virtual void update ( int thread_no, int nthreads ) override;
   virtual void update ( ) override;
private:
   const base_multiple_value_history_array<arg1type>& arg1;
   const base_multiple_value_history_array<arg2type>& arg2;
};

template <class restype, class arg1type, class arg2type, class op>
void single_molecule_CCF<restype,arg1type,arg2type,op>::update ( int thread_no, int nthreads ) {
   for ( int i = thread_no; i < arg1.maxelements(); i += nthreads )
      if ( arg1.has(i) )
         this->results[thread_no].add ( arg1[i], arg2[i] );
}

template <class restype, class arg1type, class arg2type, class op>
void single_molecule_CCF<restype,arg1type,arg2type,op>::update ( ) {
   for ( int i = 0; i < arg1.maxelements(); ++i )
      if ( arg1.has(i) )
         this->results[0].add ( arg1[i], arg2[i] );
}
// ============================================================================
// ============================ single_molecule_ACF ===========================
template <class restype, class argtype, class op = tcf::multiplies>
class single_molecule_ACF : public base_ACF<restype,argtype,op> {
public:
   single_molecule_ACF ( const std::string& key,
                         int t_size,
                         const mdformat& fmt,
                         const base_multiple_value_history_array<argtype>& a,
                         int nthreads = 1
                       )
      : base_ACF<restype,argtype,op>(key,t_size,fmt,nthreads), arg(a) {}
   virtual ~single_molecule_ACF () {}

   virtual void update ( int thread_no, int nthreads ) override;
   virtual void update ( ) override;
private:
   const base_multiple_value_history_array<argtype>& arg;
};

template <class restype, class argtype, class op>
void single_molecule_ACF<restype,argtype,op>::update ( int thread_no, int nthreads ) {
   for ( int i = thread_no; i < arg.maxelements(); i += nthreads ) {
      if ( arg.has(i) ) {
         //this->results[thread_no].add ( arg[i] );
         this->results[thread_no]->add ( arg[i] );
      }
   }
}

template <class restype, class argtype, class op>
void single_molecule_ACF<restype,argtype,op>::update ( ) {
   for ( int i = 0; i < arg.maxelements(); ++i ) {
      if ( arg.has(i) ) {
         //this->results[0].add ( arg[i] );
         this->results[0]->add ( arg[i] );
      }
   }
}
// ============================================================================
#include "lib/vect.h"
typedef single_molecule_ACF<double,vect,tcf::R1> ABS_Displ;
typedef single_molecule_ACF<double,vect,tcf::R2> SQR_Displ;
typedef single_molecule_ACF<double,vect,tcf::Legendre1> ACFP1;
typedef single_molecule_ACF<double,vect,tcf::Legendre2> ACFP2;

// ============================================================================
// ============================ single_value_CCF ===========================
template <class restype, class arg1type, class arg2type, class op = tcf::multiplies>
class single_value_CCF : public base_CCF<restype,arg1type,arg2type,op> {
public:
   single_value_CCF ( const std::string& key,
                      int t_size,
                      const mdformat& fmt,
                      const base_single_value_history_array<arg1type>& a,
                      const base_single_value_history_array<arg2type>& b )
      : base_CCF<restype,arg1type,arg2type,op>(key, t_size, fmt), arg1(a), arg2(b) {}
   virtual ~single_value_CCF () {}

//    virtual void update ( int thread_no, int nthreads ) override;
   virtual void update ( ) override;
private:
   const base_single_value_history_array<arg1type>& arg1;
   const base_single_value_history_array<arg2type>& arg2;
};

template <class restype, class arg1type, class arg2type, class op>
void single_value_CCF<restype,arg1type,arg2type,op>::update ( ) {
   this->results[0].add ( arg1.getHA(), arg2.getHA() );
}
// ============================================================================
// ============================ single_value_ACF ===========================
template <class restype, class argtype, class op = tcf::multiplies>
class single_value_ACF : public base_ACF<restype,argtype,op> {
public:
   single_value_ACF ( const std::string& key,
                      int t_size,
                      const mdformat& fmt,
                      const base_single_value_history_array<argtype>& a )
      : base_ACF<restype,argtype,op>(key,t_size,fmt), arg(a) {}
   virtual ~single_value_ACF () {}

//    virtual void update ( int thread_no, int nthreads ) override;
   virtual void update ( ) override;
private:
   const base_single_value_history_array<argtype>& arg;
};

template <class restype, class argtype, class op>
void single_value_ACF<restype,argtype,op>::update ( ) {
   //this->results[0].add ( arg.getHA() );
   this->results[0]->add ( arg.getHA() );
}

// ============================================================================
// =================================== Cdif ===================================
#include "mymath.h"
#include "units.h"
inline double calc_CDif_ABS ( const TTDF<double>* f, double tstep ) {
   const int size = f->size();
   std::vector<double> tmp;

   for ( int i = 0; i < size; ++i ) {
      tmp.push_back ( (*f)[i] * (*f)[i] );
   }

   double a = -1.0; // invalid value in this context, error indicator. better to use NaN?
   lmnk1x ( tmp, size/4, size-size/4, tstep*size/4, tstep, &a, 0 );

   return 1e9 * LENGTH_UNIT*LENGTH_UNIT/TIME_UNIT * a * SI_PI / 16.0;
}

inline double calc_CDif_SQR ( const TTDF<double>* f, double tstep ) {
   const int size = f->size();
   double a;
   lmnk1x ( *f, size/4, size-size/4, tstep*size/4, tstep, &a, 0 );
   return 1e9 * LENGTH_UNIT*LENGTH_UNIT/TIME_UNIT * a / 6.0;
}

#endif
