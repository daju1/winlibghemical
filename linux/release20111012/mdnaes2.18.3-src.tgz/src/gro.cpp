#include "lib/mdformat.h"
#include "globals.h"
#include "units.h"
#include "all_particles.h"
#include "lib/constsi.h"
using namespace mdnaes;

//#include <cstdlib>
//#include <ctime>
//#include <cmath>
#include <iomanip>
#include <limits>


void Print_gro () { // prints GROMACS gro file
   std::ofstream out ( "conf.gro" );
   
   printSimulatedSystemMessage ( out );
   
   int natoms = 0;
   for ( const auto& array: SimSystem.molecules ) {
      if ( array.size() > 0 )
         natoms += array.size() * array[0]->natoms();
   }
   for ( const auto& array: SimSystem.cations ) {
      if ( array.size() > 0 )
         natoms += array.size() * array[0]->natoms();
   }
   for ( const auto& array: SimSystem.anions ) {
      if ( array.size() > 0 )
         natoms += array.size() * array[0]->natoms();
   }
   
   out << natoms << std::endl;
   
   int curmol = 0, curatom = 0;
   for ( std::size_t i = 0; i < SimSystem.all_particles.size(); ++i ) {
      for ( auto a: *(SimSystem.all_particles[i]) ) {
         out << mdformat(5) << i+1;
         out << std::setw(5) << std::left << SimSystem.all_particles[i]->name();
         out << mdformat(5)  << a.name();
         out << mdformat(5) << curatom+1;
         out << mdformat(8,3) << a.r();
         out << mdformat(8,4) << a.v();
         out << std::endl;
         curatom++;
      }
      curmol++;
   }
   
   out << mdformat(10,5) << LBOX << mdformat(10,5) << LBOX << mdformat(10,5) << LBOX;
}

int Import_gro ( std::istream &in ) { // import GROMACS gro file
   // skip first line:
   // printSimulatedSystemMessage ( out );
   in.ignore(std::numeric_limits<int>::max(),'\n');

   int natoms = 0;
   for ( const auto& array: SimSystem.molecules ) {
      if ( array.size() > 0 )
         natoms += array.size() * array[0]->natoms();
   }
   for ( const auto& array: SimSystem.cations ) {
      if ( array.size() > 0 )
         natoms += array.size() * array[0]->natoms();
   }
   for ( const auto& array: SimSystem.anions ) {
      if ( array.size() > 0 )
         natoms += array.size() * array[0]->natoms();
   }
   
   int natoms_new = 0;
   in >> natoms_new;
   in.ignore(std::numeric_limits<int>::max(),'\n');
   if ( natoms != natoms_new ) {
      // ellegal number of atoms on input
      std::cout << "Error in Import_gro: " << "total number of atoms in gro file (" << natoms_new \
      << ") and in system (" << natoms << ") don't match." << std::endl;
      Error     << "Error in Import_gro: " << "total number of atoms in gro file (" << natoms_new \
      << ") and in system (" << natoms << ") don't match." << std::endl;
      //exit ( EXIT_FAILURE );
      return 1;
   }
   

   
   int i, j;
   int curmol = 0, curatom = 0;
   //static char line[1000];
   
   //out << natoms << std::endl;
   
   for ( auto p: SimSystem.all_particles ) {
      for ( auto a: *p ) {
         int mol_nr  = -1;
         int atom_nr = -1;
         /*
         line[0] = '\0';
         in.getline(line,sizeof(line));
         if ( line[0] == '\0' ) {
            // cannot read data line
            std::cout << "Error in Import_gro: " << "cannot find input line for molecule " << curmol << ", atom " << curatom << std::endl;
            Error     << "Error in Import_gro: " << "cannot find input line for molecule " << curmol << ", atom " << curatom << std::endl;
            //exit ( EXIT_FAILURE );
            return 2;
         }
         */
         
         // skip mol_number, mol_name, atom_name and atomnumber
         in.ignore(5+5+5+5,'\n');
         //out << mdformat(5) << i+1;
         //out << std::setw(5) << std::left << all_particles[i]->name();
         //out << mdformat(5)  << all_particles[i]->getAtom(j).name();
         //out << mdformat(5) << curatom+1;
         
         
         //out << mdformat(8,3) << all_particles[i]->getAtom(j).r;
         //out << mdformat(8,4) << all_particles[i]->getAtom(j).v;
         //out << std::endl;
         vect r, v;
         in >> r >> v; // must have velocities in gro file!
         in.ignore(std::numeric_limits<int>::max(),'\n');
         
         a.r() = r;
         a.v() = v;
         
         curatom++;
      }
      curmol++;
   }
   
   //out << mdformat(10,5) << LBOX << mdformat(10,5) << LBOX << mdformat(10,5) << LBOX;
   in >> LBOX; // assuming cubic box
   setBoxSizeVariables ();
   return 0;
}

