#ifndef MYLIST_H
#define MYLIST_H

#include <string>

class mylist_item;

class mylist {
public:
   mylist ( const std::string& );
   mylist ( const mylist& );
   ~mylist ();

   mylist& operator = ( const mylist& );

   int num_elems () const { return numelems; }
   const std::string& getval () const { return value; }
   const mylist& get_elem ( int ) const;

   mylist& add ( const mylist& );
private:
   void release ();
private:
   std::string value;

   mylist_item *root;
   mylist_item *end;
   int numelems;
};

class mylist_item {
private:
   mylist_item *next;
   mylist sublist;

   mylist_item ( const mylist& m ) : next ( nullptr ), sublist ( m ) { }

   friend class mylist;
};


class mylist_const_iterator {
public:
   mylist_const_iterator ( const mylist& );
   mylist_const_iterator ( const mylist_const_iterator& );
   ~mylist_const_iterator () { }

   mylist_const_iterator& operator = ( const mylist_const_iterator& );

   bool is_on_end ()   const;
   bool is_on_start () const;

   mylist_const_iterator& operator ++ ();
   mylist_const_iterator& operator -- ();

   void reset ( int = 0 );

   const std::string& item_name () const { return repList->get_elem(index).getval(); }
   const mylist& get_item () const   { return repList->get_elem(index); }
   int    get_int ()    const;
   std::size_t get_size_t () const;
   double get_double () const;

   bool find ( const char *str );
private:
   const mylist *repList;
   int index;
};


inline mylist_const_iterator& operator >> ( mylist_const_iterator& it, int& x ) {
   x = it.get_int();
   ++it;
   return it;
}

inline mylist_const_iterator& operator >> ( mylist_const_iterator& it, std::size_t& x ) {
   x = it.get_size_t();
   ++it;
   return it;
}

inline mylist_const_iterator& operator >> ( mylist_const_iterator& it, double& x ) {
   x = it.get_double();
   ++it;
   return it;
}

inline mylist_const_iterator& operator >> ( mylist_const_iterator& it, float& x ) {
   x = it.get_double();
   ++it;
   return it;
}

#endif
