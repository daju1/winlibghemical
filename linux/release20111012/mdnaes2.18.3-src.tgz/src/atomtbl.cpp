#include "globals.h"
#include "atomtbl.h"
#include "units.h"
#include "md_exception.h"

interactions_table::interactions_table ( atom_types_table& at_tbl ) : m_AtomTypes(at_tbl) {
   n_atom_types = 0;

   for ( int i = 0; i < MAX_ATOM_TYPES; ++i )
      for ( int j = 0; j < MAX_ATOM_TYPES; ++j )
         m_Interactions[i][j] = nullptr;
   m_AtomTypes.register_interactions_table ( this );
}

int interactions_table::natom_types () const {
   return n_atom_types;
}

bool interactions_table::is_OK () const {
   for ( int i = 0; i < n_atom_types; ++i )
      for ( int j = 0; j < n_atom_types; ++j )
         if ( m_Interactions[i][j] == nullptr )
            return false;
   return true;
}

bool interactions_table::is_present ( int id1, int id2 ) const {
   return ( m_Interactions[id1][id2] != nullptr );
}

interaction* interactions_table::get_interaction ( int id1, int id2 ) const {
   return m_Interactions[id1][id2];
}

void interactions_table::clear () {
   for ( int i = 0; i < MAX_ATOM_TYPES; ++i )
      for ( int j = 0; j < MAX_ATOM_TYPES; ++j )
         m_Interactions[i][j] = nullptr;
   n_atom_types = 0;
}

void interactions_table::add_interaction ( int id1, int id2, interaction *I ) {
   m_Interactions[id1][id2] = I;
   m_Interactions[id2][id1] = m_Interactions[id1][id2];
}

void interactions_table::read_interaction ( mylist_const_iterator& in ) {
   int id1 = m_AtomTypes.id ( in.item_name() );
   ++in;
   int id2 = m_AtomTypes.id ( in.item_name() );
   ++in;
   const std::string& key = in.item_name();
   ++in;

   if ( key == "LJ6-12" )
      m_Interactions[id1][id2] = LJ_6_12::read_params ( in );
   if ( key == "LJ6-9" )
      m_Interactions[id1][id2] = LJ_6_9::read_params ( in );
   if ( key == "LJ4-8" )
      m_Interactions[id1][id2] = LJ_4_8::read_params ( in );
   if ( key == "Exp_DivR" )
      m_Interactions[id1][id2] = Exp_DivR::read_params ( in );
   if ( key == "A*exp(-r/r0)/r-B/r^4" || key == "Exp_R4" )
      m_Interactions[id1][id2] = Exp_R4::read_params ( in );
   if ( key == "A*exp(-r/r0)/r-B/r^6" || key == "Exp_R6" )
      m_Interactions[id1][id2] = Exp_R6::read_params ( in );
   if ( key == "null" )
      m_Interactions[id1][id2] = null_interaction::read_params ( in );

   m_Interactions[id2][id1] = m_Interactions[id1][id2];
}

int interactions_table::expand () {
   if ( n_atom_types >= MAX_ATOM_TYPES ) {
      Error << "number of atom types is too large (must be < " << MAX_ATOM_TYPES+1 << ")\n";
      raise_md_exception ( "Error in interactions_table::expand()" );
   }
   int row, col;
   for ( row = n_atom_types, col = 0; col <= n_atom_types; ++col )
      m_Interactions[row][col] = nullptr;
   for ( row = 0, col = n_atom_types; row < n_atom_types; ++row )
      m_Interactions[row][col] = nullptr;
   n_atom_types++;
   return n_atom_types;
}

// ====================================================================================

bool atom_types_table::is_present ( int id ) const {
   return ( id < m_Atom_types.size() && id >= 0 );
}

bool atom_types_table::is_present ( const std::string& at_name ) const {
   int i = find_id ( m_Atom_types, at_name );
   if ( i < 0 || i >= m_Atom_types.size () ) {
      return false;
   }
   return true;
}

int atom_types_table::id ( const std::string& at_name ) const {
   int i = find_id ( m_Atom_types, at_name );
   if ( i < 0 || i >= m_Atom_types.size () ) {
      Error << "cannot find atom name: " << at_name << "\n";
      raise_md_exception ( "Error in atom_types_table::id()" );
   }
   return i;
}

const std::string& atom_types_table::name ( int ID ) const {
   return m_Atom_types.at(ID).name();
}

const atom_type& atom_types_table::get_atom_type ( int ID ) const {
   return m_Atom_types.at ( ID );
}

void atom_types_table::read_atom_type ( mylist_const_iterator& in,
                                        int use_shifted_force,
                                        int LJ_default_combining_rule ) {
   const std::string& Name = in.item_name ();
   ++in;
   if ( in.is_on_end() )
      raise_md_exception ( "atom_types_table::read_atom_type (): Cannot read mass in #atom definition" );

   const double mass = in.get_double() * EXTERNAL_MASS_UNIT / MASS_UNIT;
   ++in;

   const int atom_id = m_Atom_types.size();
   if ( in.is_on_end() ) { // this is dummy atom (without interactions at all).
      m_Atom_types.emplace_back ( Name, atom_id, mass,    0.0, true );
   }
   else {                  // this is normal atom
      const double charge = in.get_double() * EXTERNAL_CHARGE_UNIT / CHARGE_UNIT;
      ++in;
      m_Atom_types.emplace_back ( Name, atom_id, mass, charge, false );
   }
   const int num_at = m_Atom_types.size();
   
   m_InteractionsTable->expand ();

   if ( in.is_on_end() ) { // no short-ranged interactions with this atom
      has_defaults.emplace_back ( atom_types_table::Null_defaults );
      sigmas.emplace_back ( 0.0 );
      epsilons.emplace_back ( 0.0 );

      for ( int i = 0; i < num_at; ++i )
         m_InteractionsTable->add_interaction ( i, num_at-1, new null_interaction () );
   }
   else if ( in.item_name() == "LJ" ) {
      has_defaults.emplace_back ( LJ_defaults );
      ++in;
      sigmas.emplace_back   ( in.get_double() * EXTERNAL_LENGTH_UNIT / LENGTH_UNIT );
      ++in;
      epsilons.emplace_back ( in.get_double() * EXTERNAL_ENERGY_UNIT / ENERGY_UNIT );
      ++in;

      for ( int i = 0; i < num_at; ++i ) {
         if ( has_defaults[i] == LJ_defaults ) {
            double sigma   = 0.0;
            double epsilon = 0.0;
            switch (LJ_default_combining_rule) {
               case 0:
                  sigma   = 0.5*(sigmas.at(i)+sigmas.at(num_at-1));
                  epsilon = sqrt(epsilons.at(i)*epsilons.at(num_at-1));
                  break;
               case 1:
                  sigma   = sqrt(sigmas.at(i)  * sigmas.at(num_at-1));
                  epsilon = sqrt(epsilons.at(i)* epsilons.at(num_at-1));
                  break;
               default:
                  ;
            }

            m_InteractionsTable->add_interaction ( i, num_at-1,
               use_shifted_force == 0 ? (interaction*)new LJ_6_12   ( sigma, epsilon )
                                      : (interaction*)new LJ_6_12_SF( sigma, epsilon ) );
         }
         else if ( has_defaults.at(i) == atom_types_table::Null_defaults )
            m_InteractionsTable->add_interaction ( i, num_at-1, new null_interaction () );
      }
   }
   else {
      raise_md_exception ( "atom_types_table::read_atom_type (): Not supported parameter in #atom definition" );
   }
}
