#ifndef UNITS_H
#define UNITS_H

#include "lib/constsi.h"
//!!!  external_value * EXTERNAL_UNIT = standart_value (in SI units)
//!!!  internal_value * INTERNAL_UNIT = standart_value (in SI units)

constexpr double LENGTH_UNIT = 1.0e-09;                // nm
constexpr double   TIME_UNIT = 1.0e-12;                // ps
constexpr double CHARGE_UNIT = SI_E;                   // |e|
constexpr double   MASS_UNIT = SI_AMU;                 // a.m.u.

//                        Complex units
constexpr double VOLUME_UNIT = LENGTH_UNIT * LENGTH_UNIT * LENGTH_UNIT;
constexpr double ENERGY_UNIT = MASS_UNIT * LENGTH_UNIT * LENGTH_UNIT / ( TIME_UNIT * TIME_UNIT );
constexpr double CPROD_UNIT  = ENERGY_UNIT * LENGTH_UNIT;
constexpr double DIPOLE_MOMENTUM_UNIT = CHARGE_UNIT * LENGTH_UNIT;
constexpr double PRESSURE_UNIT = ENERGY_UNIT / VOLUME_UNIT;

//        External units, used in input and output files
constexpr double EXTERNAL_LENGTH_UNIT = 1.0e-09;       // nm
constexpr double EXTERNAL_TIME_UNIT   = 1.0e-12;       // ps
constexpr double EXTERNAL_MASS_UNIT   = SI_AMU;        // a.m.u.
constexpr double EXTERNAL_CHARGE_UNIT = SI_E;          // |e|
constexpr double EXTERNAL_ENERGY_UNIT = 1000 / SI_Na;  // kJ / mol
constexpr double EXTERNAL_DIPOLE_MOMENTUM_UNIT = SI_D; // Debye
constexpr double EXTERNAL_PRESSURE_UNIT = 101.3e3;     // atm

#endif
