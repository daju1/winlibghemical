#ifndef INTERACTIONS_H
#define INTERACTIONS_H

#include <iostream>
#include <utility>
#include "mylist.h"
#include "real.h"


class interaction {
public:
   //virtual ~interaction () {};

   struct res_t { real U; real Vir; };
   
   virtual res_t operator () ( real r, real ri ) const = 0;
   virtual real DC_energy ( real Rc ) const = 0; // integral from Rc to +inf of 4*pi*r*r*U(r)*dr
   virtual real DC_virial ( real Rc ) const = 0; // integral from Rc to +inf of 4*pi*r*r*Vir(r)*dr

   virtual void print ( std::ostream& ) const = 0;
};

// =========================================================================================
extern interaction **all_interactions;

// =========================================================================================
class null_interaction : public interaction {
public:
   null_interaction ();
   virtual res_t operator () ( real r, real ri ) const override;
   virtual real DC_energy ( real Rc ) const override;
   virtual real DC_virial ( real Rc ) const override;

   virtual void print ( std::ostream& ) const override;
   static null_interaction* read_params ( mylist_const_iterator& );
};

class LJ_6_12 : public interaction { // Uij = C12*r^-12 - C06*r^6
private:
   real C06; // C06 = 4*epsilon/sigma^6
   real C12; // C12 = 4*epsilon/sigma^12
public:
   LJ_6_12 ( real sigma, real epsilon );
   
   virtual res_t operator () ( real r, real ri ) const override;
   virtual real DC_energy ( real Rc ) const override;
   virtual real DC_virial ( real Rc ) const override;

   virtual void print ( std::ostream& ) const;
   static LJ_6_12* read_params ( mylist_const_iterator& );
};

class LJ_6_12_SF : public interaction { // Uij = C12*r^-12 - C06*r^6 
private:
   real C06; // C06 = 4*epsilon/sigma^6
   real C12; // C12 = 4*epsilon/sigma^12
   real CCut;
   real DCut;
public:
   LJ_6_12_SF ( real sigma, real epsilon );
   
   virtual res_t operator () ( real r, real ri ) const override;
   virtual real DC_energy ( real Rc ) const override;
   virtual real DC_virial ( real Rc ) const override;

   virtual void print ( std::ostream& ) const override;
   static LJ_6_12_SF* read_params ( mylist_const_iterator& );
};

class LJ_6_9 : public interaction { // Uij = C09*r^-9 - C06*r^6
private:
   real C06; // C06 = 27/4*epsilon/sigma^6
   real C09; // C09 = 27/4*epsilon/sigma^9
public:
   LJ_6_9 ( real sigma, real epsilon );
   
   virtual res_t operator () ( real r, real ri ) const override;
   virtual real DC_energy ( real Rc ) const override;
   virtual real DC_virial ( real Rc ) const override;

   virtual void print ( std::ostream& ) const override;
   static LJ_6_9* read_params ( mylist_const_iterator& );
};

class LJ_4_8 : public interaction {
private:
   real C04;
   real C08;
   real CCut;
   real DCut;
public:
   LJ_4_8 ( real sigma, real epsilon );
   virtual res_t operator () ( real r, real ri ) const override;
   virtual real DC_energy ( real Rc ) const override;
   virtual real DC_virial ( real Rc ) const override;

   virtual void print ( std::ostream& ) const override;
   static LJ_4_8* read_params ( mylist_const_iterator& );
};


class Exp_DivR : public interaction { // A*exp(-r/r0)/r
private:
   real A;
   real r0;
public:
   Exp_DivR ( real aa, real rr );
   virtual res_t operator () ( real r, real ri ) const override;
   virtual real DC_energy ( real Rc ) const override;
   virtual real DC_virial ( real Rc ) const override;

   virtual void print ( std::ostream& ) const override;
   static Exp_DivR* read_params ( mylist_const_iterator& );
};

class Exp_R4 : public interaction { // A*exp(-r/r0)/r - B/r^4
private:
   real A;
   real r0;
   real B;
public:
   Exp_R4 ( real aa, real rr, real bb );
   virtual res_t operator () ( real r, real ri ) const override;
   virtual real DC_energy ( real Rc ) const override;
   virtual real DC_virial ( real Rc ) const override;

   virtual void print ( std::ostream& ) const override;
   static Exp_R4* read_params ( mylist_const_iterator& );
};

class Exp_R6 : public interaction { // A*exp(r/r0)/r - B/r^6
private:
   real A;
   real r0;
   real B;
public:
   Exp_R6 ( real aa, real rr, real bb );
   virtual res_t operator () ( real r, real ri ) const override;
   virtual real DC_energy ( real Rc ) const override;
   virtual real DC_virial ( real Rc ) const override;

   virtual void print ( std::ostream& ) const override;
   static Exp_R6* read_params ( mylist_const_iterator& );
};

#endif
