#ifndef CLUSTER_H
#define CLUSTER_H

#include <iosfwd>
#include <set>
#include <vector>

class cluster {
private:
   std::set<int> cations;
   std::set<int> anions;
public:
   virtual void read ( std::istream& );
   virtual void save ( std::ostream& ) const;

   cluster& clear () { cations.clear (); anions.clear ();  return *this; }
   cluster& addCat ( int index ) { cations.insert (index); return *this; }
   cluster& addAn  ( int index ) { anions.insert (index);  return *this; }

   int nCat () const { return cations.size(); }
   int nAn  () const { return anions.size();  }

   bool empty () const { return cations.empty() && anions.empty(); }
   bool has_cat ( int index ) const { return cations.count(index) != 0; }
   bool has_an  ( int index ) const { return anions.count(index) != 0; }

   bool operator == ( const cluster& other ) const { return cations == other.cations && anions == other.anions; }

   cluster& merge ( const cluster& other );

   friend cluster merge ( const cluster& , const cluster& );
   friend cluster intersect ( const cluster& , const cluster& );
   friend bool has_intersection ( const cluster& , const cluster& );
};

cluster merge ( const cluster& , const cluster& );
cluster intersect ( const cluster& , const cluster& );
bool has_intersection ( const cluster& , const cluster& );


class cluster_collection {
private:
   std::vector<cluster> m_clusters;
public:
   void add ( const cluster& cl ) { m_clusters.emplace_back (cl); }
   void addPair ( int c, int a ) { m_clusters.emplace_back (cluster{}.addCat(c).addAn(a)); }

   void read ( std::istream& );
   void save ( std::ostream& ) const;

   int size () const { return m_clusters.size(); }
   auto begin () const { return m_clusters.begin(); }
   auto begin () { return m_clusters.begin(); }
   auto end () const { return m_clusters.end(); }
   auto end () { return m_clusters.end(); }

   const cluster& operator [] ( int i ) const { return m_clusters[i]; }
   cluster& operator [] ( int i ) { return m_clusters[i]; }

   void proceed (); // trying to merge as many clusters as possible
   void clear () { m_clusters.resize (0); }
};

#endif
