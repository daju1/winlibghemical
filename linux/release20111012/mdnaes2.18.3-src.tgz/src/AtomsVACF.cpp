#include "AtomsVACF.h"

#include <vector>
#include <memory>

#include "corr_aux.h"
#include "corclass.h"
#include "corclass_utils.h"
#include "correl.h"
#include "globals.h"
#include "iomanager.h"
#include "lib/mdformat.h"
using namespace mdnaes;

// ================================== Atoms VACF ==================================
static std::vector<const_atom_ref> all_atoms {};
static std::vector<subsystem<const_atom_ref> > atoms_by_types {};

static const char *AtomsVACFFileName    = "AtomsVACF.cf";
static const char *AtomsVACFResFileName = "AtomsVACF.dat";

static iomanager AtomsVACF_IOManager ( AtomsVACFFileName );


static vect AtomV_calc ( const const_atom_ref  a ) {
   return a.v();
}

static void SaveAtomsVACF ();
static void ResultAtomsVACF ();
static void ReleaseAtomsVACF ();

static std::vector<std::unique_ptr<base_history_array> > AtomsVACF_history_arrays;
static std::vector<std::unique_ptr<TDF> > AtomsVACF_Cvvs;

static std::unique_ptr<HA_Allocator<vect> >  vect_HA_allocator;

static int this_nthreads = 1;

static void AtomsVACF_init () {
   vect_HA_allocator = std::make_unique<HA_Allocator<vect> >   (CorrelSize, 30);
   
   if ( NTHREADS > 1 ) {
      this_nthreads = std::max(2,NTHREADS/2);
   }
   else {
      this_nthreads = 1;
   }
   
   int natoms = 0;
   for ( auto p: SimSystem.all_particles ) {
      natoms += p->natoms();
   }

   for ( auto p: SimSystem.all_particles ) {
      for ( auto a: *p ) {
         all_atoms.push_back (a);
      }
   }

   for ( const auto& t: Atom_types ) {
      atoms_by_types.emplace_back ( t.name(), all_atoms );
   }
   
   for ( auto& s: atoms_by_types ) {
      s.removeall();
   }

   for ( int i = 0; i < natoms; ++i ) {
      atoms_by_types[all_atoms[i].id()].add (i);
   }


   const mdformat format(11,5);

   multiple_value_history_array_creator<vect,const_atom_ref> VCM ( "VCM", *vect_HA_allocator, AtomV_calc, AtomsVACF_history_arrays );
   single_molecule_ACF_creator<double,vect,const_atom_ref> Cvv ( "Cvv", VCM, format );

   Message << "starting Cvv calculation for atoms" << std::endl;

   for ( const auto& s: atoms_by_types ) {
      AtomsVACF_Cvvs.emplace_back ( Cvv.create (s, this_nthreads) );
   }
   
   for ( const auto& p: AtomsVACF_history_arrays ) {
      AtomsVACF_IOManager.add ( p.get() );
   }

   for ( const auto& p: AtomsVACF_Cvvs ) {
      AtomsVACF_IOManager.add ( p.get() );
   }

   if ( KLH ) {
      Message << "reading atomic Cvvs from file...";
      AtomsVACF_IOManager.read ();
      Message << " done" << std::endl;
   }

   SMan.AddFun ( &SaveAtomsVACF );
   ShowRes.AddFun ( &ResultAtomsVACF );
}

static void do_update_CF ( int thread_no ) {
   for ( const auto& p: AtomsVACF_history_arrays ) {
      p->update ( thread_no, this_nthreads );
   }
   
   for ( const auto& p: AtomsVACF_Cvvs ) {
      p->update ( thread_no, this_nthreads );
   }
}

void AtomsVACF_Calc () {
   static bool init = true;
   if ( init ) {
      AtomsVACF_init ();
      init = false;
   }
   
   exec_parallel ( do_update_CF, this_nthreads );
}

static void SaveAtomsVACF () {
   for ( const auto& p: AtomsVACF_Cvvs ) {
      p->sync ( );
   }
   AtomsVACF_IOManager.save ();
}

static void ResultAtomsVACF () {
   for ( const auto& p: AtomsVACF_Cvvs ) {
      p->sync ( );
   }
   PrintTDFRes ( AtomsVACF_Cvvs, AtomsVACFResFileName, StepShortCF );
}
