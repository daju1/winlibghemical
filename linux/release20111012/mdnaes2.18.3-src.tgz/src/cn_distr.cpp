#include <iostream>
#include <fstream>
#include <algorithm>

#include "globals.h"
#include "version.h"
#include "all_particles.h"
#include "lib/mdformat.h"
#include "distr_func.h"
using namespace mdnaes;

// ============================================================================
static const char *CoorNumFileName = "cndistr.cf";
static const char *CN_distr_2D_ResFileName = "cndistr2d.dat";
static const char *CN_distr_1D_ResFileName = "cndistr1d.dat";

static distrib_2D* cn_kat1 = 0;
static distrib_2D* cn_kat2 = 0;
static distrib_2D* cn_an1 = 0;
static distrib_2D* cn_an2 = 0;

constexpr std::size_t MAX_CN_AVAIL = 48; // this is "magic" number.
static std::size_t MAX_CN1;
static std::size_t MAX_CN2;

static void CN_distr_save ();
static void CN_distr_PrintRes ();
static void CN_distr_Init ();

void CN_distr_Calc () {
   static bool init = true;
   if ( init ) {
      CN_distr_Init ();
      init = false;
   }

   if ( SimSystem.all_ions.size() == 0 )
      return;

   if ( SimSystem.all_cations.size() == 1 && SimSystem.all_anions.size() == 0 ) {
      int cn1FSS = 0, cn1SSS = 0;
      int cn2FSS = 0, cn2SSS = 0;

      const auto IonCMPos = SimSystem.all_cations[0]->getCoordinationCenters ();
      for ( auto p_mol: SimSystem.all_molecules1 ) {
         const double r = p_mol->getMinCationCoordinationCenterDistance (IonCMPos);
         if ( r > RSHL[1] ) continue; // 1bulk
         else
         if ( r > RSHL[0] ) cn1SSS++; // 1Kt2
         else               cn1FSS++; // 1Kt1
      }
      for ( auto p_mol: SimSystem.all_molecules2 ) {
         const double r = p_mol->getMinCationCoordinationCenterDistance (IonCMPos);
         if ( r > RSHL[6] ) continue; // 2bulk
         else
         if ( r > RSHL[5] ) cn2SSS++; // 2Kt2
         else               cn2FSS++; // 2Kt1
      }
      cn_kat1->add ( cn1FSS, cn2FSS );
      cn_kat2->add ( cn1SSS, cn2SSS );
      
      return;
   }

   if ( SimSystem.all_cations.size() == 0 && SimSystem.all_anions.size() == 1 ) {
      int cn1FSS = 0, cn1SSS = 0;
      int cn2FSS = 0, cn2SSS = 0;

      const auto IonCMPos = SimSystem.all_anions[0]->getCoordinationCenters ();
      for ( auto p_mol: SimSystem.all_molecules1 ) {
         const double r = p_mol->getMinAnionCoordinationCenterDistance (IonCMPos);
         if ( r > RSHL[3] ) continue; // 1bulk
         else
         if ( r > RSHL[2] ) cn1SSS++; // 1An2
         else               cn1FSS++; // 1An1
      }
      for ( auto p_mol: SimSystem.all_molecules2 ) {
         const double r = p_mol->getMinAnionCoordinationCenterDistance (IonCMPos);
         if ( r > RSHL[8] ) continue; // 2bulk
         else
         if ( r > RSHL[7] ) cn2SSS++; // 2An2
         else               cn2FSS++; // 2An1
      }
      cn_an1->add ( cn1FSS, cn2FSS );
      cn_an2->add ( cn1SSS, cn2SSS );
      
      return;
   }

   for ( auto p_ion: SimSystem.all_cations ) {
      int cn1FSS = 0;
      int cn2FSS = 0;
      
      const auto IonCMPos = p_ion->getCoordinationCenters ();
      
      for ( auto p_mol: SimSystem.all_molecules1 ) {
         const double r = p_mol->getMinCationCoordinationCenterDistance (IonCMPos);
         if ( r < RSHL[0] )
            cn1FSS++; // 1Kt1
      }
      for ( auto p_mol: SimSystem.all_molecules2 ) {
         const double r = p_mol->getMinCationCoordinationCenterDistance (IonCMPos);
         if ( r < RSHL[5] )
            cn2FSS++; // 2Kt1
      }
      cn_kat1->add ( cn1FSS, cn2FSS );
   }
   
   for ( auto p_ion: SimSystem.all_anions ) {
      int cn1FSS = 0;
      int cn2FSS = 0;
      
      const auto IonCMPos = p_ion->getCoordinationCenters ();
      for ( auto p_mol: SimSystem.all_molecules1 ) {
         const double r = p_mol->getMinAnionCoordinationCenterDistance (IonCMPos);
         if ( r < RSHL[2] )
            cn1FSS++; // 1An1
      }
      for ( auto p_mol: SimSystem.all_molecules2 ) {
         const double r = p_mol->getMinAnionCoordinationCenterDistance (IonCMPos);
         if ( r < RSHL[7] )
            cn2FSS++; // 2An1
      }
      cn_an1->add ( cn1FSS, cn2FSS );
   }
}

static void CN_distr_Init () {
   Message << "starting coordination numbers distributions calculation" << std::endl;

   MAX_CN1 = std::min(SimSystem.all_molecules1.size(), MAX_CN_AVAIL);
   MAX_CN2 = std::min(SimSystem.all_molecules2.size(), MAX_CN_AVAIL);

   if ( SimSystem.all_ions.size() == 0 ) {
      return;
   }
   else if ( SimSystem.all_cations.size() == 1 && SimSystem.all_anions.size() == 0 ) {
      cn_kat1 = new distrib_2D ( MAX_CN1+1, MAX_CN2+1 );
      cn_kat2 = new distrib_2D ( MAX_CN1+1, MAX_CN2+1 );
   }
   else if ( SimSystem.all_cations.size() == 0 && SimSystem.all_anions.size() == 1 ) {
      cn_an1  = new distrib_2D ( MAX_CN1+1, MAX_CN2+1 );
      cn_an2  = new distrib_2D ( MAX_CN1+1, MAX_CN2+1 );
   }
   else {
      if ( SimSystem.all_cations.size() > 1 ) {
         cn_kat1 = new distrib_2D ( MAX_CN1+1, MAX_CN2+1 );
      }
      if ( SimSystem.all_anions.size() > 1 ) {
         cn_an1  = new distrib_2D ( MAX_CN1+1, MAX_CN2+1 );
      }
   }

   if ( KLH ) {
      std::ifstream in ( CoorNumFileName, std::ios::binary | std::ios::in );
      if ( !in ) {
         std::cerr << '\a';
         Error << __FILE__ << "; void CN_distr_Calc ()" << ": cannot open file " << CoorNumFileName;
         Error << "\n" "starting new coordination numbers calculation." << std::endl;
      }
      else {
         version::check_ver ( in, CoorNumFileName );
         if ( cn_kat1 ) cn_kat1->read ( in );
         if ( cn_kat2 ) cn_kat2->read ( in );
         if ( cn_an1 )  cn_an1->read ( in );
         if ( cn_an2 )  cn_an2->read ( in );
      }
   }

   SMan.AddFun ( &CN_distr_save );
   ShowRes.AddFun ( &CN_distr_PrintRes );
}

static void CN_distr_save () {
   std::ofstream out ( CoorNumFileName, std::ios::binary | std::ios::out | std::ios::trunc );

   version::out ( out );
   if ( cn_kat1 ) cn_kat1->save ( out );
   if ( cn_kat2 ) cn_kat2->save ( out );
   if ( cn_an1 )  cn_an1->save ( out );
   if ( cn_an2 )  cn_an2->save ( out );
}

static void CN_distr_PrintRes () {
   if ( SimSystem.all_ions.size() == 0 ) return;

   std::ofstream out2D ( CN_distr_2D_ResFileName );
   const mdformat cn_format (4,0);
   const mdformat format (7,3);

   out2D << cn_format << "cn1" << cn_format << "cn2";
   if ( cn_kat1 ) out2D << format << "Kat1";
   if ( cn_kat2 ) out2D << format << "Kat2";
   if ( cn_an1 )  out2D << format << "An1";
   if ( cn_an2 )  out2D << format << "An2";
   out2D << "\n";

   out2D << mdformat(8,0) << "CN1:   ";
   if ( cn_kat1 ) out2D << format << cn_kat1->get_aveX ();
   if ( cn_kat2 ) out2D << format << cn_kat2->get_aveX ();
   if ( cn_an1 )  out2D << format << cn_an1->get_aveX ();
   if ( cn_an2 )  out2D << format << cn_an2->get_aveX ();
   out2D << "\n";
   out2D << mdformat(8,0) << "CN2:   ";
   if ( cn_kat1 ) out2D << format << cn_kat1->get_aveY ();
   if ( cn_kat2 ) out2D << format << cn_kat2->get_aveY ();
   if ( cn_an1 )  out2D << format << cn_an1->get_aveY ();
   if ( cn_an2 )  out2D << format << cn_an2->get_aveY ();
   out2D << "\n";

   for ( int i = 0; i <= MAX_CN1; ++i ) {
      for ( int j = 0; j <= MAX_CN2; ++j ) {
         out2D << cn_format << i << cn_format << j;
         if ( cn_kat1 ) out2D << format << cn_kat1->get_value (i,j);
         if ( cn_kat2 ) out2D << format << cn_kat2->get_value (i,j);
         if ( cn_an1 )  out2D << format << cn_an1->get_value (i,j);
         if ( cn_an2 )  out2D << format << cn_an2->get_value (i,j);
         out2D << "\n";
      }
   }
}
