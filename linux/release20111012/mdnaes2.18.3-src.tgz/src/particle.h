#ifndef PARTICLE_H
#define PARTICLE_H

#include "basic_particle.h"

#include "lib/vect.h"
#include "lib/matrix_3x3.h"
#include "atom.h"
#include "mylist.h"
#include "atomtbl.h"
#include "md_exception.h"
using namespace mdnaes;

#include <iosfwd>

class particle_type : public basic_particle_type {
protected:
   particle_type ( mylist_const_iterator& );

   vect getInitialCMPos () const;
   void getInitialInertiaTensor ( double I[3][3] ) const;
   
public:
   virtual ~particle_type ();
   
   double charge () const;

   double getInitialInteratomicDistance ( int i, int j ) const;

   virtual int nRotDegFree () const = 0;
   virtual int nVibrDegFree () const = 0;
   virtual int nDegFree () const;

   virtual void print ( std::ostream& ) const;

   enum { general = 0, linear, point };
   virtual int shape () const = 0;
};

class particle : public basic_particle {
private:
   const particle_type *type;
protected:
   particle ( const particle_type *t, vect origin )
   : basic_particle(*t,origin), type(t) {}
   
   particle ( const particle &src, vect cmpos )
   : basic_particle(src,cmpos), type(src.type) {}
   
   //particle ( configuration_space& cs, const particle &src )
   //: basic_particle(cs,src), type(src.type) {}
   virtual ~particle ();
   
protected:
   double m_Ubond = 0.0;
   double m_Uangle = 0.0;
   double m_Udihedral = 0.0;
   double m_Udihedral_2 = 0.0;
   double m_Uharmonic_dihedral = 0.0;
public:
   double Ubond () const { return m_Ubond; }
   double Uangle () const { return m_Uangle; }
   double Udihedral () const { return m_Udihedral; }
   double Udihedral_2 () const { return m_Udihedral_2; }
   double Uharmonic_dihedral () const { return m_Uharmonic_dihedral; }
   
   virtual void bonded_forces ( std::size_t thread_no = 0 );
   
public:
   virtual void move ( double tstep, int substeps, std::size_t thread_no = 0 ) = 0;
   virtual void correctorStep ( double tstep ) = 0;
   void scalv ( double factor );
   virtual void scalPos ( double factor );

   virtual void randomize_velocities () = 0;
   void reset_near_forces ();
   void reset_far_forces ();
   void sync_near_forces ();
   void sync_far_forces ();

   virtual int is_bonded ( int atom1, int atom2 ) const = 0;
   // if atoms i and j are bonded, then we shoud not calculate forces between them

   double charge () const;
   int shape () const { return type->shape (); }

   double interatomic_distance_error ( int i, int j ) const;

   vect getChargesCMPos () const;
   vect getCMVel () const;

   vect getAngleVelInMolAxes () const;
   virtual vect getAngleVelInBoxAxes () const;
   vect getAngleMomentumInMolAxes () const;
   vect getAngleMomentumInBoxAxes () const;

   vect getTorque () const; //returns momentum of force, acting on the particle
   vect getForce () const;

   vect getShortTorque () const; // from short-ranged forces
   vect getLongTorque () const;  // from long-ranged forces
   vect getShortForce () const;
   vect getLongForce () const;

   virtual vect getAngleAcceleration () const;
   virtual vect getShortAngleAcceleration () const;
   virtual vect getLongAngleAcceleration () const;

   vect getCMAcceleration () const;
   vect getShortCMAcceleration () const;
   vect getLongCMAcceleration () const;
   

   void getInertiaTenzor ( double I[3][3] ) const;
   virtual void getMolAxes ( vect [3] ) const = 0;
   virtual vect toMolAxes ( const vect& ) const;

   double getEkin () const;
   double getEkinTrans () const;
   virtual double getEkinRot () const = 0;
   virtual double getEkinVibr () const = 0;

   virtual vect getCurrent () const;
   virtual matrix_3x3 getInternalStress () const = 0;
   
   int nRotDegFree () const { return type->nRotDegFree(); }
   int nVibrDegFree () const { return type->nVibrDegFree(); }
   int nDegFree () const { return type->nDegFree(); }
};

#endif
