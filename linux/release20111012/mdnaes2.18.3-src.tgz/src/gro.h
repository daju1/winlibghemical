#include <iosfwd>

void Print_gro (); // prints GROMACS gro file
int Import_gro ( std::istream &in ); // import GROMACS gro file
