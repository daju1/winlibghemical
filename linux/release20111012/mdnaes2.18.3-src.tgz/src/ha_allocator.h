#ifndef HA_ALLOCATOR_H
#define HA_ALLOCATOR_H

#include "lib/HA.h"

#include <mutex>

// ================== class HA_Allocator ==================
template <class data_type> 
class HA_Allocator {
public:
   HA_Allocator ( int ha_sz, int Cache_sz );
  ~HA_Allocator ();

   HA<data_type>* Allocate ();
   void Deallocate ( HA<data_type>*& );
   int HA_size () const { return ha_size; }
private:
   const int ha_size;
   const int cache_size;
   HA<data_type>** cache;
   int top;
   
   std::mutex m_guard;
};

template <class data_type>
HA_Allocator<data_type>::HA_Allocator ( int ha_sz, int Cache_sz )
: ha_size(ha_sz), cache_size(Cache_sz), cache(new HA<data_type>*[cache_size]), top(0) {
}

template <class data_type>
HA_Allocator<data_type>::~HA_Allocator () {
   for ( int i = 0; i < top; ++i )
      delete cache[i];
   delete[] cache;
}

template <class data_type>
HA<data_type>* HA_Allocator<data_type>::Allocate () {
   std::lock_guard<std::mutex> guard{m_guard};
   if ( top > 0 )
      return cache[--top];
   else
      return new HA<data_type>(ha_size);
}

template <class data_type>
void HA_Allocator<data_type>::Deallocate ( HA<data_type>*& ptr ) {
   std::lock_guard<std::mutex> guard{m_guard};
   if ( top < cache_size ) {
      ptr->clear();
      cache[top] = ptr;
      ptr = 0;
      ++top;
   } else {
      delete ptr;
      ptr = 0;
   }
}

#endif
