/* ======================================================
   | Copyright(c) by Departament Inorganic Chemistry of |
   | Kharkiv National University 1997-2006              |
   ====================================================== */
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <fstream>

#include "all_particles.h"
#include "globals.h"
#include "version.h"
#include "lib/mdformat.h"
#include "lib/vect.h"
#include "orient.h"
#include "subsystem.h"
#include "distr_func.h"
#include "lib/constsi.h"
using namespace mdnaes;

int KDSOR, KMolOr;
double StepRInShl;

// ==== Main orientation of molecules as function of ion-molecule distance ====
const char *OrVectFileName = "OrVect.cf";
const char *OrVectResFileName = "OrVect.dat";

static void SaveOrVect ();
static void ShowResOrVect ();

static aver_func *OrVectDipMom1Kat = 0;
static aver_func *OrVectDipMom2Kat = 0;
static aver_func *OrVectDipMom1An  = 0;
static aver_func *OrVectDipMom2An  = 0;
static aver_func *OrVectMainVect1Kat  = 0;
static aver_func *OrVectMainVect2Kat  = 0;
static aver_func *OrVectMainVect1An   = 0;
static aver_func *OrVectMainVect2An   = 0;

static int OrVectRSize = -1;

void OrVect_Calc () {
   static int init = 1;
   if ( init ) {
      Message << "starting calculation of average molecule orientations\n";
      Message << "as function of ion-molecule distance" << std::endl;

      OrVectRSize = static_cast<int> (LBOX2/StepRInShl);

      if ( SimSystem.all_cations.size() > 0 ) {
         if ( SimSystem.all_molecules1.size() > 0 ) {
            OrVectDipMom1Kat = new aver_func ( OrVectRSize );
            OrVectMainVect1Kat = new aver_func ( OrVectRSize );
         }
         if ( SimSystem.all_molecules2.size() > 0 ) {
            OrVectDipMom2Kat = new aver_func ( OrVectRSize );
            OrVectMainVect2Kat = new aver_func ( OrVectRSize );
         }
      }
      if ( SimSystem.all_anions.size() > 0 ) {
         if ( SimSystem.all_molecules1.size() > 0 ) {
            OrVectDipMom1An = new aver_func ( OrVectRSize );
            OrVectMainVect1An = new aver_func ( OrVectRSize );
         }
         if ( SimSystem.all_molecules2.size() > 0 ) {
            OrVectDipMom2An = new aver_func ( OrVectRSize );
            OrVectMainVect2An = new aver_func ( OrVectRSize );
         }
      }

      if ( KLH ) {
         std::ifstream in ( OrVectFileName, std::ios::binary | std::ios::in );
         if ( !in ) {
            Error << __FILE__ << "; void OrVect_Calc ()" << ": cannot open file " << OrVectFileName;
            Error << "\n" "starting new OrVect calculation" << std::endl;
         }
         else {
            version::check_ver ( in, OrVectFileName );
            if ( OrVectDipMom1Kat )   OrVectDipMom1Kat->read ( in );
            if ( OrVectMainVect1Kat ) OrVectMainVect1Kat->read ( in );
            if ( OrVectDipMom1An )    OrVectDipMom1An->read ( in );
            if ( OrVectMainVect1An )  OrVectMainVect1An->read ( in );
            if ( OrVectDipMom2Kat )   OrVectDipMom2Kat->read ( in );
            if ( OrVectMainVect2Kat ) OrVectMainVect2Kat->read ( in );
            if ( OrVectDipMom2An )    OrVectDipMom2An->read ( in );
            if ( OrVectMainVect2An )  OrVectMainVect2An->read ( in );
         }
      }
      SMan.AddFun ( &SaveOrVect );
      ShowRes.AddFun ( &ShowResOrVect );
      init = 0;
   }

   for ( auto c: SimSystem.all_cations ) {
      const vect IonPos = (c->getCoordinationCenters ())[0];
      for ( auto m: SimSystem.all_molecules1 ) {
         vect dr = m->getCationCoordinationCenter () - IonPos;
         PBC ( dr );
         const double r = norm (dr);

         const int rrr = static_cast<int> (r/StepRInShl);
         if ( rrr < OrVectRSize ) {
            const vect dipmom = m->getDipolMomentum ();
            OrVectDipMom1Kat->add   ( rrr, (dipmom*dr)/(norm(dipmom)*r) );
            const vect mvect  = m->getMainVect ();
            OrVectMainVect1Kat->add ( rrr, (mvect*dr)/(norm(mvect)*r) );
         }
      }
      for ( auto m: SimSystem.all_molecules2 ) {
         vect dr = m->getCationCoordinationCenter () - IonPos;
         PBC ( dr );
         const double r = norm (dr);

         const int rrr = static_cast<int> (r/StepRInShl);
         if ( rrr < OrVectRSize ) {
            const vect dipmom = m->getDipolMomentum ();
            OrVectDipMom2Kat->add   ( rrr, (dipmom*dr)/(norm(dipmom)*r) );
            const vect mvect  = m->getMainVect ();
            OrVectMainVect2Kat->add ( rrr, (mvect*dr)/(norm(mvect)*r) );
         }
      }
   }
   
   for ( auto a: SimSystem.all_anions ) {
      const vect IonPos = (a->getCoordinationCenters ())[0];
      for ( auto m: SimSystem.all_molecules1 ) {
         vect dr = m->getAnionCoordinationCenter () - IonPos;
         PBC ( dr );
         const double r = norm (dr);

         const int rrr = static_cast<int> (r/StepRInShl);
         if ( rrr < OrVectRSize ) {
            const vect dipmom = m->getDipolMomentum ();
            OrVectDipMom1An->add   ( rrr, (dipmom*dr)/(norm(dipmom)*r) );
            const vect mvect  = m->getMainVect ();
            OrVectMainVect1An->add ( rrr, (mvect*dr)/(norm(mvect)*r) );
         }
      }
      for ( auto m: SimSystem.all_molecules2 ) {
         vect dr = m->getAnionCoordinationCenter () - IonPos;
         PBC ( dr );
         const double r = norm (dr);

         const int rrr = static_cast<int> (r/StepRInShl);
         if ( rrr < OrVectRSize ) {
            const vect dipmom = m->getDipolMomentum ();
            OrVectDipMom2An->add   ( rrr, (dipmom*dr)/(norm(dipmom)*r) );
            const vect mvect  = m->getMainVect ();
            OrVectMainVect2An->add ( rrr, (mvect*dr)/(norm(mvect)*r) );
         }
      }
   }
}

static void SaveOrVect () {
   std::ofstream out ( OrVectFileName, std::ios::binary | std::ios::out | std::ios::trunc );

   version::out ( out );
   if ( OrVectDipMom1Kat )   OrVectDipMom1Kat->save ( out );
   if ( OrVectMainVect1Kat ) OrVectMainVect1Kat->save ( out );
   if ( OrVectDipMom1An )    OrVectDipMom1An->save ( out );
   if ( OrVectMainVect1An )  OrVectMainVect1An->save ( out );
   if ( OrVectDipMom2Kat )   OrVectDipMom2Kat->save ( out );
   if ( OrVectMainVect2Kat ) OrVectMainVect2Kat->save ( out );
   if ( OrVectDipMom2An )    OrVectDipMom2An->save ( out );
   if ( OrVectMainVect2An )  OrVectMainVect2An->save ( out );
}

static void ShowResOrVect () {
   if ( SimSystem.all_ions.size() == 0 )
      return;

   const mdformat fcolfmt (7,3);
   const mdformat format (13,3);

   std::ofstream out ( OrVectResFileName );

   out << fcolfmt << "r, nm";
   if ( OrVectDipMom1Kat )   out << format << "DipMom1Kat";
   if ( OrVectMainVect1Kat ) out << format << "MainVect1Kat";
   if ( OrVectDipMom1An )    out << format << "DipMom1An";
   if ( OrVectMainVect1An )  out << format << "MainVect1An";
   if ( OrVectDipMom2Kat )   out << format << "DipMom2Kat";
   if ( OrVectMainVect2Kat ) out << format << "MainVect2Kat";
   if ( OrVectDipMom2An )    out << format << "DipMom2An";
   if ( OrVectMainVect2An )  out << format << "MainVect2An";
   out << std::endl;

   int i;
   for ( i = 0; i < OrVectRSize; ++i ) {
      out << fcolfmt << i*StepRInShl;
      if ( OrVectDipMom1Kat ) {
         if ( OrVectDipMom1Kat->has_value(i) )
            out << format << OrVectDipMom1Kat->get_value(i);
         else
            out << format << "--   ";
      }
      if ( OrVectMainVect1Kat ) {
         if ( OrVectMainVect1Kat->has_value(i) )
            out << format << OrVectMainVect1Kat->get_value(i);
         else
            out << format << "--   ";
      }
      if ( OrVectDipMom1An ) {
         if ( OrVectDipMom1An->has_value(i) )
            out << format << OrVectDipMom1An->get_value(i);
         else
            out << format << "--   ";
      }
      if ( OrVectMainVect1An ) {
         if ( OrVectMainVect1An->has_value(i) )
            out << format << OrVectMainVect1An->get_value(i);
         else
            out << format << "--   ";
      }
      if ( OrVectDipMom2Kat ) {
         if ( OrVectDipMom2Kat->has_value(i) )
            out << format << OrVectDipMom2Kat->get_value(i);
         else
            out << format << "--   ";
      }
      if ( OrVectMainVect2Kat ) {
         if ( OrVectMainVect2Kat->has_value(i) )
            out << format << OrVectMainVect2Kat->get_value(i);
         else
            out << format << "--   ";
      }
      if ( OrVectDipMom2An ) {
         if ( OrVectDipMom2An->has_value(i) )
            out << format << OrVectDipMom2An->get_value(i);
         else
            out << format << "--   ";
      }
      if ( OrVectMainVect2An ) {
         if ( OrVectMainVect2An->has_value(i) )
            out << format << OrVectMainVect2An->get_value(i);
         else
            out << format << "--   ";
      }
      out << std::endl;
   }
}
// ============================================================================
// ===== Distribution of molecules orientations in first solvation shell ======
const char *DistrCosFileName = "DistrCos.cf";
const char *DistrCosResFileName = "DistrCos.dat";
const int DistrCosHistSize = 100;

static void SaveDistrCos ();
static void ShowResDistrCos ();

static distrib_1D *DistrCosDipMom1Kat = 0;
static distrib_1D *DistrCosMainVect1Kat = 0;
static distrib_1D *DistrCosDipMom2Kat = 0;
static distrib_1D *DistrCosMainVect2Kat = 0;
static distrib_1D *DistrCosDipMom1An = 0;
static distrib_1D *DistrCosMainVect1An = 0;
static distrib_1D *DistrCosDipMom2An = 0;
static distrib_1D *DistrCosMainVect2An = 0;

void DistrCos_Calc () {
   static int init = 1;
   if ( init ) {
      Message << "starting calculation of molecule orientations distributions\n";
      Message << "in solvation shells" << std::endl;

      if ( SimSystem.all_cations.size() > 0 ) {
         if ( SimSystem.all_molecules1.size() > 0 ) {
            DistrCosDipMom1Kat   = new distrib_1D ( DistrCosHistSize );
            DistrCosMainVect1Kat = new distrib_1D ( DistrCosHistSize );
         }
         if ( SimSystem.all_molecules2.size() > 0 ) {
            DistrCosDipMom2Kat   = new distrib_1D ( DistrCosHistSize );
            DistrCosMainVect2Kat = new distrib_1D ( DistrCosHistSize );
         }
      }
      if ( SimSystem.all_anions.size() > 0 ) {
         if ( SimSystem.all_molecules1.size() > 0 ) {
            DistrCosDipMom1An   = new distrib_1D ( DistrCosHistSize );
            DistrCosMainVect1An = new distrib_1D ( DistrCosHistSize );
         }
         if ( SimSystem.all_molecules2.size() > 0 ) {
            DistrCosDipMom2An   = new distrib_1D ( DistrCosHistSize );
            DistrCosMainVect2An = new distrib_1D ( DistrCosHistSize );
         }
      }

      if ( KLH ) {
         std::ifstream in ( DistrCosFileName, std::ios::binary | std::ios::in );
         if ( !in ) {
            Error << __FILE__ << "; void DistrCos_Calc ()" << ": cannot open file " << OrVectFileName;
            Error << "\n" "starting new DistrCos calculation" << std::endl;
         }
         else {
            version::check_ver ( in, DistrCosFileName );
            if ( DistrCosDipMom1Kat )   DistrCosDipMom1Kat->read ( in );
            if ( DistrCosMainVect1Kat ) DistrCosMainVect1Kat->read ( in );
            if ( DistrCosDipMom2Kat )   DistrCosDipMom2Kat->read ( in );
            if ( DistrCosMainVect2Kat ) DistrCosMainVect2Kat->read ( in );
            if ( DistrCosDipMom1An )    DistrCosDipMom1An->read ( in );
            if ( DistrCosMainVect1An )  DistrCosMainVect1An->read ( in );
            if ( DistrCosDipMom2An )    DistrCosDipMom2An->read ( in );
            if ( DistrCosMainVect2An )  DistrCosMainVect2An->read ( in );
         }
      }
      SMan.AddFun ( &SaveDistrCos );
      ShowRes.AddFun ( &ShowResDistrCos );
      init = 0;
   }

   for ( auto c: SimSystem.all_cations ) {
      const vect IonPos = (c->getCoordinationCenters ())[0];
      for ( auto m: SimSystem.all_molecules1 ) {
         vect dr = m->getCationCoordinationCenter () - IonPos;
         PBC ( dr );
         const double r = norm (dr);
         if ( r < RSHL[0] ) {
            const vect dipmom = m->getDipolMomentum ();
            DistrCosDipMom1Kat->add ( ((dipmom*dr)/(norm(dipmom)*r) + 1.0) * DistrCosHistSize / 2.0 );
            const vect mvect  = m->getMainVect ();
            DistrCosMainVect1Kat->add ( ((mvect*dr)/(norm(mvect)*r) + 1.0) * DistrCosHistSize / 2.0 );
         }
      }
      for ( auto m: SimSystem.all_molecules2 ) {
         vect dr = m->getCationCoordinationCenter () - IonPos;
         PBC ( dr );
         const double r = norm (dr);
         if ( r < RSHL[5] ) {
            const vect dipmom = m->getDipolMomentum ();
            DistrCosDipMom2Kat->add ( ((dipmom*dr)/(norm(dipmom)*r) + 1.0) * DistrCosHistSize / 2.0 );
            const vect mvect  = m->getMainVect ();
            DistrCosMainVect2Kat->add ( ((mvect*dr)/(norm(mvect)*r) + 1.0) * DistrCosHistSize / 2.0 );
         }
      }
   }
   
   for ( auto a: SimSystem.all_anions ) {
      const vect IonPos = (a->getCoordinationCenters ())[0];
      for ( auto m: SimSystem.all_molecules1 ) {
         vect dr = m->getAnionCoordinationCenter () - IonPos;
         PBC ( dr );
         const double r = norm (dr);
         if ( r < RSHL[2] ) {
            const vect dipmom = m->getDipolMomentum ();
            DistrCosDipMom1An->add ( ((dipmom*dr)/(norm(dipmom)*r) + 1.0) * DistrCosHistSize / 2.0 );
            const vect mvect  = m->getMainVect ();
            DistrCosMainVect1An->add ( ((mvect*dr)/(norm(mvect)*r) + 1.0) * DistrCosHistSize / 2.0 );
         }
      }
      for ( auto m: SimSystem.all_molecules2 ) {
         vect dr = m->getAnionCoordinationCenter () - IonPos;
         PBC ( dr );
         const double r = norm (dr);
         if ( r < RSHL[7] ) {
            const vect dipmom = m->getDipolMomentum ();
            DistrCosDipMom2An->add ( ((dipmom*dr)/(norm(dipmom)*r) + 1.0) * DistrCosHistSize / 2.0 );
            const vect mvect  = m->getMainVect ();
            DistrCosMainVect2An->add ( ((mvect*dr)/(norm(mvect)*r) + 1.0) * DistrCosHistSize / 2.0 );
         }
      }
   }
}

static void SaveDistrCos () {
   std::ofstream out ( DistrCosFileName, std::ios::binary | std::ios::out | std::ios::trunc );

   version::out ( out );
   if ( DistrCosDipMom1Kat )   DistrCosDipMom1Kat->save ( out );
   if ( DistrCosMainVect1Kat ) DistrCosMainVect1Kat->save ( out );
   if ( DistrCosDipMom2Kat )   DistrCosDipMom2Kat->save ( out );
   if ( DistrCosMainVect2Kat ) DistrCosMainVect2Kat->save ( out );
   if ( DistrCosDipMom1An )    DistrCosDipMom1An->save ( out );
   if ( DistrCosMainVect1An )  DistrCosMainVect1An->save ( out );
   if ( DistrCosDipMom2An )    DistrCosDipMom2An->save ( out );
   if ( DistrCosMainVect2An )  DistrCosMainVect2An->save ( out );
}

static void ShowResDistrCos () {
   if ( SimSystem.all_ions.size() == 0 )
      return;

   const mdformat fcolfmt (7,3);
   const mdformat format (13,3);

   std::ofstream out ( DistrCosResFileName );
   out << "P(cos) via cos\n";

   out << fcolfmt << "cos";
   if ( DistrCosDipMom1Kat )   out << format << "DipMom1Kat";
   if ( DistrCosMainVect1Kat ) out << format << "MainVect1Kat";
   if ( DistrCosDipMom2Kat )   out << format << "DipMom2Kat";
   if ( DistrCosMainVect2Kat ) out << format << "MainVect2Kat";
   if ( DistrCosDipMom1An )    out << format << "DipMom1An";
   if ( DistrCosMainVect1An )  out << format << "MainVect1An";
   if ( DistrCosDipMom2An )    out << format << "DipMom2An";
   if ( DistrCosMainVect2An )  out << format << "MainVect2An";
   out << std::endl;

   int i;
   for ( i = 0; i < DistrCosHistSize; ++i ) {
      out << fcolfmt << 2*i / static_cast<double>(DistrCosHistSize) - 1.0;
      if ( DistrCosDipMom1Kat )   out << format << DistrCosDipMom1Kat->get_value(i) * DistrCosHistSize;
      if ( DistrCosMainVect1Kat ) out << format << DistrCosMainVect1Kat->get_value(i) * DistrCosHistSize;
      if ( DistrCosDipMom2Kat )   out << format << DistrCosDipMom2Kat->get_value(i) * DistrCosHistSize;
      if ( DistrCosMainVect2Kat ) out << format << DistrCosMainVect2Kat->get_value(i) * DistrCosHistSize;
      if ( DistrCosDipMom1An )    out << format << DistrCosDipMom1An->get_value(i) * DistrCosHistSize;
      if ( DistrCosMainVect1An )  out << format << DistrCosMainVect1An->get_value(i) * DistrCosHistSize;
      if ( DistrCosDipMom2An )    out << format << DistrCosDipMom2An->get_value(i) * DistrCosHistSize;
      if ( DistrCosMainVect2An )  out << format << DistrCosMainVect2An->get_value(i) * DistrCosHistSize;
      out << std::endl;
   }
}
// ============================================================================
// ================================= MolOr ====================================
const char* MolOrientFileName = "MolOr.dat";
const char* MolOrientBinName  = "MolOr.cf";
const char* cmRDF_FileName    = "cmRDF.dat";

static void MolOrientResult ();
static void SaveMolOrient ();

distrib_1D **DistrMain11 = 0;
distrib_1D **DistrMain12 = 0;
distrib_1D **DistrMain22 = 0;
distrib_1D **DistrDipole11 = 0;
distrib_1D **DistrDipole12 = 0;
distrib_1D **DistrDipole22 = 0;

distrib_1D *cmRDF_11 = 0;
distrib_1D *cmRDF_12 = 0;
distrib_1D *cmRDF_22 = 0;

int SizeRDim;
const int SizeCosDim = 100;
double RStep, CosStep;
#include "df.h"

void AnalyseMolOrient () {
   static bool init = true;
   if ( init ) {
      Message << "starting molecular orientation distributions calculation" << std::endl;
      RStep = StepRInShl;
      SizeRDim = static_cast<int> ( RCut.LJ / RStep );
      CosStep = 2.0 / SizeCosDim;

      int i;
      if ( SimSystem.all_molecules1.size() > 0 ) {
         DistrMain11   = new distrib_1D*[SizeRDim];
         DistrDipole11 = new distrib_1D*[SizeRDim];
         cmRDF_11 = new distrib_1D (SizeRDim);
         for ( i = 0; i < SizeRDim; ++i ) {
            DistrMain11[i]   = new distrib_1D ( SizeCosDim );
            DistrDipole11[i] = new distrib_1D ( SizeCosDim );
         }
      }
      if ( SimSystem.all_molecules2.size() > 0 ) {
         DistrMain22   = new distrib_1D*[SizeRDim];
         DistrDipole22 = new distrib_1D*[SizeRDim];
         cmRDF_22 = new distrib_1D (SizeRDim);
         for ( i = 0; i < SizeRDim; ++i ) {
            DistrMain22[i]   = new distrib_1D ( SizeCosDim );
            DistrDipole22[i] = new distrib_1D ( SizeCosDim );
         }
      }
      if ( SimSystem.all_molecules1.size() > 0 && SimSystem.all_molecules2.size() > 0 ) {
         DistrMain12   = new distrib_1D*[SizeRDim];
         DistrDipole12 = new distrib_1D*[SizeRDim];
         cmRDF_12 = new distrib_1D (SizeRDim);
         for ( i = 0; i < SizeRDim; ++i ) {
            DistrMain12[i]   = new distrib_1D ( SizeCosDim );
            DistrDipole12[i] = new distrib_1D ( SizeCosDim );
         }
      }

      if ( KLH ) {
         std::ifstream in ( MolOrientBinName, std::ios::binary | std::ios::in );
         if ( !in ) {
            Error << __FILE__ << "; void AnalyseMolOrient ()" << ": cannot open file " << MolOrientBinName;
            Error << "\n" "starting new MolOr calculation" << std::endl;
         }
         else {
            version::check_ver ( in, MolOrientBinName );
            int i;
            if ( SimSystem.all_molecules1.size() > 0 ) {
               for ( i = 0; i < SizeRDim; ++i ) {
                  DistrMain11[i]->read ( in );
                  DistrDipole11[i]->read ( in );
               }
               cmRDF_11->read ( in );
            }
            if ( SimSystem.all_molecules2.size() > 0 ) {
               for ( i = 0; i < SizeRDim; ++i ) {
                  DistrMain22[i]->read ( in );
                  DistrDipole22[i]->read ( in );
               }
               cmRDF_22->read ( in );
            }
            if ( SimSystem.all_molecules1.size() > 0 && SimSystem.all_molecules2.size() > 0 ) {
               for ( i = 0; i < SizeRDim; ++i ) {
                  DistrMain12[i]->read ( in );
                  DistrDipole12[i]->read ( in );
               }
               cmRDF_12->read ( in );
            }
         }
      }

      ShowRes.AddFun ( &MolOrientResult );
      SMan.AddFun ( &SaveMolOrient );
      init = false;
   }

   int i, j;
   for ( i = 0; i < SimSystem.all_molecules1.size(); ++i ) {
      auto p1 = SimSystem.all_molecules1[i];
      const vect cm1 = p1->getCMPos ();
      const vect dipmomI = p1->getDipolMomentum ();
      const vect mvectI  = p1->getMainVect ();
      
      for ( j = i+1; j < SimSystem.all_molecules1.size(); ++j ) {
         auto p2 = SimSystem.all_molecules1[j];
         
         vect dr = cm1 - p2->getCMPos ();
         PBC ( dr );
         const int r_index = static_cast<int>( norm(dr) / RStep );
         cmRDF_11->add ( r_index ); // here total_count equals nsteps * NMOL1*(NMOL1-1)/2
         if ( r_index < SizeRDim ) {
            const vect dipmomJ = p2->getDipolMomentum ();
            const vect mvectJ  = p2->getMainVect ();

            DistrMain11[r_index]->add ( 
               static_cast<int>(((mvectI*mvectJ)/norm(mvectI)/norm(mvectJ)+1)/CosStep) );
            DistrDipole11[r_index]->add ( 
               static_cast<int>(((dipmomI*dipmomJ)/norm(dipmomI)/norm(dipmomJ)+1)/CosStep) );
         }
      }
   }
   for ( i = 0; i < SimSystem.all_molecules2.size(); ++i ) {
      auto p1 = SimSystem.all_molecules2[i];
      
      const vect cm1 = p1->getCMPos ();
      const vect dipmomI = p1->getDipolMomentum ();
      const vect mvectI  = p1->getMainVect ();
      
      for ( j = i+1; j < SimSystem.all_molecules2.size(); ++j ) {
         auto p2 = SimSystem.all_molecules2[j];
         
         vect dr = cm1 - p2->getCMPos ();
         PBC ( dr );
         const int r_index = static_cast<int>( norm(dr) / RStep );
         cmRDF_22->add ( r_index ); // here total_count equals nsteps * NMOL2*(NMOL2-1)/2
         if ( r_index < SizeRDim ) {
            const vect dipmomJ = p2->getDipolMomentum ();
            const vect mvectJ  = p2->getMainVect ();

            DistrMain22[r_index]->add ( 
               static_cast<int>(((mvectI*mvectJ)/norm(mvectI)/norm(mvectJ)+1)/CosStep) );
            DistrDipole22[r_index]->add ( 
               static_cast<int>(((dipmomI*dipmomJ)/norm(dipmomI)/norm(dipmomJ)+1)/CosStep) );
         }
      }
   }
   for ( auto p1: SimSystem.all_molecules1 ) {
      const vect cm1 = p1->getCMPos ();
      const vect dipmomI = p1->getDipolMomentum ();
      const vect mvectI  = p1->getMainVect ();
      
      for ( auto p2: SimSystem.all_molecules2 ) {
         vect dr = cm1 - p2->getCMPos ();
         PBC ( dr );
         const int r_index = static_cast<int>( norm(dr) / RStep );
         cmRDF_12->add ( r_index ); // here total_count equals nsteps * NMOL1*NMOL2
         if ( r_index < SizeRDim ) {
            const vect dipmomJ = p2->getDipolMomentum ();
            const vect mvectJ  = p2->getMainVect ();

            DistrMain12[r_index]->add ( 
               static_cast<int>(((mvectI*mvectJ)/norm(mvectI)/norm(mvectJ)+1)/CosStep) );
            DistrDipole12[r_index]->add ( 
               static_cast<int>(((dipmomI*dipmomJ)/norm(dipmomI)/norm(dipmomJ)+1)/CosStep) );
         }
      }
   }
}

static void SaveMolOrient () {
   std::ofstream out ( MolOrientBinName, std::ios::binary | std::ios::out | std::ios::trunc );

   version::out ( out );
   int i;
   if ( SimSystem.all_molecules1.size() > 0 ) {
      for ( i = 0; i < SizeRDim; ++i ) {
         DistrMain11[i]->save ( out );
         DistrDipole11[i]->save ( out );
      }
      cmRDF_11->save ( out );
   }
   if ( SimSystem.all_molecules2.size() > 0 ) {
      for ( i = 0; i < SizeRDim; ++i ) {
         DistrMain22[i]->save ( out );
         DistrDipole22[i]->save ( out );
      }
      cmRDF_22->save ( out );
   }
   if ( SimSystem.all_molecules1.size() > 0 && SimSystem.all_molecules2.size() > 0 ) {
      for ( i = 0; i < SizeRDim; ++i ) {
         DistrMain12[i]->save ( out );
         DistrDipole12[i]->save ( out );
      }
      cmRDF_12->save ( out );
   }
}

static void MolOrientResult ( ) {
   std::ofstream out ( MolOrientFileName );
   const mdformat rformat( 9,3);
   const mdformat cformat( 9,3);
   const mdformat dformat(11,5);

   out << rformat << "r, nm" << cformat << "cos(h)";
   if ( DistrMain11 ) out << dformat << "MainVect11";
   if ( DistrMain12 ) out << dformat << "MainVect12";
   if ( DistrMain22 ) out << dformat << "MainVect22";
   if ( DistrDipole11 ) out << dformat << "DipMom11";
   if ( DistrDipole12 ) out << dformat << "DipMom12";
   if ( DistrDipole22 ) out << dformat << "DipMom22";
   out << "\n";

   int r, c;
   for ( r = 0; r < SizeRDim; ++r ) {
      for ( c = 0; c < SizeCosDim; ++c ) {
         out << rformat << r * RStep;
         out << cformat << c * CosStep - 1.0;
         if ( DistrMain11 ) out << dformat << DistrMain11[r]->get_value(c) * SizeCosDim;
         if ( DistrMain12 ) out << dformat << DistrMain12[r]->get_value(c) * SizeCosDim;
         if ( DistrMain22 ) out << dformat << DistrMain22[r]->get_value(c) * SizeCosDim;
         if ( DistrDipole11 ) out << dformat << DistrDipole11[r]->get_value(c) * SizeCosDim;
         if ( DistrDipole12 ) out << dformat << DistrDipole12[r]->get_value(c) * SizeCosDim;
         if ( DistrDipole22 ) out << dformat << DistrDipole22[r]->get_value(c) * SizeCosDim;
         out << "\n";
      }
   }
   out.close ();

   out.open ( cmRDF_FileName );
   out << rformat << "r, nm";
   if ( cmRDF_11 ) out << dformat << "g11";
   if ( cmRDF_12 ) out << dformat << "g12";
   if ( cmRDF_22 ) out << dformat << "g22";
   out << "\n";

   for ( r = 0; r < SizeRDim; ++r ) {
      out << rformat << (r+0.5) * RStep;
      const double dV = 4.0/3.0*SI_PI*RStep*RStep*RStep*((r+1)*(r+1)*(r+1) - r*r*r);
      if ( cmRDF_11 ) out << dformat << cmRDF_11->get_value(r)*(VOLBOX/dV);
      if ( cmRDF_12 ) out << dformat << cmRDF_12->get_value(r)*(VOLBOX/dV);
      if ( cmRDF_22 ) out << dformat << cmRDF_22->get_value(r)*(VOLBOX/dV);
      out << "\n";
   }
}
// ============================================================================


// ???????????????????????????????????????????????????????????????????????????????????????????
static void ShowResultW98OrVect ( );
static void SaveW98OrVect ( );
const char OrVect_Name[]      = "Wiy98OrVect.cf";
static double *IonMainVect, *IonAdvVect;
static int *NormOrOne, *NormOrTwo;

static double StepR_OrVect = -1;
static int SizeHist = -1;

static void InitW98OrVect () {
    static int error = 0;
    std::ifstream in;
    double Temp = -1;
    StepR_OrVect = StepRInShl;
    SizeHist = int(LBOX2 / StepR_OrVect) + 1;

    if ( KLH ) {  // Restore arrays from file
        in.open ( OrVect_Name, std::ios::binary | std::ios::in );
        if ( !in ) {
            std::cout << UnOpen << OrVect_Name << std::endl;
            error = 1;
        }
        else {
           version::check_ver ( in, OrVect_Name );
            in.read ( (char*) &Temp, sizeof(double) );
            if ( fabs(Temp - StepR_OrVect)/StepR_OrVect > 0.0001 ) {
                Error << "StepR_OrVect in " << OrVect_Name << " (" << Temp;
                Error << ") is not equal to StepRInShl in fint.dat (";
                Error << StepR_OrVect << ")" << std::endl;
                std::cerr << "\a";
                std::exit (1);
            }

            in.read ( (char*) &SizeHist, sizeof(int) );
        }
    }
    IonMainVect = new double[SizeHist*2];
    IonAdvVect  = new double[SizeHist*2];
    NormOrOne   = new int[SizeHist*2];
    NormOrTwo   = new int[SizeHist*2];
    if ( KLH && !error ) {
        in.read ( (char*) IonMainVect,    sizeof(double) * SizeHist*2 );
        in.read ( (char*) IonAdvVect,     sizeof(double) * SizeHist*2 );
        in.read ( (char*) NormOrOne,      sizeof(int) *    SizeHist*2 );
        in.read ( (char*) NormOrTwo,      sizeof(int) *    SizeHist*2 );
        Message << "\n configuration is succesfully read from the file " << OrVect_Name << std::endl; }
    else {
        memset ( IonMainVect, 0, SizeHist*2*sizeof(double) );
        memset ( IonAdvVect,  0, SizeHist*2*sizeof(double) );
        memset ( NormOrOne,   0, SizeHist*2*sizeof(int) );
        memset ( NormOrTwo,   0, SizeHist*2*sizeof(int) );
    }

    SMan.AddFun ( SaveW98OrVect );
    ShowRes.AddFun ( ShowResultW98OrVect );
}

void CalculWiy98OrVect () {
   static int init = 1;
   if ( init ) {
      InitW98OrVect ();
      init = 0;
   }
   
   vect Qion(0.0), QIonCent(0.0), MainVect(0.0);
   double CosAlfa = 0, Rij = 0;
   int i = 0, j = 0, k, Index = 0;

    for ( j = 0; j < SimSystem.all_cations.size(); j++ ) {
        Qion = (SimSystem.all_cations[j]->getCoordinationCenters ())[0];
        for ( i = 0; i < SimSystem.all_molecules1.size(); i++ ) {
            QIonCent = SimSystem.all_molecules1[i]->getCationCoordinationCenter() - Qion;

            PBC ( QIonCent );
            Rij = norm(QIonCent);
            if ( Rij >= LBOX2 )
                continue;
            
            MainVect = 0.0;
            for ( k = 0; k < SimSystem.molecule_types[0]->natoms(); ++k )
               MainVect += SimSystem.all_molecules1[i]->getAtomPos(k) * Wiy98_AdvancedCationCoordinationCenter_coefs[k];
            MainVect -= SimSystem.all_molecules1[i]->getCationCoordinationCenter ();

            // Define the angle between Ion-Kt and Kt-Kt' vectors
            CosAlfa = ( QIonCent * MainVect ) /
                      ( Rij * norm(MainVect) );
            Index = int(Rij / StepR_OrVect) * 2 + 0;
            if ( NormOrOne[Index] )
                IonMainVect[Index] *= NormOrOne[Index];
            IonMainVect[Index] += CosAlfa;
            NormOrOne[Index]++;
            IonMainVect[Index] /= NormOrOne[Index];

            // analog
            QIonCent = SimSystem.all_molecules[i]->getAnionCoordinationCenter () - Qion;

            PBC ( QIonCent );
            Rij = norm(QIonCent);
            if ( Rij >= LBOX2 )
                continue;

            MainVect = 0.0;
            for ( k = 0; k < SimSystem.molecule_types[0]->natoms(); ++k )
               MainVect += SimSystem.all_molecules1[i]->getAtomPos(k) * Wiy98_AdvancedAnionCoordinationCenter_coefs[k];
            MainVect -= SimSystem.all_molecules1[i]->getAnionCoordinationCenter ();
            CosAlfa = ( QIonCent*MainVect) / ( Rij * norm(MainVect) );
            Index = int(Rij / StepR_OrVect) * 2 + 0;

            if ( NormOrTwo[Index] )
                IonAdvVect[Index] *= NormOrTwo[Index];
            IonAdvVect[Index] += CosAlfa;
            NormOrTwo[Index]++;
            IonAdvVect[Index] /= NormOrTwo[Index];
        }
    }

    for ( j = 0; j < SimSystem.all_anions.size(); j++ ) {
        Qion = (SimSystem.all_anions[j]->getCoordinationCenters ())[0];
        for ( i = 0; i < SimSystem.all_molecules1.size(); i++ ) {
            QIonCent = SimSystem.all_molecules1[i]->getCationCoordinationCenter() - Qion;

            PBC ( QIonCent );
            Rij = norm(QIonCent);
            if ( Rij >= LBOX2 )
                continue;
            
            MainVect = 0.0;
            for ( k = 0; k < SimSystem.molecule_types[0]->natoms(); ++k )
               MainVect += SimSystem.all_molecules1[i]->getAtomPos(k) * Wiy98_AdvancedCationCoordinationCenter_coefs[k];
            MainVect -= SimSystem.all_molecules1[i]->getCationCoordinationCenter ();

            // Define the angle between Ion-Kt and Kt-Kt' vectors
            CosAlfa = ( QIonCent * MainVect ) /
                      ( Rij * norm(MainVect) );
            Index = int(Rij / StepR_OrVect) * 2 + 1;
            if ( NormOrOne[Index] )
                IonMainVect[Index] *= NormOrOne[Index];
            IonMainVect[Index] += CosAlfa;
            NormOrOne[Index]++;
            IonMainVect[Index] /= NormOrOne[Index];

            // analog
            QIonCent = SimSystem.all_molecules1[i]->getAnionCoordinationCenter () - Qion;

            PBC ( QIonCent );
            Rij = norm(QIonCent);
            if ( Rij >= LBOX2 )
                continue;

            MainVect = 0.0;
            for ( k = 0; k < SimSystem.molecule_types[0]->natoms(); ++k )
               MainVect += SimSystem.all_molecules1[i]->getAtomPos(k) * Wiy98_AdvancedAnionCoordinationCenter_coefs[k];
            MainVect -= SimSystem.all_molecules1[i]->getAnionCoordinationCenter ();
            CosAlfa = ( QIonCent*MainVect) / ( Rij * norm(MainVect) );
            Index = int(Rij / StepR_OrVect) * 2 + 1;

            if ( NormOrTwo[Index] )
                IonAdvVect[Index] *= NormOrTwo[Index];
            IonAdvVect[Index] += CosAlfa;
            NormOrTwo[Index]++;
            IonAdvVect[Index] /= NormOrTwo[Index];
        }
    }
}

static void ShowResultW98OrVect ( ) {
const double R2 = double(StepR_OrVect * 0.5);
std::ofstream out ( "W98OrVect.dat" );
    out.flags ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
    out.precision ( 3 );

    if ( SimSystem.all_cations.size() > 0 )
        out << std::setw ( 11 ) << " Kation";
    if ( SimSystem.all_anions.size() > 0 )
        out << std::setw ( 11 ) << " Anion";
    out << std::endl;

    out << std::setw ( 6 ) << "Step";
    if ( SimSystem.all_cations.size() > 0 )
        out << std::setw ( 8 ) << "Main" << std::setw ( 8 ) << "Advan.";
    if ( SimSystem.all_anions.size() > 0 )
        out << std::setw ( 8 ) << "Advan." << std::setw ( 8 ) << "Main";
    out << std::endl;

    for ( int i = 0; i < SizeHist; i++ ) {
        out << std::setw ( 6 ) << StepR_OrVect*i + R2;
        if ( SimSystem.all_cations.size() > 0 ) {
            out << std::setw ( 8 ) << IonMainVect[i*2] << std::flush;
            out << std::setw ( 8 ) << IonAdvVect[i*2] << std::flush ;
        }
        if ( SimSystem.all_anions.size() > 0 ) {
            out << std::setw ( 8 ) << IonMainVect[i*2 + 1] << std::flush;
            out << std::setw ( 8 ) <<  IonAdvVect[i*2 + 1] << std::flush;
        }
        out << std::endl;
    }
}

static void SaveW98OrVect ( ) {
std::ofstream out ( OrVect_Name, std::ios::binary | std::ios::out | std::ios::trunc );
    if ( !out ) {
        std::cout << UnOpen << OrVect_Name << std::endl;
        std::exit (1);
    }
    version::out ( out );
    out.write ( (char*) &StepR_OrVect,  sizeof(double) );
    out.write ( (char*) &SizeHist,      sizeof(int) );
    out.write ( (char*) IonMainVect,    sizeof(double) * SizeHist*2 );
    out.write ( (char*) IonAdvVect,     sizeof(double) * SizeHist*2 );
    out.write ( (char*) NormOrOne,      sizeof(int) *    SizeHist*2 );
    out.write ( (char*) NormOrTwo,      sizeof(int) *    SizeHist*2 );
}

// ???????????????????????????????????????????????????????????????????????????????????????????
const char *Distrib_cos_Name = "Wiy98DistrCos.cf";
static int *CosDistribKat = NULL, *CosDistribAn = NULL;
static int NumMolDistrib_cos_kat = -1;
static int NumMolDistrib_cos_an  = -1;
const int SizeCosArray = 360; // For step 1 grad
const double StepDistrib_cos = 2.0 / 360; // Cos(a): { -1 ... 1 }

static void SaveWiy98Distr_cos ();
static void ShowResultWiy98Distr_cos ();
static void InitWiy98Distr_cos ( ) {
    CosDistribKat  = new int[SizeCosArray*2];
    CosDistribAn   = new int[SizeCosArray*2];
    if ( KLH ) {
        std::ifstream in ( Distrib_cos_Name, std::ios::binary | std::ios::in );
        if ( !in ) {
            Error << "\n\a" << UnOpen << Distrib_cos_Name << std::endl;
            std::exit(1);
        }
        version::check_ver ( in, Distrib_cos_Name );
        in.read ( (char*) &NumMolDistrib_cos_kat,    sizeof(int) );
        in.read ( (char*) &NumMolDistrib_cos_an,     sizeof(int) );
        in.read ( (char*) CosDistribKat,  sizeof(int) * SizeCosArray*2 );
        in.read ( (char*) CosDistribAn,   sizeof(int) * SizeCosArray*2 );
        Message << "\nRestore in " << Distrib_cos_Name << " is complete" << std::endl;
    }
    else {
        memset ( CosDistribKat,  0, sizeof(int)*SizeCosArray*2 );
        memset ( CosDistribAn,   0, sizeof(int)*SizeCosArray*2 );
        NumMolDistrib_cos_kat = 0;
        NumMolDistrib_cos_an  = 0;
    }

    SMan.AddFun ( SaveWiy98Distr_cos );
    ShowRes.AddFun ( ShowResultWiy98Distr_cos );
}

void CalculWiy98Distr_cos () {
   static int init = 1;
   if ( init ) {
      InitWiy98Distr_cos ();
      init = 0;
   }
   
   int i = 0, j = 0, k;
   vect Qion(0.0), R(0.0), R1(0.0), Bis(0.0), Distance;
   double Cos = 0;
   
    for ( j = 0; j < SimSystem.all_cations.size(); j++ ) {
        Qion = SimSystem.all_cations[j]->getCMPos ();
        for ( i = 0; i < SimSystem.all_molecules1.size(); i++ ) {
            Distance = SimSystem.all_molecules1[i]->getCationCoordinationCenter () - Qion;
            PBC ( Distance );
            if ( norm(Distance) > RSHL[0] )
                continue;
            // Define coords of main vector
            R = 0.0;
            for ( k = 0; k < SimSystem.molecule_types[0]->natoms(); ++k )
               R += SimSystem.all_molecules1[i]->getAtomPos(k) * Wiy98_AdvancedCationCoordinationCenter_coefs[k];
            R -= SimSystem.all_molecules1[i]->getCationCoordinationCenter ();

            // Define coords of Ion-Center vector
            R1 = SimSystem.all_molecules1[i]->getCationCoordinationCenter () - Qion;
            PBC ( R1 );

            Cos = ( R * R1 ) / ( norm(R) * norm(R1) );
            CosDistribKat[int((Cos+1)/StepDistrib_cos)*2]++;

            // Define coords of main vector
            R = 0.0;
            for ( k = 0; k < SimSystem.molecule_types[0]->natoms(); ++k )
               R += SimSystem.all_molecules1[i]->getAtomPos(k) * Wiy98_AdvancedAnionCoordinationCenter_coefs[k];
            R -= SimSystem.all_molecules1[i]->getAnionCoordinationCenter ();

            // Define coords of Ion-Center vector
            R1 = SimSystem.all_molecules1[i]->getAnionCoordinationCenter () - Qion;
            PBC ( R1 );

            Cos = ( R * R1 ) / ( norm(R) * norm(R1) );
            CosDistribKat [int((Cos+1)/StepDistrib_cos)*2 + 1]++;

            NumMolDistrib_cos_kat++;
        }
    }

    for ( j = 0; j < SimSystem.all_anions.size(); j++ ) {
        Qion = SimSystem.all_anions[j]->getCMPos ();
        for ( i = 0; i < SimSystem.all_molecules1.size(); i++ ) {
            Distance = SimSystem.all_molecules1[i]->getAnionCoordinationCenter() - Qion;
            PBC ( Distance );
            if ( norm(Distance) > RSHL[2] )
                continue;
            // Define coords of main vector
            R = 0.0;
            for ( k = 0; k < SimSystem.molecule_types[0]->natoms(); ++k )
               R += SimSystem.all_molecules1[i]->getAtomPos(k) * Wiy98_AdvancedCationCoordinationCenter_coefs[k];
            R -= SimSystem.all_molecules1[i]->getCationCoordinationCenter ();

            // Define coords of Ion-Center vector
            R1 = SimSystem.all_molecules1[i]->getCationCoordinationCenter () - Qion;
            PBC ( R1 );

            Cos = ( R * R1 ) / ( norm(R) * norm(R1) );
            CosDistribAn[int((Cos+1)/StepDistrib_cos)*2]++;

            // Define coords of main vector
            R = 0.0;
            for ( k = 0; k < SimSystem.molecule_types[0]->natoms(); ++k )
               R += SimSystem.all_molecules1[i]->getAtomPos(k) * Wiy98_AdvancedAnionCoordinationCenter_coefs[k];
            R -= SimSystem.all_molecules1[i]->getAnionCoordinationCenter ();

            // Define coords of Ion-Center vector
            R1 = SimSystem.all_molecules1[i]->getAnionCoordinationCenter () - Qion;
            PBC ( R1 );

            Cos = ( R * R1 ) / ( norm(R) * norm(R1) );
            CosDistribAn [int((Cos+1)/StepDistrib_cos)*2 + 1]++;

            NumMolDistrib_cos_an++;
        }
    }
}

static void ShowResultWiy98Distr_cos ( ) {
std::ofstream out ( "Wiy98DistrCos.dat" );
    out.flags ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
    out.precision ( 5 );

    if ( SimSystem.all_cations.size() > 0 )
        out << std::setw ( 26 ) << " Kation";
    if ( SimSystem.all_anions.size() > 0 )
        out << std::setw ( 16 ) << " Anion";
    out << std::endl;

    out << std::setw ( 10 ) << "Cos";
    if ( SimSystem.all_cations.size() > 0 )
        out << std::setw ( 10 ) << "Main" << std::setw ( 10 ) << "Advan.";
    if ( SimSystem.all_anions.size() > 0 )
        out << std::setw ( 10 ) << "Advan." << std::setw ( 10 ) << "Main";
    out << std::endl;

    for ( int i = 0; i < SizeCosArray; i++ ) {
        out << std::setw ( 10 ) << i*StepDistrib_cos + StepDistrib_cos/2 - 1;
        if ( SimSystem.all_cations.size() > 0 ) {
            out << std::setw ( 10 ) << ((double)CosDistribKat[i*2]) / NumMolDistrib_cos_kat;
            out << std::setw ( 10 ) << ((double)CosDistribKat[i*2 + 1]) / NumMolDistrib_cos_kat;
        }
        if ( SimSystem.all_anions.size() > 0 ) {
            out << std::setw ( 10 ) << ((double)CosDistribAn[i*2]) / NumMolDistrib_cos_an;
            out << std::setw ( 10 ) << ((double)CosDistribAn[i*2 + 1]) / NumMolDistrib_cos_an;
        }
        out << std::endl;
    }
}

static void SaveWiy98Distr_cos () {
std::ofstream out ( Distrib_cos_Name, std::ios::binary | std::ios::out | std::ios::trunc );
    if ( !out ) {
        std::cout << UnOpen << Distrib_cos_Name << std::endl;
        std::exit (1);
    }
    version::out ( out );
    out.write ( (char*) &NumMolDistrib_cos_kat,    sizeof(int) );
    out.write ( (char*) &NumMolDistrib_cos_an,     sizeof(int) );
    out.write ( (char*) CosDistribKat,  sizeof(int) * SizeCosArray * 2 );
    out.write ( (char*) CosDistribAn,   sizeof(int) * SizeCosArray * 2 );
}
