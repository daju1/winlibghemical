#if !defined M_ION
#define M_ION

#include "crystal_grids.h"

#include <utility>
#include <vector>

void ins_ions ( int numkat, int numan ); // replace molecules with ions

std::pair<std::vector<crystal_grid::size_type>, std::vector<crystal_grid::size_type> >
select_ions_positions ( const crystal_grid& grid, int numkat, int numan );

#endif
