/* =====================================================================================
   In this file some procedures for calculating and printing miscellaneous properties
   of the simulated system are placed. Most of them are called by using '-n' command-
   line option (corresponding functions must being called from OutMiscProp () procedure)
   ===================================================================================== */

#include "lib/mdformat.h"
#include "globals.h"
#include "units.h"
#include "all_particles.h"
#include "lib/constsi.h"
#include "orient.h"
#include "miscprop.h"
#include "cluster.h"
#include "gro.h"
using namespace mdnaes;

#include <vector>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <iomanip>
#include <limits>

static void PrintShells ();
static void PrintMolPairs ();
static void PrintClustersXYZ ();

double min_distance ( const std::vector<vect>& a, const std::vector<vect>& b ) {
   double rmin = std::numeric_limits<double>::max();
      
   for ( int i = 0; i < a.size(); ++i ) {
      for ( int j = 0; j < b.size(); ++j ) {
         vect dr = a[i] - b[j];
         PBC ( dr );
         const double r = norm ( dr );
         if ( r < rmin ) {
            rmin = r;
         }
      }
   }
    return rmin;
}

   


template <class Pointer_t>
void PrintInteratomicDistanceError ( const std::vector<Pointer_t>& particles ) {
   if ( particles.size() == 0 )
      return;
   
   const int Nat = particles[0]->natoms();
   double *maxerror = new double[Nat*Nat];
   double *sumerror = new double[Nat*Nat];

   for ( int i = 0; i < Nat*Nat; ++i )
      sumerror[i] = maxerror[i] = 0.0;

   for ( int i = 0; i < particles.size(); ++i )
      for ( int a = 0; a < Nat-1; ++a )
         for ( int b = a+1; b < Nat; ++b ) {
            const double dist_error = particles[i]->interatomic_distance_error (a, b);
            if ( fabs(dist_error) > maxerror[a*Nat+b] )
               maxerror[a*Nat+b] = fabs(dist_error);
            sumerror[a*Nat+b] += dist_error;
         }

   const mdformat format ( 20, 15 );
   const mdformat atnameformat ( 8, 0 );

   Message << "ineratomic distance errors for " << particles[0]->name() << "\n";
   Message << atnameformat << "atom1" << atnameformat << "atom2";
   Message << atnameformat << "at1name";
   Message << atnameformat << "at2name";
   Message << format << "maxerror" << format << "mean error";
   Message << "\n";

   for ( int a = 0; a < Nat-1; ++a ) {
      for ( int b = a+1; b < Nat; ++b ) {
         Message << atnameformat << a << atnameformat << b;
         Message << atnameformat << (*particles[0])[a].name();
         Message << atnameformat << (*particles[0])[b].name();
         Message << format << maxerror[a*Nat+b] << format << sumerror[a*Nat+b]/particles.size();
         Message << "\n";
      }
   }
   Message << "\n";

   delete[] maxerror;
   delete[] sumerror;
}


void OutMiscProp ( int mode ) {
   if ( SimSystem.all_ions.size() > 0 ) {
      PrintShells ();
      PrintClusters ();
      PrintClustersXYZ ();
   }
   if ( mode == 1 )
      PrintMolPairs ();

   {  // printing coordinates of all particles in system
      std::ofstream boxdump ( "boxdump.xyz" );
      const vect boxorigin = vect ( LBOX/2, LBOX/2, LBOX/2 );
      for ( auto p: SimSystem.all_particles )
         p->print ( boxdump, boxorigin );
   }
   
   if ( K_PrintGRO ) {
      Print_gro ();
   }

   for ( const auto& array: SimSystem.molecules ) {
      if ( array.size() > 0 )
         PrintInteratomicDistanceError ( array );
   }
   for ( const auto& array: SimSystem.cations ) {
      if ( array.size() > 0 )
         PrintInteratomicDistanceError ( array );
   }
   for ( const auto& array: SimSystem.anions ) {
      if ( array.size() > 0 )
         PrintInteratomicDistanceError ( array );
   }
   
   Message << std::endl;
}

void Out_DLPOLY_Config ( const char *filename, int mode ) {
   std::ofstream out ( filename );
   const mdformat format = mdformat(20,12);

   out << SimSystem.all_molecules.size() << " molecules + "
       << SimSystem.all_cations.size() << " cations + "
       << SimSystem.all_anions.size() << " anions" << "\n";

   out << mdformat(10,0) << mode << mdformat(10,0) << 1 << "\n"; // 1 means cubic boundary conditions

   out << format << 10*LBOX << format << 0.0     << format << 0.0     << "\n";
   out << format << 0.0     << format << 10*LBOX << format << 0.0     << "\n";
   out << format << 0.0     << format << 0.0     << format << 10*LBOX << "\n";
   
   int atom = 1;
   for ( auto p: SimSystem.all_particles )
      atom = p->DLPOLY_Out ( out, atom, mode );
}

static void PrintShells () {
   std::ofstream out  ( "shellsFlash.dat" );
   std::ofstream outM ( "shellsFlashM.dat" );

   // Print cation's shells:
   for ( auto p_ion: SimSystem.all_cations ) {
      const std::vector<vect> ion_cc = p_ion->getCoordinationCenters ();
      const vect IonPos = p_ion->getCMPos();
      
      p_ion->print ( out,  IonPos  );
      p_ion->print ( outM, IonPos );

      for ( auto p: SimSystem.all_molecules1 ) {
         const double r = p->getMinCationCoordinationCenterDistance ( ion_cc );

         if ( r < RSHL[0] ) {
            p->print ( out,  IonPos );
            p->print ( outM, IonPos );
         }
      }
	  for ( auto p: SimSystem.all_molecules2 ) {
         const double r = p->getMinCationCoordinationCenterDistance ( ion_cc );

         if ( r < RSHL[5] ) {
            p->print ( out,  IonPos );
            p->print ( outM, IonPos );
         }
      }

      for ( auto p: SimSystem.all_cations ) {
         if ( p != p_ion ) {
            const double r = min_distance ( ion_cc, p->getCoordinationCenters() );

            if ( r < RSHL[4] )
               p->print ( out,  IonPos );
         }
      }

      for ( auto p: SimSystem.all_anions ) {
         const double r = min_distance ( ion_cc, p->getCoordinationCenters() );

         if ( r < RSHL[4] )
            p->print ( out,  IonPos );
      }
      out  << std::endl;
      outM << std::endl;
   }

   // Print anion's shells:
   for ( auto p_ion: SimSystem.all_anions ) {
      const std::vector<vect> ion_cc = p_ion->getCoordinationCenters ();
      const vect IonPos = p_ion->getCMPos();
      
      p_ion->print ( out,  IonPos );
      p_ion->print ( outM, IonPos );

      for ( auto p: SimSystem.all_molecules1 ) {
         const double r = p->getMinAnionCoordinationCenterDistance ( ion_cc );

         if ( r < RSHL[2] ) {
            p->print ( out,  IonPos );
            p->print ( outM, IonPos );
         }
      }
	  for ( auto p: SimSystem.all_molecules2 ) {
         const double r = p->getMinAnionCoordinationCenterDistance ( ion_cc );

         if ( r < RSHL[7] ) {
            p->print ( out,  IonPos );
            p->print ( outM, IonPos );
         }
      }

      for ( auto p: SimSystem.all_anions ) {
         if ( p != p_ion ) {
            const double r = min_distance ( ion_cc, p->getCoordinationCenters() );

            if ( r < RSHL[4] )
               p->print ( out,  IonPos );
         }
      }

      for ( auto p: SimSystem.all_cations ) {
         const double r = min_distance ( ion_cc, p->getCoordinationCenters() );

         if ( r < RSHL[4] )
            p->print ( out,  IonPos );
      }
      out  << std::endl;
      outM << std::endl;
   }
}



// ================================================================================================================ //
static cluster_collection AnalizeClusters () {
   cluster_collection clusters;

   for ( int c = 0; c < SimSystem.all_cations.size(); ++c ) {
      const std::vector<vect> cation_cc = SimSystem.all_cations[c]->getCoordinationCenters ();
      
      for ( int a = 0; a < SimSystem.all_anions.size(); ++a ) {
         const std::vector<vect> anion_cc = SimSystem.all_anions[a]->getCoordinationCenters ();

         const double r = min_distance ( cation_cc, anion_cc );
         
         if ( r < RSHL[4] )
            clusters.addPair ( c, a );
      }
   }
   clusters.proceed ();
   return clusters;
}

void PrintClusters () {
   static const char *ClustersFileName = "clusters.dat";

   const cluster_collection clusters = AnalizeClusters ();

   std::ofstream out ( ClustersFileName, std::ios::ate | std::ios::out | std::ios::app );
   out << mdformat(9,0) << NSTTOT << "  ";

   for ( auto cl: clusters ) {
      out << "[";
      out << cl.nCat();
      out << ",";
      out << cl.nAn();
      out << "]  ";
   }
   out << std::endl;
}

static vect cluster_amplitude ( const cluster& c, const vect& origin ) {
   vect minXYZ( LBOX, LBOX, LBOX);
   vect maxXYZ(-LBOX,-LBOX,-LBOX);

   for ( int i = 0; i < SimSystem.all_cations.size(); ++i ) {
      if ( c.has_cat(i) ) {
         const std::vector<vect> cc = SimSystem.all_cations[i]->getCoordinationCenters ();
         
         for ( int k = 0; k < cc.size(); ++k ) {
            vect r = cc[k] - origin;
            PBC (r);

            if ( r.x > maxXYZ.x )
               maxXYZ.x = r.x;
            if ( r.x < minXYZ.x )
               minXYZ.x = r.x;

            if ( r.y > maxXYZ.y )
               maxXYZ.y = r.y;
            if ( r.y < minXYZ.y )
               minXYZ.y = r.y;

            if ( r.z > maxXYZ.z )
               maxXYZ.z = r.z;
            if ( r.z < minXYZ.z )
               minXYZ.z = r.z;
         }
      }
   }

   for ( int i = 0; i < SimSystem.all_anions.size(); ++i ) {
      if ( c.has_an(i) ) {
         const std::vector<vect> cc = SimSystem.all_anions[i]->getCoordinationCenters ();
         
         for ( int k = 0; k < cc.size(); ++k ) {
            vect r = cc[k] - origin;
            PBC (r);

            if ( r.x > maxXYZ.x )
               maxXYZ.x = r.x;
            if ( r.x < minXYZ.x )
               minXYZ.x = r.x;

            if ( r.y > maxXYZ.y )
               maxXYZ.y = r.y;
            if ( r.y < minXYZ.y )
               minXYZ.y = r.y;

            if ( r.z > maxXYZ.z )
               maxXYZ.z = r.z;
            if ( r.z < minXYZ.z )
               minXYZ.z = r.z;
         }
      }
   }
   return maxXYZ - minXYZ;
}

static void print_cluster ( std::ostream& out, const cluster& c, const vect& origin, const vect origin_pos = 0.0 ) {
   for ( int i = 0; i < SimSystem.all_cations.size(); ++i ) {
      if ( c.has_cat(i) )
         SimSystem.all_cations[i]->print ( out, origin, origin_pos );
   }
   for ( int i = 0; i < SimSystem.all_anions.size(); ++i ) {
      if ( c.has_an(i) )
         SimSystem.all_anions[i]->print ( out, origin, origin_pos );
   }
}

static void PrintClustersXYZ () {
   static const char *ClustersXYZFileName = "clusters.xyz";
   constexpr int Nsamples = 100;

   const cluster_collection clusters = AnalizeClusters ();

   std::ofstream out ( ClustersXYZFileName );

   for ( const auto& c: clusters ) {
      // search for optimal origin for current cluster:
      vect current_origin (0,0,0);
      vect min_amplitude (LBOX,LBOX,LBOX);

      for ( int j = 0; j < Nsamples; ++j ) {
         double x_origin = double(j)*LBOX/Nsamples;
         double x_amplitude = cluster_amplitude (c, vect(x_origin,0,0)).x;
         if ( x_amplitude < min_amplitude.x ) {
            current_origin.x = x_origin;
            min_amplitude.x = x_amplitude;
         }

         double y_origin = double(j)*LBOX/Nsamples;
         double y_amplitude = cluster_amplitude (c, vect(0,y_origin,0)).y;
         if ( y_amplitude < min_amplitude.y ) {
            current_origin.y = y_origin;
            min_amplitude.y = y_amplitude;
         }

         double z_origin = double(j)*LBOX/Nsamples;
         double z_amplitude = cluster_amplitude (c, vect(0,0,z_origin)).z;
         if ( z_amplitude < min_amplitude.z ) {
            current_origin.z = z_origin;
            min_amplitude.z = z_amplitude;
         }
      }

      // print this cluster:
      print_cluster ( out, c, current_origin, current_origin );
      out << std::endl;
   }
}

/* ========================================================================
   ======================================================================== */
static double MP_DeltaR;

struct molpair {
   int i, j;
   double r;
   double dipole_angle;
   double mainvect_angle;
};

static int compare_dip ( const void *a, const void *b ) {
   const molpair *pair1 = (molpair*)a;
   const molpair *pair2 = (molpair*)b;
   //std::cout << '*';

   const int r1 = (int)floor(pair1->r/MP_DeltaR);
   const int r2 = (int)floor(pair2->r/MP_DeltaR);

   if ( r1 > r2 )
      return  1;
   if ( r1 < r2 )
      return -1;
   if ( pair1->dipole_angle > pair2->dipole_angle )
      return  1;
   if ( pair1->dipole_angle < pair2->dipole_angle )
      return -1;

   return 0;
}

static int compare_mv ( const void *a, const void *b ) {
   const molpair *pair1 = (molpair*)a;
   const molpair *pair2 = (molpair*)b;
   //std::cout << '#';

   const int r1 = (int)floor(pair1->r/MP_DeltaR);
   const int r2 = (int)floor(pair2->r/MP_DeltaR);

   if ( r1 > r2 )
      return  1;
   if ( r1 < r2 )
      return -1;
   if ( pair1->mainvect_angle > pair2->mainvect_angle )
      return  1;
   if ( pair1->mainvect_angle < pair2->mainvect_angle )
      return -1;

   return 0;
}


static void PrintMolPairs () {
   const int nmol = SimSystem.all_molecules.size ();
   molpair *pairs = new molpair[nmol*(nmol-1)/2];
   MP_DeltaR = StepRInShl;

   // Initialization step
   for ( int i = 0; i < nmol-1; ++i ) {
      auto mol1 = SimSystem.all_molecules[i];
      
      for ( int j = i+1; j < nmol; ++j ) {
         auto mol2 = SimSystem.all_molecules[j];
         
         const int index = (nmol-1)*i - i*(i+1)/2 + j - 1;
         vect R = mol2->getCMPos() - mol1->getCMPos();
         PBC(R);

         pairs[index].i = i;
         pairs[index].j = j;
         pairs[index].r = norm(R);
         {
            const vect vec1 = mol1->getDipolMomentum();
            const vect vec2 = mol2->getDipolMomentum();
            pairs[index].dipole_angle = acos ((vec1*vec2)/(norm(vec1)*norm(vec2)))*(180/SI_PI);
         }
         {
            const vect vec1 = mol1->getMainVect();
            const vect vec2 = mol2->getMainVect();
            pairs[index].mainvect_angle = acos ((vec1*vec2)/(norm(vec1)*norm(vec2)))*(180/SI_PI);
         }
      }
   }

   clock_t StartTime = clock ();
   std::ofstream out;
   int r_index;

   out.open ("DVS.dat");
   qsort(pairs, nmol*(nmol-1)/2, sizeof(molpair), compare_dip );
   
   r_index = 0;
   for ( int i = 0; i < nmol*(nmol-1)/2; ++i ) {
      while ( r_index*MP_DeltaR < pairs[i].r ) {
         out << "\n ! DISTANCE: " << mdformat(5,3) << r_index*MP_DeltaR << " nm !\n";
         r_index++;
      }
      if ( (r_index-1)*MP_DeltaR > RCut.LJ )
         break;

      out <<  "i = " << mdformat(3) << pairs[i].i;
      out << " j = " << mdformat(3) << pairs[i].j;
      out << "\nRij = " << mdformat(6,4) << pairs[i].r << " nm,";
      out <<  " DipMom angle = "   << mdformat(5,1) << pairs[i].dipole_angle;
      out << ", MainVect angle = " << mdformat(5,1) << pairs[i].mainvect_angle;
      out << "\n";
      const vect origin = SimSystem.all_molecules[pairs[i].i]->getCMPos();
      SimSystem.all_molecules[pairs[i].i]->print(out, origin);
      SimSystem.all_molecules[pairs[i].j]->print(out, origin);
   }
   out.close ();

   out.open ("MVS.dat");
   qsort(pairs, nmol*(nmol-1)/2, sizeof(molpair), compare_mv );
   
   r_index = 0;
   for ( int i = 0; i < nmol*(nmol-1)/2; ++i ) {
      while ( r_index*MP_DeltaR < pairs[i].r ) {
         out << "\n ! DISTANCE: " << mdformat(5,3) << r_index*MP_DeltaR << " nm !\n";
         r_index++;
      }
      if ( (r_index-1)*MP_DeltaR > RCut.LJ )
         break;

      out <<  "i = " << mdformat(3) << pairs[i].i;
      out << " j = " << mdformat(3) << pairs[i].j;
      out << "\nRij = " << mdformat(6,4) << pairs[i].r << " nm,";
      out <<  " DipMom angle = "   << mdformat(5,1) << pairs[i].dipole_angle;
      out << ", MainVect angle = " << mdformat(5,1) << pairs[i].mainvect_angle;
      out << "\n";
      const vect origin = SimSystem.all_molecules[pairs[i].i]->getCMPos();
      SimSystem.all_molecules[pairs[i].i]->print(out, origin);
      SimSystem.all_molecules[pairs[i].j]->print(out, origin);
   }
   out.close ();
   std::cout << "\n" << double(clock()-StartTime)/CLOCKS_PER_SEC << "s\n";

   delete[] pairs;
}


void Print_trajectory ( std::ostream& out ) {
   /* static bool first = true;
   
   if ( first ) {
      out << mdformat(8) << "#Step";
      out << mdformat(10) << "X   " << mdformat(10) << "Y   " << mdformat(10) << "Z   ";
      out << mdformat(11) << "Vx   " << mdformat(11) << "Vy   " << mdformat(11) << "Vz   ";
      out << mdformat(5) << "Atom" << mdformat(5) << "Mol" << "\n";

      first = false;
   }
   */

   out.setf ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
   for ( std::size_t i = 0;  i < SimSystem.all_particles.size(); ++i ) {
      auto p = SimSystem.all_particles[i];
      for ( basic_particle::const_reference a: *p ) {
         out << std::setw(8) << NSTTOT;
         out << mdformat(10,5) << a.r() - p->getCMPos() + p->getUnPBC_CMPos(); // in nm
         out << mdformat(11,4) << a.v() * LENGTH_UNIT/TIME_UNIT; // in m/s
         out << std::setw(5) << a.name() << std::setw(5) << i+1;
         out << "\n";
      }
   }
}

void Print_trajectory4Mol ( std::ostream& out ) {
   /*
   static bool first = true;
   if ( first ) {
      out << mdformat(8) << "#Step";
      out << mdformat(10) << "Xcm   " << mdformat(10) << "Ycm   " << mdformat(10) << "Zcm   ";
      out << mdformat(11) << "Vxcm   " << mdformat(11) << "Vycm   " << mdformat(11) << "Vzcm   ";
      out << mdformat(5) << "Mol" << "\n";

      first = false;
   }
   */

   out.setf ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
   for ( std::size_t i = 0;  i < SimSystem.all_particles.size(); ++i ) {
      auto p = SimSystem.all_particles[i];
      
      out << std::setw(8) << NSTTOT;
      out << mdformat(10,5) << p->getUnPBC_CMPos(); // in nm
      out << mdformat(11,4) << p->getCMVel() * LENGTH_UNIT/TIME_UNIT; // in m/s
      out << std::setw(5) << i+1;
      out << "\n";
   }
}
