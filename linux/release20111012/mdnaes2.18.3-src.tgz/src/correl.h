#ifndef CORREL_H
#define CORREL_H

#include "STCF.h"
#include "SMolCF.h"
#include "LMolCF.h"
#include "SIonCF.h"
#include "LIonCF.h"
#include "AtomsVACF.h"
#include "SVisc.h"
#include "Conduct.h"
#include "TLife.h"
#include "Fkt.h"

void DynamFunctions ();

// =====================================================================
extern int KShortMolCF;  //
extern int KLongMolCF;   //
extern int KShortIonCF;  //
extern int KLongIonCF;   //
extern int KTimeLife;    //
extern int KSVisc;       // Calculate shear viscosity
extern int KConduct;     // Calculate electrical conductivity
extern int KConduct_E;   // Calculate electrical conductivity by Einstein-like formula
extern int KAtomsCvv;    //
extern int KSTCF;        // Calculate van Hove function G(r,t)
extern int KFktInc;

extern int KLegendre;    // Calculate Legendre polinomials

extern int StepShortCF;
extern int StepLongCF;
extern int CorrelSize;   // size of correlation arrays

#endif
