#include <cstdlib>
#include <thread>

#include "globals.h"
#include "all_particles.h"
#include "units.h"


SaveManager SMan;
SaveManager ShowRes;

std::mt19937_64 global_random_engine {0};

int NORUN = 0;
int NORUN_MODE = -1;

bool NOSCRPRINT = false;
bool K_PrintGRO = false;
bool K_PrintVbox = false;
bool K_StartRUN = false;
bool K_ImportGRO = false;


int32_t ORIGINAL_SEED = 0;
int32_t CURRENT_SEED = 0;

int NTHREADS = (std::thread::hardware_concurrency()>0)? std::thread::hardware_concurrency() : 1;

int NSTTOT;

int SubSteps = 1;

//cutt_off_t RCut = {0.0,0.0,0.0, 1.0,0.8,1.2};
cutt_off_t RCut = {0.0,0.0,0.0, 0.0,0.0,0.0};

double LBOX, LBOX2;
double LBOXinit; // Box side length calculated from fint.dat file data

double VOLBOX;        // Volume of cubic box
double DENS;          // Density of system
double DENSinit;      // initial density of system
// double RCUT_LJ;       // Cutt off radius for short-ranged interactions
// double RCUT_LJ_init;  // Cut off radius for short-ranged interactions readed from fint.dat
// double RCUT_Coul;     // Cutt off radius for coulombic interactions
double DELTR;         // 1 / Step for RDF
double TIME;          // Total time of live system ( in picoseconds )
double DELT;          // Time step
double TMPR0;         // Temperature of thermostat
double TMPR;          // Temperature of system
double PRES;          // pressure
double taw;           // Thermal parameter
double External_Field;// External (?) electric field.
double Eps;

double extPRES;
double tawP;

// ===========================================================================
void System_therm_values_t::zero_bonded_components () {
   Ubond = Uangle = Udihedral = Udihedral_2 = Uharmonic_dihedral = 0;
   stressInt.set_to_zero();
}

void System_therm_values_t::zero_short_components () {
   sUpot = 0;
   sVIRtot = 0;
   sUmm = sUmc = sUma = sUcc = sUca = sUaa = 0;
   sVIRmm = sVIRmc = sVIRma = sVIRcc = sVIRca = sVIRaa = 0;
   
   Unb_intra = 0;
   VIRnb_intra = 0;
   
   for ( int i = 0; i < MAX_PARTICLE_TYPES; ++i ) {
      for ( int j = 0; j < MAX_PARTICLE_TYPES; ++j ) {
         sU[i][j] = 0;
         sVIR[i][j] = 0;
      }
   }
   
   stressPotS.set_to_zero();
}

void System_therm_values_t::zero_far_components () {
   cUpot = 0;
   cVIRtot = 0;
   cUmm = cUmc = cUma = cUcc = cUca = cUaa = 0;
   cVIRmm = cVIRmc = cVIRma = cVIRcc = cVIRca = cVIRaa = 0;
   
   for ( int i = 0; i < MAX_PARTICLE_TYPES; ++i ) {
      for ( int j = 0; j < MAX_PARTICLE_TYPES; ++j ) {
         cU[i][j] = 0;
         cVIR[i][j] = 0;
      }
   }
   
   stressPotC.set_to_zero();
}

void System_therm_values_t::zero_general_components () {
   UT = 0;
   Enthalpy = 0;
   
   EkinM = EkinC = EkinA = 0;
   Ekin = 0;
   
   Uinter = 0;
   Uintra = 0;
   Upot = 0;
   VIRtot = 0;
   
   dcUpot = 0;
   dcVIRtot = 0;
   
   dcUmm = dcUmc = dcUma = dcUcc = dcUca = dcUaa = 0;
   dcVIRmm = dcVIRmc = dcVIRma = dcVIRcc = dcVIRca = dcVIRaa = 0;
   
   for ( int i = 0; i < MAX_PARTICLE_TYPES; ++i ) {
      for ( int j = 0; j < MAX_PARTICLE_TYPES; ++j ) {
         dcU[i][j] = 0;
         dcVIR[i][j] = 0;
      }
   }
   
   stressKin.set_to_zero();
   stress.set_to_zero();
}

void System_therm_values_t::zero_ab_components () {
   dcUmm = dcUmc = dcUma = dcUcc = dcUca = dcUaa = 0;
   dcVIRmm = dcVIRmc = dcVIRma = dcVIRcc = dcVIRca = dcVIRaa = 0;
   
   sUmm = sUmc = sUma = sUcc = sUca = sUaa = 0;
   sVIRmm = sVIRmc = sVIRma = sVIRcc = sVIRca = sVIRaa = 0;
   
   cUmm = cUmc = cUma = cUcc = cUca = cUaa = 0;
   cVIRmm = cVIRmc = cVIRma = cVIRcc = cVIRca = cVIRaa = 0;
}

void System_therm_values_t::zero_all () {
   zero_bonded_components ();
   zero_short_components ();
   zero_far_components ();
   zero_general_components ();
}

System_therm_values_t& System_therm_values_t::operator += ( const System_therm_values_t& other ) {
   EkinM += other.EkinM;
   EkinC += other.EkinC;
   EkinA += other.EkinA;
   
   Ekin += other.Ekin;
   sVIRtot += other.sVIRtot;
   cVIRtot += other.cVIRtot;
   dcVIRtot += other.dcVIRtot;
   VIRtot += other.VIRtot;
   
   sUpot += other.sUpot;
   cUpot += other.cUpot;
   dcUpot += other.dcUpot;
   Uinter += other.Uinter;
   Uintra += other.Uintra;
   Upot += other.Upot;
   UT += other.UT;
   Enthalpy += other.Enthalpy;
   
   sUmm += other.sUmm;
   sUmc += other.sUmc;
   sUma += other.sUma;
   sUcc += other.sUcc;
   sUca += other.sUca;
   sUaa += other.sUaa;
   cUmm += other.cUmm;
   cUmc += other.cUmc;
   cUma += other.cUma;
   cUcc += other.cUcc;
   cUca += other.cUca;
   cUaa += other.cUaa;
   
   sVIRmm += other.sVIRmm;
   sVIRmc += other.sVIRmc;
   sVIRma += other.sVIRma;
   sVIRcc += other.sVIRcc;
   sVIRca += other.sVIRca;
   sVIRaa += other.sVIRaa;
   
   cVIRmm += other.cVIRmm;
   cVIRmc += other.cVIRmc;
   cVIRma += other.cVIRma;
   cVIRcc += other.cVIRcc;
   cVIRca += other.cVIRca;
   cVIRaa += other.cVIRaa;
   
   dcUmm += other.dcUmm;
   dcUmc += other.dcUmc;
   dcUma += other.dcUma;
   dcUcc += other.dcUcc;
   dcUca += other.dcUca;
   dcUaa += other.dcUaa;
   
   dcVIRmm += other.dcVIRmm;
   dcVIRmc += other.dcVIRmc;
   dcVIRma += other.dcVIRma;
   dcVIRcc += other.dcVIRcc;
   dcVIRca += other.dcVIRca;
   dcVIRaa += other.dcVIRaa;
   
   Ubond += other.Ubond;
   Uangle += other.Uangle;
   Udihedral += other.Udihedral;
   Udihedral_2 += other.Udihedral_2;
   Uharmonic_dihedral += other.Uharmonic_dihedral;
   
   Unb_intra += other.Unb_intra;
   VIRnb_intra += other.VIRnb_intra;
   
   for ( int i = 0; i < MAX_PARTICLE_TYPES; ++i ) {
      for ( int j = 0; j < MAX_PARTICLE_TYPES; ++j ) {
         sU[i][j] += other.sU[i][j];
         cU[i][j] += other.cU[i][j];
         sVIR[i][j] += other.sVIR[i][j];
         cVIR[i][j] += other.cVIR[i][j];
         dcU[i][j] += other.dcU[i][j];
         dcVIR[i][j] += other.dcVIR[i][j];
      }
   }
   
   stressPotS += other.stressPotS;
   stressPotC += other.stressPotC;
   stressKin += other.stressKin;
   stressInt += other.stressInt;
   stress += other.stress;
      
   return *this;
}

System_therm_values_t Therm_values;
std::vector<System_therm_values_t> TL_Therm_values;
// ===========================================================================

int Kstress;

int  NSTRUN;        // Number of steps for this run

int StepRDF;            // Interval calculations RDF
int SPRNT;              // Interval energy printing
int SWRIT;              // Interval printing config file

int KRS;
int KCF;
int KSTR;
int KLH;
int KLK;
int KStat;
int KScrOut;
int KCoorOut;
int KSV;
int KCoul;

int NMOL1, NMOL2, NION_C, NION_A;

int KDBL;         // System: Number of atoms *= KDBL*KDBL*KDBL
int NumInsIon[2]; // [0] - NumInsIon for kation; [1] - for anion

double RSHL[9];

double *Wiy98_AdvancedCationCoordinationCenter_coefs = nullptr;
double *Wiy98_AdvancedAnionCoordinationCenter_coefs = nullptr;

// ========================================================================
void setBoxSizeVariables() {
   VOLBOX = LBOX * LBOX * LBOX;
   LBOX2 = LBOX * 0.5;
   RCut.Coul = LBOX2;
   RCut.LJ = RCut.LJ_init;
   if ( RCut.LJ > LBOX2 ) {
      RCut.LJ = LBOX2;
   }

   DENS = SimSystem.total_mass() * MASS_UNIT / (VOLBOX * VOLUME_UNIT); // in SI units, kg/m^3.
}

void printSimulatedSystemMessage ( std::ostream& out ) {
   bool isprinted = false;
   
   out << " Simulated system: ";

   for ( const auto& arr: SimSystem.molecules ) {
      if ( arr.size() > 0 ) {
         if ( isprinted ) out << " + ";
         
         out << arr.size() << " " << arr[0]->name ();
         
         isprinted = true;
      }
   }
   
   for ( const auto& arr: SimSystem.cations ) {
      if ( arr.size() > 0 ) {
         if ( isprinted ) out << " + ";
         
         out << arr.size() << " " << arr[0]->name ();
         
         isprinted = true;
      }
   }
   
   for ( const auto& arr: SimSystem.anions ) {
      if ( arr.size() > 0 ) {
         if ( isprinted ) out << " + ";
         
         out << arr.size() << " " << arr[0]->name ();
         
         isprinted = true;
      }
   }
   
   out << std::endl;
}

