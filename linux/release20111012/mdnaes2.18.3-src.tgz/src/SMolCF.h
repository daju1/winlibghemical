#ifndef SMolCF_H
#define SMolCF_H

extern int KMol_Cvv;
extern int KMol_Cww;
extern int KMol_Cff;
extern int KMol_Cnn;
extern int KMol_Cll;

extern int KMol_Cfc;
extern int KMol_Cnc;

extern int KMol_Cwc;
extern int KMol_Cvw;

extern int KMol_WcWc;
extern int KMol_VcVc;
extern int KMol_VcWc;

extern int KMol_Cii;

void ShortMolCF_Calc ();

#endif
