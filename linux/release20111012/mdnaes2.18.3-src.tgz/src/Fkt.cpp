#include <vector>
#include <complex>
#include <cmath>

#include "globals.h"
#include "all_particles.h"
#include "correl.h"
#include "lib/HA.h"
#include "lib/TCF.h"
#include "units.h"
#include "version.h"
#include "lib/mdformat.h"
#include "task_pool.h"
#include "utils.h"
using namespace mdnaes;

// ============================== F(k,t) Function =============================
static const char *FktFileName = "F(k,t).cf";
static const char *FktResFileName = "F(k,t).dat";

static void InitFkt ();
static void SaveFkt ();
static void PrintFktRes ();

int StepFkt;
int Fkt_TSIZE;
int Fkt_KSIZE;
static double Fkt_Kmin;

vect *k_array = 0; // [Fkt_KSIZE]
static HA<std::complex<double> > **rho_kt = 0; // [NATOM_TYPES*Fkt_KSIZE]
static TCCF<std::complex<double>,std::complex<double> > **Fkt = 0; // [NATOM_TYPES*NATOM_TYPES*Fkt_KSIZE]
static std::complex<double> *rho_k = 0; // [NATOM_TYPES*Fkt_KSIZE]

static int NATOM_TYPES = 0;

void Fkt_Calc () {
   static bool init = true;
   if ( init ) {
      InitFkt ();
      SMan.AddFun ( &SaveFkt );
      ShowRes.AddFun ( &PrintFktRes );
      init = false;
   }

   for ( int i = 0; i < NATOM_TYPES*Fkt_KSIZE; ++i ) {
      rho_k[i] = 0.0;
   }

   for ( auto p: SimSystem.all_particles ) {
      for ( auto a: *p ) {
         const vect r = a.r();
         const auto ID = a.id();

         for ( int k = 0; k < Fkt_KSIZE; ++k ) {
            rho_k[ID*Fkt_KSIZE + k] += std::exp(std::complex<double>(0,-(r*k_array[k])));
         }
      }
   }

   for ( int i = 0; i < NATOM_TYPES*Fkt_KSIZE; ++i )
      rho_kt[i]->add ( rho_k[i] );
   
   for ( int a = 0; a < NATOM_TYPES; ++a ) {
      for ( int b = 0; b < NATOM_TYPES; ++b ) {
         for ( int k = 0; k < Fkt_KSIZE; ++k ) {
            //calculate F(k,t) as complex function
            Fkt[a*NATOM_TYPES*Fkt_KSIZE + b*Fkt_KSIZE + k]->add (
               *rho_kt[a*Fkt_KSIZE+k], *rho_kt[b*Fkt_KSIZE+k] );
         }
      }
   }
}

static void InitFkt () {
   Message << "starting F(k,t) calculation" << std::endl;
   
   NATOM_TYPES = Atom_types.size ();

   StepFkt = StepShortCF;
   Fkt_TSIZE = CorrelSize;
   // maybe k_array shoud be initialized, when reading fint.dat!
   Fkt_KSIZE = 20;
   k_array = new vect[Fkt_KSIZE];
   const double L = 2*SI_PI/LBOX;
   Fkt_Kmin = L;

   int i;
   for ( i = 0; i < Fkt_KSIZE; ++i )
      k_array[i] = vect(0,0,(i+1)*Fkt_Kmin);
   // but for testing perporses we initialise it here

   rho_kt = new HA<std::complex<double> >* [NATOM_TYPES*Fkt_KSIZE];
   for ( i = 0; i < NATOM_TYPES*Fkt_KSIZE; ++i )
      rho_kt[i] = new HA<std::complex<double> >(Fkt_TSIZE);

   Fkt = new TCCF<std::complex<double>,std::complex<double> >* [NATOM_TYPES*NATOM_TYPES*Fkt_KSIZE];
   for ( i = 0; i < NATOM_TYPES*NATOM_TYPES*Fkt_KSIZE; ++i )
      Fkt[i] = new TCCF<std::complex<double>,std::complex<double> >(Fkt_TSIZE);

   rho_k = new std::complex<double>[NATOM_TYPES*Fkt_KSIZE];

   if ( KLH ) {
      std::ifstream in ( FktFileName, std::ios::binary | std::ios::in );
      if ( !in ) {
         Error << "void InitFkt (): cannot open file " << FktFileName << std::endl;
         Error << "starting new F(k,t) calculation" << std::endl;
      }
      else {
         Message << "reading saved F(k,t) from file" << std::endl;
         version::check_ver ( in, "void InitFkt ()" );

         int tmp = -1;
         in.read ( (char*)&tmp, sizeof (int) );
         if ( tmp != NSTTOT ) {
            Error << "Warning in restoring F(k,t) calculations : saved NSTTOT = ";
            Error << tmp << ", actual NSTTOT = " << NSTTOT << std::endl;
         }

         tmp = -1;
         in.read ( (char*)&tmp, sizeof (int) );
         if ( tmp != Fkt_TSIZE ) {
            Error << "Error in restoring F(k,t) calculations : saved Fkt_TSIZE = ";
            Error << tmp << ", current Fkt_TSIZE = " << Fkt_TSIZE << std::endl;
            std::exit ( EXIT_FAILURE );
         }

         tmp = -1;
         in.read ( (char*)&tmp, sizeof (int) );
         if ( tmp != Fkt_KSIZE ) {
            Error << "Error in restoring F(k,t) calculations : saved Fkt_KSIZE = ";
            Error << tmp << ", current Fkt_KSIZE = " << Fkt_KSIZE << std::endl;
            std::exit ( EXIT_FAILURE );
         }

         tmp = -1;
         in.read ( (char*)&tmp, sizeof (int) );
         if ( tmp != NATOM_TYPES ) {
            Error << "Error in restoring F(k,t) calculations : saved NATOM_TYPES = ";
            Error << tmp << ", current NATOM_TYPES = " << NATOM_TYPES << std::endl;
            std::exit ( EXIT_FAILURE );
         }

         vect vtmp = 0;
         for ( i = 0; i < Fkt_KSIZE; ++i ) {
            in.read ( (char*)&vtmp, sizeof(vect) );
            if ( norm(k_array[i] - vtmp) > 1.0e-10 ) {
               Error << "Error in restoring F(k,t) calculations : saved k_array[" << i << "] = ";
               Error << vtmp << ", currently used: " << k_array[i] << std::endl;
               std::exit ( EXIT_FAILURE );
            }
         }

         for ( i = 0; i < NATOM_TYPES*Fkt_KSIZE; ++i ) {
            rho_kt[i]->read ( in );
         }
         for ( i = 0; i < NATOM_TYPES*NATOM_TYPES*Fkt_KSIZE; ++i )
            Fkt[i]->read ( in );
      }
   }
}

static void SaveFkt () {
   std::ofstream out ( FktFileName, std::ios::binary | std::ios::out | std::ios::trunc );

   version::out ( out );

   out.write ( (char*)&NSTTOT,      sizeof (int) );
   out.write ( (char*)&Fkt_TSIZE,   sizeof (int) );
   out.write ( (char*)&Fkt_KSIZE,   sizeof (int) );
   out.write ( (char*)&NATOM_TYPES, sizeof (int) );

   out.write ( (char*)k_array, sizeof(vect)*Fkt_KSIZE );
   int i;
   for ( i = 0; i < NATOM_TYPES*Fkt_KSIZE; ++i ) {
      rho_kt[i]->save ( out );
   }
   for ( i = 0; i < NATOM_TYPES*NATOM_TYPES*Fkt_KSIZE; ++i )
      Fkt[i]->save ( out );
}

static void PrintFktRes () {
   std::ofstream out_re ( "ReF(k,t).dat" );
   std::ofstream out_im ( "ImF(k,t).dat" );

   mdformat k_format ( 8, 3 );
   mdformat t_format ( 7, 3 );
   mdformat F_format (10, 5 );

   int a, b, k, t;

   // calculate number of atoms of each type:
   std::vector<int> N_Atoms(NATOM_TYPES, 0);
   
   for ( auto p: SimSystem.all_particles ) {
      for ( auto a: *p ) {
         ++N_Atoms[a.id()];
      }
   }

   out_re << "( x, y, z)";
   out_im << "( x, y, z)";
   out_re << k_format << "k, nm-1" << t_format << "t, ps";
   out_im << k_format << "k, nm-1" << t_format << "t, ps";
   for ( a = 0; a < NATOM_TYPES; ++a ) {
      for ( b = 0; b < NATOM_TYPES; ++b ) {
         if ( N_Atoms[a] > 0 && N_Atoms[b] > 0 ) {
            out_re << F_format << Atom_types[a].name() + Atom_types[b].name();
            out_im << F_format << Atom_types[a].name() + Atom_types[b].name();
         }
      }
   }
   out_re << "\n";
   out_im << "\n";

   for ( k = 0; k < Fkt_KSIZE; ++k ) {
      for ( t = 0; t < Fkt_TSIZE; ++t ) {
         const double L = 2*SI_PI/LBOX;
         out_re << "(" << mdformat(2,0) << static_cast<int>(k_array[k].x/L+0.001);
         out_im << "(" << mdformat(2,0) << static_cast<int>(k_array[k].x/L+0.001);
         out_re << "," << mdformat(2,0) << static_cast<int>(k_array[k].y/L+0.001);
         out_im << "," << mdformat(2,0) << static_cast<int>(k_array[k].y/L+0.001);
         out_re << "," << mdformat(2,0) << static_cast<int>(k_array[k].z/L+0.001);
         out_im << "," << mdformat(2,0) << static_cast<int>(k_array[k].z/L+0.001);
         out_re << ")";
         out_im << ")";
         out_re << k_format << norm(k_array[k]);
         out_im << k_format << norm(k_array[k]);
         out_re << t_format << t*DELT*StepShortCF;
         out_im << t_format << t*DELT*StepShortCF;
         for ( a = 0; a < NATOM_TYPES; ++a ) {
            for ( b = 0; b < NATOM_TYPES; ++b ) {
               if ( N_Atoms[a] > 0 && N_Atoms[b] > 0 ) {
                  out_re << F_format 
                         << std::real((*Fkt[a*NATOM_TYPES*Fkt_KSIZE + b*Fkt_KSIZE + k])[t])
                         / sqrt(static_cast<double>(N_Atoms[a])*static_cast<double>(N_Atoms[b]));
                  out_im << F_format 
                         << std::imag((*Fkt[a*NATOM_TYPES*Fkt_KSIZE + b*Fkt_KSIZE + k])[t])
                         / sqrt(static_cast<double>(N_Atoms[a])*static_cast<double>(N_Atoms[b]));
               }
            }
         }
         out_re << "\n";
         out_im << "\n";
      }
   }
}

// ===========================================================================
// ======================== F(k,t)incoherent Function ========================
// ===========================================================================
class kTACF : public TACF<double,vect> {
public:
   typedef TACF<double,vect> Base;
   typedef Base::value_type value_type;
   typedef Base::reference reference;
   typedef Base::const_reference const_reference;
   typedef Base::size_type size_type;

   explicit kTACF ( size_type tsize ): Base(tsize) {}
   kTACF ( const kTACF& src ): Base( src ) {}
   ~kTACF () {}

   kTACF& operator = ( const kTACF& src ) {
      this->Base::operator = (src);
      return (*this);
   }

   void add ( const HA<vect>&, const double k );
};

void kTACF::add ( const HA<vect>& src, const double k ) {
   const size_type size = std::min ( this->t_size, src.size () );

   for ( size_type i = 0; i < size; ++i ) {
      const double kr = k*norm(src[0]-src[i]);
      if ( kr < 1.0e-6 )
         this->histogram[i] += 1.0 - kr*kr/6;
      else
         this->histogram[i] += sin(kr)/kr;
      this->counts[i]++;
   }
}


static const char *FktIncFileName = "Finc(k,t).cf";

static void InitFktInc ();
static void SaveFktInc ();
static void PrintFktIncRes ();

int StepFktInc;
int FktInc_TSIZE;
static int FktInc_KSIZE;
std::vector<double> k_array_inc;

static std::vector<std::vector<HA<vect> > > atoms_positions; // [NPART][natoms()]
static std::vector<std::vector<HA<vect> > > atoms_posRot;    // [NPART][natoms()]
static std::vector<std::vector<HA<vect> > > atoms_posTrans;  // [NPART][natoms()]

static std::vector<kTACF> FktIncoherent; // [NATOM_TYPES][FktInc_KSIZE]
static std::vector<kTACF> FktIncRot;     // [NATOM_TYPES][FktInc_KSIZE]
static std::vector<kTACF> FktIncTrans;   // [NATOM_TYPES][FktInc_KSIZE]

static task_pool fktinc_tpool;

static void do_update_HA ( int thread_no ) {
#ifdef STATIC_WORK_BALANCING
   for ( int i = thread_no; i < SimSystem.all_particles.size(); i += NTHREADS )
#else
   for ( int i = fktinc_tpool(); i < SimSystem.all_particles.size(); i = fktinc_tpool() )
#endif
   {
      const vect CMPos = SimSystem.all_particles[i]->getCMPos();
      const vect UnPBC_CMPos = SimSystem.all_particles[i]->getUnPBC_CMPos();
      
      const auto& part = SimSystem.all_particles[i]->Fkt_view();
   
      for ( int a = 0; a < part.natoms(); ++a ) {
         auto at = part[a];
         
         atoms_positions[i][a].add ( at.r() - CMPos + UnPBC_CMPos );
         atoms_posRot[i][a].add ( at.r() - CMPos );
         atoms_posTrans[i][a].add ( UnPBC_CMPos );
      }
   }
}

static void do_update_ACF ( int thread_no ) {
   for ( int i = 0; i < SimSystem.all_particles.size(); ++i ) {
      const auto& part = SimSystem.all_particles[i]->Fkt_view();
   
      for ( int a = 0; a < part.natoms(); ++a ) {
         auto at = part[a];
         
#ifdef STATIC_WORK_BALANCING
         for ( int k = thread_no; k < FktInc_KSIZE; k += NTHREADS )
#else
         for ( int k = fktinc_tpool(); k < FktInc_KSIZE; k = fktinc_tpool() )
#endif
         {
            FktIncoherent[at.id()*FktInc_KSIZE + k].add ( atoms_positions[i][a], k_array_inc[k] );
            FktIncRot[at.id()*FktInc_KSIZE + k].add     ( atoms_posRot[i][a], k_array_inc[k] );
            FktIncTrans[at.id()*FktInc_KSIZE + k].add   ( atoms_posTrans[i][a], k_array_inc[k] );
         }
      }
   }
}

void FktInc_Calc () {
   static bool init = true;
   if ( init ) {
      InitFktInc ();
      init = false;
   }

   fktinc_tpool.reset ();

   if ( 1 == NTHREADS ) {
      for ( int i = 0; i < SimSystem.all_particles.size(); ++i ) {
         const vect CMPos = SimSystem.all_particles[i]->getCMPos();
         const vect UnPBC_CMPos = SimSystem.all_particles[i]->getUnPBC_CMPos();
      
         const auto& part = SimSystem.all_particles[i]->Fkt_view();
         
         for ( int a = 0; a < part.natoms(); ++a ) {
            auto at = part[a];
            
            atoms_positions[i][a].add ( at.r() - CMPos + UnPBC_CMPos );
            atoms_posRot[i][a].add ( at.r() - CMPos );
            atoms_posTrans[i][a].add ( UnPBC_CMPos );
            
            for ( int k = 0; k < FktInc_KSIZE; ++k ) {
               FktIncoherent[at.id()*FktInc_KSIZE + k].add ( atoms_positions[i][a], k_array_inc[k] );
               FktIncRot[at.id()*FktInc_KSIZE + k].add     ( atoms_posRot[i][a], k_array_inc[k] );
               FktIncTrans[at.id()*FktInc_KSIZE + k].add   ( atoms_posTrans[i][a], k_array_inc[k] );
            }
         }
      }
   }
   else {
      exec_parallel (do_update_HA,  NTHREADS);
      exec_parallel (do_update_ACF, NTHREADS);
   }
}

static void InitFktInc () {
   Message << "starting F(k,t)incoherent calculation\n";
   Message << "for k values:";

   NATOM_TYPES = Atom_types.size ();
   FktInc_KSIZE = k_array_inc.size();
   
   for ( auto k: k_array_inc )
      Message << " " << k;
   Message << "\n";

   atoms_positions.resize(SimSystem.all_particles.size());
   atoms_posRot.resize(SimSystem.all_particles.size());
   atoms_posTrans.resize(SimSystem.all_particles.size());
   
   for( int i = 0; i < SimSystem.all_particles.size(); ++i ) {
      const auto& part = SimSystem.all_particles[i]->Fkt_view();
      
      atoms_positions[i].resize( part.natoms(), HA<vect>(FktInc_TSIZE) );
      atoms_posRot[i].resize( part.natoms(), HA<vect>(FktInc_TSIZE) );
      atoms_posTrans[i].resize( part.natoms(), HA<vect>(FktInc_TSIZE) );
   }

   FktIncoherent.resize ( NATOM_TYPES*FktInc_KSIZE, kTACF(FktInc_TSIZE) );
   FktIncRot.resize ( NATOM_TYPES*FktInc_KSIZE, kTACF(FktInc_TSIZE) );
   FktIncTrans.resize ( NATOM_TYPES*FktInc_KSIZE, kTACF(FktInc_TSIZE) );

   if ( KLH ) {
      std::ifstream in ( FktIncFileName, std::ios::binary | std::ios::in );
      if ( !in ) {
         Error << "void InitFktInc (): cannot open file " << FktIncFileName << std::endl;
         Error << "starting new F(k,t)incoherent calculation" << std::endl;
      }
      else {
         Message << "reading saved F(k,t)incoherent from file" << std::endl;
         version::check_ver ( in, "void InitFktInc ()" );

         const auto savedNSTTOT = read_as<int> ( in );
         if ( savedNSTTOT != NSTTOT-StepFktInc ) {
            Error << "Warning in restoring F(k,t)incoherent calculations : saved NSTTOT = ";
            Error << savedNSTTOT << ", actual NSTTOT = " << NSTTOT << std::endl;
         }

         const auto savedFktInc_TSIZE = read_as<int> ( in );
         if ( savedFktInc_TSIZE != FktInc_TSIZE ) {
            Error << "Error in restoring F(k,t)incoherent calculations : saved FktInc_TSIZE = ";
            Error << savedFktInc_TSIZE << ", current FktInc_TSIZE = " << FktInc_TSIZE << std::endl;
            std::exit ( EXIT_FAILURE );
         }

         const auto savedFktInc_KSIZE = read_as<int> ( in );
         if ( savedFktInc_KSIZE != FktInc_KSIZE ) {
            Error << "Error in restoring F(k,t)incoherent calculations : saved FktInc_KSIZE = ";
            Error << savedFktInc_KSIZE << ", current FktInc_KSIZE = " << FktInc_KSIZE << std::endl;
            std::exit ( EXIT_FAILURE );
         }

         const auto savedNATOM_TYPES = read_as<int> ( in );
         if ( savedNATOM_TYPES != NATOM_TYPES ) {
            Error << "Error in restoring F(k,t)incoherent calculations : saved NATOM_TYPES = ";
            Error << savedNATOM_TYPES << ", current NATOM_TYPES = " << NATOM_TYPES << std::endl;
            std::exit ( EXIT_FAILURE );
         }

         for ( int i = 0; i < FktInc_KSIZE; ++i ) {
            const auto ktmp = read_as<decltype(k_array_inc)::value_type> ( in );
            if ( fabs(k_array_inc[i] - ktmp) > 1.0e-10 ) {
               Error << "Error in restoring F(k,t)incoherent calculations : saved k_array_inc[" << i << "] = ";
               Error << ktmp << ", currently used: " << k_array_inc[i] << std::endl;
               std::exit ( EXIT_FAILURE );
            }
         }

         for ( auto& v: atoms_positions ) {
            for ( auto& ha: v ) {
               ha.read ( in );
            }
         }
         for ( auto& v: atoms_posRot ) {
            for ( auto& ha: v ) {
               ha.read ( in );
            }
         }
         for ( auto& v: atoms_posTrans ) {
            for ( auto& ha: v ) {
               ha.read ( in );
            }
         }
         
         for ( auto& cf: FktIncoherent ) {
            cf.read ( in );
         }
         for ( auto& cf: FktIncRot ) {
            cf.read ( in );
         }
         for ( auto& cf: FktIncTrans ) {
            cf.read ( in );
         }
      }
   }
   
   SMan.AddFun ( &SaveFktInc );
   ShowRes.AddFun ( &PrintFktIncRes );
}

static void SaveFktInc () {
   std::ofstream out ( FktIncFileName, std::ios::binary | std::ios::out | std::ios::trunc );

   version::out ( out );

   write_as<int> ( out, NSTTOT );
   write_as<int> ( out, FktInc_TSIZE );
   write_as<int> ( out, FktInc_KSIZE );
   write_as<int> ( out, NATOM_TYPES );

   out.write ( (char*)k_array_inc.data(), sizeof(decltype(k_array_inc)::value_type)*FktInc_KSIZE );

   for ( const auto& v: atoms_positions ) {
      for ( const auto& ha: v ) {
         ha.save ( out );
      }
   }
   for ( const auto& v: atoms_posRot ) {
      for ( const auto& ha: v ) {
         ha.save ( out );
      }
   }
   for ( const auto& v: atoms_posTrans ) {
      for ( const auto& ha: v ) {
         ha.save ( out );
      }
   }
         
   for ( const auto& cf: FktIncoherent ) {
      cf.save ( out );
   }
   for ( const auto& cf: FktIncRot ) {
      cf.save ( out );
   }
   for ( const auto& cf: FktIncTrans ) {
      cf.save ( out );
   }
}

static void PrintFktIncRes () {
   std::ofstream outTot   ( "Finc(k,t).dat" );
   std::ofstream outRot   ( "Finc(k,t)rot.dat" );
   std::ofstream outTrans ( "Finc(k,t)trans.dat" );
   std::ofstream outCross ( "Finc(k,t)cross.dat" );

   mdformat k_format ( 8, 3 );
   mdformat t_format ( 7, 3 );
   mdformat F_format (10, 5 );

   // calculate number of atoms of each type:
   std::vector<int> N_Atoms(NATOM_TYPES, 0);
   
   for ( auto p: SimSystem.all_particles )
      for ( auto a: p->Fkt_view() )
         ++N_Atoms[a.id()];

   outTot << k_format << "k, nm-1" << t_format << "t, ps";
   outRot << k_format << "k, nm-1" << t_format << "t, ps";
   outTrans << k_format << "k, nm-1" << t_format << "t, ps";
   outCross << k_format << "k, nm-1" << t_format << "t, ps";
   for ( int a = 0; a < NATOM_TYPES; ++a ) {
      if ( N_Atoms[a] > 0 ) {
         outTot << F_format << Atom_types[a].name();
         outRot << F_format << Atom_types[a].name();
         outTrans << F_format << Atom_types[a].name();
         outCross << F_format << Atom_types[a].name();
      }
   }

   outTot << "\n";
   outRot << "\n";
   outTrans << "\n";
   outCross << "\n";

   for ( int k = 0; k < FktInc_KSIZE; ++k ) {
      for ( int t = 0; t < FktInc_TSIZE; ++t ) {
         outTot << k_format << (k_array_inc[k]);
         outRot << k_format << (k_array_inc[k]);
         outTrans << k_format << (k_array_inc[k]);
         outCross << k_format << (k_array_inc[k]);
         
         outTot << t_format << t*DELT*StepFktInc;
         outRot << t_format << t*DELT*StepFktInc;
         outTrans << t_format << t*DELT*StepFktInc;
         outCross << t_format << t*DELT*StepFktInc;
         for ( int a = 0; a < NATOM_TYPES; ++a ) {
            if ( N_Atoms[a] > 0 ) {
               outTot << F_format << FktIncoherent[a*FktInc_KSIZE + k][t];
               outRot << F_format << FktIncRot[a*FktInc_KSIZE + k][t];
               outTrans << F_format << FktIncTrans[a*FktInc_KSIZE + k][t];
               outCross << F_format << FktIncoherent[a*FktInc_KSIZE + k][t] - 
                  FktIncRot[a*FktInc_KSIZE + k][t]*FktIncTrans[a*FktInc_KSIZE + k][t];
            }
         }
         outTot << "\n";
         outRot << "\n";
         outTrans << "\n";
         outCross << "\n";
      }
   }
}
