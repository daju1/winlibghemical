#ifndef SUBSYSTEM_H
#define SUBSYSTEM_H

#include "lib/mdformat.h"
using namespace mdnaes;

#include <string>
#include <vector>
#include <iostream>
#include <mutex>

class updateable {
public:
   updateable () { }
   virtual ~updateable () { }
   
   virtual void update ( ) = 0;
   virtual void update ( int thread_no, int nthreads ) {
      throw "called not implemented function updateable::update()";
   }
};

class identified_saveable {
public:
   virtual ~identified_saveable () { }

   virtual void read ( std::istream& ) = 0;
   virtual void save ( std::ostream& ) const = 0;

   const std::string& getkey () const { return (this_key); }
   bool operator == ( const identified_saveable& other ) const { return this_key == other.getkey (); }
protected:
   explicit identified_saveable ( const std::string& key ) : this_key ( key ) { }
   const std::string this_key;
};

// =========================================================================================
template <class T>
class subsystem : public identified_saveable  {
public:
   subsystem ( const std::string& key, const std::vector<T>& Universe );
   subsystem ( const subsystem<T>& );
   //subsystem& operator = ( const subsystem& );
   ~subsystem ();

   virtual void read ( std::istream& ) override;
   virtual void save ( std::ostream& ) const override;

   int maxelements () const { return maxelems; }
   int numelements () const;
   bool has ( int i ) const { return present[i]; }
   const T element ( int i ) const { return universe[i]; }
   const T example_element () const { return universe[0]; } // use only if maxelems > 0

   void add ( int i ) { present[i] = true; }
   void remove ( int i ) { present[i] = false; }
   void removeall ();
private:
   int maxelems;
   const std::vector<T>& universe;
   bool *present;
};

template <class T>
inline subsystem<T>::subsystem ( const std::string& key, const std::vector<T>& Universe )
 : identified_saveable (key), maxelems (Universe.size()),
   universe (Universe), present(new bool[maxelems])
{
   for ( int i = 0; i < maxelems; ++i )
      present[i] = true;
}

template <class T>
inline subsystem<T>::subsystem ( const subsystem<T>& s )
 : identified_saveable (s.this_key), maxelems (s.maxelems),
   universe (s.universe), present(new bool[maxelems])
{
   for ( int i = 0; i < maxelems; ++i )
      present[i] = s.present[i];
}

/*template <class T>
subsystem<T>& subsystem<T>::operator = ( const subsystem& s ) {
   actual_timer = s.actual_timer;
   this_key = s.this_key;
   maxelems = s.maxelems;
   universe = s.universe;
   func = s.func;

   delete[] present;
   present = new bool[maxelems];

   for ( int i = 0; i < maxelems; ++i )
      present[i] = s.present[i];
}*/

template <class T>
inline subsystem<T>::~subsystem () {
   delete[] present;
}

template <class T>
inline void subsystem<T>::save ( std::ostream& out ) const {
   out.write ( (char*)&maxelems, sizeof (maxelems) );
   out.write ( (char*)present, sizeof (*present) * maxelems );
}

template <class T>
inline void subsystem<T>::read ( std::istream& in ) {
   int saved_size = -1;
   in.read ( (char*)&saved_size, sizeof (maxelems) );
   if ( saved_size != maxelems )
      throw saved_size;
   in.read ( (char*)present, sizeof (*present) * maxelems );
}

template <class T>
inline int subsystem<T>::numelements () const {
   int n = 0;

   for ( int i = 0; i < maxelements (); ++i )
      if ( has(i) ) ++n;
   return n;
}

template <class T>
inline void subsystem<T>::removeall () {
   for ( int i = 0; i < maxelems; ++i )
      present[i] = false;
}

// ============================================================================
#include "all_particles.h"

extern std::unique_ptr<subsystem<particle*> > AllParticles;
extern std::unique_ptr<subsystem<molecule*> > AllMolecules;
extern std::unique_ptr<subsystem<ion*> > AllIons;
extern std::unique_ptr<subsystem<ion*> > AllCations;
extern std::unique_ptr<subsystem<ion*> > AllAnions;

extern std::vector<subsystem<molecule*>*> shells;

void ShellsDefinition ();
#endif
