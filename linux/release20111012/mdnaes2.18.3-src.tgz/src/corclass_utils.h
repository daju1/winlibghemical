#ifndef CORCLASS_UTILS_H
#define CORCLASS_UTILS_H

#include "corclass.h"

#include <memory>

// ============================================================================

template <class T>
T *find_identified ( const std::vector<std::unique_ptr<T> >& cont, const std::string& key ) {
   for ( const auto& p: cont ) {
      if ( p->getkey() == key )
         return p.get();
   }
   return nullptr;
}

// ============================================================================
// ============================ base_MVHA_creator =============================
template <class data_type, class part_t>
class base_MVHA_creator {
public:
   using ret_type = base_multiple_value_history_array<data_type>;
   using base_type = base_history_array;
   base_MVHA_creator () {}
   virtual ~base_MVHA_creator () {}

   virtual ret_type *create ( const subsystem<part_t>& Shell ) = 0;
};
// ============================================================================
// =================== multiple_value_history_array_creator ===================
template <class data_type, class part_t, typename data_source = data_type (*)(part_t)>
class multiple_value_history_array_creator : public base_MVHA_creator<data_type,part_t> {
public:
   using typename base_MVHA_creator<data_type,part_t>::ret_type;
   using typename base_MVHA_creator<data_type,part_t>::base_type;
   
   multiple_value_history_array_creator ( const std::string& bkey,
                                          HA_Allocator<data_type>& Alloc,
                                          data_source CalcFun,
                                          std::vector<std::unique_ptr<base_type> >& Holder )
   : base_name(bkey), data_holder(Holder), alloc(Alloc), calc_fun(CalcFun) {}
   
   ~multiple_value_history_array_creator () {}

   virtual ret_type *create ( const subsystem<part_t>& Shell ) override;
   
private:
   const std::string base_name;
   std::vector<std::unique_ptr<base_type> >& data_holder;
   HA_Allocator<data_type>& alloc;
   data_source calc_fun;
};

template <class data_type, class part_t, typename data_source>
inline
auto
multiple_value_history_array_creator<data_type,part_t,data_source>::create ( const subsystem<part_t>& shell ) -> ret_type*
{
   const std::string name = base_name + shell.getkey ();
   base_type* i = find_identified ( data_holder, name );
   if ( i )
      return dynamic_cast<ret_type*>(i);
   else {
      auto t = new multiple_value_history_array<data_type,part_t,data_source> ( name, alloc, shell, calc_fun );
      data_holder.emplace_back (t);
      return t;
   }
}

// ============================================================================
// ============================ base_SVHA_creator =============================
template <class data_type>
class base_SVHA_creator {
public:
   using ret_type = base_single_value_history_array<data_type>;
   using base_type = base_history_array;
   base_SVHA_creator () {}
   virtual ~base_SVHA_creator () {}

   virtual ret_type *create ( ) = 0;
};
// ============================================================================
// ==================== single_value_history_array_creator ====================
template <class data_type, class data_source = data_type (*)()>
class single_value_history_array_creator : public base_SVHA_creator<data_type> {
public:
   using typename base_SVHA_creator<data_type>::ret_type;
   using typename base_SVHA_creator<data_type>::base_type;
   single_value_history_array_creator ( const std::string& bkey,
                                        HA_Allocator<data_type>& Alloc,
                                        data_source CalcFun,
                                        std::vector<std::unique_ptr<base_type> >& Holder )
   : base_name(bkey), alloc(Alloc), data_holder(Holder), calc_fun(CalcFun) {}
   
   ~single_value_history_array_creator () {}

   ret_type *create ( ) override;
   
private:
   const std::string base_name;
   HA_Allocator<data_type>& alloc;
   std::vector<std::unique_ptr<base_type> >& data_holder;
   data_source calc_fun;
};

template <class data_type, class data_source>
inline
auto
single_value_history_array_creator<data_type,data_source>::create ( ) -> ret_type*
{
   const std::string name = base_name;
   base_type* i = find_identified ( data_holder, name );
   if ( i )
      return dynamic_cast<ret_type*>(i);
   else {
      ret_type* t = new single_value_history_array<data_type,data_source> ( name, alloc.HA_size(), calc_fun );
      data_holder.emplace_back (t);
      return t;
   }
}


// ============================================================================
// ============================================================================
// ======================== single_molecule_CCF_creator =======================
template <class restype, class arg1type, class arg2type, class part_t, class op = tcf::multiplies>
class single_molecule_CCF_creator {
public:
   using ret_type = base_CCF<restype,arg1type,arg2type,op>;
   using base_type = TDF;
   
   single_molecule_CCF_creator ( const std::string& bkey,
                                 base_MVHA_creator<arg1type,part_t>& a1,
                                 base_MVHA_creator<arg2type,part_t>& a2,
                                 const mdformat& fmt )
   : base_name(bkey), arg1(a1), arg2(a2), format(fmt) {}
   
   ~single_molecule_CCF_creator () {}

   [[nodiscard]] std::unique_ptr<ret_type> create ( const subsystem<part_t>& Shell, int nthreads = 1 );
private:
   const std::string base_name;
   base_MVHA_creator<arg1type,part_t>& arg1;
   base_MVHA_creator<arg2type,part_t>& arg2;
   const mdformat format;
};

template <class restype, class arg1type, class arg2type, class part_t, class op>
inline
auto 
single_molecule_CCF_creator<restype,arg1type,arg2type,part_t,op>::create ( const subsystem<part_t>& shell, int nthreads ) -> std::unique_ptr<ret_type>
{
   const std::string name = base_name + shell.getkey ();
   // objects, pointed by a1 and a2 are owned by arg1 and arg2 (they store them in one global std::vector)
   auto a1 = arg1.create ( shell );
   auto a2 = arg2.create ( shell );
   return std::make_unique<single_molecule_CCF<restype,arg1type,arg2type,op> > ( name.c_str(), a1->HA_size(), format, *a1, *a2, nthreads );
}

// ============================================================================
// ======================== single_molecule_ACF_creator =======================
template <class restype, class argtype, class part_t, class op = tcf::multiplies>
class single_molecule_ACF_creator {
public:
   using ret_type = base_ACF<restype,argtype,op>;
   using base_type = TDF;
   single_molecule_ACF_creator ( const std::string& bkey,
                                 base_MVHA_creator<argtype,part_t>& a,
                                 const mdformat& fmt )
   : base_name(bkey), arg(a), format(fmt) {}
   
   ~single_molecule_ACF_creator () {}

   [[nodiscard]] std::unique_ptr<ret_type> create ( const subsystem<part_t>& shell, int nthreads = 1 );
   
private:
   const std::string base_name;
   base_MVHA_creator<argtype,part_t>& arg;
   const mdformat format;
};

template <class restype, class argtype, class part_t, class op>
inline
auto
single_molecule_ACF_creator<restype,argtype,part_t,op>::create ( const subsystem<part_t>& shell, int nthreads ) -> std::unique_ptr<ret_type>
{
   const std::string name = base_name + shell.getkey ();
   auto a = arg.create ( shell );
   return std::make_unique<single_molecule_ACF<restype,argtype,op> > ( name, a->HA_size(), format, *a, nthreads );
}

// ============================================================================
// ========================= single_value_ACF_creator =========================
template <class restype, class argtype, class op = tcf::multiplies>
class single_value_ACF_creator {
public:
   using ret_type = base_ACF<restype,argtype,op>;
   using base_type = TDF;
   single_value_ACF_creator ( const std::string& bkey,
                              base_SVHA_creator<argtype>& a,
                              const mdformat& fmt )
   : base_name(bkey), arg(a), format(fmt) {}
   
   ~single_value_ACF_creator () {}
   
   [[nodiscard]] std::unique_ptr<ret_type> create ( );
private:
   const std::string base_name;
   base_SVHA_creator<argtype>& arg;
   const mdformat format;
};

template <class restype, class argtype, class op>
auto
single_value_ACF_creator<restype,argtype,op>::create ( ) -> std::unique_ptr<ret_type>
{
   auto *a = arg.create (); // arg owns returned object
   return std::make_unique<single_value_ACF<restype,argtype,op> > ( base_name, a->HA_size(), format, *a );
}

// ============================================================================
#include "subsystem.h"
template <class Fun, class Container>
void create_from_shells ( bool key, Fun& function, Container& holder, int nthreads = 1 ) {
   if ( key ) {
      for ( auto p: shells ) { // all elements in shells has maxelements() > 0
         holder.emplace_back ( function.create (*p, nthreads) );
      }
   }
}

template <class Fun, class Container, class Cond>
void create_from_shells_if ( bool key, Fun& function, Container& holder, Cond Condition, int nthreads = 1 ) {
   if ( key ) {
      for ( auto p: shells ) { // all elements in shells has maxelements() > 0
         if ( Condition(*p) )
            holder.emplace_back ( function.create (*p, nthreads) );
      }
   }
}

template <class Fun, class part_t, class Container>
void create_from_static_shell ( bool key, Fun& function, const subsystem<part_t*>& shell, Container& holder, int nthreads = 1 ) {
   if ( key && shell.maxelements() > 0 ) {
      holder.emplace_back ( function.create (shell, nthreads) );
   }
}

template <class Fun, class part_t, class Container, class Cond>
void create_from_static_shell_if ( bool key, Fun& function, const subsystem<part_t*>& shell, Container& holder, Cond Condition, int nthreads = 1 ) {
   if ( key && shell.maxelements() > 0 && Condition(shell) ) {
      holder.emplace_back ( function.create (shell, nthreads) );
   }
}

template <class part_t>
inline bool shape_general (const subsystem<part_t*> &shell) {
   return shell.example_element()->shape() == particle_type::general;
}

template <class part_t>
inline bool shape_linear (const subsystem<part_t*> &shell) {
   return shell.example_element()->shape() == particle_type::linear;
}

template <class part_t>
inline bool shape_notpoint (const subsystem<part_t*> &shell) {
   return shell.example_element()->shape() != particle_type::point;
}

#endif
