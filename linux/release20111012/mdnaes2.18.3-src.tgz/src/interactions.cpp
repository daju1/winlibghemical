#include "interactions.h"
#include "units.h"
#include <cmath>
#include <iostream>
#include <cstdlib>

#include "globals.h"
using namespace mdnaes;

null_interaction::null_interaction () {
}

interaction::res_t null_interaction::operator () ( real r, real ri ) const {
   return {0.0,0.0};
}

real null_interaction::DC_energy ( real Rc ) const {
   return 0.0;
}

real null_interaction::DC_virial ( real Rc ) const {
   return 0.0;
}

void null_interaction::print ( std::ostream& out ) const {
   out << "null interaction ";
}

null_interaction* null_interaction::read_params ( mylist_const_iterator& in ) {
   return new null_interaction ();
}

// ============================================================================
LJ_6_12::LJ_6_12 ( real sigma, real epsilon ) {
   C06 = 4.0 * epsilon * pow ( sigma, 6 );
   C12 = 4.0 * epsilon * pow ( sigma, 12 );
}

interaction::res_t LJ_6_12::operator () ( real r, real ri ) const {
   const real r2i = ri*ri;//1.0 / (r*r);
   const real r6i = r2i * r2i * r2i;

   const real C06R6I = C06 * r6i;
   const real C12R12I = C12 * r6i * r6i;

   const real U = C12R12I - C06R6I;
   const real virial = 6 * (U + C12R12I);
   
   return {U,virial};
}

real LJ_6_12::DC_energy ( real Rc ) const {
   // Dispersion Correction for energy (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*U(r)*dr
   const real R3i = 1/(Rc*Rc*Rc);
   return 1.396263402*C12*R3i*R3i*R3i - 4.188790204*C06*R3i;
}

real LJ_6_12::DC_virial ( real Rc ) const {
   // Dispersion Correction for virial (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*Vir(r)*dr
   const real R3i = 1/(Rc*Rc*Rc);
   return 16.75516082*C12*R3i*R3i*R3i - 25.13274123*C06*R3i;
}

void LJ_6_12::print ( std::ostream& out ) const {
   out << "Lennard-Johns 6-12 ";
}

LJ_6_12* LJ_6_12::read_params ( mylist_const_iterator& in ) {
   const real sigma   = in.get_double() * EXTERNAL_LENGTH_UNIT / LENGTH_UNIT;
   ++in;
   const real epsilon = in.get_double() * EXTERNAL_ENERGY_UNIT / ENERGY_UNIT;
   ++in;
   return new LJ_6_12 ( sigma, epsilon);
}

// ==========================================================================
LJ_6_12_SF::LJ_6_12_SF ( real sigma, real epsilon ) {
   if ( epsilon == 0.0 ) {
      C06 = C12 = 0.0;
      CCut = DCut = 0.0;
   }
   else {
      C06 = 4.0 * epsilon * pow ( sigma, 6 );
      C12 = 4.0 * epsilon * pow ( sigma, 12 );
      const real RCUTI = 1/RCut.LJ_init;
      const real RCUT2I = RCUTI*RCUTI;
      const real RCUT6I = RCUT2I*RCUT2I*RCUT2I;
      const real RCUT12I = RCUT6I*RCUT6I;
      CCut = 12.0*C12*RCUT12I*RCUTI - 6.0*C06*RCUT6I*RCUTI;
      DCut = -( 13.0*C12*RCUT12I - 7.0*C06*RCUT6I );
   }
}

interaction::res_t LJ_6_12_SF::operator () ( real r, real ri ) const {
   const real r2i = ri*ri; //1.0 / (r*r);
   const real r6i = r2i * r2i * r2i;
   const real CCutr = CCut*r;
   const real C06R6I = C06 * r6i;
   const real C12R12I = C12 * r6i * r6i;
   const real virial = 12*C12R12I - 6*C06R6I - CCutr;
   const real U = C12R12I - C06R6I + CCutr + DCut;
   return {U,virial};
}

real LJ_6_12_SF::DC_energy ( real Rc ) const {
   return 0.0;
}

real LJ_6_12_SF::DC_virial ( real Rc ) const {
   return 0.0;
}

void LJ_6_12_SF::print ( std::ostream& out ) const {
   out << "Lennard-Johns 6-12 Shifted force ";
}

LJ_6_12_SF* LJ_6_12_SF::read_params ( mylist_const_iterator& in ) {
   const real sigma   = in.get_double() * EXTERNAL_LENGTH_UNIT / LENGTH_UNIT;
   ++in;
   const real epsilon = in.get_double() * EXTERNAL_ENERGY_UNIT / ENERGY_UNIT;
   ++in;
   return new LJ_6_12_SF ( sigma, epsilon);
}

// ==========================================================================

LJ_6_9::LJ_6_9 ( real sigma, real epsilon ) {
   C06 = 27.0 / 4.0 * epsilon * pow ( sigma, 6 );
   C09 = 27.0 / 4.0 * epsilon * pow ( sigma, 9 );
}

interaction::res_t LJ_6_9::operator () ( real r, real ri ) const {
   const real r3i = 1.0 / (r*r*r);
   const real r6i = r3i * r3i;

   const real C06R6I = C06 * r6i;
   const real C09R9I = C09 * r6i * r3i;

   const real U = C09R9I - C06R6I;
   const real virial = 9*C09R9I - 6*C06R6I;
   return {U,virial};
}

real LJ_6_9::DC_energy ( real Rc ) const {
   // Dispersion Correction for energy (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*U(r)*dr
   const real R3i = 1/(Rc*Rc*Rc);
   return 2.094395103*C09*R3i*R3i - 4.188790204*C06*R3i;
}

real LJ_6_9::DC_virial ( real Rc ) const {
   // Dispersion Correction for virial (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*Vir(r)*dr
   const real R3i = 1/(Rc*Rc*Rc);
   return 18.84955592*C09*R3i*R3i - 25.13274123*C06*R3i;
}

void LJ_6_9::print ( std::ostream& out ) const {
   out << "Lennard-Johns 6-9 ";
}

LJ_6_9* LJ_6_9::read_params ( mylist_const_iterator& in ) {
   const real sigma   = in.get_double() * EXTERNAL_LENGTH_UNIT / LENGTH_UNIT;
   ++in;
   const real epsilon = in.get_double() * EXTERNAL_ENERGY_UNIT / ENERGY_UNIT;
   ++in;
   return new LJ_6_9 ( sigma, epsilon);
}
// ==========================================================================
LJ_4_8::LJ_4_8 ( real sigma, real epsilon ) {
   if ( epsilon == 0.0 ) {
      C04 = C08 = 0.0;
      CCut = DCut = 0.0;
   }
   else {
      C04 = 4.0 * epsilon * pow ( sigma, 4 );
      C08 = 4.0 * epsilon * pow ( sigma, 8 );
      const real RCUTI = 1/RCut.LJ_init;
      const real RCUT2I = RCUTI*RCUTI;
      const real RCUT4I = RCUT2I*RCUT2I;
      const real RCUT8I = RCUT4I*RCUT4I;
      CCut = 8.0*C08*RCUT8I*RCUTI - 4.0*C04*RCUT4I*RCUTI;
      DCut = -( 9.0*C08*RCUT8I - 5.0*C04*RCUT4I );
   }
}

interaction::res_t LJ_4_8::operator () ( real r, real ri ) const {
   const real r2i = 1.0 / (r*r);
   const real r4i = r2i * r2i;
   const real CCutr = CCut*r;
   const real C04R4I = C04 * r4i;
   const real C08R8I = C08 * r4i * r4i;
   const real virial = 8*C08R8I - 4*C04R4I - CCutr;
   const real U = C08R8I - C04R4I + CCutr + DCut;
   return {U,virial};
}

real LJ_4_8::DC_energy ( real Rc ) const {
   return 0.0;
}

real LJ_4_8::DC_virial ( real Rc ) const {
   return 0.0;
}

void LJ_4_8::print ( std::ostream& out ) const {
   out << "Lennard Johns 4-8 ";
}

LJ_4_8* LJ_4_8::read_params ( mylist_const_iterator& in ) {
   const real sigma   = in.get_double() * EXTERNAL_LENGTH_UNIT / LENGTH_UNIT;
   ++in;
   const real epsilon = in.get_double() * EXTERNAL_ENERGY_UNIT / ENERGY_UNIT;
   ++in;
   return new LJ_4_8 ( sigma, epsilon);
}


// ==========================================================================
Exp_DivR::Exp_DivR ( real aa, real rr ) : A(aa), r0(rr) {
}

interaction::res_t Exp_DivR::operator () ( real r, real ri ) const {
   const real rr0 = r/r0;
   const real U = A*std::exp(-rr0)/r;
   const real virial = U*(1.0+rr0);
   return {U,virial};
}

real Exp_DivR::DC_energy ( real Rc ) const {
   // Dispersion Correction for energy (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*U(r)*dr
   return 12.56637062*A*r0*std::exp(-Rc/r0)*(Rc+r0);
}

real Exp_DivR::DC_virial ( real Rc ) const {
   // Dispersion Correction for virial (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*Vir(r)*dr
   return 12.56637062*A*std::exp(-Rc/r0)*(3*r0*r0 + 3*r0*Rc + Rc*Rc);
}

void Exp_DivR::print ( std::ostream& out ) const {
   out << "A*exp(-r/r0)/r ";
}

Exp_DivR* Exp_DivR::read_params ( mylist_const_iterator& in ) {
   const real aa = in.get_double() * EXTERNAL_ENERGY_UNIT*EXTERNAL_LENGTH_UNIT / (ENERGY_UNIT*LENGTH_UNIT);
   ++in;
   const real r0 = in.get_double() * EXTERNAL_LENGTH_UNIT / LENGTH_UNIT;
   ++in;
   return new Exp_DivR ( aa, r0 );
}


// ==========================================================================
Exp_R4::Exp_R4 ( real aa, real rr, real bb ) : A(aa), r0(rr), B(bb) {
}

interaction::res_t Exp_R4::operator () ( real r, real ri ) const {
   const real rr0 = r/r0;
   const real r2i = ri * ri;
   const real r4i = r2i * r2i;
   const real T = A*std::exp(-rr0)*ri;
   const real U = T - B*r4i;
   const real virial = T*(1.0+rr0) - 4*B*r4i;
   return {U,virial};
}

real Exp_R4::DC_energy ( real Rc ) const {
   // Dispersion Correction for energy (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*U(r)*dr
   return 12.56637062*A*r0*std::exp(-Rc/r0)*(Rc+r0) - 12.56637062*B/Rc;
}

real Exp_R4::DC_virial ( real Rc ) const {
   // Dispersion Correction for virial (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*Vir(r)*dr
   return 12.56637062*A*std::exp(-Rc/r0)*(3*r0*r0 + 3*r0*Rc + Rc*Rc) - 50.26548246*B/Rc;
}

void Exp_R4::print ( std::ostream& out ) const {
   out << "A*exp(-r/r0)/r - B/r^4 ";
}

Exp_R4* Exp_R4::read_params ( mylist_const_iterator& in ) {
   const real aa = in.get_double() * EXTERNAL_ENERGY_UNIT*EXTERNAL_LENGTH_UNIT / (ENERGY_UNIT*LENGTH_UNIT);
   ++in;
   const real r0 = in.get_double() * EXTERNAL_LENGTH_UNIT / LENGTH_UNIT;
   ++in;
   const real bb = in.get_double() * 
      EXTERNAL_ENERGY_UNIT*EXTERNAL_LENGTH_UNIT*EXTERNAL_LENGTH_UNIT*EXTERNAL_LENGTH_UNIT*EXTERNAL_LENGTH_UNIT /
      (ENERGY_UNIT*LENGTH_UNIT*LENGTH_UNIT*LENGTH_UNIT*LENGTH_UNIT);
   ++in;
   return new Exp_R4 ( aa, r0, bb );
}

// ==========================================================================
Exp_R6::Exp_R6 ( real aa, real rr, real bb ) : A(aa), r0(rr), B(bb) {
}

interaction::res_t Exp_R6::operator () ( real r, real ri ) const {
   const real rr0 = r/r0;
   const real r2i = ri * ri;
   const real r6i = r2i * r2i * r2i;
   const real T = A*std::exp(-rr0)*ri;
   const real U = T - B*r6i;
   const real virial = T*(1.0+rr0) - 6*B*r6i;
   return {U,virial};
}

real Exp_R6::DC_energy ( real Rc ) const {
   // Dispersion Correction for energy (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*U(r)*dr
   return 12.56637062*A*r0*std::exp(-Rc/r0)*(Rc+r0) - 4.188790204*B/(Rc*Rc*Rc);
}

real Exp_R6::DC_virial ( real Rc ) const {
   // Dispersion Correction for virial (must be multiplied by concentration):
   // integral from Rc to +inf of 4*Pi*r*r*Vir(r)*dr
   return 12.56637062*A*std::exp(-Rc/r0)*(3*r0*r0 + 3*r0*Rc + Rc*Rc) - 25.13274123*B/(Rc*Rc*Rc);
}

void Exp_R6::print ( std::ostream& out ) const {
   out << "A*exp(-r/r0)/r - B/r^6 ";
}

Exp_R6* Exp_R6::read_params ( mylist_const_iterator& in ) {
   const real aa = in.get_double() * EXTERNAL_ENERGY_UNIT*EXTERNAL_LENGTH_UNIT / (ENERGY_UNIT*LENGTH_UNIT);
   ++in;
   const real r0 = in.get_double() * EXTERNAL_LENGTH_UNIT / LENGTH_UNIT;
   ++in;
   const real bb = in.get_double() * 
      EXTERNAL_ENERGY_UNIT*EXTERNAL_LENGTH_UNIT*EXTERNAL_LENGTH_UNIT*EXTERNAL_LENGTH_UNIT*EXTERNAL_LENGTH_UNIT*EXTERNAL_LENGTH_UNIT*EXTERNAL_LENGTH_UNIT /
      (ENERGY_UNIT*LENGTH_UNIT*LENGTH_UNIT*LENGTH_UNIT*LENGTH_UNIT*LENGTH_UNIT*LENGTH_UNIT);
   ++in;
   return new Exp_R6 ( aa, r0, bb );
}
