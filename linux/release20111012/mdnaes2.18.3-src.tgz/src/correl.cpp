#include "correl.h"
#include "globals.h"
#include "subsystem.h"

// ============================================================================================
int KShortMolCF; //
int KLongMolCF;  //
int KShortIonCF; //
int KLongIonCF;  //
int KTimeLife;   //
int KSVisc;      // Calculate shear viscosity
int KConduct;    // Calculate electrical conductivity
int KConduct_E;  // Calculate electrical conductivity by Einstein-like formula
int KAtomsCvv;   //
int KSTCF;       // Calculate van Hove function G(r,t)
int KFktInc;

int KLegendre;   // Calculate Legendre polynomials

int StepShortCF;
int StepLongCF;
int CorrelSize;   // size of correlation arrays

void DynamFunctions () {
   ShellsDefinition ();
   
   if ( KSTCF && !(NSTTOT % StepSTCF) ) {
      STCF_Calc ();
   }
   
   if ( KShortMolCF && !(NSTTOT % StepShortCF) ) {
      ShortMolCF_Calc ();
   }
   
   if ( KLongMolCF  && !(NSTTOT % StepLongCF) ) {
      LongMolCF_Calc ();
   }

   if ( KShortIonCF && !(NSTTOT % StepShortCF) ) {
      ShortIonCF_Calc ();
   }
   
   if ( KLongIonCF  && !(NSTTOT % StepLongCF) ) {
      LongIonCF_Calc ();
   }

   if ( KSVisc && !(NSTTOT%SViscMulT) ) {
      SVisc_Calc ();
   }

   if ( KConduct && !(NSTTOT % ConductMult) ) {
      Conduct_Calc ();
   }
   
   if ( KConduct_E && !(NSTTOT % ConductMult_E) ) {
      Conduct_Einstein_Calc ();
   }

   if ( KFktInc && !(NSTTOT % StepFktInc) ) {
      FktInc_Calc ();
   }

   if ( KAtomsCvv && !(NSTTOT % StepShortCF) ) {
      AtomsVACF_Calc ();
   }

   if ( KTimeLife && !(NSTTOT % TimeLifeMult) ) {
      TimeLife_Calc ();
      TLifeACF_Calc ();
   }
}
