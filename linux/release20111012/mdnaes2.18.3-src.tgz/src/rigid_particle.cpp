#include <cmath>
#include <cassert>
#include <cstdlib>
#include <iomanip>

#include "globals.h"
#include "units.h"
#include "rigid_particle.h"
#include "mymath.h"
#include "lib/mdformat.h"


template <class Base>
rigid_particle<Base>::rigid_particle ( const type_t *t, vect origin )
: Base(t,origin), type(t)
{
   CMPosCache = basic_particle::getCMPos ();
}

template <class Base>
rigid_particle<Base>::rigid_particle ( const rigid_particle &src, vect cmpos )
: Base(src,cmpos), type(src.type)
{
   CMPosCache = basic_particle::getCMPos ();
}

template <class Base>
void rigid_particle<Base>::swap ( rigid_particle<Base>& other ) {
   this->basic_particle::swap (other);
   std::swap(this->CMPosCache,other.CMPosCache);
}

template <class Base>
vect rigid_particle<Base>::getAngleAcceleration () const {
   switch ( type->shape () ) {
   case particle_type::point:
      return vect(0.0);
      break;
   case particle_type::linear:
      return this->getTorque () / type->Izz ();
      break;
   case particle_type::general:
      return particle::getAngleAcceleration();
      break;
   default:
      raise_md_exception ( "rigid_particle::getAngleAcceleration(): illegal value of rigid_particle shape" );
      return 0;
   }
}

template <class Base>
vect rigid_particle<Base>::getShortAngleAcceleration () const {
   switch ( type->shape () ) {
   case particle_type::point:
      return vect(0.0);
      break;
   case particle_type::linear:
      return this->getShortTorque () / type->Izz ();
      break;
   case particle_type::general:
      return particle::getShortAngleAcceleration();
      break;
   default:
      raise_md_exception ( "rigid_particle::getAngleAcceleration(): illegal value of rigid_particle shape" );
      return 0;
   }
}

template <class Base>
vect rigid_particle<Base>::getLongAngleAcceleration () const {
   switch ( type->shape () ) {
   case particle_type::point:
      return vect(0.0);
      break;
   case particle_type::linear:
      return this->getLongTorque () / type->Izz ();
      break;
   case particle_type::general:
      return particle::getLongAngleAcceleration();
      break;
   default:
      raise_md_exception ( "rigid_particle::getAngleAcceleration(): illegal value of rigid_particle shape" );
      return 0;
   }
}

template <class Base>
vect rigid_particle<Base>::getAngleVelInBoxAxes () const {
   switch ( type->shape () ) {
   case particle_type::point:
      return vect(0.0);
      break;
   case particle_type::linear:
      return this->getAngleMomentumInBoxAxes () / type->Izz();
      break;
   case particle_type::general:
      return particle::getAngleVelInBoxAxes();
      break;
   default:
      raise_md_exception ( "rigid_particle::getAngleVelInBoxAxes(): illegal value of rigid_particle shape" );
      return 0;
   }
}

template <class Base>
int rigid_particle<Base>::is_bonded ( int atom1, int atom2 ) const {
// if atoms i and j are bonded, then we need not to calculate forces between them
   return 1; // in rigid particle all atoms are bonded
}

template <class Base>
vect rigid_particle<Base>::getCMPos () const {
/* Version  of  getCMPos ()   function
   that  returns  cached  value of
   particle's center of mass position */
   return CMPosCache;
}

template <class Base>
void rigid_particle<Base>::read_v2_0 ( std::istream& in ) {
   Base::read_v2_0 ( in );
   CMPosCache = basic_particle::getCMPos ();
}


static void getRotateMatrix ( double T[3][3], const vect& v );

template <class Base>
void rigid_particle<Base>::move ( double tstep, int substeps, std::size_t thread_no ) {
   switch ( type->shape () ) {
   case particle_type::point:
   {
      basic_particle::reference a = (*this)[0];
      
      a.v() += 0.5*tstep * this->getLongCMAcceleration (); // long_move
      a.r() += tstep * a.v();       // r(t+dt) = r(t) + dt*v(t+0.5dt)
      
      this->unPBC_CMPos += tstep * a.v();
      
      while ( a.r().x >  LBOX ) a.r().x -= LBOX;
      while ( a.r().x < 0.0 ) a.r().x += LBOX;
      
      while ( a.r().y >  LBOX ) a.r().y -= LBOX;
      while ( a.r().y < 0.0 ) a.r().y += LBOX;
      
      while ( a.r().z >  LBOX ) a.r().z -= LBOX;
      while ( a.r().z < 0.0 ) a.r().z += LBOX;
      
      CMPosCache = a.r();
      
      break;
   }
   case particle_type::linear:
   case particle_type::general:
   {
      double T[3][3];
      
      const double short_dt = tstep/static_cast<double>(substeps);
      
      const vect Wstart = this->getAngleVelInBoxAxes ();
      const vect B = this->getLongAngleAcceleration ();
      
      const vect Rold = this->getCMPos ();
      
      vect V = this->getCMVel () + 0.5*tstep * this->getLongCMAcceleration ();
      vect W = Wstart + 0.5*tstep * this->getLongAngleAcceleration ();
      
      if ( K_StartRUN ) {
         // displacements of atoms in molecule will not be larger than
         // tstep*(angular velocity)*(radius of molecule)
         if ( tstep*norm(W) * 0.3 > 0.001 ) {
            const double correction = 0.001/0.3/tstep/norm(W);
            W *= correction;
         }
         
         getRotateMatrix ( T, tstep*W );
         
         // rotate only, move later in this function
         for ( basic_particle::reference a: *this ) {
            a.r() = Rold + T * (a.r() - Rold);
         }
         
         // center of mass will not move farther than 0.001 nm
         if ( norm(tstep*V) > 0.001 ) {
            V = 0.001 * V/norm(V) / tstep;
         }
      }
      else {
         vect w = Wstart;
         for ( int s = 0; s < substeps; ++s ) {
            //const vect B = this->getLongAngleAcceleration ();
            w += 0.5*short_dt * B;
            
            getRotateMatrix ( T, short_dt*w );
            
            // rotate only, move later in this function
            for ( basic_particle::reference a: *this ) {
               a.r() = Rold + T * (a.r() - Rold);
            }
            
            w += 0.5*short_dt * B;
         }
      }
      
      this->unPBC_CMPos += tstep * V;
      
      vect Rnew = Rold + tstep * V;
      
      while ( Rnew.x >  LBOX ) Rnew.x -= LBOX;
      while ( Rnew.x < 0.0 ) Rnew.x += LBOX;
      
      while ( Rnew.y >  LBOX ) Rnew.y -= LBOX;
      while ( Rnew.y < 0.0 ) Rnew.y += LBOX;
      
      while ( Rnew.z >  LBOX ) Rnew.z -= LBOX;
      while ( Rnew.z < 0.0 ) Rnew.z += LBOX;
      
      // move only and calculate new velocities of atoms
      for ( basic_particle::reference a: *this ) {
         a.r() = Rnew +  (a.r() - Rold);
         a.v() = V + vecmul ( W, a.r() - Rnew );
      }
      
      this->CMPosCache = particle::getCMPos (); // Caching this value for better performance
      
      


      
/*      double T[3][3];
      vect V = this->getCMVel () + 0.5*tstep * this->getLongCMAcceleration ();
      vect W = this->getAngleVelInBoxAxes () + 0.5*tstep * this->getLongAngleAcceleration ();
      
      if ( K_StartRUN ) {
         // displacements of atoms in molecule will not be larger than
         // tstep*(angular velocity)*(radius of molecule)
         if ( tstep*norm(W) * 0.3 > 0.001 ) {
            const double correction = 0.001/0.3/tstep/norm(W);
            W *= correction;
         }
         
         // center of mass will not move farther than 0.001 nm
         if ( norm(tstep*V) > 0.001 ) {
            V = 0.001 * V/norm(V) / tstep;
         }
      }
      
      this->unPBC_CMPos += tstep * V;
      
      const vect Rold = this->getCMPos ();
      vect Rnew = Rold + tstep * V;
      
      while ( Rnew.x >  LBOX ) Rnew.x -= LBOX;
      while ( Rnew.x < 0.0 ) Rnew.x += LBOX;
      
      while ( Rnew.y >  LBOX ) Rnew.y -= LBOX;
      while ( Rnew.y < 0.0 ) Rnew.y += LBOX;
      
      while ( Rnew.z >  LBOX ) Rnew.z -= LBOX;
      while ( Rnew.z < 0.0 ) Rnew.z += LBOX;
      
      getRotateMatrix ( T, tstep*W );
      
      for ( basic_particle::reference a: *this ) {
         a.r() = Rnew + T * (a.r() - Rold);
         a.v() = V + vecmul ( W, a.r() - Rnew );
      }
      this->CMPosCache = particle::getCMPos (); // Caching this value for better performance
*/
      break;
   }
   default:
      raise_md_exception ( "rigid_particle::move(): illegal value of rigid_particle shape" );
   }
}

template <class Base>
void rigid_particle<Base>::correctorStep ( const double tstep ) {
   switch ( type->shape () ) {
   case particle_type::point:
   {
      basic_particle::reference a = (*this)[0];
      
      a.v() += 0.5*tstep * this->getLongCMAcceleration ();
      
      break;
   }
   case particle_type::linear:
   case particle_type::general:
   {
      vect V = this->getCMVel () + 0.5*tstep * this->getLongCMAcceleration ();
      vect W = this->getAngleVelInBoxAxes () + 0.5*tstep * this->getLongAngleAcceleration ();

      const vect& R = CMPosCache;

      for ( basic_particle::reference a: *this ) {
         a.v() = V + vecmul ( W, a.r() - R );
      }
      
      break;
   }
   default:
      raise_md_exception ( "rigid_particle::move(): illegal value of rigid_particle shape" );
   }
}

template <class Base>
void rigid_particle<Base>::scalPos ( double factor ) {
   const vect dr = (factor-1) * this->getCMPos();

   for ( basic_particle::reference a: *this ) {
      a.r() += dr;
   }

   this->CMPosCache = basic_particle::getCMPos ();
}

template <class Base>
void rigid_particle<Base>::randomize_velocities () {
   for ( basic_particle::reference a: *this ) {
      if ( a.mass() > 0.01 ) {
         const double sigma = std::sqrt(SI_Kbol*TMPR0/(a.mass()*MASS_UNIT)) / (LENGTH_UNIT/TIME_UNIT);
         std::normal_distribution<double> v_distr_1d {0.0,sigma};
         
         a.v().x = v_distr_1d(global_random_engine);
         a.v().y = v_distr_1d(global_random_engine);
         a.v().z = v_distr_1d(global_random_engine);
      }
      else {
         a.v() = 0.0;
      }
   }
   
   const vect R = basic_particle::getCMPos ();
   const vect V = this->getCMVel ();
   const vect W = this->getAngleVelInBoxAxes ();
   
   for ( basic_particle::reference a: *this ) {
      a.v() = V + vecmul ( W, a.r() - R );
   }
}

template <class Base>
double rigid_particle<Base>::getEkinRot () const {
   return this->getEkin () - this->getEkinTrans ();
}

template <class Base>
double rigid_particle<Base>::getEkinVibr () const {
   return 0.0;
}

template <class Base>
void rigid_particle<Base>::getMolAxes ( vect Axes[3] ) const {
   type->molAxesCalc ( *this, Axes );
}

template <class Base>
matrix_3x3 rigid_particle<Base>::getInternalStress () const {
   matrix_3x3 S;
   S.set_to_zero ();

   const vect w = this->getAngleVelInBoxAxes ();
   const vect b = this->getAngleAcceleration ();
   const vect R = this->getCMPos ();
   const vect A = this->getForce () / this->mass();

   for ( basic_particle::const_reference a: *this ) {
      const vect ri = a.r() - R;
      // calculate internal force on atom i as mass*acceleration - intermolecular force.
      const vect fi = a.mass() * (A + vecmul(w,vecmul(w,ri)) + vecmul(b,ri)) - (a.f().far+a.f().near);

      // note: Sum(vecmul(w,vecmul(w,ri))) * ri * atoms[i].mass() == -2*EkinRot;

      S[0][0] += fi.x * ri.x;
      S[0][1] += fi.x * ri.y;
      S[0][2] += fi.x * ri.z;

      S[1][0] += fi.y * ri.x;
      S[1][1] += fi.y * ri.y;
      S[1][2] += fi.y * ri.z;

      S[2][0] += fi.z * ri.x;
      S[2][1] += fi.z * ri.y;
      S[2][2] += fi.z * ri.z;
   }
   
   return S;
}


// ===========================================================================================
template <class Base_part>
rigid_particle_type<Base_part>::rigid_particle_type ( mylist_const_iterator& in )
   : Base (in)
{
   double I[3][3];
   molXAxesCoefs = new double[this->natoms()];
   molYAxesCoefs = new double[this->natoms()];
   this->getInitialInertiaTensor ( I );
   vect V[3];
   double d[3];
   eigenval ( I, d, V );
   ixx = d[0];
   iyy = d[1];
   izz = d[2];
   if ( izz < 1.0e-6 ) {
      particle_shape = particle_type::point;
      return;
   }
   if ( ixx < 1.0e-6 ) {
      particle_shape = particle_type::linear;
      return;
   }
   vector_expansion ( V[0], this->natoms(), this->initial_positions.data(), this->molXAxesCoefs );
   vector_expansion ( V[1], this->natoms(), this->initial_positions.data(), this->molYAxesCoefs );
   particle_shape = particle_type::general;
}

template <class Base_part>
rigid_particle_type<Base_part>::~rigid_particle_type () {
   delete[] molXAxesCoefs;
   delete[] molYAxesCoefs;
}

template <class Base_part>
std::unique_ptr<Base_part> rigid_particle_type<Base_part>::create ( vect origin ) const
{
   return std::make_unique<rigid_particle<Base_part> > ( this, origin );
}

template <class Base_part>
std::unique_ptr<Base_part> rigid_particle_type<Base_part>::create ( const Base_part *src, vect cmpos ) const
{
   return std::make_unique<rigid_particle<Base_part> > ( *dynamic_cast<const rigid_particle<Base_part>*>(src), cmpos );
}


/*template <class Base_part>
p_array<Base_part> rigid_particle_type<Base_part>::new_array () const {
   return p_array<Base_part> ( new p_array_impl<Base_part,rigid_particle<Base_part> >(this) );
}*/

template <class Base_part>
int rigid_particle_type<Base_part>::shape () const {
   return particle_shape;
}

template <class Base_part>
void rigid_particle_type<Base_part>::molAxesCalc ( const basic_particle& atoms, vect axes[3] ) const {
   axes[0] = axes[1] = axes[2] = 0;

   for ( int i = 0; i < atoms.natoms(); ++i ) {
      axes[0] += molXAxesCoefs[i] * atoms[i].r();
      axes[1] += molYAxesCoefs[i] * atoms[i].r();
   }
   axes[2] = vecmul ( axes[0], axes[1] );
}

template <class Base_part>
int rigid_particle_type<Base_part>::nRotDegFree () const {
   switch ( this->shape () ) {
   case particle_type::general:
      return 3;
      break;
   case particle_type::linear:
      return 2;
      break;
   case particle_type::point:
      return 0;
      break;
   }
   return -1;
}

template <class Base_part>
int rigid_particle_type<Base_part>::nVibrDegFree () const {
   return 0;
}

template <class Base_part>
void rigid_particle_type<Base_part>::print ( std::ostream& out ) const {
   this->particle_type::print ( out );
   
   const mdformat format (9,5);

   if ( this->shape() == particle_type::general ) {
      vect eX (0.0), eY (0.0), eZ (0.0);
      vect CM = this->getInitialCMPos ();

      for ( int i = 0; i < this->natoms (); ++i ) {
         eX += this->initial_positions[i] * this->molXAxesCoefs[i];
         eY += this->initial_positions[i] * this->molYAxesCoefs[i];
      }
      eZ = vecmul ( eX, eY );

      out << "\nGeometry in molecular axes:\n";
      out << mdformat(5,0) << "N" << mdformat(5,0) << "name";
      out << format << "X" << format << "Y" << format << "Z\n";
      for ( int i = 0; i < this->natoms (); ++i ) {
         out << mdformat(5,0) << i << mdformat(5,0) << this->get_atom_type(i).name();
         out << format << eX*(this->initial_positions[i]-CM);
         out << format << eY*(this->initial_positions[i]-CM);
         out << format << eZ*(this->initial_positions[i]-CM);
         out << "\n";
      }
   }

   out << "RIGID ROTATION algorithm is used!";
   out << "\nSHAPE: ";
   switch ( this->shape() ) {
   case particle_type::point:
      out << "point";
      break;
   case particle_type::linear:
      out << "linear";
      break;
   case particle_type::general:
      out << "nonlinear";
      break;
   }
   out << "\nIxx = "<< this->Ixx();
   out << "\nIyy = "<< this->Iyy();
   out << "\nIzz = "<< this->Izz();
   out << std::endl;

   if ( this->shape () == particle_type::general ) {
      int i;
      out << "molXAxesCoefs, nm^-1:\n";
      for ( i = 0; i < this->natoms (); ++i )
         out << format << this->molXAxesCoefs[i];
      out << std::endl;

      out << "molYAxesCoefs, nm^-1:\n";
      for ( i = 0; i < this->natoms (); ++i )
         out << format << this->molYAxesCoefs[i];
      out << std::endl;
   }

   this->Base::print ( out );
}

// ===========================================================================================

static void getRotateMatrix ( double T[3][3], const vect& v ) {
// r' = (1-c)*n*(n,r) + c*r + s*[n,r],    n = v / |v|, r - vectors; c = cos (|v|), s = sin (|v|)
// r' = T * r
   double nx, ny, nz, c , s, cc;
   double ccnx, ccny, ccnz, snx, sny, snz;
   double ccnxny, ccnxnz, ccnynz;
   const double p = norm ( v );
   if ( p < 1.0e-8 ) {
       T[0][0] = T[1][1] = T[2][2] = 1;
       T[0][1] = T[0][2] = T[1][0] = T[1][2] = T[2][0] = T[2][1] = 0;
       return;
   }
   c = cos ( p ); s = sin ( p ); cc = 1 - c;
   nx = v.x / p; ny = v.y / p; nz = v.z / p;
   ccnx = cc * nx; ccny = cc * ny; ccnz = cc * nz;
   snx = s * nx; sny = s * ny; snz = s * nz;
   ccnxny = ccnx * ny; ccnxnz = ccnx * nz; ccnynz = ccny * nz;
   T[0][0] = ccnx * nx + c;
   T[0][1] = ccnxny - snz;
   T[0][2] = ccnxnz + sny;
   T[1][0] = ccnxny + snz;
   T[1][1] = ccny * ny + c;
   T[1][2] = ccnynz - snx;
   T[2][0] = ccnxnz - sny;
   T[2][1] = ccnynz + snx;
   T[2][2] = ccnz * nz + c;
}

// Explicit instantiation
template class rigid_particle<molecule>;
template class rigid_particle<ion>;
template class rigid_particle_type<molecule>;
template class rigid_particle_type<ion>;
