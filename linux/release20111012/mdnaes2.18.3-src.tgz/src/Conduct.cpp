#include "Conduct.h"

#include <vector>
#include <memory>

#include "corr_aux.h"
#include "corclass.h"
#include "corclass_utils.h"
#include "correl.h"
#include "globals.h"
#include "iomanager.h"
#include "lib/mdformat.h"
using namespace mdnaes;

// ===================================== Electric conductivity =====================================
static const char *ConductFileName = "conduct.cf";
static const char *ConductResFileName = "conduct.dat";

// exports these identifires:
int ConductTSize = -1;
int ConductMult = -1;
// end globals

static iomanager Conduct_IOManager ( ConductFileName );


static vect get_m_current () {
   vect I(0.0);

   for ( auto p: SimSystem.all_molecules )
      I += p->getCurrent ();
   return I / VOLBOX;
}

static vect get_c_current () {
   vect I(0.0);

   for ( auto p: SimSystem.all_cations )
      I += p->getCurrent ();
   return I / VOLBOX;
}

static vect get_a_current () {
   vect I(0.0);

   for ( auto p: SimSystem.all_anions )
      I += p->getCurrent ();
   return I / VOLBOX;
}


static void SaveConduct ();
static void ResultConduct ();
static void ReleaseConduct ();

static std::vector<std::unique_ptr<base_history_array> > Conduct_history_arrays;
static std::vector<std::unique_ptr<TDF> > Conduct_TDFs;

static void Conduct_init () {
   Message << "starting conductivity calculation" << std::endl;
   
   auto M = new single_value_history_array<vect> ( "M", ConductTSize, get_m_current );
   auto C = new single_value_history_array<vect> ( "C", ConductTSize, get_c_current );
   auto A = new single_value_history_array<vect> ( "A", ConductTSize, get_a_current );
   
   Conduct_history_arrays.emplace_back ( M );
   Conduct_history_arrays.emplace_back ( C );
   Conduct_history_arrays.emplace_back ( A );
   
   const mdformat format (14,5);
   
   Conduct_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "MM", ConductTSize, format, *M, *M ) );
   Conduct_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "MC", ConductTSize, format, *M, *C ) );
   Conduct_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "MA", ConductTSize, format, *M, *A ) );
   Conduct_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "CM", ConductTSize, format, *C, *M ) );
   Conduct_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "CC", ConductTSize, format, *C, *C ) );
   Conduct_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "CA", ConductTSize, format, *C, *A ) );
   Conduct_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "AM", ConductTSize, format, *A, *M ) );
   Conduct_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "AC", ConductTSize, format, *A, *C ) );
   Conduct_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "AA", ConductTSize, format, *A, *A ) );
   
   for ( const auto& p: Conduct_history_arrays ) {
      Conduct_IOManager.add ( p.get() );
   }
   
   for ( const auto& p: Conduct_TDFs ) {
      Conduct_IOManager.add ( p.get() );
   }
   
   if ( KLH ) {
      Conduct_IOManager.read ();
   }
   
   SMan.AddFun ( &SaveConduct );
   ShowRes.AddFun ( &ResultConduct );
}

void Conduct_Calc () {
   static int init = 1;
   if ( init ) {
      Conduct_init ();
      init = 0;
   }
   
   for ( const auto& p: Conduct_history_arrays ) {
      p->update ( );
   }
   for ( const auto& p: Conduct_TDFs ) {
      p->update ( );
   }
}

static void SaveConduct () {
   Conduct_IOManager.save ();
}

static void ResultConduct () {
   Message << "Components of the conductivity" << std::endl;

   for ( const auto& p: Conduct_TDFs ) {
      p->print_header ( Message );
      Message << mdformat(12,4) << 
         (VOLBOX/(3*SI_Kbol*TMPR0)) * CHARGE_UNIT * CHARGE_UNIT / (LENGTH_UNIT * TIME_UNIT) *
         integral ( *static_cast<TTDF<double>*>(p.get()), p->size(), ConductMult*DELT );
      Message << ", Om^(-1)/m" << std::endl;
   }
   
   PrintTDFRes ( Conduct_TDFs, ConductResFileName, ConductMult,
      (VOLBOX/(3*SI_Kbol*TMPR0)) * CHARGE_UNIT * CHARGE_UNIT / (LENGTH_UNIT * TIME_UNIT),
      "dimention of Cii(t) functions is Sm/m/ps" );
}


// ================================== Electric conductivity Alt ==================================
static const char *ConductFileName_E = "conduct_E.cf";
static const char *ConductResFileName_E = "conduct_E.dat";

// exports these identifires:
int ConductTSize_E = -1;
int ConductMult_E  = -1;
// end globals

static iomanager Conduct_IOManager_E ( ConductFileName_E );


static vect get_unPBC_dipole () {
   vect M(0.0);

   for ( auto p: SimSystem.all_ions )
      M += p->getUnPBC_CMPos() * p->charge();
   return M;
}

static void SaveConduct_E ();
static void ResultConduct_E ();

static std::vector<std::unique_ptr<base_history_array> > Conduct_history_arrays_E;
static std::vector<std::unique_ptr<TDF> > Conduct_TDFs_E;

static void Conduct_Einstein_init () {
   Message << "starting conductivity calculation by Einstein method" << std::endl;
   
   auto dipole = new single_value_history_array<vect> ( "dipole", ConductTSize_E, get_unPBC_dipole );
   
   Conduct_history_arrays_E.emplace_back ( dipole );
   
   const mdformat format (14,5);
   
   Conduct_TDFs_E.emplace_back ( std::make_unique<single_value_ACF<double, vect, tcf::R2> > ( "Tr_Dipole", ConductTSize_E, format, *dipole ) );
   
   for ( const auto& p: Conduct_history_arrays_E ) {
      Conduct_IOManager_E.add ( p.get() );
   }
   
   for ( const auto& p: Conduct_TDFs_E ) {
      Conduct_IOManager_E.add ( p.get() );
   }
   
   if ( KLH ) {
      Conduct_IOManager_E.read ();
   }
   
   SMan.AddFun ( &SaveConduct_E );
   ShowRes.AddFun ( &ResultConduct_E );
}

void Conduct_Einstein_Calc () {
   static int init = 1;
   if ( init ) {
      Conduct_Einstein_init ();
      init = 0;
   }

   for ( const auto& p: Conduct_history_arrays_E ) {
      p->update ( );
   }
   
   for ( const auto& p: Conduct_TDFs_E ) {
      p->update ( );
   }
}

static void SaveConduct_E () {
   Conduct_IOManager_E.save ();
}

static void ResultConduct_E () {
   auto f = dynamic_cast<TTDF<double>*>( Conduct_TDFs_E[0].get() );
   const int size = f->size();
   double a;
   const double tstep = ConductMult_E*DELT;
   lmnk1x ( *f, size/4, size-size/4, tstep*size/4, tstep, &a, 0 );

   Message << "Total conductivity, calculated from Einstein-like relations:\n";
   Message << mdformat(12,5) << a/6 / VOLBOX / SI_Kbol / TMPR0 * CHARGE_UNIT * CHARGE_UNIT / LENGTH_UNIT / TIME_UNIT;
   Message << " Sm/m" << std::endl;

   PrintTDFRes ( Conduct_TDFs_E, ConductResFileName_E, ConductMult_E,
      1e12 / VOLBOX / SI_Kbol / TMPR0 * CHARGE_UNIT * CHARGE_UNIT / LENGTH_UNIT, // C^2/J/m
      "1e12 * (dM)^2/V/k/T, Sm*s/m" );
}
