#include "molecular_geometry.h"
#include <cmath>

namespace mdnaes {

dihedral::dihedral ( const vect& r1, const vect& r2, const vect& r3, const vect& r4 ) {
   const vect r12 = r2 - r1;
   const vect r23 = r3 - r2;
   const vect r34 = r4 - r3;

   vect n123 = vecmul(r12,r23);
   vect n234 = vecmul(r23,r34);

   const double norm123 = 1/norm(n123);
   const double norm234 = 1/norm(n234);

   n123 *= norm123;
   n234 *= norm234;
   const vect n23 = r23 / norm(r23);

   this->CosB = n123 * n234;
   this->SinB = vecmul(n123,n234)*n23;
   this->Beta = std::atan2 (this->SinB, this->CosB);

   const double c1  =  norm123 * (n23*r23);
   const double c2p = -norm123 * (n23*(r12+r23));
   const double c2s = -norm234 * (n23*r34);
   const double c3p =  norm123 * (n23*r12);
   const double c3s =  norm234 * (n23*(r23+r34));
   const double c4  = -norm234 * (n23*r23);

   // Beta gradients:
   this->g1 =  -c1  * n123;
   this->g2 = -(c2p * n123 + c2s * n234);
   this->g3 = -(c3p * n123 + c3s * n234);
   this->g4 =  -c4  * n234;
}

angle::angle ( const vect& r1, const vect& r2, const vect& r3 ) {
   const vect r12 = r2 - r1;
   const vect r23 = r3 - r2;

   const double r12i = 1/norm(r12);
   const double r23i = 1/norm(r23);

   const vect n12 = r12 * r12i;
   const vect n23 = r23 * r23i;

   this->CosA = -n12*n23;
   this->Alpha = std::acos(this->CosA);
   //const double SinA = std::sqrt(1 - this->CosA*this->CosA);
   //const double SinA_inv = 1 / SinA;

   // Alpha gradients:
   //this->g1 = -(n23+n12*this->CosA)*r12i*SinA_inv;
   //this->g3 =  (n12+n23*this->CosA)*r23i*SinA_inv;
   vect n = (n23+n12*this->CosA);
   double nnorm = norm(n);
   if ( nnorm < 0.0001 ) {
      n = 0.0;
   }
   else {
      n /= nnorm;
   }
   
   this->g1 = -n*r12i;

   n = (n12+n23*this->CosA);
   nnorm = norm(n);
   if ( nnorm < 0.0001 ) {
      n = 0.0;
   }
   else {
      n /= nnorm;
   }

   this->g3 =  n*r23i;

   this->g2 = -this->g1 - this->g3;
}

distance::distance ( const vect& r1, const vect& r2 ) {
   const vect r12 = r2 - r1;

   this->sqr_Dist = r12*r12;
   this->Dist = std::sqrt(this->sqr_Dist);

   // Alpha gradients:
   this->g1 = -r12/this->Dist;
   this->g2 = -this->g1;
}

} // end of namespace mdnaes
