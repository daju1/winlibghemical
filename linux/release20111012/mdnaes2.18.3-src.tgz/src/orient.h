#if !defined M_ORIENT
#define M_ORIENT


extern int KDSOR, KMolOr;    // Calculate molecular orientation as f(r)
extern double StepRInShl;

void OrVect_Calc ();
void DistrCos_Calc ();
void AnalyseMolOrient ( );

void CalculWiy98OrVect ();
void CalculWiy98Distr_cos ();

#endif
