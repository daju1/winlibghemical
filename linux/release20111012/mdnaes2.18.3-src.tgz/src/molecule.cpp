#include <cstdlib>
#include <limits>
#include "globals.h"
#include "molecule.h"
#include "lib/mdformat.h"
#include "md_exception.h"

vect molecule::getDipolMomentum () const {
   vect m = 0;

   for ( const_reference a: *this )
      m += a.q() * a.r();
   
   return m;
}

vect molecule::getMainVect () const {
   return type->calcMainVect ( *this );
}

vect molecule::getCationCoordinationCenter () const {
   return type->calcCationCoordinationCenter ( *this, 0 );
}

vect molecule::getAnionCoordinationCenter () const {
   return type->calcAnionCoordinationCenter ( *this, 0 );
}

double molecule::getMinCationCoordinationCenterDistance ( const std::vector<vect>& extR ) const {
   double r = std::numeric_limits<double>::max();

   for ( int i = 0; i < type->numberOfCationCoordinationCenters(); ++i ) {
      const vect cc_coor = type->calcCationCoordinationCenter ( *this, i );
      
      for ( int j = 0; j < extR.size(); ++j ) {
         vect dr = cc_coor - extR[j];
         PBC ( dr );
         const double rr = norm ( dr );
         if ( rr < r ) {
            r = rr;
         }
      }
   }
   
   return r;
}

double molecule::getMinAnionCoordinationCenterDistance ( const std::vector<vect>& extR ) const {
   double r = std::numeric_limits<double>::max();

   for ( int i = 0; i < type->numberOfAnionCoordinationCenters(); ++i ) {
      const vect cc_coor = type->calcAnionCoordinationCenter ( *this, i );
      
      for ( int j = 0; j < extR.size(); ++j ) {
         vect dr = cc_coor - extR[j];
         PBC ( dr );
         const double rr = norm ( dr );
         if ( rr < r ) {
            r = rr;
         }
      }
   }
   return r;
}

// =====================================================================================
molecule_type::molecule_type ( mylist_const_iterator& in ) : particle_type(in) {
   mainVectCoefs = new double[natoms ()];

   in.reset();
   if ( in.find( "mainVect" ) ) {
      mylist_const_iterator coor ( in.get_item() );

      for ( int i = 0; i < natoms(); ++i ) {
         mainVectCoefs[i] = coor.get_double();
         ++coor;
      }
   }
   else {
      Error << "Cannot find \"mainVect\" pararmeter for molecule " << this->name() << " in params file\n";
      raise_md_exception ( "Error constructing molecule_type" );
   }

   for ( in.reset(); in.find( "cationCoordinationCenter" ); ++in ) {
      std::vector<double> coefs;
      mylist_const_iterator coor ( in.get_item() );

      for ( int i = 0; i < natoms(); ++i ) {
         coefs.push_back ( coor.get_double() );
         ++coor;
      }
      cationCoordinationCenterCoefs.push_back ( coefs );
   }
   if ( cationCoordinationCenterCoefs.size() < 1 ) {
      Error << "Cannot find \"cationCoordinationCenter\" pararmeter for molecule ";
      Error << this->name() << " in params file\n";
      raise_md_exception ( "Error constructing molecule_type" );
   }

   for ( in.reset(); in.find( "anionCoordinationCenter" ); ++in ) {
      std::vector<double> coefs;
      mylist_const_iterator coor ( in.get_item() );

      for ( int i = 0; i < natoms(); ++i ) {
         coefs.push_back ( coor.get_double() );
         ++coor;
      }
      anionCoordinationCenterCoefs.push_back ( coefs );
   }
   if ( anionCoordinationCenterCoefs.size() < 1 ) {
      Error << "Cannot find \"anionCoordinationCenter\" pararmeter for molecule ";
      Error << this->name() << " in params file\n";
      raise_md_exception ( "Error constructing molecule_type" );
   }
}

molecule_type::~molecule_type () {
   delete[] mainVectCoefs;
}

vect molecule_type::calcMainVect ( const basic_particle& atoms ) const {
   vect res ( 0.0 );

   for ( int i = 0; i < natoms (); ++i )
      res += mainVectCoefs[i] * atoms[i].r();
   
   return res;
}

int molecule_type::numberOfCationCoordinationCenters () const {
   return cationCoordinationCenterCoefs.size();
}

vect molecule_type::calcCationCoordinationCenter ( const basic_particle& atoms, int c ) const {
   vect res ( 0.0 );

   for ( int i = 0; i < natoms (); ++i )
      res += cationCoordinationCenterCoefs[c][i] * atoms[i].r();
   
   return res;
}

int molecule_type::numberOfAnionCoordinationCenters () const {
   return anionCoordinationCenterCoefs.size();
}

vect molecule_type::calcAnionCoordinationCenter ( const basic_particle& atoms, int c ) const {
   vect res ( 0.0 );

   for ( int i = 0; i < natoms (); ++i )
      res += anionCoordinationCenterCoefs[c][i] * atoms[i].r();
   
   return res;
}

void molecule_type::print ( std::ostream& out ) const {
   // do nothing
}
