#include <fstream>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <vector>

#include "mylist.h"
#include "init.h"
#include "atomtbl.h"
#include "rigid_particle.h"
#include "shaked_particle.h"
#include "units.h"
#include "all_particles.h"
#include "globals.h"
#include "md_exception.h"
using namespace mdnaes;

// =========================================================================================
namespace {
constexpr char BEGIN_LIST_SYMBOL = '#';
constexpr char ENDOF_LIST_SYMBOL = ';';

static int line = 1;
static int col = 0;

char readsymbol ( std::istream& in ) {
   //char c;
   //in.read ( &c, 1 );
   const char c = in.get();
   if ( in.eof ( ) )
      return 0;
   col++;
   if ( c == '\n' ) {
      line++;
      col = 0;
   }
   return c;
}

void read_cpp_comment ( std::istream& in ) {
   char c;
   do {
      c = readsymbol ( in );
   } while ( c != '\n' && !in.eof ( ) );
}

void read_c_comment ( std::istream& in ) {
   char c;
   for ( ; ; ) {
      c = readsymbol ( in );
      if ( in.eof () )
         return;
      if ( c == '*' ) {
         c = readsymbol ( in );
         if ( in.eof () )
            return;
         if ( c == '/' )
            return;
         else
            in.putback ( c );
      }
   }
}

void rparams_error ( const char *s ) {
   Error << "Error was found in params file in line " << line << " column " << col;
   Error << ": " << s << std::endl;
}

int readstring ( std::istream& in, char dst[] ) {
   int i = 0;
   char c = 0;
   for ( ; ; ) {
      c = readsymbol ( in );
      if ( in.eof () )
         break;
      if ( isspace ( c ) )
         break;
      if ( c == ENDOF_LIST_SYMBOL || c == BEGIN_LIST_SYMBOL )
         break;
      dst[i] = c;
      i++;
   }
   dst[i] = '\0';
   return c;
}

int getnextstring ( std::istream& in, char dst[] ) {
   char c = '\0';

   dst[0] = '\0';

   for ( ; ; ) {
      c = readsymbol ( in );
      if ( in.eof () )
         return '\0';
      if ( isspace ( c ) )
         continue;
      if ( c == ENDOF_LIST_SYMBOL || c == BEGIN_LIST_SYMBOL )
         return c;
      if ( c == '/' ) {
         c = readsymbol ( in );
         if ( in.eof ( ) )
            return c;
         switch ( c ) {
            case '/':
               read_cpp_comment ( in );
               break;
            case '*':
               read_c_comment ( in );
               break;
            default: // it is not comment
               *dst = '/';
               *++dst = c;
               *++dst = '\0';
               goto readrest;
         }
      }
      else {
         *dst = c;
         *++dst = '\0';
         goto readrest;
      }
   }
readrest:
   return readstring ( in, dst );
}

mylist readlist ( std::istream& in ) {
   char name[256] = "";
   
   const char rnstate = readstring ( in, name );
   if ( name[0] == '\0' ) {
      rparams_error ( "name of list symbol is absent" );
      std::exit ( EXIT_FAILURE );
   }
   if ( rnstate == ENDOF_LIST_SYMBOL ) {
      in.putback ( rnstate );
      col--;
      if ( col < 0 ) {
         line--;
         col = 0;
      }
   }

   mylist newlist { name };

   for ( ; ; ) {
      memset ( name, 0, sizeof ( name ) );
      const int rnstate = getnextstring ( in, name );
      if ( name[0] != '\0' ) {
         newlist.add ( mylist ( name ) );
         if ( rnstate == ENDOF_LIST_SYMBOL )
            return newlist;
      }
      else // legalstring was not found
         switch ( rnstate ) { // why?
            case ENDOF_LIST_SYMBOL: // end of list was found
               return newlist;
            case BEGIN_LIST_SYMBOL: // sublist was found
               newlist.add ( readlist ( in ) );
               break;
            default: // any illegal symbol
               rparams_error ( "end of list symbol is absent" );
               std::exit ( EXIT_FAILURE );
         }
   }
}

mylist readParamsList ( const char *ParamsFileName ) {
   std::ifstream in ( ParamsFileName );
   if ( !in ) {
      std::cerr << "Cannot open file: " << ParamsFileName << std::endl;
      Error     << "Cannot open file: " << ParamsFileName << std::endl;
      std::exit ( EXIT_FAILURE );
   }

   char c;
   mylist all_lists ( "_all_lists" );

   line = 1; col = 0;
   for ( ; ; ) {
      c = readsymbol ( in );

      if ( in.eof ( ) )
         break;

      if ( isspace ( c ) )
         continue;

      switch ( c ) {
         case BEGIN_LIST_SYMBOL:
            all_lists.add ( readlist ( in ) );
            break;
         case '/':
            c = readsymbol ( in );
            if ( in.eof ( ) )
               break;
            switch ( c ) {
               case '/':
                  read_cpp_comment ( in );
                  break;
               case '*':
                  read_c_comment ( in );
                  break;
               default:
                  rparams_error ( "only spaces and comments can be placed out of lists" );
                  std::exit ( EXIT_FAILURE );
            }
            break;
         default:
            rparams_error ( "only spaces and comments can be placed out of lists" );
            std::exit ( EXIT_FAILURE );
            break;
      }
   }
   return all_lists;
}
} // end of anonymous namespace

void ReadParams () {
   static int use_LJ_shift_force = 0;
   static int LJ_default_combining_rule = 0;

   atom_types_table atom_types {Atom_types};
   interactions_table interactions { atom_types };

   mylist all_params { readParamsList ( ParamsFileName ) };

   for ( int i = 0; i < all_params.num_elems (); ++i ) {
      mylist_const_iterator param = all_params.get_elem(i);
      const std::string& name = all_params.get_elem(i).getval();
      
      if ( name == "use_shift_force" ) { // use shift force correction for LJ
         if ( param.get_int() )
            use_LJ_shift_force = 1;
         else
            use_LJ_shift_force = 0;
         continue;
      }
      if ( name == "combining_rule" ) { // combining rules for LJ 6-12 interactions
         LJ_default_combining_rule = param.get_int();
         continue;
      }
      
      if ( name == "atom" ) {
         atom_types.read_atom_type ( param, use_LJ_shift_force, LJ_default_combining_rule );
         continue;
      }
      if ( name == "interaction" ) {
         interactions.read_interaction ( param );
         continue;
      }
      if ( name == "rigid_molecule" ) {
         SimSystem.add_molecule_type ( std::make_unique<rigid_molecule_type>(param) );
         continue;
      }
      if ( name == "shaked_molecule" || name == "flexible_molecule" ) {
         SimSystem.add_molecule_type ( std::make_unique<shaked_molecule_type>(param) );
         continue;
      }
      if ( name == "rigid_cation" ) {
         SimSystem.add_cation_type ( std::make_unique<rigid_ion_type>(param) );
         continue;
      }
      if ( name == "shaked_cation" || name == "flexible_cation" ) {
         SimSystem.add_cation_type ( std::make_unique<shaked_ion_type>(param) );
         continue;
      }
      if ( name == "rigid_anion" ) {
         SimSystem.add_anion_type ( std::make_unique<rigid_ion_type>(param) );
         continue;
      }
      if ( name == "shaked_anion" || name == "flexible_anion" ) {
         SimSystem.add_anion_type ( std::make_unique<shaked_ion_type>(param) );
         continue;
      }
      
      if ( name == "Wiy98_AdvancedCationCoordinationCenter" ) {
         if ( Wiy98_AdvancedCationCoordinationCenter_coefs == NULL ) {
            const int NAT = SimSystem.molecule_types[0]->natoms();
            Wiy98_AdvancedCationCoordinationCenter_coefs = new double[NAT];

            for ( int i = 0; i < NAT; ++i ) {
               param >> Wiy98_AdvancedCationCoordinationCenter_coefs[i];
            }
         }
         continue;
      }
      if ( name == "Wiy98_AdvancedAnionCoordinationCenter" ) {
         if ( Wiy98_AdvancedAnionCoordinationCenter_coefs == NULL ) {
            const int NAT = SimSystem.molecule_types[0]->natoms();
            Wiy98_AdvancedAnionCoordinationCenter_coefs = new double[NAT];

            for ( int i = 0; i < NAT; ++i ) {
               param >> Wiy98_AdvancedAnionCoordinationCenter_coefs[i];
            }
         }
         continue;
      }

      Error << "Unsupported parameter: " << name << std::endl;
   }

   const int NTYPE_ATOMS = Atom_types.size();

   all_interactions = new interaction*[NTYPE_ATOMS*NTYPE_ATOMS];
   for ( int i = 0; i < NTYPE_ATOMS; ++i ) {
      for ( int j = 0; j < NTYPE_ATOMS; ++j ) {
         all_interactions[i*NTYPE_ATOMS+j] = interactions.get_interaction ( i, j );
      }
   }
}
