#include "corr_aux.h"

#include <fstream>
#include <string>

#include "globals.h"

void PrintTDFRes ( const std::vector<std::unique_ptr<TDF> >& TDFs,
                   const char *filename,
                   int CorStep,
                   double factor,
                   const std::string comment )
{
   if ( TDFs.size() < 1 )
      return;

   std::ofstream out ( filename );

   const mdformat format(10, 3);

   if ( comment.size() > 0 ) {
      out << comment << "\n";
   }

   out << format << "t_ps";
   
   for ( const auto& pf: TDFs ) {
      out << " ";
      pf->print_header ( out );
   }
   out << "\n";

   out << format << "zero_value";
   for ( const auto& pf: TDFs ) {
      out << " ";
      pf->print_value ( out, 0, factor );
   }
   out << "\n";

   for ( int i = 0; i < TDFs[0]->size (); ++i ) {
      out << format << i*DELT*CorStep;
      for ( const auto& pf: TDFs ) {   
         out << " ";
         pf->print_value_normated ( out, i, factor );
      }
      out << "\n";
   }
}



void PrintTDFRes ( const std::vector<TDF*>& TDFs,
                   const char *filename,
                   int CorStep,
                   double factor,
                   const std::string comment )
{
   if ( TDFs.size() < 1 )
      return;

   std::ofstream out ( filename );

   const mdformat format(10, 3);

   if ( comment.size() > 0 ) {
      out << comment << "\n";
   }

   out << format << "t_ps";
   
   for ( const auto pf: TDFs ) {
      out << " ";
      pf->print_header ( out );
   }
   out << "\n";

   out << format << "zero_value";
   for ( const auto pf: TDFs ) {
      out << " ";
      pf->print_value ( out, 0, factor );
   }
   out << "\n";

   for ( int i = 0; i < TDFs[0]->size (); ++i ) {
      out << format << i*DELT*CorStep;
      for ( const auto pf: TDFs ) {   
         out << " ";
         pf->print_value_normated ( out, i, factor );
      }
      out << "\n";
   }
}
