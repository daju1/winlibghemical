#include "LIonCF.h"

#include <vector>
#include <memory>

#include "corr_aux.h"
#include "corclass.h"
#include "corclass_utils.h"
#include "correl.h"
#include "globals.h"
#include "iomanager.h"
#include "lib/mdformat.h"
using namespace mdnaes;

// ==================================== Long Ions CF ====================================
static const char *LongIonCFFileName    = "LIonCF.cf";
static const char *LongIonCFResFileName = "LIonCF.dat";
static const char *CDifIonCFResFileName = "R(t)Ion.dat";

int KIon_Axes; // Ex, Ey and Ez
int KIon_RCM;  // <|R(t)|> and <|R(t)|^2>

static iomanager LongIonCF_IOManager ( LongIonCFFileName );


static vect eX_calc ( ion* part ) {
   vect axes[3];
   part->getMolAxes ( axes );
   return axes[0];
}

static vect eY_calc ( ion* part ) {
   vect axes[3];
   part->getMolAxes ( axes );
   return axes[1];
}

static vect eZ_calc ( ion* part ) {
   vect axes[3];
   part->getMolAxes ( axes );
   return axes[2];
}

static vect CMPos_calc ( ion* part ) {
   return part->getUnPBC_CMPos ();
}


static void SaveLongIonCF ();
static void ResultLongIonCF ();

static std::unique_ptr<HA_Allocator<double> > dbl_HA_allocator;
static std::unique_ptr<HA_Allocator<vect> >  vect_HA_allocator;

static std::vector<std::unique_ptr<base_history_array> > longIonCF_history_arrays;
static std::vector<std::unique_ptr<TDF> > longIonCF_TDFs;
static std::vector<std::unique_ptr<TDF> > longIonABSDispl;
static std::vector<std::unique_ptr<TDF> > longIonSQRDispl;

static void LongIonCF_init () {
   dbl_HA_allocator  = std::make_unique<HA_Allocator<double> > (CorrelSize, 20);
   vect_HA_allocator = std::make_unique<HA_Allocator<vect> >   (CorrelSize, 30);
   
   const mdformat format(11,5);

   multiple_value_history_array_creator<vect,ion*> eX ( "eX", *vect_HA_allocator, eX_calc, longIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> eY ( "eY", *vect_HA_allocator, eY_calc, longIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> eZ ( "eZ", *vect_HA_allocator, eZ_calc, longIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> CMPos ( "CMPos", *vect_HA_allocator, CMPos_calc, longIonCF_history_arrays );
   
   using ion_ABS_Displ_creator = single_molecule_ACF_creator<double,vect,ion*,tcf::R1>;
   using ion_SQR_Displ_creator = single_molecule_ACF_creator<double,vect,ion*,tcf::R2>;
   using ion_ACFP1_creator = single_molecule_ACF_creator<double,vect,ion*,tcf::Legendre1>;
   using ion_ACFP2_creator = single_molecule_ACF_creator<double,vect,ion*,tcf::Legendre2>;

   ion_ACFP1_creator CeX ( "CeX", eX, format );
   ion_ACFP1_creator CeY ( "CeY", eY, format );
   ion_ACFP1_creator CeZ ( "CeZ", eZ, format );
   ion_ACFP2_creator CeXP2 ( "CeXP2", eX, format );
   ion_ACFP2_creator CeYP2 ( "CeYP2", eY, format );
   ion_ACFP2_creator CeZP2 ( "CeZP2", eZ, format );

   ion_ABS_Displ_creator R1 ( "R1(t)", CMPos, mdformat(14,5) );
   ion_SQR_Displ_creator R2 ( "R2(t)", CMPos, mdformat(14,5) );

   Message << "starting long CF calculation for ions" << std::endl;

   create_from_static_shell_if (KIon_Axes, CeX, *AllCations, longIonCF_TDFs, shape_general<ion>);
   create_from_static_shell_if (KIon_Axes, CeY, *AllCations, longIonCF_TDFs, shape_general<ion>);
   create_from_static_shell_if (KIon_Axes, CeZ, *AllCations, longIonCF_TDFs, shape_general<ion>);
   
   create_from_static_shell_if (KIon_Axes && KLegendre, CeXP2, *AllCations, longIonCF_TDFs, shape_general<ion>);
   create_from_static_shell_if (KIon_Axes && KLegendre, CeYP2, *AllCations, longIonCF_TDFs, shape_general<ion>);
   create_from_static_shell_if (KIon_Axes && KLegendre, CeZP2, *AllCations, longIonCF_TDFs, shape_general<ion>);
   
   create_from_static_shell_if (KIon_Axes, CeX, *AllAnions, longIonCF_TDFs, shape_general<ion>);
   create_from_static_shell_if (KIon_Axes, CeY, *AllAnions, longIonCF_TDFs, shape_general<ion>);
   create_from_static_shell_if (KIon_Axes, CeZ, *AllAnions, longIonCF_TDFs, shape_general<ion>);
   
   create_from_static_shell_if (KIon_Axes && KLegendre, CeXP2, *AllAnions, longIonCF_TDFs, shape_general<ion>);
   create_from_static_shell_if (KIon_Axes && KLegendre, CeYP2, *AllAnions, longIonCF_TDFs, shape_general<ion>);
   create_from_static_shell_if (KIon_Axes && KLegendre, CeZP2, *AllAnions, longIonCF_TDFs, shape_general<ion>);
   
   create_from_static_shell (KIon_RCM, R1, *AllCations, longIonABSDispl);
   create_from_static_shell (KIon_RCM, R1, *AllAnions,  longIonABSDispl);
   
   create_from_static_shell (KIon_RCM, R2, *AllCations, longIonSQRDispl);
   create_from_static_shell (KIon_RCM, R2, *AllAnions,  longIonSQRDispl);


   for ( const auto& p: longIonCF_history_arrays ) {
      LongIonCF_IOManager.add ( p.get() );
   }

   for ( const auto& p: longIonCF_TDFs ) {
      LongIonCF_IOManager.add ( p.get() );
   }

   for ( const auto& p: longIonABSDispl ) {
      LongIonCF_IOManager.add ( p.get() );
   }
   for ( const auto& p: longIonSQRDispl ) {
      LongIonCF_IOManager.add ( p.get() );
   }

   if ( KLH ) {
      Message << "reading long ionic CF from file...";
      LongIonCF_IOManager.read ();
      Message << " done" << std::endl;
   }

   SMan.AddFun ( &SaveLongIonCF );
   ShowRes.AddFun ( &ResultLongIonCF );
}

void LongIonCF_Calc () {
   static int init = 1;
   if ( init ) {
      LongIonCF_init ();
      init = 0;
   }
   
   for ( const auto& p: longIonCF_history_arrays ) {
      p->update ( );
   }
   
   for ( const auto& p: longIonCF_TDFs ) {
      p->update ( );
   }
   for ( const auto& p: longIonABSDispl ) {
      p->update ( );
   }
   for ( const auto& p: longIonSQRDispl ) {
      p->update ( );
   }
}

static void SaveLongIonCF () {
   LongIonCF_IOManager.save ();
}

static void ResultLongIonCF () {
   if ( longIonSQRDispl.size() > 0 )
      Message << "Diffusion coefficients, obtained from CM displacements for ions:" << std::endl;
   for ( const auto& p: longIonSQRDispl ) {
      p->print_header ( Message );
      if ( !p->empty() ) {
         Message << mdformat(12,5) << calc_CDif_SQR(dynamic_cast<TTDF<double>*>(p.get()),DELT*StepLongCF);
      }
      else {
         Message << mdformat(12,5) << "--";
      }
      Message << " * 1e-9 m^2/s" << std::endl;
   }
   for ( const auto& p: longIonABSDispl ) {
      p->print_header ( Message );
      if ( !p->empty() ) {
         Message << mdformat(12,5) << calc_CDif_ABS(dynamic_cast<TTDF<double>*>(p.get()),DELT*StepLongCF);
      }
      else {
         Message << mdformat(12,5) << "--";
      }
      Message << " * 1e-9 m^2/s" << std::endl;
   }

   PrintTDFRes ( longIonCF_TDFs, LongIonCFResFileName, StepLongCF );

   std::vector<TDF*> AllDispl;
   for ( const auto& p: longIonABSDispl )
      AllDispl.push_back ( p.get() );
   for ( const auto& p: longIonSQRDispl )
      AllDispl.push_back ( p.get() );
   
   PrintTDFRes ( AllDispl, CDifIonCFResFileName, StepLongCF );
}
