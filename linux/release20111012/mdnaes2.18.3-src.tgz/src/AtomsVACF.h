#ifndef AtomsVACF_H
#define AtomsVACF_H

void AtomsVACF_Calc ();

#endif
