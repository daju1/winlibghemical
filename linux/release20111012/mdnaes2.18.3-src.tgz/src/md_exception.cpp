#include "md_exception.h"

namespace mdnaes {

const char* md_exception::what () const noexcept {
   return message;
}

} // end namespace mdnaes

#include "globals.h"

void raise_md_exception ( const char *text ) {
   Error << text << std::endl;
   throw mdnaes::md_exception ( text );
}

error_logger Error ( "error.log" );
