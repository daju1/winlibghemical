#include "SIonCF.h"

#include <vector>
#include <memory>

#include "corr_aux.h"
#include "corclass.h"
#include "corclass_utils.h"
#include "correl.h"
#include "globals.h"
#include "iomanager.h"
#include "lib/mdformat.h"
using namespace mdnaes;

// ======================================= Short Ions CF =======================================
static const char *ShortIonCFFileName    = "SIonCF.cf";
static const char *ShortIonCFResFileName = "SIonCF.dat";
static const char *ShortIonCrossCFResFileName = "SCIonCF.dat";

int KIon_Cvv;
int KIon_Cww;
int KIon_Cff;
int KIon_Cnn;
int KIon_Cll;

int KIon_Cfc;

int KIon_Cwc;
int KIon_Cvw;

int KIon_WcWc;
int KIon_VcVc;
int KIon_VcWc;

int KIon_Cii;

static iomanager ShortIonCF_IOManager ( ShortIonCFFileName );


static vect VCM_calc ( ion* part ) {
   return part->getCMVel ();
}

static vect FCM_calc ( ion* part ) {
   return part->getForce ();
}

static vect ShortF_calc ( ion* part ) {
   return part->getShortForce ();
}

static vect CoulF_calc ( ion* part ) {
   return part->getLongForce ();
}

static vect N_calc ( ion* part ) {
   return part->getTorque ();
}

static vect ShortN_calc ( ion* part ) {
   return part->getShortTorque ();
}

static vect CoulN_calc ( ion* part ) {
   return part->getLongTorque ();
}

static vect L_calc ( ion* part ) {
   return part->getAngleMomentumInBoxAxes ();
}

static vect W_calc ( ion* part ) {
   return part->getAngleVelInBoxAxes ();
}

static vect Wc_calc ( ion* part ) {
   return part->getAngleVelInMolAxes ();
}

static double Wx_calc ( ion* part ) {
   return (part->getAngleVelInMolAxes ()).x;
}

static double Wy_calc ( ion* part ) {
   return (part->getAngleVelInMolAxes ()).y;
}

static double Wz_calc ( ion* part ) {
   return (part->getAngleVelInMolAxes ()).z;
}

static double Vx_calc ( ion* part ) {
   return (part->toMolAxes(part->getCMVel ())).x;
}

static double Vy_calc ( ion* part ) {
   return (part->toMolAxes(part->getCMVel ())).y;
}

static double Vz_calc ( ion* part ) {
   return (part->toMolAxes(part->getCMVel ())).z;
}

static vect Vl_calc ( ion* part ) {
   const vect n = (*part)[1].r() - (*part)[0].r();
   const double nn = n * n;
   return ((part->getCMVel ()*n)/nn) * n;
}

static vect Vt_calc ( ion* part ) {
   return part->getCMVel () - Vl_calc (part);
}

static vect Current_calc ( ion* part ) {
   return part->getCurrent ();
}

static void SaveShortIonCF ();
static void ResultShortIonCF ();

static std::unique_ptr<HA_Allocator<double> > dbl_HA_allocator;
static std::unique_ptr<HA_Allocator<vect> >  vect_HA_allocator;

static std::vector<std::unique_ptr<base_history_array> > shortIonCF_history_arrays;
static std::vector<std::unique_ptr<TDF> > shortIonCF_Cvvs;
static std::vector<std::unique_ptr<TDF> > shortIonCF_TDFs;

static int sioncf_nthreads = 1;

static void ShortIonCF_init () {
   dbl_HA_allocator  = std::make_unique<HA_Allocator<double> > (CorrelSize, 20); // dont even need them at runtime
   vect_HA_allocator = std::make_unique<HA_Allocator<vect> >   (CorrelSize, 30);
   
   if ( NTHREADS > 1 ) {
      sioncf_nthreads = std::max(2,NTHREADS/2);
   }
   else {
      sioncf_nthreads = 1;
   }
   
   const mdformat format(11,5);

   multiple_value_history_array_creator<vect,ion*> VCM ( "VCM", *vect_HA_allocator, VCM_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> FCM ( "FCM", *vect_HA_allocator, FCM_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> SF  ( "SF", *vect_HA_allocator, ShortF_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> CF  ( "CF", *vect_HA_allocator, CoulF_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> L   ( "L",  *vect_HA_allocator,     L_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> N   ( "N",  *vect_HA_allocator,     N_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> SN  ( "SN", *vect_HA_allocator, ShortN_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> CN  ( "CN", *vect_HA_allocator, CoulN_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> W   ( "W",  *vect_HA_allocator,     W_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> Wc  ( "Wc", *vect_HA_allocator,   Wc_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> Vl  ( "Vl", *vect_HA_allocator,   Vl_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> Vt  ( "Vt", *vect_HA_allocator,   Vt_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<vect,ion*> Cur ( "Cur",*vect_HA_allocator, Current_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<double,ion*> Wx  ( "Wx", *dbl_HA_allocator,  Wx_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<double,ion*> Wy  ( "Wy", *dbl_HA_allocator,  Wy_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<double,ion*> Wz  ( "Wz", *dbl_HA_allocator,  Wz_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<double,ion*> Vx  ( "Vx", *dbl_HA_allocator,  Vx_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<double,ion*> Vy  ( "Vy", *dbl_HA_allocator,  Vy_calc, shortIonCF_history_arrays );
   multiple_value_history_array_creator<double,ion*> Vz  ( "Vz", *dbl_HA_allocator,  Vz_calc, shortIonCF_history_arrays );

   single_molecule_ACF_creator<double,vect,ion*> Cvv ( "Cvv",  VCM, format );
   single_molecule_ACF_creator<double,vect,ion*> Cff ( "Cff",  FCM, format );
   single_molecule_ACF_creator<double,vect,ion*> Cll ( "Cll",  L,   format );
   single_molecule_ACF_creator<double,vect,ion*> Cnn ( "Cnn",  N,   format );
   single_molecule_ACF_creator<double,vect,ion*> Cww ( "Cww",  W,   format );
   single_molecule_ACF_creator<double,vect,ion*> Cwc ( "WcWc", Wc,  format );

   single_molecule_ACF_creator<double,double,ion*> WxWx ( "WxWx", Wx, format );
   single_molecule_ACF_creator<double,double,ion*> WyWy ( "WyWy", Wy, format );
   single_molecule_ACF_creator<double,double,ion*> WzWz ( "WzWz", Wz, format );
   single_molecule_ACF_creator<double,double,ion*> VxVx ( "WxWx", Wx, format );
   single_molecule_ACF_creator<double,double,ion*> VyVy ( "WyWy", Wy, format );
   single_molecule_ACF_creator<double,double,ion*> VzVz ( "WzWz", Wz, format );

   single_molecule_CCF_creator<double,double,double,ion*> WxWy ( "WxWy", Wx, Wy, format );
   single_molecule_CCF_creator<double,double,double,ion*> WxWz ( "WxWz", Wx, Wz, format );
   single_molecule_CCF_creator<double,double,double,ion*> WyWz ( "WyWz", Wy, Wz, format );
   single_molecule_CCF_creator<double,double,double,ion*> VxVy ( "VxVy", Vx, Vy, format );
   single_molecule_CCF_creator<double,double,double,ion*> VxVz ( "VxVz", Vx, Vz, format );
   single_molecule_CCF_creator<double,double,double,ion*> VyVz ( "VyVz", Vy, Vz, format );

   single_molecule_CCF_creator<double,double,double,ion*> VxWx ( "VxWx", Vx, Wx, format );
   single_molecule_CCF_creator<double,double,double,ion*> VxWy ( "VxWy", Vx, Wy, format );
   single_molecule_CCF_creator<double,double,double,ion*> VxWz ( "VxWz", Vx, Wz, format );
   single_molecule_CCF_creator<double,double,double,ion*> VyWx ( "VyWx", Vy, Wx, format );
   single_molecule_CCF_creator<double,double,double,ion*> VyWy ( "VyWy", Vy, Wy, format );
   single_molecule_CCF_creator<double,double,double,ion*> VyWz ( "VyWz", Vy, Wz, format );
   single_molecule_CCF_creator<double,double,double,ion*> VzWx ( "VzWx", Vz, Wx, format );
   single_molecule_CCF_creator<double,double,double,ion*> VzWy ( "VzWy", Vz, Wy, format );
   single_molecule_CCF_creator<double,double,double,ion*> VzWz ( "VzWz", Vz, Wz, format );

   single_molecule_ACF_creator<double,vect,ion*> VlVl ( "VlVl", Vl, format );
   single_molecule_ACF_creator<double,vect,ion*> VtVt ( "VtVt", Vt, format );
   single_molecule_CCF_creator<double,vect,vect,ion*> VlVt ( "VlVt", Vl, Vt, format );
   single_molecule_CCF_creator<double,vect,vect,ion*> VlW ( "VlW", Vl, W, format );
   single_molecule_CCF_creator<double,vect,vect,ion*> VtW ( "VtW", Vt, W, format );

   single_molecule_ACF_creator<double,vect,ion*> SFSF ( "SFSF", SF, mdformat(13,5) );
   single_molecule_ACF_creator<double,vect,ion*> CFCF ( "CFCF", CF, mdformat(13,5) );
   single_molecule_CCF_creator<double,vect,vect, ion*> SFCF ( "SFCF", SF, CF, mdformat(13,5) );
   single_molecule_ACF_creator<double,vect,ion*> SNSN ( "SNSN", SN, mdformat(13,5) );
   single_molecule_ACF_creator<double,vect,ion*> CNCN ( "CNCN", CN, mdformat(13,5) );
   single_molecule_CCF_creator<double,vect,vect,ion*> SNCN ( "SNCN", SN, CN, mdformat(13,5) );

   single_molecule_CCF_creator<double,vect, vect, ion*> Cvw ( "Cvw", VCM, W, format );

   single_molecule_ACF_creator<double,vect,ion*> Cii ( "Cii", Cur, format );

   Message << "starting short CF calculation for ions" << std::endl;

   create_from_static_shell (KIon_Cvv, Cvv, *AllCations, shortIonCF_Cvvs, sioncf_nthreads);
   create_from_static_shell (KIon_Cvv, Cvv, *AllAnions,  shortIonCF_Cvvs, sioncf_nthreads);
   
   create_from_static_shell_if (KIon_Cww, Cww, *AllCations, shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_Cww, Cww, *AllAnions,  shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   
   create_from_static_shell (KIon_Cff, Cff, *AllCations, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell (KIon_Cff, Cff, *AllAnions,  shortIonCF_TDFs, sioncf_nthreads);
   
   create_from_static_shell_if (KIon_Cnn, Cnn, *AllCations, shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_Cnn, Cnn, *AllAnions,  shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   
   create_from_static_shell (KIon_Cfc, SFSF, *AllCations, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell (KIon_Cfc, CFCF, *AllCations, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell (KIon_Cfc, SFCF, *AllCations, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell_if (KIon_Cfc, SNSN, *AllCations, shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_Cfc, CNCN, *AllCations, shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_Cfc, SNCN, *AllCations, shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   
   create_from_static_shell (KIon_Cfc, SFSF, *AllAnions, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell (KIon_Cfc, CFCF, *AllAnions, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell (KIon_Cfc, SFCF, *AllAnions, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell_if (KIon_Cfc, SNSN, *AllAnions, shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_Cfc, CNCN, *AllAnions, shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_Cfc, SNCN, *AllAnions, shortIonCF_TDFs, shape_notpoint<ion>, sioncf_nthreads);
   
   create_from_static_shell (KIon_Cll, Cll, *AllCations, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell (KIon_Cll, Cll, *AllAnions,  shortIonCF_TDFs, sioncf_nthreads);

   create_from_static_shell (KIon_Cwc, Cwc, *AllCations, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell (KIon_Cwc, Cwc, *AllAnions,  shortIonCF_TDFs, sioncf_nthreads);
   
   create_from_static_shell (KIon_Cvw, Cvw, *AllCations, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell (KIon_Cvw, Cvw, *AllAnions,  shortIonCF_TDFs, sioncf_nthreads);

   create_from_static_shell_if (KIon_WcWc, WxWx, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WxWy, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WxWz, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WyWy, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WyWz, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WzWz, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   
   create_from_static_shell_if (KIon_WcWc, WxWx, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WxWy, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WxWz, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WyWy, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WyWz, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_WcWc, WzWz, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);

   create_from_static_shell_if (KIon_VcVc, VxVx, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VxVy, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VxVz, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VyVy, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VyVz, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VzVz, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   
   create_from_static_shell_if (KIon_VcVc, VlVl, *AllCations, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VlVt, *AllCations, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VtVt, *AllCations, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);
   
   create_from_static_shell_if (KIon_VcVc, VxVx, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VxVy, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VxVz, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VyVy, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VyVz, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VzVz, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   
   create_from_static_shell_if (KIon_VcVc, VlVl, *AllAnions, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VlVt, *AllAnions, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcVc, VtVt, *AllAnions, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);

   create_from_static_shell_if (KIon_VcWc, VxWx, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VxWy, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VxWz, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VyWx, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VyWy, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VyWz, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VzWx, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VzWy, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VzWz, *AllCations, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   
   create_from_static_shell_if (KIon_VcWc, VlW, *AllCations, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VtW, *AllCations, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);
   
   create_from_static_shell_if (KIon_VcWc, VxWx, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VxWy, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VxWz, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VyWx, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VyWy, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VyWz, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VzWx, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VzWy, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VzWz, *AllAnions, shortIonCF_TDFs, shape_general<ion>, sioncf_nthreads);
   
   create_from_static_shell_if (KIon_VcWc, VlW, *AllAnions, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);
   create_from_static_shell_if (KIon_VcWc, VtW, *AllAnions, shortIonCF_TDFs, shape_linear<ion>, sioncf_nthreads);

   create_from_static_shell (KIon_Cii, Cii, *AllCations, shortIonCF_TDFs, sioncf_nthreads);
   create_from_static_shell (KIon_Cii, Cii, *AllAnions,  shortIonCF_TDFs, sioncf_nthreads);


   for ( const auto& p: shortIonCF_history_arrays ) {
      ShortIonCF_IOManager.add ( p.get() );
   }

   for ( const auto& p: shortIonCF_Cvvs ) {
      ShortIonCF_IOManager.add ( p.get() );
   }
   
   for ( const auto& p: shortIonCF_TDFs ) {
      ShortIonCF_IOManager.add ( p.get() );
   }


   if ( KLH ) {
      Message << "reading short ionic CF from file...";
      ShortIonCF_IOManager.read ();
      Message << " done" << std::endl;
   }

   SMan.AddFun ( &SaveShortIonCF );
   ShowRes.AddFun ( &ResultShortIonCF );
}

static void do_update_CF ( int thread_no ) {
   for ( const auto& p: shortIonCF_history_arrays ) {
      p->update ( thread_no, sioncf_nthreads );
   }

   for ( const auto& p: shortIonCF_Cvvs ) {
      p->update ( thread_no, sioncf_nthreads );
   }
   
   for ( const auto& p: shortIonCF_TDFs ) {
      p->update ( thread_no, sioncf_nthreads );
   }
}

void ShortIonCF_Calc () {
   static int init = 1;
   if ( init ) {
      ShortIonCF_init ();
      init = 0;
   }
   
   std::vector<std::thread> threads;
   for ( int thread_no = 1; thread_no < sioncf_nthreads; ++thread_no ) {
      threads.emplace_back ( do_update_CF,  thread_no );
   }
   do_update_CF (0);
   for ( auto& th : threads ) {
      th.join();
   }
}

static void SaveShortIonCF () {
   for ( const auto& p: shortIonCF_Cvvs ) {
      p->sync ( );
   }
   
   for ( const auto& p: shortIonCF_TDFs ) {
      p->sync ( );
   }
   
   ShortIonCF_IOManager.save ();
}

static void ResultShortIonCF () {
   for ( const auto& p: shortIonCF_Cvvs ) {
      p->sync ( );
   }
   
   for ( const auto& p: shortIonCF_TDFs ) {
      p->sync ( );
   }
   
   Message << "Diffusion coefficients, obtained by integrating of Cvv(t) for ions:" << std::endl;
   for ( const auto& p: shortIonCF_Cvvs ) {
      p->print_header ( Message );
      if ( !p->empty() ) {
         Message << mdformat(12,5) << 1e9*LENGTH_UNIT*LENGTH_UNIT/(3*TIME_UNIT)*
            integral( *dynamic_cast<TTDF<double>*>(p.get()), p->size(), StepShortCF*DELT);
      }
      else {
         Message << mdformat(12,5) << "--";
      }
      Message << " * 1.0e-9 m^2/s" << std::endl;
   }
   
   std::vector<TDF*> AllTDFs;
   for ( const auto& p: shortIonCF_Cvvs )
      AllTDFs.push_back ( p.get() );
   for ( const auto& p: shortIonCF_TDFs )
      AllTDFs.push_back ( p.get() );
   
   PrintTDFRes ( AllTDFs, ShortIonCFResFileName, StepShortCF );
}
