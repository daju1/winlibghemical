#include "TLife.h"

#include <vector>
#include <memory>

#include "corr_aux.h"
#include "corclass.h"
#include "corclass_utils.h"
#include "correl.h"
#include "globals.h"
#include "iomanager.h"
#include "lib/mdformat.h"
#include "utils.h"
#include "version.h"
using namespace mdnaes;

// ================================== Time of life in shells ==================================
static const char *TimeLifeFileName = "timelife.cf";
static const char *TimeLifeResFileName = "timelife.dat";

static void SaveTimeLife ();
static void ResultTimeLife ();

int TimeLifeTSize;
int TimeLifeMult;

static int LifeTimeCount;
static int LT_nshells;
static int *LifeTimes; // [nshells*NMOL]
static int *LifeTimeHist; // [nshells*TimeLifeTSize];

static void SaveTimeLife () {
   std::ofstream out ( TimeLifeFileName, std::ios::binary | std::ios::out | std::ios::trunc );
   
   const int NMOL = SimSystem.all_molecules.size ();

   version::out ( out );
   write_as<int> ( out, TimeLifeTSize );
   write_as<int> ( out, TimeLifeMult );
   write_as<int> ( out, LT_nshells );
   write_as<int> ( out, NMOL );
   write_as<int> ( out, LifeTimeCount );
   out.write ( (char*)LifeTimes, sizeof(int)*LT_nshells*NMOL );
   out.write ( (char*)LifeTimeHist, sizeof(int)*LT_nshells*TimeLifeTSize );
}

static void TimeLife_init () {
   Message << " starting time of life in shells calculation" << std::endl;
   
   LT_nshells = shells.size ();
   LifeTimes = new int[LT_nshells*SimSystem.all_molecules.size()];
   LifeTimeHist = new int[LT_nshells*TimeLifeTSize];
   LifeTimeCount = 0;
   
   for ( int i = 0; i < LT_nshells*SimSystem.all_molecules.size (); ++i )
      LifeTimes[i] = 0;
   for ( int i = 0; i < LT_nshells*TimeLifeTSize; ++i )
      LifeTimeHist[i] = 0;
   
   if ( KLH ) {
      std::ifstream in ( TimeLifeFileName, std::ios::binary | std::ios::in );
      if ( !in ) {
         std::cerr << '\a';
         Error << __FILE__ << " line " << __LINE__ << ": cannot open file " << TimeLifeFileName;
         Error << "\n" "starting new time of life calculation" << std::endl;
      }
      else {
         version::check_ver ( in, "void TimeLife_Calc ()" );
         
         const auto savedTimeLifeTSize = read_as<int> ( in );
         if ( savedTimeLifeTSize != TimeLifeTSize ) {
            Error << " Not equal values of TimeLifeTSize: " << savedTimeLifeTSize << " and " << TimeLifeTSize << "\n";
            throw md_io_error ("Error in TimeLife_Calc()");
         }
         
         const auto savedTimeLifeMult = read_as<int> ( in );
         if ( savedTimeLifeMult != TimeLifeMult ) {
            Error << " Not equal values of TimeLifeMult: " << savedTimeLifeMult << " and " << TimeLifeMult << "\n";
            throw md_io_error ("Error in TimeLife_Calc()");
         }
         
         const auto savednshells = read_as<int> ( in );
         if ( savednshells != LT_nshells ) {
            Error << " Not equal values of nshells: " << savednshells << " and " << LT_nshells << "\n";
            throw md_io_error ("Error in TimeLife_Calc()");
         }
         
         const auto savedNMOL = read_as<int> ( in );
         if ( savedNMOL != SimSystem.all_molecules.size() ) {
            Error << " Not equal values of NMOL: " << savedNMOL << " and " << SimSystem.all_molecules.size() << "\n";
            throw md_io_error ("Error in TimeLife_Calc()");
         }
         
         LifeTimeCount = read_as<int> ( in );
         in.read ( (char*)LifeTimes, sizeof(int)*LT_nshells*SimSystem.all_molecules.size() );
         in.read ( (char*)LifeTimeHist, sizeof(int)*LT_nshells*TimeLifeTSize );
      }
   }
   
   SMan.AddFun ( SaveTimeLife );
   ShowRes.AddFun ( ResultTimeLife );
}

void TimeLife_Calc () {
   static int init = 1;
   if ( init ) {
      TimeLife_init ();
      init = 0;
   }

   for ( int s = 0; s < shells.size(); ++s ) {
      for ( int i = 0; i < shells[s]->maxelements (); ++i ) {
         if ( shells[s]->has (i) )
            LifeTimes[s*SimSystem.all_molecules.size()+i]++;
         else
            LifeTimes[s*SimSystem.all_molecules.size()+i] = 0;

         if ( LifeTimes[s*SimSystem.all_molecules.size()+i] > 0 ) {
            if ( LifeTimes[s*SimSystem.all_molecules.size()+i] < TimeLifeTSize ) {
               LifeTimeHist[TimeLifeTSize*s + LifeTimes[s*SimSystem.all_molecules.size()+i]-1]++;
            }
            else { // here we store the number of molecules, that stays longer than TimeLifeTSize ticks
               LifeTimeHist[TimeLifeTSize*s + TimeLifeTSize-1]++;
            }
         }
      }
   }
   LifeTimeCount++;
}

static void ResultTimeLife () {
   if ( SimSystem.all_ions.size() < 1 )
      return;

   const mdformat fcolfmt (8,4);
   const mdformat format (8,3);

   std::ofstream out ( TimeLifeResFileName );

   out << fcolfmt << "t_ps" << " ";
   for ( auto ps: shells ) {
      out << format << ps->getkey ();
   }
   out << std::endl;

   std::vector<std::vector<double> > tlife_data;
   tlife_data.resize ( shells.size() );
   for ( auto& a: tlife_data ) {
      a.resize ( TimeLifeTSize );
   }

   for ( int s = 0; s < shells.size(); ++s ) {
      tlife_data[s][TimeLifeTSize-1] = static_cast<double>(LifeTimeHist[TimeLifeTSize*s+TimeLifeTSize-1])/LifeTimeCount;
      for ( int t = TimeLifeTSize-2; t >= 0; --t ) {
         tlife_data[s][t] = tlife_data[s][t+1] + static_cast<double>(LifeTimeHist[TimeLifeTSize*s+t])/LifeTimeCount;
      }
   }

   // tlife_data[s][t] is an average number of molecules, that stays in the shell for t of more ticks

   for ( int t = 0; t < TimeLifeTSize; ++t ) {
      out << fcolfmt << DELT*t*TimeLifeMult << " ";
      for ( int s = 0; s < shells.size(); ++s ) {
         out << format << tlife_data[s][t];
      }
      out << "\n";
   }
}

// ======================================================================================
// ================================== Time of life ACF ==================================
static const char *TLifeACFFileName = "tlifeacf.cf";
static const char *TLifeACFResFileName = "tlifeacf.dat";

static void SaveTLifeACF ();
static void ResultTLifeACF ();

int TLifeACFTSize;
int TLifeACFMult;

static int TLife_nshells;
static HA<int>* *TLifeACF_HA = nullptr; // [nshells*NMOL];
static int *TLifeACFHist; // [nshells*TLifeACFTSize];
static int *TLifeACFCount;// [nshells*TLifeACFTSize];

static void SaveTLifeACF () {
   std::ofstream out ( TLifeACFFileName, std::ios::binary | std::ios::out | std::ios::trunc );
   
   const int NMOL = SimSystem.all_molecules.size ();

   version::out ( out );
   write_as<int> ( out, TLifeACFTSize );
   write_as<int> ( out, TLifeACFMult );
   write_as<int> ( out, TLife_nshells );
   write_as<int> ( out, NMOL );

   for ( int i = 0; i < TLife_nshells*NMOL; ++i )
      TLifeACF_HA[i]->save ( out );

   out.write ( (char*)TLifeACFHist,  sizeof(int)*TLife_nshells*TLifeACFTSize );
   out.write ( (char*)TLifeACFCount, sizeof(int)*TLife_nshells*TLifeACFTSize );
}

static void TLifeACF_init () {
   Message << " starting time of life ACF calculation" << std::endl;
   
   TLife_nshells = shells.size ();
   TLifeACFTSize = TimeLifeTSize;
   TLifeACFMult  = TimeLifeMult;
   
   TLifeACF_HA = new HA<int>*[TLife_nshells*SimSystem.all_molecules.size()];
   TLifeACFHist  = new int [TLife_nshells*TLifeACFTSize];
   TLifeACFCount = new int [TLife_nshells*TLifeACFTSize];
   
   for ( int i = 0; i < TLife_nshells*SimSystem.all_molecules.size(); ++i ) {
      TLifeACF_HA[i] = new HA<int> ( TLifeACFTSize );
   }
   
   for ( int i = 0; i < TLife_nshells*TLifeACFTSize; ++i ) {
      TLifeACFHist[i]  = 0;
      TLifeACFCount[i] = 0;
   }
   
   if ( KLH ) {
      std::ifstream in ( TLifeACFFileName, std::ios::binary | std::ios::in );
      if ( !in ) {
         std::cerr << '\a';
         Error << __FILE__ << " line " << __LINE__ << ": cannot open file " << TLifeACFFileName;
         Error << "\n" "starting new time of life ACF calculation" << std::endl;
      }
      else {
         version::check_ver ( in, "void TLifeACF_Calc ()" );
         
         const auto savedTLifeACFTSize = read_as<int> ( in );
         if ( savedTLifeACFTSize != TLifeACFTSize ) {
            Error << " Not equal values of TLifeACFTSize: " << savedTLifeACFTSize << " and " << TLifeACFTSize << "\n";
            throw md_io_error ("Error in TLifeACF_Calc()");
         }
         
         const auto savedTLifeACFMult = read_as<int> ( in );
         if ( savedTLifeACFMult != TLifeACFMult ) {
            Error << " Not equal values of TLifeACFMult: " << savedTLifeACFMult << " and " << TLifeACFMult << "\n";
            throw md_io_error ("Error in TLifeACF_Calc()");
         }
         
         const auto savednshells = read_as<int> ( in );
         if ( savednshells != TLife_nshells ) {
            Error << " Not equal values of nshells: " << savednshells << " and " << TLife_nshells << "\n";
            throw md_io_error ("Error in TLifeACF_Calc()");
         }
         
         const auto savedNMOL = read_as<int> ( in );
         if ( savedNMOL != SimSystem.all_molecules.size() ) {
            Error << " Not equal values of NMOL: " << savedNMOL << " and " << SimSystem.all_molecules.size() << "\n";
            throw md_io_error ("Error in TLifeACF_Calc()");
         }
         
         for ( int i = 0; i < TLife_nshells*SimSystem.all_molecules.size (); ++i )
            TLifeACF_HA[i]->read ( in );
         
         in.read ( (char*)TLifeACFHist,  sizeof(int)*TLife_nshells*TLifeACFTSize );
         in.read ( (char*)TLifeACFCount, sizeof(int)*TLife_nshells*TLifeACFTSize );
      }
   }
   
   SMan.AddFun ( SaveTLifeACF );
   ShowRes.AddFun ( ResultTLifeACF );
}

void TLifeACF_Calc () {
   static int init = 1;
   if ( init ) {
      TLifeACF_init ();
      init = 0;
   }

   for ( int s = 0; s < TLife_nshells; ++s ) {
      for ( int i = 0; i < shells[s]->maxelements (); ++i ) {
         TLifeACF_HA[s*SimSystem.all_molecules.size()+i]->add ( shells[s]->has (i) ? 1 : 0 );

         for ( int t = 0; t < TLifeACF_HA[s*SimSystem.all_molecules.size()+i]->size (); ++t ) {
            TLifeACFHist[s*TLifeACFTSize+t] += (*TLifeACF_HA[s*SimSystem.all_molecules.size()+i])[0] * (*TLifeACF_HA[s*SimSystem.all_molecules.size()+i])[t];
            TLifeACFCount[s*TLifeACFTSize+t]++;
         }
      }
   }
}

static void ResultTLifeACF () {
   if ( SimSystem.all_ions.size () < 1 )
      return;

   const mdformat fcolfmt (8,3);
   const mdformat format (10,5);

   std::ofstream out ( TLifeACFResFileName );

   out << fcolfmt << "t_ps";
   for ( auto ps: shells ) {
      out << " ";
      out << format << ps->getkey ();
   }
   out << std::endl;

   out << fcolfmt << "<N>:";
   for ( int s = 0; s < TLife_nshells; ++s ) {
      out << " ";
      if ( TLifeACFCount[s*TLifeACFTSize] != 0 ) {
         out << format << shells[s]->maxelements() * (double(TLifeACFHist[s*TLifeACFTSize]) / TLifeACFCount[s*TLifeACFTSize]);
      }
      else {
         out << format << "--";
      }
   }
   out << std::endl;

   for ( int i = 0; i < TLifeACFTSize; ++i ) {
      out << fcolfmt << DELT*i*TLifeACFMult;
      for ( int s = 0; s < TLife_nshells; ++s ) {
         out << " ";
         if (  TLifeACFCount[s*TLifeACFTSize+i] != 0
            && TLifeACFCount[s*TLifeACFTSize] != 0
            && TLifeACFHist[s*TLifeACFTSize] != 0 ) {
            out << format << double(TLifeACFHist[s*TLifeACFTSize+i]) / TLifeACFCount[s*TLifeACFTSize+i] /
                            (double(TLifeACFHist[s*TLifeACFTSize])   / TLifeACFCount[s*TLifeACFTSize]);
         } else {
            out << format << "--";
         }
      }
      out << std::endl;
   }
}
