#include "basic_particle.h"

#include "lib/mdformat.h"
#include "md_exception.h"
#include "globals.h"
#include "utils.h"

using namespace mdnaes;

#include <vector>
#include <string>
#include <iostream>
#include <cstdint>

basic_particle_type::size_type basic_particle_type::next_id = 0;

basic_particle_type::basic_particle_type ( mylist_const_iterator& in  )
: particle_id(next_id++)
{
   in.reset ();
   
   this->particle_name = in.item_name ();
   ++in;

   in >> this->num_atoms;
   if ( num_atoms < 1 ) {
      Error << "illegal number of atoms in particle " << particle_name << ": " << num_atoms;
      Error << " (or number of atoms in this molecule was not specified)" <<  std::endl;
      raise_md_exception ( " from \"basic_particle_type::basic_particle_type ( mylist_const_iterator&, atom_types_table& )\"" );
   }

   for ( ; in.find( "site" ); ++in ) {
      mylist_const_iterator site = in.get_item();

      const auto atom_name = site.item_name();
      auto id = find_id ( Atom_types, atom_name );
      if ( id < 0 || id >= Atom_types.size() ) {
         Error << "Cannot find site name: " << atom_name << std::endl;
         raise_md_exception ( " from \"basic_particle_type::basic_particle_type ( mylist_const_iterator&\"" );
      }
      this->atom_ids.emplace_back ( id );
      ++site;
      
      vect r;
      site >> r.x >> r.y >> r.z;
      this->initial_positions.push_back ( r );
   }
   
   if ( this->num_atoms != this->atom_ids.size() ) {
      Error << "specified number of atoms in particle " << this->num_atoms <<
               " differs from actial number of sites " <<  this->atom_ids.size() <<  std::endl;
      raise_md_exception ( " from \"basic_particle_type::basic_particle_type ( mylist_const_iterator&, atom_types_table& )\"" );
   }
   
   particle_mass = 0.0;
   for ( int a: this->atom_ids ) {
      particle_mass += Atom_types[a].mass();
   }
   

   // default views contains no atoms!
   // for ( int a = 0; a < this->num_atoms; ++a ) {
   //    this->view_Grt.emplace_back (a);
   //    this->view_Fkt.emplace_back (a);
   // }
   for ( in.reset (); in.find( "view" ); ++in ) {
      mylist_const_iterator v = in.get_item();
      
      const std::string view_name = v.item_name();
      ++v;
      
      std::vector<size_type> view;
      while ( !v.is_on_end() ) {
         auto atom_no = v.get_size_t();
         
         if ( atom_no > this->num_atoms-1 ) {
            Error << "In particle " << this->particle_name << " in #view " << view_name <<
                     " index of atom (" << atom_no << ") is larger than number of atoms-1.\n";
            raise_md_exception ( " from \"basic_particle_type::basic_particle_type ( mylist_const_iterator&, atom_types_table& )\"" );
         }
         
         view.push_back( atom_no );
         ++v;
      }
      
      if ( view_name == "STCF" ) {
         this->view_STCF = view;
      }
      else { // unknown view
         Error << "In particle " << this->particle_name << " not supported #view " << view_name << "\n";
         raise_md_exception ( " from \"basic_particle_type::basic_particle_type ( mylist_const_iterator&, atom_types_table& )\"" );
      }
   }
}

basic_particle_type::~basic_particle_type () {}

//================================================================================================
basic_particle::basic_particle ( const basic_particle_type& t, vect origin )
: type(t), numatoms(t.natoms())
{
   //first_index = global_cspace.allocate_atoms ( type.get_atom_types(), id() );
   first_index = global_cspace.allocate_atoms ( type.get_atom_ids(), id() );
   for ( size_type i = 0; i < natoms(); ++i ) {
      reference a = (*this)[i];
      a.r() = origin + type.init_pos(i);
      a.v() = 0.0;
      a.q() = a.orig_charge();
   }
   
   unPBC_CMPos = getCMPos ();
}

basic_particle::basic_particle ( const basic_particle &src, vect cmpos )
: type(src.type), numatoms(src.natoms())
{
   const auto old_cmpos = src.getCMPos ();
   
   //first_index = global_cspace.allocate_atoms ( type.get_atom_types(), id() );
   first_index = global_cspace.allocate_atoms ( type.get_atom_ids(), id() );
   for ( size_type i = 0; i < natoms(); ++i ) {
      reference a = (*this)[i];
      a.r() = src[i].r() + cmpos-old_cmpos;
      a.v() = src[i].v();
      a.q() = src[i].q();
   }
   
   unPBC_CMPos = getCMPos ();
}

void basic_particle::swap ( basic_particle& other ) {
   if ( id() != other.id() ) {
      raise_md_exception ( "Cannot swap particles of different types\n" );
   }
   
   for ( size_type i = 0; i < natoms(); ++i ) {
      (*this)[i].swap(other[i]);
   }
   std::swap(this->unPBC_CMPos,other.unPBC_CMPos);
}

// -----------------------------------------------------------------------------------------------
void basic_particle::read_v2_0 ( std::istream& in ) {
   const auto num_atoms = read_as<int32_t> ( in );
   if ( num_atoms != natoms() )
      raise_md_exception ( "basic_particle::read_v2_0(): illegal number of atoms in input" );
   
   for ( reference a: *this ) {
      a.read_v2_0 ( in );
   }
   
   unPBC_CMPos = read_as<vect> ( in );
}

void basic_particle::save_v2_0 ( std::ostream& out ) const {
   write_as<int32_t> ( out, natoms() );

   for ( const_reference a: *this ) {
      a.save_v2_0 ( out );
   }
   
   write_as<vect> ( out, unPBC_CMPos );
}

// -----------------------------------------------------------------------------------------------
void basic_particle::print ( std::ostream& out, const vect origin, const vect origin_pos ) const {
   const vect CMPos = getCMPos ();
   vect relativeCMPos = CMPos - origin;
   PBC (relativeCMPos);
   relativeCMPos += origin_pos;

   for ( const_reference a: *this ) {
      out << mdformat(6,0) << a.name ();
      out << mdformat(11,6) << 10*(a.r() - CMPos + relativeCMPos) << '\n';
   }
}

int basic_particle::DLPOLY_Out ( std::ostream& out, int num_of_first_atom, int mode ) const {
   for ( size_type i = 0; i < natoms(); ++i ) {
      const_reference a = (*this)[i];
      out << mdformat(8) << a.name() << mdformat(10) << (num_of_first_atom + i) << '\n';
      out << mdformat(20,9) << 10*a.r() << '\n';
      if ( mode > 0 )
         out << mdformat(20,9) << 10*a.v() << '\n';
   }

   return num_of_first_atom + natoms();
}

// -----------------------------------------------------------------------------------------------
vect basic_particle::getCMPos () const {
   vect r = 0.0;
   for ( const_reference a: *this ) {
      r += a.r() * a.mass();
   }
   return r/mass();
}

