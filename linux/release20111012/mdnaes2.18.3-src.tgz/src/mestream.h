#if !defined M_MESTREAM
#define M_MESTREAM

void read_fint ();

#endif
