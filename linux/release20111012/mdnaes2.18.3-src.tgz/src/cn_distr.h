#ifndef CN_DISTR_H
#define CN_DISTR_H

extern void CN_distr_Calc ();

#endif
