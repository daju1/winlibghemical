#if !defined M_INIT
#define M_INIT

void CONFIG  ();
void DUBL    ( int );
void ReadCommandLine ( char *arg[] );


extern const char *LogFileName;      // Name of log file
extern const char *Co_inFileName;    // Name of file with in binary config information
extern const char *Co_outFileName;   // Name of file with out binary config information
extern const char *ResFileName;      // Name of file with result data
extern const char *FintFileName;     // Name of file with descriptions MD run
extern const char *ParamsFileName;   // Name of file with molucular parameters

extern int CO_IN_VERSION;
extern int CO_IN_SUBVER;

#endif
