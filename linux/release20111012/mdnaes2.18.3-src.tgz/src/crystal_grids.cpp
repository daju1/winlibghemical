#include "crystal_grids.h"

#include "lib/vect.h"
using namespace mdnaes;

#include <cmath>
#include <limits>

crystal_grid::~crystal_grid () {}

crystal_grid::size_type crystal_grid::find_nearest ( vect position ) const
{
   double rmin = std::numeric_limits<double>::max();
   size_type index = size();
   
   for ( size_type i = 0; i < size(); ++i ) {
      const double r = norm(position-(*this)[i]);
      if ( r < rmin ) {
         index = i;
         rmin = r;
      }
   }
   
   return index;
}

// ============================================================================
Pcubic_grid::Pcubic_grid ( size_type requested_size, double lbox )
: crystal_grid(lbox), n(0)
{
   n = 1;
   while ( n*n*n < requested_size )
      ++n;
}
   
Pcubic_grid::~Pcubic_grid () {}
   
crystal_grid::size_type Pcubic_grid::size () const {
   return n*n*n;
}

vect Pcubic_grid::operator [] ( size_type i) const
{
   const size_type ix = i/(n*n);
   const size_type iy = (i%(n*n))/n;
   const size_type iz = (i%(n*n))%n;
   
   return vect ( (ix+0.5)*m_lbox/n, (iy+0.5)*m_lbox/n, (iz+0.5)*m_lbox/n );
}


// ============================================================================
FCC_grid::FCC_grid ( size_type requested_size, double lbox )
: crystal_grid(lbox), n(0)
{
   n = 1;
   while ( 4*n*n*n < requested_size )
      ++n;
}
   
FCC_grid::~FCC_grid () {}
   
crystal_grid::size_type FCC_grid::size () const {
   return 4*n*n*n;
}

vect FCC_grid::operator [] ( size_type i) const
{
   static const vect coords[4] = { vect(1,1,1), vect(-1,-1,1), vect(1,-1,-1), vect(-1,1,-1) };
   const size_type i4 = i/4;
   const size_type ix = i4/(n*n);
   const size_type iy = (i4%(n*n))/n;
   const size_type iz = (i4%(n*n))%n;
   
   return ( vect(ix+0.5,iy+0.5,iz+0.5) + 0.25*coords[i%4] ) * m_lbox/n;
}


