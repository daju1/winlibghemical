#include <cmath>
#include <cassert>
#include <cstdlib>
#include <algorithm>

#include "globals.h"
#include "mymath.h"
#include "molecular_geometry.h"
#include "shaked_particle.h"
//#include "parray_impl.h"
#include "mylist.h"
#include "lib/mdformat.h"
#include "units.h"

namespace {
   void gen_auto_exclusions ( const bool *X, bool *Res, int n, bool exclude_1_4 );
}

template <class Base_part>
shaked_particle_type<Base_part>::shaked_particle_type ( mylist_const_iterator& in )
:  Base (in), exclusions() {
   // ----------------------------------------------------------
   exclusions = new bool[this->natoms()*this->natoms()];
   std::fill_n ( exclusions, this->natoms()*this->natoms(), false );

   bool *auto_exclusions = new bool[this->natoms()*this->natoms()];
   std::fill_n ( auto_exclusions, this->natoms()*this->natoms(), false );

   bool exclude_1_4 = true;
   in.reset();
   if ( in.find( "unexclude_1-4" ) ) {
      exclude_1_4 = false;
   }

   for ( in.reset(); in.find( "distance_constraint" ); ++in ) {
      distance_constraint new_bond;
      mylist_const_iterator it (in.get_item());

      it >> new_bond.i1;
      it >> new_bond.i2;

      if ( new_bond.i1 < 0 || new_bond.i1 >= this->natoms() ||
           new_bond.i2 < 0 || new_bond.i2 >= this->natoms() ) {
         raise_md_exception ( "atom index in distance_constraint is out of range" );
      }

      if ( new_bond.i1 == new_bond.i2 )
         raise_md_exception ( "atoms indexes in distance_constraint are equal" );

      if ( it.is_on_end() ) {
         mdnaes::distance d ( this->initial_positions[new_bond.i1],
                              this->initial_positions[new_bond.i2] );
         new_bond.sqr_dist = d.r2();
      }
      else {
         double tmp = 0.0;
         it >> tmp;
         new_bond.sqr_dist = tmp * tmp;
      }

      constraints.push_back ( new_bond );

      exclusions[new_bond.i1*this->natoms()+new_bond.i2] = true;
      exclusions[new_bond.i2*this->natoms()+new_bond.i1] = true;
   }

   for ( in.reset(); in.find( "bond_constraint" ); ++in ) {
      distance_constraint new_bond;
      mylist_const_iterator it (in.get_item());

      it >> new_bond.i1;
      it >> new_bond.i2;

      if ( new_bond.i1 < 0 || new_bond.i1 >= this->natoms() ||
           new_bond.i2 < 0 || new_bond.i2 >= this->natoms() ) {
         raise_md_exception ( "atom index in bond_constraint is out of range" );
      }

      if ( new_bond.i1 == new_bond.i2 ) {
         raise_md_exception ( "atom indexes in bond_constraint are equal" );
      }

      if ( it.is_on_end() ) {
         mdnaes::distance d ( this->initial_positions[new_bond.i1],
                              this->initial_positions[new_bond.i2] );
         new_bond.sqr_dist = d.r2();
      }
      else {
         double tmp = 0.0;
         it >> tmp;
         new_bond.sqr_dist = tmp * tmp;
      }
      
      bond_constraints.push_back ( new_bond );

      exclusions[new_bond.i1*this->natoms()+new_bond.i2] = true;
      exclusions[new_bond.i2*this->natoms()+new_bond.i1] = true;

      auto_exclusions[new_bond.i1*this->natoms()+new_bond.i2] = true;
      auto_exclusions[new_bond.i2*this->natoms()+new_bond.i1] = true;
   }

   for ( in.reset(); in.find( "angle_constraint" ); ++in ) {
      angle_constraint new_angle;
      mylist_const_iterator it (in.get_item());

      it >> new_angle.i1;
      it >> new_angle.i2;
      it >> new_angle.i3;

      if ( new_angle.i1 < 0 || new_angle.i1 >= this->natoms() ||
           new_angle.i2 < 0 || new_angle.i2 >= this->natoms() ||
           new_angle.i3 < 0 || new_angle.i3 >= this->natoms() ) {
         raise_md_exception ( "atom index in angle_constraint is out of range" );
      }

      if ( new_angle.i1 == new_angle.i2 || new_angle.i1 == new_angle.i3 ||
           new_angle.i2 == new_angle.i3 ) {
         raise_md_exception ( "atom indexes in angle_constraint are equal" );
      }

      if ( it.is_on_end() ) {
         mdnaes::angle a ( this->initial_positions[new_angle.i1],
                           this->initial_positions[new_angle.i2],
                           this->initial_positions[new_angle.i3] );
         new_angle.alpha = a.alpha();
      }
      else {
         //it >> new_angle.alpha;
         new_angle.alpha = it.get_double() * SI_PI/180;
         ++it;
      }
      
      angle_constraints.push_back ( new_angle );

      exclusions[new_angle.i1*this->natoms()+new_angle.i3] = true;
      exclusions[new_angle.i3*this->natoms()+new_angle.i1] = true;
   }
   
   for ( in.reset(); in.find( "dihedral_constraint" ); ++in ) {
      dihedral_constraint new_dihedral;
      mylist_const_iterator it (in.get_item());

      it >> new_dihedral.i1;
      it >> new_dihedral.i2;
      it >> new_dihedral.i3;
      it >> new_dihedral.i4;

      if ( new_dihedral.i1 < 0 || new_dihedral.i1 >= this->natoms() ||
           new_dihedral.i2 < 0 || new_dihedral.i2 >= this->natoms() ||
           new_dihedral.i3 < 0 || new_dihedral.i3 >= this->natoms() ||
           new_dihedral.i4 < 0 || new_dihedral.i4 >= this->natoms() ) {
         raise_md_exception ( "atom index in dihedral_constraint is out of range" );
      }
      if ( new_dihedral.i1 == new_dihedral.i2 || new_dihedral.i1 == new_dihedral.i3 ||
           new_dihedral.i1 == new_dihedral.i4 || new_dihedral.i2 == new_dihedral.i3 ||
           new_dihedral.i2 == new_dihedral.i4 || new_dihedral.i3 == new_dihedral.i4 ) {
         raise_md_exception ( "atom indexes in dihedral_constraint are equal" );
      }

      if ( it.is_on_end() ) {
         mdnaes::dihedral b ( this->initial_positions[new_dihedral.i1],
                              this->initial_positions[new_dihedral.i2],
                              this->initial_positions[new_dihedral.i3],
                              this->initial_positions[new_dihedral.i4] );
         new_dihedral.beta = b.beta();
      }
      else {
         //it >> new_dihedral.beta;
         new_dihedral.beta = it.get_double() * SI_PI/180;
         ++it;
      }

      dihedral_constraints.push_back ( new_dihedral );

      if ( exclude_1_4 ) {
         exclusions[new_dihedral.i1*this->natoms()+new_dihedral.i4] = true;
         exclusions[new_dihedral.i4*this->natoms()+new_dihedral.i1] = true;
      }
   }

   // -----------------------------------------------
   {  // trying to calculate number of degrees of freedom
      int *constrained = new int[this->natoms()];
      std::fill_n ( constrained, this->natoms(), 0 );

      NTotDegFree = 3*this->natoms ();

      std::size_t i;
      for ( i = 0; i < constraints.size(); ++i ) {
         if ( constrained[constraints[i].i1] < 3 ||
              constrained[constraints[i].i2] < 3 )
              --NTotDegFree;

         constrained[constraints[i].i1]++;
         constrained[constraints[i].i2]++;
      }
      for ( i = 0; i < bond_constraints.size(); ++i ) {
         if ( constrained[bond_constraints[i].i1] < 3 ||
              constrained[bond_constraints[i].i2] < 3 )
              --NTotDegFree;

         constrained[bond_constraints[i].i1]++;
         constrained[bond_constraints[i].i2]++;
      }
      for ( i = 0; i < angle_constraints.size(); ++i ) {
         if ( constrained[angle_constraints[i].i1] < 3 ||
              constrained[angle_constraints[i].i3] < 3 )
              --NTotDegFree;

         constrained[angle_constraints[i].i1]++;
         constrained[angle_constraints[i].i3]++;
      }
      for ( i = 0; i < dihedral_constraints.size(); ++i ) {
         if ( constrained[dihedral_constraints[i].i1] < 3 ||
              constrained[dihedral_constraints[i].i4] < 3 )
              --NTotDegFree;

         constrained[dihedral_constraints[i].i1]++;
         constrained[dihedral_constraints[i].i4]++;
      }
      delete[] constrained;
   }
   // -----------------------------------------------

   // If automatic calculation fails, user can specify correct value
   in.reset ();
   if ( in.find( "TotDegFree" ) ) {
      mylist_const_iterator it (in.get_item());
      
      int newNTotDegFree = it.get_int ();

      if ( newNTotDegFree < 0 ) {
         Error << "! Manually change total number of degrees of freedom\n! from ";
         Error << NTotDegFree << " to " << newNTotDegFree << " in particle ";
         Error << this->name() << " New value must be nonnegative\n";
         raise_md_exception ( "Error in shaked_particle_type::shaked_particle_type ()\n" );
      }
      NTotDegFree = newNTotDegFree;
   }
   // -----------------------------------------------

   for ( in.reset(); in.find( "bond_potential" ); ++in ) {
      bond_potential new_bond;
      mylist_const_iterator it (in.get_item());

      it >> new_bond.i1;
      it >> new_bond.i2;

      if ( new_bond.i1 < 0 || new_bond.i1 >= this->natoms() ||
           new_bond.i2 < 0 || new_bond.i2 >= this->natoms() )
         raise_md_exception ( "atom index in bond_potential is out of range" );
      if ( new_bond.i1 == new_bond.i2 )
         raise_md_exception ( "atoms indexes in bond_potential are equal" );


      new_bond.eqv_dist = it.get_double() * EXTERNAL_LENGTH_UNIT/LENGTH_UNIT;
      ++it;

      while ( !it.is_on_end() ) {
         new_bond.coefs.push_back( it.get_double() * EXTERNAL_ENERGY_UNIT/ENERGY_UNIT );
         ++it;
      }
      bonds.push_back ( new_bond );

      exclusions[new_bond.i1*this->natoms()+new_bond.i2] = true;
      exclusions[new_bond.i2*this->natoms()+new_bond.i1] = true;

      auto_exclusions[new_bond.i1*this->natoms()+new_bond.i2] = true;
      auto_exclusions[new_bond.i2*this->natoms()+new_bond.i1] = true;
   }

   for ( in.reset(); in.find( "angle_potential" ); ++in ) {
      angle_potential new_angle;
      mylist_const_iterator it (in.get_item());

      it >> new_angle.i1;
      it >> new_angle.i2;
      it >> new_angle.i3;

      if ( new_angle.i1 < 0 || new_angle.i1 >= this->natoms() ||
           new_angle.i2 < 0 || new_angle.i2 >= this->natoms() ||
           new_angle.i3 < 0 || new_angle.i3 >= this->natoms() )
         raise_md_exception ( "atom index in angle_potential is out of range" );
      if ( new_angle.i1 == new_angle.i2 ||
           new_angle.i1 == new_angle.i3 ||
           new_angle.i2 == new_angle.i3 )
         raise_md_exception ( "atoms indexes in angle_potential are equal" );

      new_angle.eqv_angle = it.get_double() * SI_PI/180;
      ++it;

      while ( !it.is_on_end() ) {
         new_angle.coefs.push_back( it.get_double() * EXTERNAL_ENERGY_UNIT/ENERGY_UNIT );
         ++it;
      }
      angles.push_back ( new_angle );

      exclusions[new_angle.i1*this->natoms()+new_angle.i3] = true;
      exclusions[new_angle.i3*this->natoms()+new_angle.i1] = true;
   }
   
   for ( in.reset(); in.find( "angle_cos_potential" ); ++in ) {
      angle_cos_potential new_angle;
      mylist_const_iterator it (in.get_item());

      it >> new_angle.i1;
      it >> new_angle.i2;
      it >> new_angle.i3;

      if ( new_angle.i1 < 0 || new_angle.i1 >= this->natoms() ||
           new_angle.i2 < 0 || new_angle.i2 >= this->natoms() ||
           new_angle.i3 < 0 || new_angle.i3 >= this->natoms() )
         raise_md_exception ( "atom index in angle_cos_potential is out of range" );
      if ( new_angle.i1 == new_angle.i2 ||
           new_angle.i1 == new_angle.i3 ||
           new_angle.i2 == new_angle.i3 )
         raise_md_exception ( "atoms indexes in angle_cos_potential are equal" );

      new_angle.eqv_angle = it.get_double() * SI_PI/180;
      ++it;
      new_angle.eqv_cos = std::cos(new_angle.eqv_angle);
      
      new_angle.k = it.get_double();
      ++it;

      /*while ( !it.is_on_end() ) {
         new_angle.coefs.push_back( it.get_double() * EXTERNAL_ENERGY_UNIT/ENERGY_UNIT );
         ++it;
      }*/
      angles_cos.push_back ( new_angle );

      exclusions[new_angle.i1*this->natoms()+new_angle.i3] = true;
      exclusions[new_angle.i3*this->natoms()+new_angle.i1] = true;
   }

   in.reset ();
   for (;;) { // search for the next dihedral:
      while ( !in.is_on_end () &&
              in.item_name () != "dihedral_potential" &&
              in.item_name () != "dihedral" )
         ++in;
      if ( in.is_on_end () ) // input list is empty now
         break;

      mylist_const_iterator it (in.get_item());
      dihedral_potential new_dihedral;

      it >> new_dihedral.i1;
      it >> new_dihedral.i2;
      it >> new_dihedral.i3;
      it >> new_dihedral.i4;

      if ( new_dihedral.i1 < 0 || new_dihedral.i1 >= this->natoms() ||
           new_dihedral.i2 < 0 || new_dihedral.i2 >= this->natoms() ||
           new_dihedral.i3 < 0 || new_dihedral.i3 >= this->natoms() ||
           new_dihedral.i4 < 0 || new_dihedral.i4 >= this->natoms() ) {
         raise_md_exception ( "atom index in dihedral is out of range" );
      }
      if ( new_dihedral.i1 == new_dihedral.i2 || new_dihedral.i1 == new_dihedral.i3 ||
           new_dihedral.i1 == new_dihedral.i4 || new_dihedral.i2 == new_dihedral.i3 ||
           new_dihedral.i2 == new_dihedral.i4 || new_dihedral.i3 == new_dihedral.i4 ) {
         raise_md_exception ( "atom indexes in dihedral are equal" );
      }

      while ( !it.is_on_end() ) {
         new_dihedral.coefs.push_back( it.get_double() * EXTERNAL_ENERGY_UNIT/ENERGY_UNIT );
         ++it;
      }
      dihedrals.push_back ( new_dihedral );

      if ( exclude_1_4 ) {
         exclusions[new_dihedral.i1*this->natoms()+new_dihedral.i4] = true;
         exclusions[new_dihedral.i4*this->natoms()+new_dihedral.i1] = true;
      }

      ++in;
   }

   for ( in.reset(); in.find( "dihedral_potential_2" ); ++in ) {
      mylist_const_iterator it (in.get_item());
      dihedral_potential_2 new_dihedral;
      
      it >> new_dihedral.i1;
      it >> new_dihedral.i2;
      it >> new_dihedral.i3;
      it >> new_dihedral.i4;

      if ( new_dihedral.i1 < 0 || new_dihedral.i1 >= this->natoms() ||
           new_dihedral.i2 < 0 || new_dihedral.i2 >= this->natoms() ||
           new_dihedral.i3 < 0 || new_dihedral.i3 >= this->natoms() ||
           new_dihedral.i4 < 0 || new_dihedral.i4 >= this->natoms() ) {
         raise_md_exception ( "atom index in dihedral is out of range" );
      }
      if ( new_dihedral.i1 == new_dihedral.i2 || new_dihedral.i1 == new_dihedral.i3 ||
           new_dihedral.i1 == new_dihedral.i4 || new_dihedral.i2 == new_dihedral.i3 ||
           new_dihedral.i2 == new_dihedral.i4 || new_dihedral.i3 == new_dihedral.i4 ) {
         raise_md_exception ( "atom indexes in dihedral are equal" );
      }

      new_dihedral.k = it.get_double() * EXTERNAL_ENERGY_UNIT/ENERGY_UNIT;
      ++it;
      new_dihedral.p = it.get_int ();
      if ( new_dihedral.p < 1 ) {
         raise_md_exception ( "p value in dihedral_potential_2 is out of range" );
      }
      ++it;
      new_dihedral.b0 = it.get_double() * SI_PI/180;

      dihedrals_2.push_back ( new_dihedral );

      if ( exclude_1_4 ) {
         exclusions[new_dihedral.i1*this->natoms()+new_dihedral.i4] = true;
         exclusions[new_dihedral.i4*this->natoms()+new_dihedral.i1] = true;
      }
   }

   for ( in.reset(); in.find( "harmonic_dihedral" ); ++in ) {
      mylist_const_iterator it (in.get_item());
      harmonic_dihedral new_dihedral;
      
      it >> new_dihedral.i1;
      it >> new_dihedral.i2;
      it >> new_dihedral.i3;
      it >> new_dihedral.i4;

      if ( new_dihedral.i1 < 0 || new_dihedral.i1 >= this->natoms() ||
           new_dihedral.i2 < 0 || new_dihedral.i2 >= this->natoms() ||
           new_dihedral.i3 < 0 || new_dihedral.i3 >= this->natoms() ||
           new_dihedral.i4 < 0 || new_dihedral.i4 >= this->natoms() ) {
         raise_md_exception ( "atom index in dihedral is out of range" );
      }
      if ( new_dihedral.i1 == new_dihedral.i2 || new_dihedral.i1 == new_dihedral.i3 ||
           new_dihedral.i1 == new_dihedral.i4 || new_dihedral.i2 == new_dihedral.i3 ||
           new_dihedral.i2 == new_dihedral.i4 || new_dihedral.i3 == new_dihedral.i4 ) {
         raise_md_exception ( "atom indexes in dihedral are equal" );
      }

      new_dihedral.k = it.get_double() * EXTERNAL_ENERGY_UNIT/ENERGY_UNIT; // kJ/mol / radian^2
      ++it;
      new_dihedral.b0 = it.get_double() * SI_PI/180;

      harmonic_dihedrals.push_back ( new_dihedral );

      if ( exclude_1_4 ) {
         exclusions[new_dihedral.i1*this->natoms()+new_dihedral.i4] = true;
         exclusions[new_dihedral.i4*this->natoms()+new_dihedral.i1] = true;
      }
   }

   for ( in.reset(); in.find( "exclusion" ); ++in ) {
      mylist_const_iterator it (in.get_item());
      int i1, i2;
      
      it >> i1 >> i2;
      
      if ( i1 < 0 || i1 >= this->natoms() || i2 < 0 || i2 >= this->natoms() ) {
         raise_md_exception ( "atom index in exclusion is out of range" );
      }
      if ( i1 == i2 ) {
         raise_md_exception ( "atom indexes in exclusion are equal" );
      }

      exclusions[i1*this->natoms()+i2] = true;
   }

   in.reset(); 
   if ( in.find( "exclude_all" ) ) {
      std::fill_n ( exclusions, this->natoms()*this->natoms(), true );
   }


   {
      bool *X = new bool[this->natoms()*this->natoms()];
      std::copy ( auto_exclusions, auto_exclusions + this->natoms()*this->natoms(), X );

      gen_auto_exclusions ( X, auto_exclusions, this->natoms(), exclude_1_4 );

      int i, j;
      for ( i = 0; i < this->natoms(); ++i ) {
         for ( j = 0; j < this->natoms(); ++j ) {
            this->exclusions[i*this->natoms()+j] = this->exclusions[i*this->natoms()+j] || auto_exclusions[i*this->natoms()+j];
         }
      }
      delete[] X;
   }
   delete[] auto_exclusions;

   for ( in.reset(); in.find( "unexclude" ); ++in ) {
      mylist_const_iterator it (in.get_item());
      int i1, i2;
      
      it >> i1 >> i2;
      
      if ( i1 < 0 || i1 >= this->natoms() || i2 < 0 || i2 >= this->natoms() ) {
         raise_md_exception ( "atom index in unexclude is out of range" );
      }
      if ( i1 == i2 ) {
         raise_md_exception ( "atom indexes in unexclude are equal" );
      }

      this->exclusions[i1*this->natoms()+i2] = false;
      this->exclusions[i2*this->natoms()+i1] = false;
   }   
}

namespace {

// Generate auto exclutions between atoms, seperated by 2 or 3 bonds
// Let X be a matrix and Xij == true when atoms i and j are separated
// exactly by one bond. Then (X^2-I)ij == true when atoms i and j are
// separated exactly by two bonds. (X^3-I)ij == true when atoms i and j are
// separated exactly by three bonds.
// We need to construct matrix X + X^2 + X^3 + I. Identity matrix is
// needed to exclude interaction of atom with itself.
// I + X*(I + X*(I + X))

void gen_auto_exclusions ( const bool *X, bool *Res, int n, bool exclude_1_4 ) {
   int i, j, k, l;

   for ( i = 0; i < n; ++i ) { // calculate X
      for ( j = 0; j < n; ++j ) {
         Res[i*n+j] = X[i*n+j];
      }
   }

   for ( i = 0; i < n; ++i ) {
      for ( j = 0; j < n; ++j ) {
         for ( k = 0; k < n; ++k ) { // calculate X^2 and add
            if ( X[i*n+k] && X[k*n+j] ) {
               Res[i*n+j] = true;
               break;
            }
         }

         if ( exclude_1_4 ) { // calculate X^3 and add
            for ( k = 0; k < n; ++k ) {
               if ( X[i*n+k] ) {
                  for ( l = 0; l < n; ++l ) {
                     if ( X[k*n+l] && X[l*n+j] ) {
                        Res[i*n+j] = true;
                        break;
                     }
                  }
               }
            }
         }

         //Res[j*n+i] = Res[i*n+j];
      }
   } // end of for ( i = 1; i < n; ++i )
}

} // end of unnamed namespace

template <class Base_part>
shaked_particle_type<Base_part>::~shaked_particle_type () {
   delete[] exclusions;
}

template <class Base_part>
std::unique_ptr<Base_part> shaked_particle_type<Base_part>::create ( vect origin ) const
{
   return std::make_unique<shaked_particle<Base_part> > ( this, origin );
}

template <class Base_part>
std::unique_ptr<Base_part> shaked_particle_type<Base_part>::create ( const Base_part *src, vect cmpos ) const
{
   return std::make_unique<shaked_particle<Base_part> > ( *dynamic_cast<const shaked_particle<Base_part>*>(src), cmpos );
}

template <class Base_part>
int shaked_particle_type<Base_part>::shape () const {
   if ( this->natoms() == 1 )
      return particle_type::point;
   if ( this->natoms() == 2 )
      return particle_type::linear;
   if ( this->natoms() >= 3 )
      return particle_type::general;
   return -1;
}

template <class Base_part>
int shaked_particle_type<Base_part>::nDegFree () const {
   return NTotDegFree;
}

template <class Base_part>
int shaked_particle_type<Base_part>::nRotDegFree () const {
   switch ( shape() ) {
   case particle_type::point:
      return 0;
      break;
   case particle_type::linear:
      return 2;
      break;
   case particle_type::general:
      return 3;
      break;
   }
   return -1;
}

template <class Base_part>
int shaked_particle_type<Base_part>::nVibrDegFree () const {
   return nDegFree() - nRotDegFree() - 3;
}

template <class Base_part>
void shaked_particle_type<Base_part>::print ( std::ostream& out ) const {
   this->particle_type::print ( out );

   out << "SHAKE algorithm is used!";
   out << "\nSHAPE: ";
   switch ( shape() ) {
   case particle_type::point:
      out << "point";
      break;
   case particle_type::linear:
      out << "linear";
      break;
   case particle_type::general:
      out << "nonlinear";
      break;
   }
   
   out << "\nDegrees of freedom: " << this->nDegFree() << std::endl;
   
   if ( this->constraints.size() > 0 )
      out << this->constraints.size()          << " distance constraints\n";
   if ( this->bond_constraints.size() > 0 )
      out << this->bond_constraints.size()     << " bond constraints\n";
   if ( this->angle_constraints.size() > 0 )
      out << this->angle_constraints.size()    << " angle constraints\n";
   if ( this->dihedral_constraints.size() > 0 )
      out << this->dihedral_constraints.size() << " dihedral constraints\n";
   if ( this->bonds.size() > 0 )
      out << this->bonds.size()       << " bond potentials\n";
   if ( this->angles.size() > 0 )
      out << this->angles.size()      << " angle potentials\n";
   if ( this->angles_cos.size() > 0 )
      out << this->angles_cos.size()  << " angle cosine potentials\n";
   if ( this->dihedrals.size() > 0 )
      out << this->dihedrals.size()   << " dihedral potentials\n";
   if ( this->dihedrals_2.size() > 0 )
      out << this->dihedrals_2.size() << " dihedral potentials of type 2\n";
   if ( this->harmonic_dihedrals.size() > 0 )
      out << this->harmonic_dihedrals.size() << " harmonic dihedral potentials\n";

   Message << "exclusions for " << this->name() << "\n";
   for ( int i = 0; i < this->natoms(); ++i ) {
      for ( int j = 0; j < this->natoms(); ++j ) {
         Message << " " << static_cast<int>(this->exclusions[i*this->natoms()+j]);
      }
      Message << "\n";
   }
   
   this->Base::print ( out );
}

template <class Base_part>
void shaked_particle_type<Base_part>::molAxesCalc ( const basic_particle& atoms, vect axes[3] ) const {
   axes[0] = vect ( 1, 0, 0);
   axes[1] = vect ( 0, 1, 0);
   axes[2] = vecmul ( axes[0], axes[1] );
}


// ==================================================================================
template <class Base>
shaked_particle<Base>::shaked_particle ( const type_t *t, vect origin )
: Base(t,origin), type(t)
{
   newpositions = new vect[this->natoms()];
}

template <class Base>
shaked_particle<Base>::shaked_particle ( const shaked_particle &src, vect cmpos )
: Base(src,cmpos), type(src.type)
{
   newpositions = new vect[this->natoms()];
}

template <class Base>
shaked_particle<Base>::~shaked_particle () {
   delete[] newpositions;
}

/*template <class Base>
void shaked_particle<Base>::read ( std::istream& in ) {
   particle::read ( in );
}*/


// ============================================================================
template <class Base>
void shaked_particle<Base>::move ( double tstep, int substeps, std::size_t thread_no ) {
   switch ( type->shape () ) {
   case particle_type::point:
      {
         basic_particle::reference a = (*this)[0];
         
         a.v() += 0.5*tstep * this->getLongCMAcceleration (); // long_move
         
         const double short_dt = tstep/static_cast<double>(substeps);
         for ( int i = 0; i < substeps; ++i ) {
            // v(t+0.5dt) = v(t) + 0.5*dt*f(t)/m
            a.v() += 0.5*short_dt * this->getShortCMAcceleration (); // == 0 because there are no internal forces
            // r(t+dt) = r(t) + dt*v(t+0.5dt)
            a.r() += short_dt * a.v();       
            
            this->unPBC_CMPos += short_dt * a.v();
            
            while ( a.r().x >  LBOX ) a.r().x -= LBOX;
            while ( a.r().x < 0.0 )   a.r().x += LBOX;
            
            while ( a.r().y >  LBOX ) a.r().y -= LBOX;
            while ( a.r().y < 0.0 )   a.r().y += LBOX;
            
            while ( a.r().z >  LBOX ) a.r().z -= LBOX;
            while ( a.r().z < 0.0 )   a.r().z += LBOX;
            
            // calculate bonded forces
            // there are no internal forces
            
            // make short corrector step
            a.v() += 0.5*short_dt * this->getShortCMAcceleration (); // == 0
         }
      }
      break;
   case particle_type::linear:
   case particle_type::general:
      {
         for ( basic_particle::reference a: *this ) {
            a.v() += 0.5*tstep * a.f().far / a.mass();
         }
         // applying velocity constraints
         //internal_stress.set_to_zero ();
         this->vrattle_stress.set_to_zero ();
         this->v_rattle ( tstep, this->vrattle_stress );
         
         const double short_dt = tstep/static_cast<double>(substeps);
         
         for ( int s = 0; s < substeps; ++s ) {
            const vect RCMstart = this->getCMPos ();
            vect *newpositions = this->newpositions; // short alias
            
            // applying Verlete algorithm for predicting atoms positions
            for ( basic_particle::reference a: *this ) {
               a.v() += 0.5*short_dt * a.f().near / a.mass();
            }
            
            this->internal_stress.set_to_zero ();
            this->v_rattle ( short_dt, this->internal_stress );
            
            for ( int i = 0; i < this->natoms (); ++i ) {
               basic_particle::reference a = (*this)[i];
               
               //a.v() += 0.5*short_dt * a.f().near / a.mass();
               
               if ( K_StartRUN ) {     
                  vect delta_r = short_dt * a.v();
                  
                  if ( delta_r.x > 0.001 ) {
                     delta_r.x = 0.001;
                  }
                  if ( delta_r.x < -0.001 ) {
                     delta_r.x = -0.001;
                  }
                  if ( delta_r.y > 0.001 ) {
                     delta_r.y = 0.001;
                  }
                  if ( delta_r.y < -0.001 ) {
                     delta_r.y = -0.001;
                  }
                  if ( delta_r.z > 0.001 ) {
                     delta_r.z = 0.001;
                  }
                  if ( delta_r.z < -0.001 ) {
                     delta_r.z = -0.001;
                  }
                  
                  newpositions[i] = a.r() + delta_r;
               }
               else {
                  newpositions[i] = a.r() + short_dt*a.v();
               }
            }
            
            // applying constraints
            this->rattle ( short_dt );
            
            for ( std::size_t i = 0; i < this->natoms(); ++i ) {
               basic_particle::reference a = (*this)[i];
               a.v() = (newpositions[i] - a.r()) / short_dt;
               a.r() = newpositions[i];
            }
            
            const vect Rbak = this->getCMPos ();
            this->unPBC_CMPos += Rbak - RCMstart;
            
            // applying PBC
            vect Rnew = Rbak;
            while ( Rnew.x >  LBOX ) Rnew.x -= LBOX;
            while ( Rnew.x < 0.0 ) Rnew.x += LBOX;
            
            while ( Rnew.y >  LBOX ) Rnew.y -= LBOX;
            while ( Rnew.y < 0.0 ) Rnew.y += LBOX;
            
            while ( Rnew.z >  LBOX ) Rnew.z -= LBOX;
            while ( Rnew.z < 0.0 ) Rnew.z += LBOX;
            
            for ( basic_particle::reference a: *this ) {
               a.r() = a.r() - Rbak + Rnew;
            }
            
            // calculate bonded forces
            this->reset_near_forces ();
            this->bonded_forces ( thread_no );
            this->sync_near_forces ();
            
            // short corrector step
            for ( basic_particle::reference a: *this ) {
               a.v() += 0.5*short_dt * a.f().near / a.mass();
            }
            this->v_rattle ( short_dt, this->internal_stress );
         }
      }
      break;
   default:
      raise_md_exception ( "shaked_particle<Base>::move(): illegal value of shaked_particle shape" );
   }
}


template <class Base>
void shaked_particle<Base>::rattle ( double tstep ) {
   //    positions part of the RATTLE algorithm
   // Hans C. Andersen  "Rattle: A "Velocity" Version of the Shake Algorithm for
   // molecular Dynamics Calculations" // J. Comp. Phys., 1983. -Vol. 52, No. 1, -P. 24-34.
   const int MAX_RATTLE_ITERATIONS = 1000;
   const double tolerance = 4.5e-9; // nm
   
   vect *newpositions = this->newpositions; // short alias
         
   int iter;
   
   for ( iter = 0; iter < MAX_RATTLE_ITERATIONS; ++iter ) {
      bool finished = true;
      
      for ( const auto& pot: type->dihedral_constraints ) {
         mdnaes::dihedral d ( newpositions[pot.i1],
                              newpositions[pot.i2],
                              newpositions[pot.i3],
                              newpositions[pot.i4] );
         
         double dBeta = pot.beta - d.beta();
         if ( dBeta >  SI_PI ) dBeta -= 2*SI_PI;
         if ( dBeta < -SI_PI ) dBeta += 2*SI_PI;
         
         if ( std::fabs(dBeta) > 4.5e-9 ) {
            // Beta gradients: g1, g2, g3, g4
            
            // forces are of the form:
            // f1 = X*g1; f2 = X*g2; f3 = X*g3; f4 = X*g4;
            // accelerations:
            // a1 = X*g1/m1; a2 = X*g2/m2; a3 = X*g3/m3; a4 = X*g4/m4;
            // displacements (dr = a*dt^2/2):
            // dr1 = X*dt^2/2/m1*g1; ...
            //
            // dBeta = g1*dr1 + g2*dr2 + g3*dr3 + g4*dr4; (== pot.beta - B)
            // dBeta = X*dt^2/2*(g1^2/m1 + g2^2/m2 + g3^2/m3 + g4^2/m4)
            // X = dBeta / (g1^2/m1 + g2^2/m2 + g3^2/m3 + g4^2/m4) * 2/dt^2
            const double X = dBeta*2/tstep/tstep /
            ( sqr(d.grad1())/(*this)[pot.i1].mass()
            + sqr(d.grad2())/(*this)[pot.i2].mass()
            + sqr(d.grad3())/(*this)[pot.i3].mass()
            + sqr(d.grad4())/(*this)[pot.i4].mass() );
            
            const vect f1 = X*d.grad1();
            const vect f2 = X*d.grad2();
            const vect f3 = X*d.grad3();
            const vect f4 = X*d.grad4();
            
            direct_product_accumulate ( f1, newpositions[pot.i1], this->internal_stress.data() );
            direct_product_accumulate ( f2, newpositions[pot.i2], this->internal_stress.data() );
            direct_product_accumulate ( f3, newpositions[pot.i3], this->internal_stress.data() );
            direct_product_accumulate ( f4, newpositions[pot.i4], this->internal_stress.data() );
            
            newpositions[pot.i1] += (tstep*tstep/2/(*this)[pot.i1].mass())*f1;
            newpositions[pot.i2] += (tstep*tstep/2/(*this)[pot.i2].mass())*f2;
            newpositions[pot.i3] += (tstep*tstep/2/(*this)[pot.i3].mass())*f3;
            newpositions[pot.i4] += (tstep*tstep/2/(*this)[pot.i4].mass())*f4;
            
            finished = false;
         }
      } // end of dihedral_constraints
      
      for ( const auto& pot: type->angle_constraints ) {
         mdnaes::angle a ( newpositions[pot.i1],
                           newpositions[pot.i2],
                           newpositions[pot.i3] );
         
         double dAlpha = pot.alpha - a.alpha();
         if ( dAlpha >  SI_PI ) dAlpha -= 2*SI_PI;
         if ( dAlpha < -SI_PI ) dAlpha += 2*SI_PI;
         
         if ( std::fabs(dAlpha) > 4.5e-9 ) {
            // Alpha gradients: g1, g2, g3
            
            // forces are of the form:
            // f1 = X*g1; f2 = X*g2; f3 = X*g3;
            // accelerations:
            // a1 = X*g1/m1; a2 = X*g2/m2; a3 = X*g3/m3;
            // displacements (dr = a*dt^2/2):
            // dr1 = X*dt^2/2/m1*g1; ...
            //
            // dAlpha = g1*dr1 + g2*dr2 + g3*dr3; (== pot.alpha - Alpha)
            // dAlpha = X*dt^2/2*(g1^2/m1 + g2^2/m2 + g3^2/m3)
            // X = dAlpha / (g1^2/m1 + g2^2/m2 + g3^2/m3) * 2/dt^2
            const double X = dAlpha*2/tstep/tstep /
            ( sqr(a.grad1())/(*this)[pot.i1].mass()
            + sqr(a.grad2())/(*this)[pot.i2].mass()
            + sqr(a.grad3())/(*this)[pot.i3].mass() );
            
            const vect f1 = X*a.grad1();
            const vect f2 = X*a.grad2();
            const vect f3 = X*a.grad3();
            
            direct_product_accumulate ( f1, newpositions[pot.i1], this->internal_stress.data() );
            direct_product_accumulate ( f2, newpositions[pot.i2], this->internal_stress.data() );
            direct_product_accumulate ( f3, newpositions[pot.i3], this->internal_stress.data() );
            
            newpositions[pot.i1] += (tstep*tstep/2/(*this)[pot.i1].mass())*f1;
            newpositions[pot.i2] += (tstep*tstep/2/(*this)[pot.i2].mass())*f2;
            newpositions[pot.i3] += (tstep*tstep/2/(*this)[pot.i3].mass())*f3;
            
            finished = false;
         }
      } // end of angle_constraints
      
      for ( int i = 0; i < type->constraints.size(); ++i ) {
         const int at1 = type->constraints[i].i1;
         const int at2 = type->constraints[i].i2;
         const vect s = newpositions[at1] - newpositions[at2];
         const double err2 = s*s - type->constraints[i].sqr_dist;
         if ( fabs(err2) > 2*tolerance*sqrt(type->constraints[i].sqr_dist) ) {
            // this constraint not yet satisfied
            const double m1i = 1.0 / (*this)[at1].mass();
            const double m2i = 1.0 / (*this)[at2].mass();
            const vect rij = (*this)[at1].r() - (*this)[at2].r();
            const double gt = 0.5*err2/((s*rij)*(m1i+m2i));
            newpositions[at1] -= rij * (gt*m1i);
            newpositions[at2] += rij * (gt*m2i);
            
            const vect fij = -(gt/(tstep*tstep)) * rij;
            direct_product_accumulate ( fij, rij, this->internal_stress.data() );
            
            finished = false;
         }
      } // end of distance_constraints
      
      for ( const auto& pot: type->bond_constraints ) {
         const vect s = newpositions[pot.i2] - newpositions[pot.i1];
         const double err2 = s*s - pot.sqr_dist;
         
         if ( std::fabs(err2) > 2*tolerance*std::sqrt(pot.sqr_dist) ) {
            // this constraint not yet satisfied
            const double m1i = 1.0 / (*this)[pot.i1].mass();
            const double m2i = 1.0 / (*this)[pot.i2].mass();
            const vect rij = (*this)[pot.i2].r() - (*this)[pot.i1].r();
            const double gt = 0.5 * err2 / ((s*rij)*(m1i+m2i));
            newpositions[pot.i1] += rij * (gt*m1i);
            newpositions[pot.i2] -= rij * (gt*m2i);
            
            /* dr2 = dv2*tstep
             * dv2 = a2*tstep = f2*m2i*tstep   (v2 at half step: v(t+dt/2) = v(t-dt/2) + a*dt)
             * dr2 = -rij*gt*m2i = f2*m2i*tstep*tstep
             * f2 = -rij*gt/tstep/tstep
             */
            
            const vect fij = -(gt/(tstep*tstep)) * rij;
            direct_product_accumulate ( fij, rij, this->internal_stress.data() );
            
            finished = false;
         }
      } // end of bond_constraints
      
      if ( finished )
         break;
   }
   
   if ( MAX_RATTLE_ITERATIONS == iter ) {
      double maxerror = 0.0;
      int i1 = -1, i2 = -1;
      std::size_t i;
      
      for ( int i = 0; i < type->bond_constraints.size(); ++i ) {
         int at1 = type->bond_constraints[i].i1;
         int at2 = type->bond_constraints[i].i2;
         const vect s = newpositions[at1] - newpositions[at2];
         double err = fabs(norm(s) - sqrt(type->bond_constraints[i].sqr_dist));
         if ( err > maxerror ) {
            maxerror = err;
            i1 = at1;
            i2 = at2;
         }
      }
      for ( int i = 0; i < type->constraints.size(); ++i ) {
         int at1 = type->constraints[i].i1;
         int at2 = type->constraints[i].i2;
         const vect s = newpositions[at1] - newpositions[at2];
         double err = fabs(norm(s) - sqrt(type->constraints[i].sqr_dist));
         if ( err > maxerror ) {
            maxerror = err;
            i1 = at1;
            i2 = at2;
         }
      }
      Error << "Constraints in positions part of RATTLE not satisfied for r(" << i1 << "," << i2 << ").";
      Error << " Maximum error = " << mdformat(18,15) << maxerror << std::endl;
   }
}


template <class Base>
void shaked_particle<Base>::correctorStep ( double tstep ) {
   switch ( type->shape () ) {
   case particle_type::point:
      {
         basic_particle::reference a = (*this)[0];
         
         // v(t) = v(t-dt/2) + 0.5*dt*a(t)
         a.v() += 0.5*tstep * this->getLongCMAcceleration ();
      }
      break;
   case particle_type::linear:
   case particle_type::general:
      {
         //    velocity part of the RATTLE algorithm
         // Hans C. Andersen  "Rattle: A "Velocity" Version of the Shake Algorithm for
         // molecular Dynamics Calculations" // J. Comp. Phys., 1983. -Vol. 52, No. 1. -P. 24-34.

         // applying Verlete algorithm for updating atoms velocities
         for ( basic_particle::reference a: *this ) {
            a.v() += 0.5*tstep * a.f().far / a.mass();
         }

         // at this point we have inernal stress, calculated from internal forces and rattle corrections.
         // applying constraints
         this->v_rattle ( tstep, this->vrattle_stress );
      }
      break;
   default:
      raise_md_exception ( "shaked_particle<Base>::correctorStep(): illegal value of shaked_particle shape" );
   }
}

template <class Base>
void shaked_particle<Base>:: v_rattle ( double tstep, matrix_3x3& stress ) {
   // orthogonolize velocities to constraints.
   int iter;
   const int MAX_RATTLE_ITERATIONS = 100;
   const double tolerance = 5.0e-6;
   for ( iter = 0; iter < MAX_RATTLE_ITERATIONS; ++iter ) {
      bool finished = true;
      
      for ( const auto& pot: type->dihedral_constraints ) {
         basic_particle::reference at1 = (*this)[pot.i1];
         basic_particle::reference at2 = (*this)[pot.i2];
         basic_particle::reference at3 = (*this)[pot.i3];
         basic_particle::reference at4 = (*this)[pot.i4];
         
         mdnaes::dihedral d ( at1.r(), at2.r(), at3.r(), at4.r() );
         
         // velocities must be orthogonal to B gradient: (and consequently to cosB gradient)
         // v1*g1 + v2*g2 + v3*g3 + v4*g4 = 0
         const double err = at1.v()*d.grad1() + at2.v()*d.grad2() + at3.v()*d.grad3() + at4.v()*d.grad4();
         
         if ( tstep*fabs(err) > tolerance ) {
            // dv1 = X*g1*tstep/m1
            // derr = dv1*g1 + dv2*g2 + dv3*g3 + dv4*g4 = -err
            // derr = X*tstep * (g1^2/m1 + g2^2/m2 + g3^2/m3 + g4^2/m4)
            // X = -err / tstep / (g1^2/m1 + g2^2/m2 + g3^2/m3 + g4^2/m4)
            // f1 = X*g1
            
            const double X = -err / tstep / (sqr(d.grad1())/at1.mass()
            + sqr(d.grad2())/at2.mass() + sqr(d.grad3())/at3.mass()
            + sqr(d.grad4())/at4.mass());
            
            const vect f1 = X*d.grad1();
            const vect f2 = X*d.grad2();
            const vect f3 = X*d.grad3();
            const vect f4 = X*d.grad4();
            
            at1.v() += tstep/at1.mass() * f1;
            at2.v() += tstep/at2.mass() * f2;
            at3.v() += tstep/at3.mass() * f3;
            at4.v() += tstep/at4.mass() * f4;
            
//             direct_product_accumulate ( f1, at1.r(), this->internal_stress.data() );
//             direct_product_accumulate ( f2, at2.r(), this->internal_stress.data() );
//             direct_product_accumulate ( f3, at3.r(), this->internal_stress.data() );
//             direct_product_accumulate ( f4, at4.r(), this->internal_stress.data() );
            direct_product_accumulate ( f1, at1.r(), stress.data() );
            direct_product_accumulate ( f2, at2.r(), stress.data() );
            direct_product_accumulate ( f3, at3.r(), stress.data() );
            direct_product_accumulate ( f4, at4.r(), stress.data() );
            
            finished = false;
         }
      } // end of dihedral_constraints
      
      for ( const auto& pot: type->angle_constraints ) {
         basic_particle::reference at1 = (*this)[pot.i1];
         basic_particle::reference at2 = (*this)[pot.i2];
         basic_particle::reference at3 = (*this)[pot.i3];
         
         mdnaes::angle a ( at1.r(), at2.r(), at3.r() );
         
         // velocities must be orthogonal to alpha gradient:
         // v1*g1 + v2*g2 + v3*g3 = 0
         const double err = at1.v()*a.grad1() + at2.v()*a.grad2() + at3.v()*a.grad3();
         
         if ( tstep*fabs(err) > 4.5e-9 ) {
            // dv1 = X*g1*tstep/m1
            // derr = dv1*g1 + dv2*g2 + dv3*g3 = -err
            // derr = X*tstep * (g1^2/m1 + g2^2/m2 + g3^2/m3)
            // X = -err / tstep / (g1^2/m1 + g2^2/m2 + g3^2/m3)
            // f1 = X*g1
            
            const double X = -err / tstep /
            ( sqr(a.grad1())/at1.mass()
            + sqr(a.grad2())/at2.mass()
            + sqr(a.grad3())/at3.mass() );
            
            const vect f1 = X*a.grad1();
            const vect f2 = X*a.grad2();
            const vect f3 = X*a.grad3();
            
            at1.v() += tstep/at1.mass() * f1;
            at2.v() += tstep/at2.mass() * f2;
            at3.v() += tstep/at3.mass() * f3;
            
//             direct_product_accumulate ( f1, at1.r(), this->internal_stress.data() );
//             direct_product_accumulate ( f2, at2.r(), this->internal_stress.data() );
//             direct_product_accumulate ( f3, at3.r(), this->internal_stress.data() );
            direct_product_accumulate ( f1, at1.r(), stress.data() );
            direct_product_accumulate ( f2, at2.r(), stress.data() );
            direct_product_accumulate ( f3, at3.r(), stress.data() );
            
            finished = false;
         }
      } // end of angle_constraints
      
      for ( const auto& pot: type->bond_constraints ) {
         basic_particle::reference at1 = (*this)[pot.i1];
         basic_particle::reference at2 = (*this)[pot.i2];
         
         const vect rij = at2.r() - at1.r();
         double err = rij * (at2.v() - at1.v());
         
         if ( tstep*fabs(err) > tolerance*std::sqrt(pot.sqr_dist) ) {
            // this constraint not yet satisfied
            const double m1i = 1.0 / at1.mass();
            const double m2i = 1.0 / at2.mass();
            double k = err / (pot.sqr_dist*(m1i+m2i));
            at1.v() += rij * (k*m1i);
            at2.v() -= rij * (k*m2i);
            
            /* v2new-v1new == v2 - rij*k*m1i - v1 - rij*k*m2i
             * err_new == rij * (v2 - rij*k*m1i - v1 - rij*k*m2i)
             * == err - rij2*k*(m1i+m2i)
             * == err - err * rij2 / (pot.sqr_dist*(m1i+m2i)) * (m1i+m2i)
             * == err - err == 0
             * 
             * rij*k*m1i == delta_v1 == a1*tstep = f1*m1i*tstep
             * f1 = rij*k/tstep = -f2
             * fij = f2 = -f1 = -rij*k/tstep
             */
            
            const vect fij = -(k/tstep) * rij;
            //direct_product_accumulate ( fij, rij, this->internal_stress.data() );
            direct_product_accumulate ( fij, rij, stress.data() );
            
            finished = false;
         }
      } // end of bond_constraints
      
      for ( const auto& pot: type->constraints ) {
         basic_particle::reference at1 = (*this)[pot.i1];
         basic_particle::reference at2 = (*this)[pot.i2];
         
         const vect rij = at2.r() - at1.r();
         double err = rij * (at2.v() - at1.v());
         
         if ( tstep*fabs(err) > tolerance*std::sqrt(pot.sqr_dist) ) {
            // this constraint not yet satisfied
            const double m1i = 1.0 / at1.mass();
            const double m2i = 1.0 / at2.mass();
            double k = err / (pot.sqr_dist*(m1i+m2i));
            at1.v() += rij * (k*m1i);
            at2.v() -= rij * (k*m2i);
            
            const vect fij = -(k/tstep) * rij;
            //direct_product_accumulate ( fij, rij, this->internal_stress.data() );
            direct_product_accumulate ( fij, rij, stress.data() );
            
            finished = false;
         }
      } // end of distance_constraints
      
      if ( finished )
         break;
   }
   
   if ( iter == MAX_RATTLE_ITERATIONS ) {
      Error << "constraints in velocity part of RATTLE not satisfied" << std::endl;
   }
}

template <class Base>
void shaked_particle<Base>::bonded_forces ( std::size_t thread_no ) {
   // because all particles are independent of each other, thread_no can be equal 0.
   // Calling two instances of internal_forces () for one particle in parallel is illegal!
   
   //System_therm_values_t& Therm_values = TL_Therm_values[thread_no];
   this->m_Ubond = 0.0;
   this->m_Uangle = 0.0;
   this->m_Udihedral = 0.0;
   this->m_Udihedral_2 = 0.0;
   this->m_Uharmonic_dihedral = 0.0;

   // bonds:
   for ( const auto& pot: this->type->bonds ) {
      //const typename shaked_particle_type<Base>::bond_potential& pot = this->type->bonds[i];
      basic_particle::reference at1 = (*this)[pot.i1];
      basic_particle::reference at2 = (*this)[pot.i2];

      const vect r12 = at2.r() - at1.r();
      const double x = (norm(r12) - pot.eqv_dist) / pot.eqv_dist;

      // U(x) = sum( C[c]*pow(x,c+2), c=0.. );
      double U = 0.0;
      for ( int c = pot.coefs.size()-1; c >= 0; --c ) {
         U = U*x + pot.coefs.at(c);
      }
      U *= x*x;

      this->m_Ubond += U;

      double Ud = 0.0; // Ud == diff(U,x)
      for ( int c = pot.coefs.size()-1; c >= 0; --c ) {
         Ud = Ud*x + (c+2)*pot.coefs.at(c);
      }
      Ud *= x/pot.eqv_dist;

      const vect f = -(Ud/norm(r12)) * r12;
      at1.f(thread_no).near -= f;
      at2.f(thread_no).near += f;

      this->internal_stress[0][0] += r12.x*f.x;
      this->internal_stress[0][1] += r12.x*f.y;
      this->internal_stress[0][2] += r12.x*f.z;
      this->internal_stress[1][0] += r12.y*f.x;
      this->internal_stress[1][1] += r12.y*f.y;
      this->internal_stress[1][2] += r12.y*f.z;
      this->internal_stress[2][0] += r12.z*f.x;
      this->internal_stress[2][1] += r12.z*f.y;
      this->internal_stress[2][2] += r12.z*f.z;
   }

   // angles:
   for ( const auto& pot: this->type->angles ) {
      //const typename shaked_particle_type<Base>::angle_potential& pot = this->type->angles[i];
      basic_particle::reference at1 = (*this)[pot.i1];
      basic_particle::reference at2 = (*this)[pot.i2];
      basic_particle::reference at3 = (*this)[pot.i3];

      mdnaes::angle a ( at1.r(), at2.r(), at3.r() );

      const double x = (a.alpha() - pot.eqv_angle) / pot.eqv_angle;

      int c;

      // U(x) = sum( C[c]*pow(x,c+2), c=0.. );
      double U = 0.0;
      for (c = pot.coefs.size()-1; c >= 0; --c ) {
         U = U*x + pot.coefs.at(c);
      }
      U *= x*x;

      this->m_Uangle += U;

      double Ud = 0.0; // Ud == diff(U,x)
      for ( c = pot.coefs.size()-1; c >= 0; --c ) {
         Ud = Ud*x + (c+2)*pot.coefs.at(c);
      }
      Ud *= x;
      Ud /= pot.eqv_angle;

      const vect f1 =  -Ud*a.grad1();
      const vect f2 =  -Ud*a.grad2();
      const vect f3 =  -Ud*a.grad3();

      at1.f(thread_no).near += f1;
      at2.f(thread_no).near += f2;
      at3.f(thread_no).near += f3;

      direct_product_accumulate ( f1, (*this)[pot.i1].r(), this->internal_stress.data() );
      direct_product_accumulate ( f2, (*this)[pot.i2].r(), this->internal_stress.data() );
      direct_product_accumulate ( f3, (*this)[pot.i3].r(), this->internal_stress.data() );
   }

   // angles (cosine potential):
   for ( const auto& pot: this->type->angles_cos ) {
      basic_particle::reference at1 = (*this)[pot.i1];
      basic_particle::reference at2 = (*this)[pot.i2];
      basic_particle::reference at3 = (*this)[pot.i3];

      mdnaes::angle a ( at1.r(), at2.r(), at3.r() );

      const double U = 0.5*pot.k*(a.cosa()-pot.eqv_cos)*(a.cosa()-pot.eqv_cos);

      this->m_Uangle += U;

      // grad(U) = dU/da * grad(a)
      // dU/da = k*(cos(a)-cos(a0))*dcos(a)/da
      // dU/da = -k*(cos(a)-cos(a0))*sin(a)
      const double dUda = -pot.k*(a.cosa()-pot.eqv_cos)*std::sin(a.alpha());
      
      const vect f1 =  -dUda*a.grad1();
      const vect f2 =  -dUda*a.grad2();
      const vect f3 =  -dUda*a.grad3();

      at1.f(thread_no).near += f1;
      at2.f(thread_no).near += f2;
      at3.f(thread_no).near += f3;

      direct_product_accumulate ( f1, (*this)[pot.i1].r(), this->internal_stress.data() );
      direct_product_accumulate ( f2, (*this)[pot.i2].r(), this->internal_stress.data() );
      direct_product_accumulate ( f3, (*this)[pot.i3].r(), this->internal_stress.data() );
   }
   
   // dihedrals:
   for ( const auto& pot: this->type->dihedrals ) {
      basic_particle::reference at1 = (*this)[pot.i1];
      basic_particle::reference at2 = (*this)[pot.i2];
      basic_particle::reference at3 = (*this)[pot.i3];
      basic_particle::reference at4 = (*this)[pot.i4];

      const mdnaes::dihedral d ( at1.r(), at2.r(), at3.r(), at4.r() );

      double U = 0.0;
      for ( int c = pot.coefs.size()-1; c >= 0; --c ) {
         U = U*d.cosb() + pot.coefs.at(c);
      }
      
      this->m_Udihedral += U;

      double Ud = 0.0; // Ud == diff(U,beta)
      for ( int c = pot.coefs.size()-1; c >= 1; --c ) {
         Ud = Ud*d.cosb() + c*pot.coefs.at(c);
      }
      Ud *= -d.sinb();

      const vect f1 = -Ud * d.grad1();
      const vect f2 = -Ud * d.grad2();
      const vect f3 = -Ud * d.grad3();
      const vect f4 = -Ud * d.grad4();

      at1.f(thread_no).near += f1;
      at2.f(thread_no).near += f2;
      at3.f(thread_no).near += f3;
      at4.f(thread_no).near += f4;

      direct_product_accumulate ( f1, at1.r(), this->internal_stress.data() );
      direct_product_accumulate ( f2, at2.r(), this->internal_stress.data() );
      direct_product_accumulate ( f3, at3.r(), this->internal_stress.data() );
      direct_product_accumulate ( f4, at4.r(), this->internal_stress.data() );
   }

   // dihedrals_2:
   for ( const auto& pot: this->type->dihedrals_2 ) {
      basic_particle::reference at1 = (*this)[pot.i1];
      basic_particle::reference at2 = (*this)[pot.i2];
      basic_particle::reference at3 = (*this)[pot.i3];
      basic_particle::reference at4 = (*this)[pot.i4];

      const mdnaes::dihedral d ( at1.r(), at2.r(), at3.r(), at4.r() );

      const double U = pot.k * ( 1 + std::cos(pot.p*d.beta()-pot.b0) );
      
      this->m_Udihedral_2 += U;

      const double Ud = -pot.k*pot.p * std::sin(pot.p*d.beta()-pot.b0); // diff(U,beta)

      const vect f1 = -Ud * d.grad1();
      const vect f2 = -Ud * d.grad2();
      const vect f3 = -Ud * d.grad3();
      const vect f4 = -Ud * d.grad4();

      at1.f(thread_no).near += f1;
      at2.f(thread_no).near += f2;
      at3.f(thread_no).near += f3;
      at4.f(thread_no).near += f4;

      direct_product_accumulate ( f1, at1.r(), this->internal_stress.data() );
      direct_product_accumulate ( f2, at2.r(), this->internal_stress.data() );
      direct_product_accumulate ( f3, at3.r(), this->internal_stress.data() );
      direct_product_accumulate ( f4, at4.r(), this->internal_stress.data() );
   }

   // harmonic_dihedrals:
   for ( const auto& pot: this->type->harmonic_dihedrals ) {
      basic_particle::reference at1 = (*this)[pot.i1];
      basic_particle::reference at2 = (*this)[pot.i2];
      basic_particle::reference at3 = (*this)[pot.i3];
      basic_particle::reference at4 = (*this)[pot.i4];

      const mdnaes::dihedral d ( at1.r(), at2.r(), at3.r(), at4.r() );

      double dbeta = d.beta()-pot.b0;
      if ( dbeta > SI_PI )
         dbeta -= 2*SI_PI;
      if ( dbeta < -SI_PI )
         dbeta += 2*SI_PI;

      const double U = pot.k / 2 * sqr(dbeta);
      
      this->m_Uharmonic_dihedral += U;

      const double Ud = pot.k * dbeta; // diff(U,beta)

      const vect f1 = -Ud * d.grad1();
      const vect f2 = -Ud * d.grad2();
      const vect f3 = -Ud * d.grad3();
      const vect f4 = -Ud * d.grad4();

      at1.f(thread_no).near += f1;
      at2.f(thread_no).near += f2;
      at3.f(thread_no).near += f3;
      at4.f(thread_no).near += f4;

      direct_product_accumulate ( f1, at1.r(), this->internal_stress.data() );
      direct_product_accumulate ( f2, at2.r(), this->internal_stress.data() );
      direct_product_accumulate ( f3, at3.r(), this->internal_stress.data() );
      direct_product_accumulate ( f4, at4.r(), this->internal_stress.data() );
   }
}

template <class Base>
void shaked_particle<Base>::randomize_velocities () {
   for ( basic_particle::reference a: *this ) {
      const double sigma = std::sqrt(SI_Kbol*TMPR0/(a.mass()*MASS_UNIT)) / (LENGTH_UNIT/TIME_UNIT) ;
      std::normal_distribution<double> v_distr_1d {0.0,sigma};
      
      a.v().x = v_distr_1d(global_random_engine);
      a.v().y = v_distr_1d(global_random_engine);
      a.v().z = v_distr_1d(global_random_engine);
   }
}

template <class Base>
int shaked_particle<Base>::is_bonded ( int atom1, int atom2 ) const {
// if atoms i and j are bonded, then we need not calculate forces between them
   return type->exclusions[atom1*this->natoms()+atom2];
}

template <class Base>
vect shaked_particle<Base>::getAngleVelInBoxAxes () const {
   switch ( type->shape () ) {
   case particle_type::point:
      return vect(0.0);
      break;
   case particle_type::linear:
   {
      /* here we are if there is two atoms in molecule */
      double I = 0;
      const vect RCM = this->getCMPos ();

      for ( basic_particle::const_reference a: *this ) {
         I += (a.r() - RCM)*(a.r() - RCM)*a.mass();      }
      return this->getAngleMomentumInBoxAxes () / I;
      break;
   }
   case particle_type::general:
      return particle::getAngleVelInBoxAxes();
      break;
   default:
      raise_md_exception ( "shaked_particle<Base>::getAngleVelInBoxAxes (): illegal value of particle shape" );
   }
   return 0;
}

template <class Base>
double shaked_particle<Base>::getEkinRot () const {
   return 0.5*(this->getAngleVelInBoxAxes()*this->getAngleMomentumInBoxAxes()) ;
}

template <class Base>
double shaked_particle<Base>::getEkinVibr () const {
   return this->getEkin () - this->getEkinTrans () - this->getEkinRot ();
}

template <class Base>
void shaked_particle<Base>::getMolAxes ( vect Axes[3] ) const {
   type->molAxesCalc ( *this, Axes );
}

template <class Base>
matrix_3x3 shaked_particle<Base>::getInternalStress () const {
   //return this->internal_stress;
   auto tmp = this->internal_stress;
   tmp += this->vrattle_stress;
   return tmp;
}

// Explicit instantiation
template class shaked_particle<molecule>;
template class shaked_particle<ion>;
template class shaked_particle_type<molecule>;
template class shaked_particle_type<ion>;
