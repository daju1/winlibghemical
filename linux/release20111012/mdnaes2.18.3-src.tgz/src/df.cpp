/* =========================================================
   | Copyright(c) by Departament of Inorganic Chemistry of |
   | Kharkiv National University 1997-2023                 |
   ========================================================= */

#include <cstring>
#include <cmath>
#include <string>
#include <algorithm>

#include "df.h"
#include "distr_func.h"
#include "cn_distr.h"
#include "globals.h"
#include "all_particles.h"
#include "version.h"
#include "units.h"
#include "utils.h"
#include "lib/mdformat.h"
using namespace mdnaes;

static void RDF_Calc ();
static void DisAbout_Calc ();

#include "orient.h"

int KRDF;
int KDSHL;
int KCoorNum;     // Calculate coordination numbers of ion(s)


void StructFunctions ( ) {
   if ( KRDF && !(NSTTOT % StepRDF) )
      RDF_Calc ();

   if ( KMolOr && !(NSTTOT % StepRDF) )
      AnalyseMolOrient ( );

   if ( KDSOR ) {
      OrVect_Calc ();
      DistrCos_Calc ();
      if ( Wiy98_AdvancedCationCoordinationCenter_coefs != nullptr &&
           Wiy98_AdvancedAnionCoordinationCenter_coefs  != nullptr ) {
         CalculWiy98OrVect ();
         CalculWiy98Distr_cos ();
      }
   }

   if ( KDSHL )
      DisAbout_Calc ();

   if ( KCoorNum && !(NSTTOT % StepRDF) )
      CN_distr_Calc ();
}


// ================================================ RDF ==========================================
static const char *RDFFileName = "rdf.cf";
static const char *RDFResFileName = "rdf.dat";
static const char *RCNResFileName = "rcn.dat";

static int *RDFdata; // [NTYPE_ATOMS*NTYPE_ATOMS*RDFHistSize]
static unsigned int *RDFpairs; // [NTYPE_ATOMS*NTYPE_ATOMS]
static int RDFcount;
static int RDFHistSize;
static int NTYPE_ATOMS = 0;

static void SaveRDF () {
   std::ofstream out ( RDFFileName, std::ios::binary | std::ios::out | std::ios::trunc );

   version::out ( out );

   write_as<int> ( out, NSTTOT );
   write_as<int> ( out, RDFHistSize );
   write_as<int> ( out, NTYPE_ATOMS );
   write_as<int> ( out, RDFcount );
   out.write ( (char*)RDFpairs, sizeof (unsigned int) * NTYPE_ATOMS*NTYPE_ATOMS );
   out.write ( (char*)RDFdata, sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*RDFHistSize );
}

static void PrintRDFRes ();

static void RDF_init () {
   Message << "starting RDF calculation" << std::endl;
   
   NTYPE_ATOMS = Atom_types.size ();
   
   RDFHistSize = static_cast<int>( floor(LBOX2/DELTR) );
   RDFcount = 0;
   RDFdata  = new int[NTYPE_ATOMS*NTYPE_ATOMS*RDFHistSize];
   RDFpairs = new unsigned int[NTYPE_ATOMS*NTYPE_ATOMS];
   
   // RDFpairs are not used during simulation!
   for ( int i = 0; i < NTYPE_ATOMS*NTYPE_ATOMS; ++i )
      RDFpairs[i] = 0;
   
   for ( int i = 0; i < NTYPE_ATOMS*NTYPE_ATOMS*RDFHistSize; ++i )
      RDFdata[i] = 0;
   
   if ( KLH ) {
      Message << "reading RDF data from file...";
      
      std::ifstream in ( RDFFileName, std::ios::binary | std::ios::in );
      if ( !in ) {
         Error << __FILE__ << " line " << __LINE__ << ": cannot open file " << RDFFileName << std::endl;
         Error << "starting new rdf calculation" << std::endl;
         Message << "error, starting new rdf calculation" << std::endl;
      }
      else {
         version::check_ver ( in, RDFFileName );
         
         const auto savedNSTTOT = read_as<int> ( in );
         if ( NSTTOT < savedNSTTOT || savedNSTTOT < NSTTOT - StepRDF ) {
            Error << " Warning! This configuration of RDF-function has been created for\n";
            Error << savedNSTTOT << " time step. Current time step is " << NSTTOT << std::endl;
         }
         
         const auto savedRDFHistSize = read_as<int> ( in );
         if ( savedRDFHistSize != RDFHistSize ) {
            Error << " Not equal RDFHistSize: " << savedRDFHistSize << " and " << RDFHistSize << "\n";
            throw md_io_error ("Error in RDF_Calc()");
         }
         const auto savedNTYPE_ATOMS = read_as<int> ( in );
         if ( savedNTYPE_ATOMS != NTYPE_ATOMS ) {
            Error << " Not equal NTYPE_ATOMS: " << savedNTYPE_ATOMS << " and " << NTYPE_ATOMS << "\n";
            throw md_io_error ("Error in RDF_Calc()");
         }
         
         RDFcount = read_as<int> ( in );
         in.read ( (char*)RDFpairs, sizeof (unsigned int) * NTYPE_ATOMS*NTYPE_ATOMS );
         in.read ( (char*)RDFdata, sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*RDFHistSize );
         Message << " done" << std::endl;
      }
   }
   SMan.AddFun ( &SaveRDF );
   ShowRes.AddFun ( &PrintRDFRes );
}

static void RDF_Calc () {
   static int init = 1;
   if ( init ) {
      RDF_init ();
      init = 0;
   }

   RDFcount++;

   const double rmax2 = LBOX2 * LBOX2;
   const double DELTRI = 1.0 / DELTR;

//    for ( int i = 0; i < NTYPE_ATOMS*NTYPE_ATOMS; ++i )
//          RDFpairs[i] = 0;

   for ( int i = 0; i < SimSystem.all_particles.size()-1; i++ ) {
      for ( auto a: *(SimSystem.all_particles[i]) ) {
         const int II  = a.id();
         
         for ( int j = i + 1; j < SimSystem.all_particles.size() ; j++ ) {
            for ( auto b: (*SimSystem.all_particles[j]) ) {
               const int JJ  = b.id();

               //RDFpairs[II*NTYPE_ATOMS+JJ]++;

               vect DR = a.r() - b.r();

               PBC ( DR );

               const double R2 = DR * DR;
               if ( R2 < rmax2 ) {
                  const double R = sqrt ( R2 );
                  
                  const int NGGG = static_cast<int>( DELTRI * R );
                  if ( NGGG < RDFHistSize )
                     RDFdata[(II*NTYPE_ATOMS+JJ)*RDFHistSize + NGGG]++;
               }
            }
         }
      }
   }
}

static void PrintRDFRes () {
   std::ofstream rdf_out ( RDFResFileName );
   std::ofstream rcn_out ( RCNResFileName );
   const mdformat rdf_format (8, 4);
   const mdformat rcn_format (9, 6);
   const mdformat firstcolformat ( 8, 3, std::ios::fixed | std::ios::left );
   
   for ( int i = 0; i < SimSystem.all_particles.size()-1; i++ ) {
      for ( auto a: *(SimSystem.all_particles[i]) ) {
         for ( int j = i + 1; j < SimSystem.all_particles.size() ; j++ ) {
            for ( auto b: (*SimSystem.all_particles[j]) ) {
               RDFpairs[a.id()*NTYPE_ATOMS+b.id()]++;
            }
         }
      }
   }

   for ( int i = 0; i < NTYPE_ATOMS; ++i ) {
      for ( int j = i+1; j < NTYPE_ATOMS; ++j ) {
         RDFpairs[i*NTYPE_ATOMS+j] += RDFpairs[j*NTYPE_ATOMS+i];
         for ( int r = 0; r < RDFHistSize; ++r )
            RDFdata[(i*NTYPE_ATOMS+j)*RDFHistSize + r] += RDFdata[(j*NTYPE_ATOMS+i)*RDFHistSize + r];
      }
   }

   rdf_out << firstcolformat << "r, nm";
   rcn_out << "Multiply column ab by Na or Nb or N-1 if a==b to obtain coordination number\n";
   rcn_out << firstcolformat << "r, nm";
   for ( int i = 0; i < NTYPE_ATOMS; ++i ) {
      for ( int j = i; j < NTYPE_ATOMS; ++j ) {
         if ( RDFpairs[i*NTYPE_ATOMS+j] ) {
            const std::string name = Atom_types[i].name() + Atom_types[j].name();
            rdf_out << " " << rdf_format << name;
            rcn_out << " " << rcn_format << name;
         }
      }
   }
   rdf_out << std::endl;
   rcn_out << std::endl;

   double *RCNdata = new double[NTYPE_ATOMS*NTYPE_ATOMS];
   for ( int i = 0; i < NTYPE_ATOMS; ++i ) {
      for ( int j = i; j < NTYPE_ATOMS; ++j ) {
         RCNdata[i*NTYPE_ATOMS+j] = 0.0;
      }
   }

   for ( int r = 0; r < RDFHistSize; ++r ) {
      double rrr = DELTR * (r + 0.5);
      rdf_out << firstcolformat << rrr;
      rcn_out << firstcolformat << rrr;
      for ( int i = 0; i < NTYPE_ATOMS; ++i ) {
         for ( int j = i; j < NTYPE_ATOMS; ++j ) {
            if ( RDFpairs[i*NTYPE_ATOMS+j] ) {
               rdf_out << " " << rdf_format
                  << ( double(RDFdata[(i*NTYPE_ATOMS+j)*RDFHistSize + r]) / (double(RDFpairs[i*NTYPE_ATOMS+j]) * RDFcount) ) *
                                ( VOLBOX / ( 4 * SI_PI * rrr * rrr * DELTR ) );

               RCNdata[i*NTYPE_ATOMS+j] += double(RDFdata[(i*NTYPE_ATOMS+j)*RDFHistSize + r]) / (double(RDFpairs[i*NTYPE_ATOMS+j]) * RDFcount);
               rcn_out << " " << rcn_format << RCNdata[i*NTYPE_ATOMS+j];
            }
         }
      }
      rdf_out << std::endl;
      rcn_out << std::endl;
   }
   delete[] RCNdata;
}

// ====== Distribution of molecules coordination centers around ions coordination center ======
static const char *DisAboutFileName = "DisAbout.cf";

static void SaveDisAbout ();
static void PrintResDisAbout ();

static distrib_2D *DisAbout1KatAboveHistogram = nullptr;
static distrib_2D *DisAbout1KatBelowHistogram = nullptr;
static distrib_2D *DisAbout1AnAboveHistogram = nullptr;
static distrib_2D *DisAbout1AnBelowHistogram = nullptr;
static distrib_2D *DisAbout2KatAboveHistogram = nullptr;
static distrib_2D *DisAbout2KatBelowHistogram = nullptr;
static distrib_2D *DisAbout2AnAboveHistogram = nullptr;
static distrib_2D *DisAbout2AnBelowHistogram = nullptr;

template <bool ion_class> // true == cation, false == anion
void do_DisAbout ( const std::vector<ion*>& ions, double rshell,
                   const std::vector<molecule*>&  Molecules,
                   distrib_2D *AboveHistogram,
                   distrib_2D *BelowHistogram ) {
   switch ( ions[0]->shape() ) {
   case particle_type::point:
      for ( const auto pion: ions ) {
         const std::vector<vect> ion_cc = pion->getCoordinationCenters ();
         const vect IonPos = ion_cc[0];
         vect XAxe(0.0), YAxe(0.0), ZAxe(0.0); // axes

         int m = 0;
         vect dr;
         // search for the first molecule in shell for definition of Z-axe
         for ( ; m < Molecules.size(); ++m ) {
            if ( ion_class )
               dr = Molecules[m]->getCationCoordinationCenter () - IonPos;
            else
               dr = Molecules[m]->getAnionCoordinationCenter () - IonPos;
            PBC ( dr );

            const double r = norm (dr);
            if ( r < rshell ) {
               ZAxe = dr / r;
               break;
            }
         }
         if ( m == Molecules.size() ) // there is 0 molecules in shell
            break;

         // search for the second molecule in shell for definition of Y-axe
         for ( ++m; m < Molecules.size(); ++m ) {
            if ( ion_class )
               dr = Molecules[m]->getCationCoordinationCenter () - IonPos;
            else
               dr = Molecules[m]->getAnionCoordinationCenter () - IonPos;
            PBC ( dr );

            const double r = norm (dr);
            if ( r < rshell ) {
               YAxe = dr - (dr*ZAxe)*ZAxe;
               YAxe.normate ();
               break;
            }
         }
         if ( m == Molecules.size() ) // there is 1 molecule in shell
            break;
         else { // adding molecule position to histogram
            const double x = 0.0;
            const double y = dr * YAxe;
            const double z = dr * ZAxe;

            const int xxx = static_cast<int>(floor(x/StepRInShl+0.5)) + AboveHistogram->getXdim()/2;
            const int yyy = static_cast<int>(floor(y/StepRInShl+0.5)) + AboveHistogram->getYdim()/2;
            if ( z > 0.0 )
               AboveHistogram->add(xxx,yyy);
            else
               BelowHistogram->add(xxx,yyy);
         }

         XAxe = vecmul ( YAxe, ZAxe );

         // search for molecules in shell
         for ( ++m; m < Molecules.size(); ++m ) {
            if ( ion_class )
               dr = Molecules[m]->getCationCoordinationCenter () - IonPos;
            else
               dr = Molecules[m]->getAnionCoordinationCenter () - IonPos;
            PBC ( dr );

            const double r = norm (dr);
            if ( r < rshell ) {
               const double x = dr * XAxe;
               const double y = dr * YAxe;
               const double z = dr * ZAxe;

               const int xxx = static_cast<int>(floor(x/StepRInShl+0.5)) + AboveHistogram->getXdim()/2;
               const int yyy = static_cast<int>(floor(y/StepRInShl+0.5)) + AboveHistogram->getYdim()/2;
               if ( z > 0.0 )
                  AboveHistogram->add(xxx,yyy);
               else
                  BelowHistogram->add(xxx,yyy);
            }
         }
      }
      break;
   case particle_type::linear:
      for ( const auto pion: ions ) {
         const std::vector<vect> ion_cc = pion->getCoordinationCenters ();
         const vect IonPos = ion_cc[0];
         
         vect XAxe(0.0), YAxe(0.0), ZAxe(0.0); // axes

         int m = 0;
         vect dr;
         // search for the first molecule in shell for definition of Z-axe
         for ( ; m < Molecules.size(); ++m ) {
            if ( ion_class )
               dr = Molecules[m]->getCationCoordinationCenter () - IonPos;
            else
               dr = Molecules[m]->getAnionCoordinationCenter () - IonPos;
            PBC ( dr );

            const double r = norm (dr);
            if ( r < rshell ) {
               ZAxe = dr / r;
               break;
            }
         }
         if ( m == Molecules.size() ) // there is 0 molecules in shell
            break;

         // search for the second molecule in shell for definition of Y-axe
         for ( ++m; m < Molecules.size(); ++m ) {
            if ( ion_class )
               dr = Molecules[m]->getCationCoordinationCenter () - IonPos;
            else
               dr = Molecules[m]->getAnionCoordinationCenter () - IonPos;
            PBC ( dr );

            const double r = norm (dr);
            if ( r < rshell ) {
               YAxe = dr - (dr*ZAxe)*ZAxe;
               YAxe.normate ();
               break;
            }
         }
         if ( m == Molecules.size() ) // there is 1 molecule in shell
            break;
         else { // adding molecule position to histogram
            const double x = 0.0;
            const double y = dr * YAxe;
            const double z = dr * ZAxe;

            const int xxx = static_cast<int>(floor(x/StepRInShl+0.5)) + AboveHistogram->getXdim()/2;
            const int yyy = static_cast<int>(floor(y/StepRInShl+0.5)) + AboveHistogram->getYdim()/2;
            if ( z > 0.0 )
               AboveHistogram->add(xxx,yyy);
            else
               BelowHistogram->add(xxx,yyy);
         }

         XAxe = vecmul ( YAxe, ZAxe );

         // search for molecules in shell
         for ( ++m; m < Molecules.size(); ++m ) {
            if ( ion_class )
               dr = Molecules[m]->getCationCoordinationCenter () - IonPos;
            else
               dr = Molecules[m]->getAnionCoordinationCenter () - IonPos;
            PBC ( dr );

            const double r = norm (dr);
            if ( r < rshell ) {
               const double x = dr * XAxe;
               const double y = dr * YAxe;
               const double z = dr * ZAxe;

               const int xxx = static_cast<int>(floor(x/StepRInShl+0.5)) + AboveHistogram->getXdim()/2;
               const int yyy = static_cast<int>(floor(y/StepRInShl+0.5)) + AboveHistogram->getYdim()/2;
               if ( z > 0.0 )
                  AboveHistogram->add(xxx,yyy);
               else
                  BelowHistogram->add(xxx,yyy);
            }
         }
      }
      break;
   case particle_type::general:
      for ( const auto pion: ions ) {
         const std::vector<vect> ion_cc = pion->getCoordinationCenters ();
         const vect IonPos = ion_cc[0];
         
         vect XAxe(0.0), YAxe(0.0), ZAxe(0.0); // axes
         {
            vect axes[3];
            pion->getMolAxes ( axes );
            XAxe = axes[0];
            YAxe = axes[1];
            ZAxe = axes[2];
         }

         vect dr;
         // search for molecules in shell
         for ( const auto pmol: Molecules ) {
            if ( ion_class )
               dr = pmol->getCationCoordinationCenter () - IonPos;
            else
               dr = pmol->getAnionCoordinationCenter () - IonPos;
            PBC ( dr );

            const double r = norm (dr);
            if ( r < rshell ) {
               const double x = dr * XAxe;
               const double y = dr * YAxe;
               const double z = dr * ZAxe;

               const int xxx = static_cast<int>(floor(x/StepRInShl+0.5)) + AboveHistogram->getXdim()/2;
               const int yyy = static_cast<int>(floor(y/StepRInShl+0.5)) + AboveHistogram->getYdim()/2;
               if ( z > 0.0 )
                  AboveHistogram->add(xxx,yyy);
               else
                  BelowHistogram->add(xxx,yyy);
            }
         }
      }
      break;
   }
}

static void DisAbout_Calc () {
   static int DisAbout1KatNPoints; // floor(RSHL[0]/StepRInShl + 1.5);
   static int DisAbout1AnNPoints;  // floor(RSHL[2]/StepRInShl + 1.5);
   static int DisAbout2KatNPoints; // floor(RSHL[5]/StepRInShl + 1.5);
   static int DisAbout2AnNPoints;  // floor(RSHL[7]/StepRInShl + 1.5);

   static int DisAbout1KatHistSize; // 2*DisAbout1KatNPoints - 1;
   static int DisAbout1AnHistSize;  // 2*DisAbout1AnNPoints - 1;
   static int DisAbout2KatHistSize; // 2*DisAbout2KatNPoints - 1;
   static int DisAbout2AnHistSize;  // 2*DisAbout2AnNPoints - 1;

   static int init = 1;
   if ( init ) {
      Message << "starting DisAbout calculation" << std::endl;

      DisAbout1KatNPoints = static_cast<int>( RSHL[0]/StepRInShl + 1.5 );
      DisAbout1AnNPoints  = static_cast<int>( RSHL[2]/StepRInShl + 1.5 );
      DisAbout2KatNPoints = static_cast<int>( RSHL[5]/StepRInShl + 1.5 );
      DisAbout2AnNPoints  = static_cast<int>( RSHL[7]/StepRInShl + 1.5 );

      DisAbout1KatHistSize = 2*DisAbout1KatNPoints-1;
      DisAbout1AnHistSize  = 2*DisAbout1AnNPoints -1;
      DisAbout2KatHistSize = 2*DisAbout2KatNPoints-1;
      DisAbout2AnHistSize  = 2*DisAbout2AnNPoints -1;

      if ( SimSystem.all_cations.size() > 0 ) {
         if ( SimSystem.all_molecules1.size() > 0 ) {
            DisAbout1KatAboveHistogram = new distrib_2D ( DisAbout1KatHistSize, DisAbout1KatHistSize );
            DisAbout1KatBelowHistogram = new distrib_2D ( DisAbout1KatHistSize, DisAbout1KatHistSize );
         }
         if ( SimSystem.all_molecules2.size() > 0 ) {
            DisAbout2KatAboveHistogram = new distrib_2D ( DisAbout2KatHistSize, DisAbout2KatHistSize );
            DisAbout2KatBelowHistogram = new distrib_2D ( DisAbout2KatHistSize, DisAbout2KatHistSize );
         }
      }
      if ( SimSystem.all_anions.size() > 0 ) {
         if ( SimSystem.all_molecules1.size() > 0 ) {
            DisAbout1AnAboveHistogram =  new distrib_2D ( DisAbout1AnHistSize,  DisAbout1AnHistSize );
            DisAbout1AnBelowHistogram =  new distrib_2D ( DisAbout1AnHistSize,  DisAbout1AnHistSize );
         }
         if ( SimSystem.all_molecules2.size() > 0 ) {
            DisAbout2AnAboveHistogram =  new distrib_2D ( DisAbout2AnHistSize,  DisAbout2AnHistSize );
            DisAbout2AnBelowHistogram =  new distrib_2D ( DisAbout2AnHistSize,  DisAbout2AnHistSize );
         }
      }

      if ( KLH ) {
         std::ifstream in ( DisAboutFileName, std::ios::binary | std::ios::in );
         if ( !in ) {
            std::cerr << '\a';
            Error << __FILE__ << "; void DisAbout_Calc (): cannot open file " << DisAboutFileName << std::endl;
            Error << "starting new DisAbout calculation" << std::endl;
         }
         else {
            version::check_ver ( in, DisAboutFileName );
            if ( DisAbout1KatAboveHistogram ) DisAbout1KatAboveHistogram->read ( in );
            if ( DisAbout1KatBelowHistogram ) DisAbout1KatBelowHistogram->read ( in );
            if ( DisAbout1AnAboveHistogram )  DisAbout1AnAboveHistogram->read ( in );
            if ( DisAbout1AnBelowHistogram )  DisAbout1AnBelowHistogram->read ( in );
            if ( DisAbout2KatAboveHistogram ) DisAbout2KatAboveHistogram->read ( in );
            if ( DisAbout2KatBelowHistogram ) DisAbout2KatBelowHistogram->read ( in );
            if ( DisAbout2AnAboveHistogram )  DisAbout2AnAboveHistogram->read ( in );
            if ( DisAbout2AnBelowHistogram )  DisAbout2AnBelowHistogram->read ( in );
         }
      }

      SMan.AddFun ( &SaveDisAbout );
      ShowRes.AddFun ( &PrintResDisAbout );
      init = 0;
   }

   if ( DisAbout1KatAboveHistogram )
      do_DisAbout<true> ( SimSystem.all_cations, RSHL[0],
                          SimSystem.all_molecules1,
                          DisAbout1KatAboveHistogram, DisAbout1KatBelowHistogram );
   if ( DisAbout2KatAboveHistogram )
      do_DisAbout<true> ( SimSystem.all_cations, RSHL[5],
                          SimSystem.all_molecules2,
                          DisAbout2KatAboveHistogram, DisAbout2KatBelowHistogram );
   if ( DisAbout1AnAboveHistogram )
      do_DisAbout<false> ( SimSystem.all_anions, RSHL[2],
                           SimSystem.all_molecules1,
                           DisAbout1AnAboveHistogram, DisAbout1AnBelowHistogram );
   if ( DisAbout2AnAboveHistogram )
      do_DisAbout<false> ( SimSystem.all_anions, RSHL[7],
                           SimSystem.all_molecules2,
                           DisAbout2AnAboveHistogram, DisAbout2AnBelowHistogram );
}

static void SaveDisAbout () {
   std::ofstream out ( DisAboutFileName, std::ios::binary | std::ios::out | std::ios::trunc );

   version::out ( out );
   if ( DisAbout1KatAboveHistogram ) DisAbout1KatAboveHistogram->save ( out );
   if ( DisAbout1KatBelowHistogram ) DisAbout1KatBelowHistogram->save ( out );
   if ( DisAbout1AnAboveHistogram )  DisAbout1AnAboveHistogram->save ( out );
   if ( DisAbout1AnBelowHistogram )  DisAbout1AnBelowHistogram->save ( out );
   if ( DisAbout2KatAboveHistogram ) DisAbout2KatAboveHistogram->save ( out );
   if ( DisAbout2KatBelowHistogram ) DisAbout2KatBelowHistogram->save ( out );
   if ( DisAbout2AnAboveHistogram )  DisAbout2AnAboveHistogram->save ( out );
   if ( DisAbout2AnBelowHistogram )  DisAbout2AnBelowHistogram->save ( out );
}

static void PrintResDisAbout () {
   if ( SimSystem.all_ions.size() < 1 )
      return;

   const mdformat argfmt ( 8,4);
   const mdformat format (10,5);
   // find maximum needed X and Y sizes:
   const int X_sizes[8] = {
      DisAbout1KatAboveHistogram ? DisAbout1KatAboveHistogram->getXdim() : 0,
      DisAbout1KatBelowHistogram ? DisAbout1KatBelowHistogram->getXdim() : 0,
      DisAbout1AnAboveHistogram ? DisAbout1AnAboveHistogram->getXdim() : 0,
      DisAbout1AnBelowHistogram ? DisAbout1AnBelowHistogram->getXdim() : 0,
      DisAbout2KatAboveHistogram ? DisAbout2KatAboveHistogram->getXdim() : 0,
      DisAbout2KatBelowHistogram ? DisAbout2KatBelowHistogram->getXdim() : 0,
      DisAbout2AnAboveHistogram ? DisAbout2AnAboveHistogram->getXdim() : 0,
      DisAbout2AnBelowHistogram ? DisAbout2AnBelowHistogram->getXdim() : 0
   };
   const int Y_sizes[8] = {
      DisAbout1KatAboveHistogram ? DisAbout1KatAboveHistogram->getYdim() : 0,
      DisAbout1KatBelowHistogram ? DisAbout1KatBelowHistogram->getYdim() : 0,
      DisAbout1AnAboveHistogram ? DisAbout1AnAboveHistogram->getYdim() : 0,
      DisAbout1AnBelowHistogram ? DisAbout1AnBelowHistogram->getYdim() : 0,
      DisAbout2KatAboveHistogram ? DisAbout2KatAboveHistogram->getYdim() : 0,
      DisAbout2KatBelowHistogram ? DisAbout2KatBelowHistogram->getYdim() : 0,
      DisAbout2AnAboveHistogram ? DisAbout2AnAboveHistogram->getYdim() : 0,
      DisAbout2AnBelowHistogram ? DisAbout2AnBelowHistogram->getYdim() : 0
   };
   const int max_x = *std::max_element(X_sizes,X_sizes+8)/2 + 1;
   const int max_y = *std::max_element(Y_sizes,Y_sizes+8)/2 + 1;

   std::ofstream out ( "DisAbout.dat" );
   out << argfmt << "X " << argfmt << "Y ";
   if ( DisAbout1KatAboveHistogram ) out << format << "Above1Kat";
   if ( DisAbout1KatBelowHistogram ) out << format << "Below1Kat";
   if ( DisAbout1AnAboveHistogram )  out << format << "Above1An";
   if ( DisAbout1AnBelowHistogram )  out << format << "Below1An";
   if ( DisAbout2KatAboveHistogram ) out << format << "Above2Kat";
   if ( DisAbout2KatBelowHistogram ) out << format << "Below2Kat";
   if ( DisAbout2AnAboveHistogram )  out << format << "Above2An";
   if ( DisAbout2AnBelowHistogram )  out << format << "Below2An";
   out << std::endl;

   for ( int x = -max_x+1; x < max_x; ++x ) {
      for ( int y = -max_y+1; y < max_y; ++y ) {
         out << argfmt << x*StepRInShl << argfmt << y*StepRInShl;
         if ( DisAbout1KatAboveHistogram )
            out << format << DisAbout1KatAboveHistogram->get_value (
                             x+DisAbout1KatAboveHistogram->getXdim()/2,
                             y+DisAbout1KatAboveHistogram->getYdim()/2 );
         if ( DisAbout1KatBelowHistogram )
            out << format << DisAbout1KatBelowHistogram->get_value (
                             x+DisAbout1KatBelowHistogram->getXdim()/2,
                             y+DisAbout1KatBelowHistogram->getYdim()/2 );
         if ( DisAbout1AnAboveHistogram )
            out << format << DisAbout1AnAboveHistogram->get_value (
                             x+DisAbout1AnAboveHistogram->getXdim()/2,
                             y+DisAbout1AnAboveHistogram->getYdim()/2 );
         if ( DisAbout1AnBelowHistogram )
            out << format << DisAbout1AnBelowHistogram->get_value (
                             x+DisAbout1AnBelowHistogram->getXdim()/2,
                             y+DisAbout1AnBelowHistogram->getYdim()/2 );
         if ( DisAbout2KatAboveHistogram )
            out << format << DisAbout2KatAboveHistogram->get_value (
                             x+DisAbout2KatAboveHistogram->getXdim()/2,
                             y+DisAbout2KatAboveHistogram->getYdim()/2 );
         if ( DisAbout2KatBelowHistogram )
            out << format << DisAbout2KatBelowHistogram->get_value (
                             x+DisAbout2KatBelowHistogram->getXdim()/2,
                             y+DisAbout2KatBelowHistogram->getYdim()/2 );
         if ( DisAbout2AnAboveHistogram )
            out << format << DisAbout2AnAboveHistogram->get_value (
                             x+DisAbout2AnAboveHistogram->getXdim()/2,
                             y+DisAbout2AnAboveHistogram->getYdim()/2 );
         if ( DisAbout2AnBelowHistogram )
            out << format << DisAbout2AnBelowHistogram->get_value (
                             x+DisAbout2AnBelowHistogram->getXdim()/2,
                             y+DisAbout2AnBelowHistogram->getYdim()/2 );
         out << std::endl;
      }
   }
}
