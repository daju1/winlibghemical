#include "SVisc.h"

#include <vector>
#include <memory>

#include "corr_aux.h"
#include "corclass.h"
#include "correl.h"
#include "globals.h"
#include "iomanager.h"
#include "lib/mdformat.h"
using namespace mdnaes;

// ===================================== Shear Viscosity =====================================
const char *SViscFileName = "svisc.cf";
const char *SViscResFileName = "svisc.dat";

int SViscTSize = -1;
int SViscMulT = -1;

static iomanager SVisc_IOManager ( SViscFileName );

static double get_xy_stress () {
   return Therm_values.stress[0][1];
}

static double get_xz_stress () {
   return Therm_values.stress[0][2];
}

static double get_yz_stress () {
   return Therm_values.stress[1][2];
}

static vect get_kinetic_stress () {
   // divide it by sqrt(3) now instead of dividing
   // correlation function by 3.
   return vect(Therm_values.stressKin[0][1], Therm_values.stressKin[0][2], Therm_values.stressKin[1][2]) / std::sqrt(3.0);
   /*return vect(stressKin[0][1] + stressInt[0][1],
      stressKin[0][2] + stressInt[0][2],
      stressKin[1][2] + stressInt[1][2]) / std::sqrt(3);
   */
}

static vect get_force_stress () {
   return vect(Therm_values.stress[0][1]-Therm_values.stressKin[0][1],
      Therm_values.stress[0][2]-Therm_values.stressKin[0][2],
      Therm_values.stress[1][2]-Therm_values.stressKin[1][2]) / std::sqrt(3.0);
   /*return vect(stressPotC[0][1]+stressPotS[0][1],
      stressPotC[0][2]+stressPotS[0][2],
      stressPotC[1][2]+stressPotS[1][2]) / std::sqrt(3);
   */
}

static void SaveSVisc ();
static void ResultSVisc ();

static std::vector<std::unique_ptr<base_history_array> > SVisc_history_arrays;
static std::vector<std::unique_ptr<TDF> > SVisc_TDFs;

static void Svisc_init () {
   Message << "starting shear viscosity calculation" << std::endl;
   
   auto XY = new single_value_history_array<double> ( "XY", SViscTSize, get_xy_stress );
   auto XZ = new single_value_history_array<double> ( "XZ", SViscTSize, get_xz_stress );
   auto YZ = new single_value_history_array<double> ( "YZ", SViscTSize, get_yz_stress );
   
   auto Pot = new single_value_history_array<vect> ( "Pot", SViscTSize, get_force_stress );
   auto Kin = new single_value_history_array<vect> ( "Kin", SViscTSize, get_kinetic_stress );
   
   SVisc_history_arrays.emplace_back ( XY );
   SVisc_history_arrays.emplace_back ( XZ );
   SVisc_history_arrays.emplace_back ( YZ );
   SVisc_history_arrays.emplace_back ( Pot );
   SVisc_history_arrays.emplace_back ( Kin );
   
   const mdformat format (14,4);
   
   SVisc_TDFs.emplace_back (std::make_unique<single_value_ACF<double, double> > ( "SViscXY", SViscTSize, format, *XY ) );
   SVisc_TDFs.emplace_back (std::make_unique<single_value_ACF<double, double> > ( "SViscXZ", SViscTSize, format, *XZ ) );
   SVisc_TDFs.emplace_back (std::make_unique<single_value_ACF<double, double> > ( "SViscYZ", SViscTSize, format, *YZ ) );
   
   SVisc_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "ViscPotPot", SViscTSize, format, *Pot, *Pot ) );
   SVisc_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "ViscPotKin", SViscTSize, format, *Pot, *Kin ) );
   SVisc_TDFs.emplace_back (std::make_unique<single_value_CCF<double, vect, vect> > ( "ViscKinKin", SViscTSize, format, *Kin, *Kin ) );
   
   for ( const auto& p: SVisc_history_arrays ) {
      SVisc_IOManager.add ( p.get() );
   }
   
   for ( const auto& p: SVisc_TDFs ) {
      SVisc_IOManager.add ( p.get() );
   }
   
   if ( KLH ) {
      Message << "reading shear viscosity CF from file...";
      SVisc_IOManager.read ();
      Message << " done" << std::endl;
   }
   
   SMan.AddFun ( &SaveSVisc );
   ShowRes.AddFun ( &ResultSVisc );
}

void SVisc_Calc () {
   static int init = 1;
   if ( init ) {
      Svisc_init ();
      init = 0;
   }

   for ( const auto& p: SVisc_history_arrays ) {
      p->update ( );
   }
   
   for ( const auto& p: SVisc_TDFs ) {
      p->update ( );
   }
}

static void SaveSVisc () {
   SVisc_IOManager.save ();
}

static void ResultSVisc () {
   Message << "Shear viscosity" << std::endl;
   for ( const auto& p: SVisc_TDFs ) {
      p->print_header ( Message );
      Message << mdformat(12,4) <<
         1000.0 * ENERGY_UNIT * ENERGY_UNIT * TIME_UNIT / (VOLBOX*VOLUME_UNIT * SI_Kbol*TMPR0) *
         integral ( *dynamic_cast<TTDF<double>*>(p.get()), p->size(), SViscMulT*DELT );
      Message << " * 1e-3, Pa*s" << std::endl;
   }
   PrintTDFRes ( SVisc_TDFs, SViscResFileName, SViscMulT );
}
