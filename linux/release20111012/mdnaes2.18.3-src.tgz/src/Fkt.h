#ifndef FKT_H
#define FKT_H

#include <vector>

extern int StepFktInc;
extern int FktInc_TSIZE;
//extern int FktInc_KSIZE;
extern std::vector<double> k_array_inc;

void Fkt_Calc ();
void FktInc_Calc ();

#endif
