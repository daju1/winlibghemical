#include "all_particles.h"
#include "md_exception.h"

#include "lib/mdformat.h"
using namespace mdnaes;

interaction **all_interactions;

simulated_system_t SimSystem {};

void simulated_system_t::add_molecule_type ( std::unique_ptr<molecule_type>&& typ ) {
   for ( const auto& arr: molecules ) {
      if ( arr.size() > 0 ) {
         raise_md_exception ( "cannot add particle type to nonempty system\n" );
      }
   }
   
   molecule_types.emplace_back ( std::move(typ) );
   molecules.emplace_back ();
}

void simulated_system_t::add_cation_type   ( std::unique_ptr<ion_type>&& typ ) {
   for ( const auto& arr: cations ) {
      if ( arr.size() > 0 ) {
         raise_md_exception ( "cannot add particle type to nonempty system\n" );
      }
   }
   
   cation_types.emplace_back ( std::move(typ) );
   cations.emplace_back ();
}

void simulated_system_t::add_anion_type    ( std::unique_ptr<ion_type>&& typ ) {
   for ( const auto& arr: anions ) {
      if ( arr.size() > 0 ) {
         raise_md_exception ( "cannot add particle type to nonempty system\n" );
      }
   }
   
   anion_types.emplace_back ( std::move(typ) );
   anions.emplace_back ();
}

void simulated_system_t::syncronize_particle_arrays () {
   all_particles.resize(0);
   
   all_cations.resize(0);
   all_anions.resize(0);
   all_ions.resize(0);
   
   all_molecules1.resize(0);
   all_molecules2.resize(0);
   all_molecules.resize(0);
   
   if ( molecules.size() > 0 ) {
      for ( const auto& part: molecules[0] ) {
         all_molecules1.push_back ( part.get() );
      }
   }
   if ( molecules.size() > 1 ) {
      for ( const auto& part: molecules[1] ) {
         all_molecules2.push_back ( part.get() );
      }
   }
   for ( const auto& array: molecules ) {
      for ( const auto& part: array ) {
         all_molecules.push_back ( part.get() );
      }
   }
   
   for ( const auto& array: cations ) {
      for ( const auto& part: array ) {
         all_cations.push_back ( part.get() );
         all_ions.push_back ( part.get() );
      }
   }
   for ( const auto& array: anions ) {
      for ( const auto& part: array ) {
         all_anions.push_back ( part.get() );
         all_ions.push_back ( part.get() );
      }
   }
   
   for ( auto p: all_molecules ) {
      all_particles.push_back ( p );
   }
   for ( auto p: all_ions ) {
      all_particles.push_back ( p );
   }
}

// ============================================================================
double simulated_system_t::total_mass () const {
   double mass = 0;
   
   for ( const auto& array: molecules ) {
      if ( array.size() > 0 ) {
         mass += array.size() * array[0]->mass();
      }
   }
   for ( const auto& array: cations ) {
      if ( array.size() > 0 ) {
         mass += array.size() * array[0]->mass();
      }
   }
   for ( const auto& array: anions ) {
      if ( array.size() > 0 ) {
         mass += array.size() * array[0]->mass();
      }
   }
   
   return mass;
}

void simulated_system_t::print_atoms () const {
   for ( auto p: all_particles ) {
      std::cout << mdformat(5,0) << p->name() << std::endl;
      for ( basic_particle::const_reference a: *p ) {
         std::cout << mdformat(3,0) << a.name() << mdformat(6,3) << a.r() << mdformat(7,3) << a.v() << " | "
                   << mdformat(8,3) << a.f().near << mdformat(8,3) << a.f().far << std::endl;
      }
   }
}

void simulated_system_t::print_atoms ( int part_no ) const {
   auto p = all_particles[part_no];
   std::cout << mdformat(5,0) << p->name() << std::endl;
   for ( basic_particle::const_reference a: *p ) {
      std::cout << mdformat(2,0) << a.id() << mdformat(3,0) << a.name() << mdformat(6,3) << a.r() << mdformat(7,3) << a.v() << " | "
      << mdformat(8,3) << a.f().near << mdformat(8,3) << a.f().far << std::endl;
   }
   //std::cout << "Ekin = " << p->getEkin () << std::endl;
}
