#ifndef IOMANAGER_H
#define IOMANAGER_H

#include <vector>
#include <string>
#include "subsystem.h"

class iomanager {
public:
   iomanager ( const char *filename ): fname(filename), objects() {}
   ~iomanager () {}

   void add ( identified_saveable* obj ) { objects.push_back (obj); }
   void read ();
   void save ();

private:
   struct head { char key[64]; std::streampos pos; };
   // dont know exact type for pos (it may depend on stream object, used to represent file)
   // so use std::streampos as recommended default

   const std::string fname;
   std::vector<identified_saveable*> objects;
};

#endif
