#include "STCF.h"

#include <cstdlib>
#include <iomanip>
#include <cstring>
#include <vector>
#include <thread>
#include <cstddef>

#include "version.h"
#include "corclass.h"
#include "correl.h"
#include "all_particles.h"
#include "globals.h"
#include "units.h"
#include "iomanager.h"
#include "task_pool.h"
#include "utils.h"


// ============================= Space-Time Correlation Function =============================
#include "version.h"
#include <fstream>
#include <cassert>

const char *STCFFileName = "dstcf.cf";

int PrintSTCFMode;
int StepSTCF;
int STCF_TSIZE;
static int STCF_RSIZE;
double STCF_DELTR;

static int STCF_NATOMS;
static HA<vect> **AtomsPos;       // [STCF_NATOMS]
static HA<vect> **UnPBC_AtomsPos; // [STCF_NATOMS]
static int *STCF_Count;           // [STCF_TSIZE]
static int *DInterSTCF_HISTOGRAM; // [NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE]
static int *DInterSTCF_PAIRS;     // [NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE]
static int *DIntraSTCF_HISTOGRAM; // [NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE]
static int *DIntraSTCF_PAIRS;     // [NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE]
static int *SSTCF_HISTOGRAM;      // [NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE]
static int *SSTCF_PAIRS;          // [NTYPE_ATOMS*STCF_TSIZE]

static void InitSTCF ();
static void SaveSTCF ();
static void PrintSTCFRes ();
static void init_step ();
static void do_STCF ( int thread_no );

static task_pool stcf_tpool;

void STCF_Calc () {
   static int init = 1;
   if ( init ) {
      InitSTCF ();
      init = 0;
   }
   
   init_step ();
   
   stcf_tpool.reset ();
   exec_parallel (do_STCF,  NTHREADS);
}

static int NTYPE_ATOMS = 0;

static void InitSTCF () {
   NTYPE_ATOMS = Atom_types.size ();
   
   Message << "starting G(r,t) calculation" << std::endl;
   
   STCF_RSIZE = static_cast<int>(floor(LBOX2/STCF_DELTR));
   
   int i;
   STCF_NATOMS = 0;
   for ( auto p_part: SimSystem.all_particles )
      STCF_NATOMS += p_part->Grt_view().natoms ();
   
   AtomsPos = new HA<vect>*[STCF_NATOMS];
   UnPBC_AtomsPos = new HA<vect>*[STCF_NATOMS];
   for ( i = 0; i < STCF_NATOMS; ++i ) {
      AtomsPos[i] = new HA<vect>( STCF_TSIZE );
      UnPBC_AtomsPos[i] = new HA<vect>( STCF_TSIZE );
   }
   
   DInterSTCF_HISTOGRAM  = new int[NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE];
   DInterSTCF_PAIRS      = new int[NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE];
   for ( i = 0; i < NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE; ++i )
      DInterSTCF_HISTOGRAM[i] = 0;
   for ( i = 0; i < NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE; ++i )
      DInterSTCF_PAIRS[i] = 0;
   
   DIntraSTCF_HISTOGRAM  = new int[NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE];
   DIntraSTCF_PAIRS      = new int[NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE];
   for ( i = 0; i < NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE; ++i )
      DIntraSTCF_HISTOGRAM[i] = 0;
   for ( i = 0; i < NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE; ++i )
      DIntraSTCF_PAIRS[i] = 0;
   
   SSTCF_HISTOGRAM  = new int[NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE];
   SSTCF_PAIRS = new int[NTYPE_ATOMS*STCF_TSIZE];
   for ( i = 0; i < NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE; ++i )
      SSTCF_HISTOGRAM[i] = 0;
   for ( i = 0; i < NTYPE_ATOMS*STCF_TSIZE; ++i )
      SSTCF_PAIRS[i] = 0;
   
   STCF_Count = new int[STCF_TSIZE];
   for ( i = 0; i < STCF_TSIZE; ++i )
      STCF_Count[i] = 0;
   
   if ( KLH ) {
      std::ifstream in ( STCFFileName, std::ios::binary | std::ios::in );
      if ( !in ) {
         Error << __FILE__ << " line " << __LINE__ << ": cannot open file " << STCFFileName;
         Error << "\n" "starting new G(r,t) calculation" << std::endl;
      }
      else {
         version::check_ver ( in, "void STCF_Calc ()" );
         
         const int savedNSTTOT = read_as<int> ( in );
         if ( NSTTOT < savedNSTTOT || savedNSTTOT < NSTTOT - StepSTCF ) {
            Error << " Warning! This configuration of G(r,t)-function has been created for\n";
            Error << savedNSTTOT << " time step. Current time step is " << NSTTOT << std::endl;
         }
         
         const int savedSTCFRSize = read_as<int> ( in );
         if ( savedSTCFRSize != STCF_RSIZE ) {
            Error << " Not equal values of STCF_RSIZE: " << savedSTCFRSize << " and " << STCF_RSIZE << "\n";
            throw md_io_error ("Error in STCF_Calc()");
         }
         const int savedSTCFTSize = read_as<int> ( in );
         if ( savedSTCFTSize != STCF_TSIZE ) {
            Error << " Not equal values of STCF_TSIZE: " << savedSTCFTSize << " and " << STCF_TSIZE << "\n";
            throw md_io_error ("Error in STCF_Calc()");
         }
         
         const int savedNTYPE_ATOMS = read_as<int> ( in );
         if ( savedNTYPE_ATOMS != NTYPE_ATOMS ) {
            Error << " Not equal values of STCF_RSIZE: " << savedNTYPE_ATOMS << " and " << NTYPE_ATOMS << "\n";
            throw md_io_error ("Error in STCF_Calc()");
         }
         
         const int savedSTCF_NATOMS = read_as<int> ( in );
         if ( savedSTCF_NATOMS != STCF_NATOMS ) {
            Error << " Not equal values of STCF_RSIZE: " << savedSTCF_NATOMS << " and " << STCF_NATOMS << "\n";
            throw md_io_error ("Error in STCF_Calc()");
         }
         
         for ( int i = 0; i < STCF_NATOMS; ++i )
            AtomsPos[i]->read ( in );
         for ( int i = 0; i < STCF_NATOMS; ++i )
            UnPBC_AtomsPos[i]->read ( in );
         
         in.read ( (char*)STCF_Count,           sizeof (int) * STCF_TSIZE );
         in.read ( (char*)DInterSTCF_PAIRS,     sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE );
         in.read ( (char*)DInterSTCF_HISTOGRAM, sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE );
         in.read ( (char*)DIntraSTCF_PAIRS,     sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE );
         in.read ( (char*)DIntraSTCF_HISTOGRAM, sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE );
         in.read ( (char*)SSTCF_PAIRS,          sizeof (int) * NTYPE_ATOMS*STCF_TSIZE );
         in.read ( (char*)SSTCF_HISTOGRAM,      sizeof (int) * NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE );
      }
   }
   SMan.AddFun ( &SaveSTCF );
   ShowRes.AddFun ( &PrintSTCFRes );
}

static void init_step () {
   // updating saved atoms positions
   int at1ind = 0;
   for ( auto p_part: SimSystem.all_particles ) {
      for ( auto a: p_part->Grt_view() ) {
         AtomsPos[at1ind]->add ( a.r() );
         UnPBC_AtomsPos[at1ind]->add ( a.r() - p_part->getCMPos () + p_part->getUnPBC_CMPos () );
         at1ind++;
      }
   }

   // pairs numbers are calculated for single time step only and then are multiplied by STCF_Count[t] --- what?!!
   for ( int i = 0; i < NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE; ++i )
      DInterSTCF_PAIRS[i] = 0;
   for ( int i = 0; i < NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE; ++i )
      DIntraSTCF_PAIRS[i] = 0;
   for ( int i = 0; i < NTYPE_ATOMS*STCF_TSIZE; ++i )
      SSTCF_PAIRS[i] = 0;
}

static void do_STCF ( int thread_no ) {
   const double rmax2 = LBOX2 * LBOX2;
   const double DELTRI = 1.0 / STCF_DELTR;

#ifdef STATIC_WORK_BALANCING
   for ( int t = thread_no; t < STCF_TSIZE && t < AtomsPos[0]->size (); t += NTHREADS ) {
#else
   for ( int t = stcf_tpool(); t < STCF_TSIZE && t < AtomsPos[0]->size (); t = stcf_tpool() ) {
#endif
      STCF_Count[t]++;
      
      int at1ind = 0;
      for ( auto p_part1: SimSystem.all_particles ) {
         auto part1 = p_part1->Grt_view();
         for ( int a = 0; a < part1.natoms(); a++, at1ind++ ) {
            const int II = part1[a].id();
            const vect Q = (*AtomsPos[at1ind])[0];
            const vect UnPBC_Q = (*UnPBC_AtomsPos[at1ind])[0];

            int at2ind = 0;
            for ( auto p_part2: SimSystem.all_particles ) {
               auto part2 = p_part2->Grt_view();
               for ( int b = 0; b < part2.natoms(); b++, at2ind++ ) {
                  if ( p_part1 != p_part2 ) {
                     const int JJ = part2[b].id();

                     DInterSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (II*NTYPE_ATOMS + JJ)]++;

                     vect DR = Q - (*AtomsPos[at2ind])[t];
                     PBC ( DR );

                     const double R2 = DR * DR;
                     if ( R2 < rmax2 ) {
                        const double R = sqrt ( R2 );

                        const int NGGG = int( DELTRI * R );
                        if ( NGGG < STCF_RSIZE )
                           DInterSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t +
                                                (II*NTYPE_ATOMS + JJ)*STCF_RSIZE + NGGG]++;
                     }
                  }
                  if ( p_part1 == p_part2 && a != b ) {
                     const int JJ = part2[b].id();

                     DIntraSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (II*NTYPE_ATOMS + JJ)]++;

                     const vect DR = UnPBC_Q - (*UnPBC_AtomsPos[at2ind])[t];

                     const double R2 = DR * DR;
                     if ( R2 < rmax2 ) {
                        const double R = sqrt ( R2 );

                        const int NGGG = int( DELTRI * R );
                        if ( NGGG < STCF_RSIZE )
                           DIntraSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t +
                                                (II*NTYPE_ATOMS + JJ)*STCF_RSIZE + NGGG]++;
                     }
                  }
                  if ( p_part1 == p_part2 && a == b ) {
                     assert ( at1ind == at2ind );

                     SSTCF_PAIRS[NTYPE_ATOMS*t + II]++;

                     const vect DR = UnPBC_Q - (*UnPBC_AtomsPos[at2ind])[t];

                     const double R2 = DR * DR;
                     if ( R2 < rmax2 ) {
                        const double R = sqrt ( R2 );

                        const int NGGG = int( DELTRI * R );
                        if ( NGGG < STCF_RSIZE )
                           SSTCF_HISTOGRAM[NTYPE_ATOMS*STCF_RSIZE*t + II*STCF_RSIZE + NGGG]++;
                     }
                  }
               }
            }
         }
      }
   }
}

static void SaveSTCF () {
   std::ofstream out ( STCFFileName, std::ios::binary | std::ios::out | std::ios::trunc );

   version::out ( out );

   write_as<int> ( out, NSTTOT );
   write_as<int> ( out, STCF_RSIZE );
   write_as<int> ( out, STCF_TSIZE );
   write_as<int> ( out, NTYPE_ATOMS );
   write_as<int> ( out, STCF_NATOMS );

   for ( int i = 0; i < STCF_NATOMS; ++i )
      AtomsPos[i]->save ( out );
   for ( int i = 0; i < STCF_NATOMS; ++i )
      UnPBC_AtomsPos[i]->save ( out );

   out.write ( (char*)STCF_Count,           sizeof (int) * STCF_TSIZE );
   out.write ( (char*)DInterSTCF_PAIRS,     sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE );
   out.write ( (char*)DInterSTCF_HISTOGRAM, sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE );
   out.write ( (char*)DIntraSTCF_PAIRS,     sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE );
   out.write ( (char*)DIntraSTCF_HISTOGRAM, sizeof (int) * NTYPE_ATOMS*NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE );
   out.write ( (char*)SSTCF_PAIRS,          sizeof (int) * NTYPE_ATOMS*STCF_TSIZE );
   out.write ( (char*)SSTCF_HISTOGRAM,      sizeof (int) * NTYPE_ATOMS*STCF_TSIZE*STCF_RSIZE );
}

static void PrintSTCFRes () {
   mdformat rcolformat (8,4);
   const mdformat format0 (8,4);
   const mdformat format1 (11,4);
   int i, j, r, t;

   for ( t = 0; t < STCF_TSIZE; ++t ) {
      for ( i = 0; i < NTYPE_ATOMS; ++i ) {
         for ( j = i+1; j < NTYPE_ATOMS; ++j ) {
            DInterSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (i*NTYPE_ATOMS + j)] +=
               DInterSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (j*NTYPE_ATOMS + i)];
            DIntraSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (i*NTYPE_ATOMS + j)] +=
               DIntraSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (j*NTYPE_ATOMS + i)];
            for ( r = 0; r < STCF_RSIZE; ++r ) {
               DInterSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t + (i*NTYPE_ATOMS + j)*STCF_RSIZE + r] +=
                  DInterSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t + (j*NTYPE_ATOMS + i)*STCF_RSIZE + r];
               DIntraSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t + (i*NTYPE_ATOMS + j)*STCF_RSIZE + r] +=
                  DIntraSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t + (j*NTYPE_ATOMS + i)*STCF_RSIZE + r];
            }
         }
      }
   }

   // Printing Distinct intermolecular part
   if ( PrintSTCFMode == 0 ) { // print to multiple files
      for ( i = 0; i < NTYPE_ATOMS; ++i ) {
         for ( j = i; j < NTYPE_ATOMS; ++j ) {
            if ( !DInterSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*0 + (i*NTYPE_ATOMS + j)] )
               continue;
            std::string fname = std::string("Gdinter") + Atom_types[i].name()
               + Atom_types[j].name() + std::string(".dat");
            std::ofstream out ( fname.c_str() );

            out << rcolformat << "r_nm";
            for ( t = 0; t < STCF_TSIZE; ++t ) {
               out << format0 << DELT * StepSTCF * t;
            }
            out << std::endl;

            for ( r = 0; r < STCF_RSIZE; ++r ) {
               double rrr = STCF_DELTR * (r + 0.5);
               out << rcolformat << rrr;
               for ( t = 0; t < STCF_TSIZE; ++t ) {
                  out << format0 << ( double(DInterSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t + (i*NTYPE_ATOMS + j)*STCF_RSIZE + r]) /
                                    (double(DInterSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (i*NTYPE_ATOMS + j)])*STCF_Count[t]) ) *
                                     ( VOLBOX / ( 4 * SI_PI * rrr * rrr * STCF_DELTR ) );
               }
               out << std::endl;
            }
         }
      }
   }
   else { // print to single file
      std::ofstream out ( "Gdinter.dat" );

      out << rcolformat << "t_ps";
      out << rcolformat << "r_nm";
      for ( i = 0; i < NTYPE_ATOMS; ++i ) {
         for ( j = i; j < NTYPE_ATOMS; ++j ) {
            if ( DInterSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*0 + (i*NTYPE_ATOMS + j)] ) {
               out << " ";
               out << format1 << Atom_types[i].name() + Atom_types[j].name();
            }
         }
      }
      out << std::endl;

      for ( t = 0; t < STCF_TSIZE; ++t ) {
         for ( r = 0; r < STCF_RSIZE; ++r ) {
            const double rrr = STCF_DELTR * (r + 0.5);
            out << rcolformat << DELT*StepSTCF*t;
            out << rcolformat << rrr;
            for ( i = 0; i < NTYPE_ATOMS; ++i ) {
               for ( j = i; j < NTYPE_ATOMS; ++j ) {
                  if ( DInterSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*0 + (i*NTYPE_ATOMS + j)] ) {
                     out << " ";
                     out << format1 << ( double(DInterSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t + (i*NTYPE_ATOMS + j)*STCF_RSIZE + r]) /
                                       (double(DInterSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (i*NTYPE_ATOMS + j)])*STCF_Count[t]) ) *
                                       ( VOLBOX / ( 4 * SI_PI * rrr * rrr * STCF_DELTR ) );
                  }
               }
            }
            out << std::endl;
         }
      }
   }

   // Printing Distinct intramolecular part
   if ( PrintSTCFMode == 0 ) { // print to multiple files
      for ( i = 0; i < NTYPE_ATOMS; ++i ) {
         for ( j = i; j < NTYPE_ATOMS; ++j ) {
            if ( !DIntraSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*0 + (i*NTYPE_ATOMS + j)] )
               continue;
            std::string fname = std::string("Gdintra") + Atom_types[i].name()
               + Atom_types[j].name() + std::string(".dat");
            std::ofstream out ( fname.c_str() );

            out << rcolformat << "r_nm";
            for ( t = 0; t < STCF_TSIZE; ++t ) {
               out << format0 << DELT * StepSTCF * t;
            }
            out << std::endl;

            for ( r = 0; r < STCF_RSIZE; ++r ) {
               double rrr = STCF_DELTR * (r + 0.5);
               out << rcolformat << rrr;
               for ( t = 0; t < STCF_TSIZE; ++t ) {
                  out << format0 << ( double(DIntraSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t + (i*NTYPE_ATOMS + j)*STCF_RSIZE + r]) /
                                    (double(DIntraSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (i*NTYPE_ATOMS + j)])*STCF_Count[t]) ) *
                                     ( VOLBOX / ( 4 * SI_PI * rrr * rrr * STCF_DELTR ) );
               }
               out << std::endl;
            }
         }
      }
   }
   else { // print to single file
      std::ofstream out ( "Gdintra.dat" );

      out << rcolformat << "t_ps";
      out << rcolformat << "r_nm";
      for ( i = 0; i < NTYPE_ATOMS; ++i ) {
         for ( j = i; j < NTYPE_ATOMS; ++j ) {
            if ( DIntraSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*0 + (i*NTYPE_ATOMS + j)] ) {
               out << " ";
               out << format1 << Atom_types[i].name() + Atom_types[j].name();
            }
         }
      }
      out << std::endl;

      for ( t = 0; t < STCF_TSIZE; ++t ) {
         for ( r = 0; r < STCF_RSIZE; ++r ) {
            const double rrr = STCF_DELTR * (r + 0.5);
            out << rcolformat << DELT*StepSTCF*t;
            out << rcolformat << rrr;
            for ( i = 0; i < NTYPE_ATOMS; ++i ) {
               for ( j = i; j < NTYPE_ATOMS; ++j ) {
                  if ( DIntraSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*0 + (i*NTYPE_ATOMS + j)] ) {
                     out << " ";
                     out << format1 << ( double(DIntraSTCF_HISTOGRAM[NTYPE_ATOMS*NTYPE_ATOMS*STCF_RSIZE*t + (i*NTYPE_ATOMS + j)*STCF_RSIZE + r]) /
                                       (double(DIntraSTCF_PAIRS[NTYPE_ATOMS*NTYPE_ATOMS*t + (i*NTYPE_ATOMS + j)])*STCF_Count[t]) ) *
                                       ( VOLBOX / ( 4 * SI_PI * rrr * rrr * STCF_DELTR ) );
                  }
               }
            }
            out << std::endl;
         }
      }
   }

   // Printing self part
   if ( PrintSTCFMode == 0 ) { // print to multiple files
      for ( i = 0; i < NTYPE_ATOMS; ++i ) {
         if ( !SSTCF_PAIRS[NTYPE_ATOMS*0 + i] )
               continue;
         std::string fname = std::string("Gs") + Atom_types[i].name()
            + Atom_types[i].name() + std::string(".dat");
         std::ofstream out ( fname.c_str() );

         out << rcolformat << "r_nm";
         for ( t = 0; t < STCF_TSIZE; ++t ) {
            out << format0 << DELT * StepSTCF * t;
         }
         out << std::endl;

         for ( r = 0; r < STCF_RSIZE; ++r ) {
            double rrr = STCF_DELTR * (r + 0.5);
            out << rcolformat << rrr;
            for ( t = 0; t < STCF_TSIZE; ++t ) {
               out << format0 << ( double(SSTCF_HISTOGRAM[NTYPE_ATOMS*STCF_RSIZE*t + i*STCF_RSIZE + r]) /
                                 (double(SSTCF_PAIRS[NTYPE_ATOMS*t + i])*STCF_Count[t]) ) *
                                  ( VOLBOX / ( 4 * SI_PI * rrr * rrr * STCF_DELTR ) );
            }
            out << std::endl;
         }
      }
   }
   else { // print to single file
      std::ofstream out ( "Gs.dat" );

      out << rcolformat << "t_ps";
      out << rcolformat << "r_nm";
      for ( i = 0; i < NTYPE_ATOMS; ++i ) {
         if ( SSTCF_PAIRS[NTYPE_ATOMS*0 + i] ) {
            out << " ";
            out << format1 << Atom_types[i].name() + Atom_types[i].name();
         }
      }
      out << std::endl;

      for ( t = 0; t < STCF_TSIZE; ++t ) {
         for ( r = 0; r < STCF_RSIZE; ++r ) {
            const double rrr = STCF_DELTR * (r + 0.5);
            out << rcolformat << DELT*StepSTCF*t;
            out << rcolformat << rrr;
            for ( i = 0; i < NTYPE_ATOMS; ++i ) {
               if ( SSTCF_PAIRS[NTYPE_ATOMS*0 + i] ) {
                  out << " ";
                  out << format1 << ( double(SSTCF_HISTOGRAM[NTYPE_ATOMS*STCF_RSIZE*t + i*STCF_RSIZE + r]) /
                                    (double(SSTCF_PAIRS[NTYPE_ATOMS*t + i])*STCF_Count[t]) ) *
                                    ( VOLBOX / ( 4 * SI_PI * rrr * rrr * STCF_DELTR ) );
               }
            }
            out << std::endl;
         }
      }
   }
}

