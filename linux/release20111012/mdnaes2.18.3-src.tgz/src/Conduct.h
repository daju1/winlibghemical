#ifndef CONDUCT_H
#define CONDUCT_H

extern int ConductTSize;
extern int ConductMult;

extern int ConductTSize_E;
extern int ConductMult_E;

extern void Conduct_Calc ();
extern void Conduct_Einstein_Calc ();

#endif
