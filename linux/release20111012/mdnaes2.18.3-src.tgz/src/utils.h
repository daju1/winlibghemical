#ifndef UTILS_H
#define UTILS_H

#include <iostream>

template <typename T>
inline void write_as ( std::ostream& out, T value ) {
   out.write ( reinterpret_cast<const char*>(&value),  sizeof(value) );
}

template <typename T>
inline T read_as ( std::istream& in ) {
   T v = 0;
   in.read ( reinterpret_cast<char*>(&v),  sizeof(v) );
   return v;
}

#endif
