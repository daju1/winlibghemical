#ifndef SHAKED_PARTICLE_H
#define SHAKED_PARTICLE_H

#include <vector>
#include <memory>

#include "basic_particle.h"
#include "molecule.h"
#include "ion.h"

#include "lib/matrix_3x3.h"

// Base_part must be derived from class particle
// actually it should be molecule or ion
template <class Base_part>
class shaked_particle_type;

// Base must be derived from class particle
// actually it should be molecule or ion
template <class Base>
class shaked_particle : public Base {
public:
   using type_t = shaked_particle_type<Base>;
private:
   const type_t *type;
   matrix_3x3 internal_stress;
   matrix_3x3 vrattle_stress;

   vect *newpositions; // [natoms()] - cache of new atomic positions, separate for each particle for parallel calculations.
   
private:
   void rattle ( double tstep );
   void v_rattle ( double tstep, matrix_3x3& );
   
public:
   shaked_particle ( const type_t *t, vect origin );
   shaked_particle ( const shaked_particle &src, vect cmpos );

   virtual ~shaked_particle () override;
   
   //virtual void read_v2_0 ( std::istream& ) override;
   
   virtual void move ( double tstep, int substeps, std::size_t thread_no = 0 ) override;
   virtual void correctorStep ( double tstep ) override;

   virtual void bonded_forces ( std::size_t thread_no = 0 ) override;

   virtual void randomize_velocities () override;
   virtual void getMolAxes ( vect [3] ) const;

   virtual vect getAngleVelInBoxAxes () const;

   virtual double getEkinRot () const;
   virtual double getEkinVibr () const;

   virtual matrix_3x3 getInternalStress () const override;

   virtual int is_bonded ( int atom1, int atom2 ) const override;
};


// Base_part must be derived from class particle
// actually it should be molecule or ion
template <class Base_part>
class shaked_particle_type : public Base_part::type_t {
public:
   typedef typename Base_part::type_t Base;
protected:
   virtual void molAxesCalc ( const basic_particle& atoms, vect [3] ) const;

   friend class shaked_particle<Base_part>;

   struct distance_constraint {
      int i1, i2;
      double sqr_dist; // square of interatomic distance
   };

   struct angle_constraint {
      int i1, i2, i3;
      double alpha;
   };

   struct dihedral_constraint {
      int i1, i2, i3, i4;
      double beta;
   };

   struct bond_potential {
      int i1, i2;
      double eqv_dist; // equilibrium interatomic distance
      std::vector<double> coefs; // U = coefs[0]*((r-r0)/r0)^2 + coefs[1]*((r-r0)/r0)^3 + ...
   };

   struct angle_potential {
      int i1, i2, i3;
      double eqv_angle; // equilibrium angle
      std::vector<double> coefs; // U = coefs[0]*((a-a0)/a0)^2 + coefs[1]*((a-a0)/a0)^3 + ...
   };
   
   struct angle_cos_potential {
      int i1, i2, i3;
      double eqv_angle; // equilibrium angle
      double eqv_cos; // = cos(eqv_angle)
      double k; // U = 1/2 * k * (cos(a) - eqv_cos)^2
   };

   struct dihedral_potential {
      int i1, i2, i3, i4;
      std::vector<double> coefs; // U = coefs[0] + coefs[1]*cos(b) + ...
   };

   struct dihedral_potential_2 {
      int i1, i2, i3, i4;
      double k;
      int p;
      double b0;
      // U = k/2 * ( 1 - cos(p*(b-b0)) )
   };

   struct harmonic_dihedral {
      int i1, i2, i3, i4;
      double k;
      double b0;
      // U = k/2 * (b-b0)^2
   };

protected:
   std::vector<distance_constraint> constraints;
   std::vector<distance_constraint> bond_constraints;
   std::vector<angle_constraint>    angle_constraints;
   std::vector<dihedral_constraint> dihedral_constraints;
   std::vector<bond_potential>       bonds;
   std::vector<angle_potential>      angles;
   std::vector<angle_cos_potential>   angles_cos;
   std::vector<dihedral_potential>   dihedrals;
   std::vector<dihedral_potential_2> dihedrals_2;
   std::vector<harmonic_dihedral>    harmonic_dihedrals;
   bool *exclusions;
   int NTotDegFree;
public:
   shaked_particle_type ( mylist_const_iterator& );
   virtual ~shaked_particle_type ();

   virtual std::unique_ptr<Base_part> create ( vect origin ) const;
   virtual std::unique_ptr<Base_part> create ( const Base_part *src, vect cmpos ) const;
   //virtual p_array<Base_part> new_array () const;
   
   virtual int shape () const;
   virtual int nDegFree () const;
   virtual int nRotDegFree () const;
   virtual int nVibrDegFree () const;

   virtual void print ( std::ostream& ) const;
};

// ===========================================================================
using shaked_molecule = shaked_particle<molecule>;
using shaked_ion = shaked_particle<ion>;
using shaked_molecule_type = shaked_particle_type<molecule>;
using shaked_ion_type = shaked_particle_type<ion>;

#endif
