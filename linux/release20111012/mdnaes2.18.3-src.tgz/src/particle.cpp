#include <iomanip>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <iomanip>

#include "particle.h"
#include "atomtbl.h"
#include "atom.h"
#include "lib/mdformat.h"
#include "units.h"

using namespace mdnaes;


particle::~particle () {}

// -----------------------------------------------------------------------------------------------
void particle::bonded_forces ( std::size_t thread_no ) {
}

void particle::reset_near_forces () {
   for ( reference a: *this ) {
      a.reset_near_forces ();
   }
}

void particle::reset_far_forces () {
   for ( reference a: *this ) {
      a.reset_far_forces ();
   }
}

void particle::sync_near_forces () {
   for ( reference a: *this ) {
      a.sync_near_forces ();
   }
}

void particle::sync_far_forces () {
   for ( reference a: *this ) {
      a.sync_far_forces ();
   }
}

void particle::scalv ( double factor ) {
   for ( reference a: *this )
      a.v() *= factor;
}

void particle::scalPos ( double factor ) {
   // for rigid or frozen particle this function will be redefined
   for ( reference a: *this ) {
      a.r() *= factor;
   }
}

double particle::interatomic_distance_error ( int i, int j ) const {
   return norm((*this)[j].r() - (*this)[i].r()) - type->getInitialInteratomicDistance(i,j);
}

double particle::charge () const {
   double charge = 0.0;
   
   for ( const_reference a: *this ) {
      charge += a.q();
   }
   
   return charge;
}

vect particle::getChargesCMPos () const {
   vect R = 0.0;
   double qmass = 0.0;

   for ( const_reference a: *this ) {
      R += a.r() * fabs(a.q());
      qmass += fabs (a.q());
   }
   R /= qmass;
   
   return R;
}

vect particle::getCMVel () const {
   vect V = 0.0;
   for ( const_reference a: *this ) {
      //std::cout << "particle::getCMVel(): a.v() = " << a.v() << std::endl;
      //std::cout << "particle::getCMVel(): a.mass() = " << a.mass() << std::endl;
      V += a.v() * a.mass();
   }
   V /= mass ();
   return V;
}

vect particle::getAngleVelInMolAxes () const {
   const vect Wb = getAngleVelInBoxAxes ();
   vect axes[3];
   getMolAxes ( axes );

   return vect ( Wb * axes[0], Wb * axes[1], Wb * axes[2] );
}

vect particle::getAngleVelInBoxAxes () const {
   extern void matrix_invertion ( double [3][3] );
   double I[3][3];
   getInertiaTenzor ( I );
   const vect Lb = getAngleMomentumInBoxAxes ();
   matrix_invertion ( I );
   return I * Lb;
}

vect particle::getAngleMomentumInMolAxes () const {
   const vect Lb = getAngleMomentumInBoxAxes ();
   vect axes[3];
   getMolAxes ( axes );

   return vect ( Lb * axes[0], Lb * axes[1], Lb * axes[2] );
}

vect particle::getAngleMomentumInBoxAxes () const {
   const vect QCM = getCMPos ();
   vect L ( 0.0 );

   for ( const_reference a: *this )
      L += a.mass () * vecmul ( a.r() - QCM, a.v() );
   
   return L;
}

vect particle::getTorque () const {
   const vect QCM = getCMPos ();
   vect N = 0.0;

   for ( const_reference a: *this )
      N += vecmul ( a.r() - QCM, a.f().near + a.f().far );
   
   return N;
}

vect particle::getShortTorque () const {
   const vect QCM = getCMPos ();
   vect N ( 0.0 );
   
   for ( const_reference a: *this )
      N += vecmul ( a.r() - QCM, a.f().near );
   
   return N;
}

vect particle::getLongTorque () const {
   const vect QCM = getCMPos ();
   vect N ( 0.0 );
   
   for ( const_reference a: *this )
      N += vecmul ( a.r() - QCM, a.f().far );
   
   return N;
}

vect particle::getForce () const {
   vect F ( 0.0 );
   
   for ( const_reference a: *this )
      F += a.f().near + a.f().far;
   
   return F;
}

vect particle::getShortForce () const {
   vect F ( 0.0 );
   
   for ( const_reference a: *this ) {
      F += a.f().near;
      //std::cout << "getShortForce(): a.f().near = " << a.f().near << std::endl;
   }
   
   return F;
}

vect particle::getLongForce () const {
   vect F ( 0.0 );
   
   for ( const_reference a: *this ) {
      F += a.f().far;
      //std::cout << "getLongForce(): a.f().far = " << a.f().far << std::endl;
   }
   
   return F;
}

vect particle::getAngleAcceleration () const {
   extern void matrix_invertion ( double [3][3] );
   double I[3][3];
   getInertiaTenzor ( I );
   const vect N = getTorque ();
   matrix_invertion ( I );
   return I * N;
}

vect particle::getShortAngleAcceleration () const {
   extern void matrix_invertion ( double [3][3] );
   double I[3][3];
   getInertiaTenzor ( I );
   const vect N = getShortTorque ();
   matrix_invertion ( I );
   return I * N;
}

vect particle::getLongAngleAcceleration () const {
   extern void matrix_invertion ( double [3][3] );
   double I[3][3];
   getInertiaTenzor ( I );
   const vect N = getLongTorque ();
   matrix_invertion ( I );
   return I * N;
}


vect particle::getCurrent () const {
   vect I(0.0);
   
   for ( const_reference a: *this )
      I += a.q() * a.v();
   return I;
}

vect particle::getCMAcceleration () const {
   return getForce () / mass ();
}

vect particle::getShortCMAcceleration () const {
   return getShortForce () / mass ();
}

vect particle::getLongCMAcceleration () const {
   return getLongForce () / mass ();
}

vect particle::toMolAxes ( const vect& v ) const {
   vect axes[3];
   getMolAxes ( axes );
   return vect ( v * axes[0], v * axes[1], v * axes[2] );
}

void particle::getInertiaTenzor ( double I[3][3] ) const {
   const vect QCM = getCMPos ();

   I[0][0] = I[0][1] = I[0][2] = 0.0;
   I[1][0] = I[1][1] = I[1][2] = 0.0;
   I[2][0] = I[2][1] = I[2][2] = 0.0;

   for ( const_reference a: *this ) {
      const vect Q = a.r() - QCM;
      const double xm = Q.x * a.mass ();
      const double ym = Q.y * a.mass ();
      const double zm = Q.z * a.mass ();
      I[0][0] +=  Q.y*ym + Q.z*zm;
      I[0][1] += -Q.x*ym;
      I[0][2] += -Q.z*xm;
      I[1][1] +=  Q.x*xm + Q.z*zm;
      I[1][2] += -Q.z*ym;
      I[2][2] +=  Q.x*xm + Q.y*ym;
   }
   I[1][0] = I[0][1];
   I[2][0] = I[0][2];
   I[2][1] = I[1][2];
}

double particle::getEkin () const {
   double Ek = 0.0;
   
   for ( const_reference a: *this )
      Ek += (a.v() * a.v()) * a.mass();
   
   return 0.5 * Ek;
}

double particle::getEkinTrans () const {
   const vect V = getCMVel ();
   return 0.5 * V * V * mass ();
}

// ==========================================================================================
particle_type::particle_type ( mylist_const_iterator& in )
: basic_particle_type(in)
{
}

particle_type::~particle_type () {}

double particle_type::getInitialInteratomicDistance ( int i, int j ) const {
   return norm (initial_positions[j] - initial_positions[i]);
}

int particle_type::nDegFree () const {
   return nRotDegFree () + nVibrDegFree () + 3;
}

double particle_type::charge () const {
   double c = 0.0;
   for ( int a: this->atom_ids ) {
      c += Atom_types[a].charge();
   }
   return c;
}

vect particle_type::getInitialCMPos () const {
   vect QCM = 0.0;
   for ( int i = 0; i < natoms (); ++i )
      QCM += initial_positions[i] * get_atom_type(i).mass();
   QCM /= mass ();

   return QCM;
}

void particle_type::getInitialInertiaTensor ( double I[3][3] ) const {
   const vect QCM = getInitialCMPos ();
   vect Q;
   double xm, ym, zm;

   I[0][0] = I[0][1] = I[0][2] = 0.0;
   I[1][0] = I[1][1] = I[1][2] = 0.0;
   I[2][0] = I[2][1] = I[2][2] = 0.0;

   for ( int i = 0; i < natoms (); ++i ) {
      Q = initial_positions[i] - QCM;
      xm = Q.x * get_atom_type(i).mass ();
      ym = Q.y * get_atom_type(i).mass ();
      zm = Q.z * get_atom_type(i).mass ();
      I[0][0] +=  Q.y*ym + Q.z*zm;
      I[0][1] += -Q.x*ym;
      I[0][2] += -Q.z*xm;
      I[1][1] +=  Q.x*xm + Q.z*zm;
      I[1][2] += -Q.z*ym;
      I[2][2] +=  Q.x*xm + Q.y*ym;
   }
   I[1][0] = I[0][1];
   I[2][0] = I[0][2];
   I[2][1] = I[1][2];
}

void particle_type::print ( std::ostream& out ) const {
   out.setf ( std::ios::showpoint | std::ios::fixed | std::ios::right | std::ios::dec );
   out << "\nNAME: " << this->name ();
   out << "\nID:   " << this->id ();
   out << "\nNATOMS: " << this->natoms ();

   double Q = 0.0;
   vect M = 0.0;

   for ( int i = 0; i < natoms(); ++i ) {
      Q += get_atom_type(i).charge();
      M += get_atom_type(i).charge() * this->initial_positions[i];
   }
   out << "\nCHARGE: " << Q;
   if ( fabs(Q) < 0.0001 )
      out << "\nDIPOLE MOMENTUM: " << norm (M) * DIPOLE_MOMENTUM_UNIT / SI_D << " D";
   out << std::endl;

   out << "MASS: " << this->mass () << " a.m.u.\n";

   out << "\nATOMS:\n";

   for ( int i = 0; i < this->natoms(); ++i ) {
      out << std::setw(8) << get_atom_type(i).name();
      out << std::setw(10) << get_atom_type(i).mass();
      out << std::setw(10) << get_atom_type(i).charge();
      out << " | " << mdformat(9,5) << initial_positions[i];
      out << "\n";
   }
   
   out << "VIEW STCF: ";
   for ( const auto i: this->view_STCF ) {
      out << " " << i;
   }
   out << ";\n\n";

   
   out << "Interatomic distances:\n";
   for ( int i = 0; i < this->natoms()-1; ++i ) {
      for ( int j = i+1; j < this->natoms(); ++j ) {
         out << std::setw(8) << get_atom_type(i).name();
         out << std::setw(8) << get_atom_type(j).name();
         out << std::setw (10) << norm ( this->initial_positions[i] - this->initial_positions[j] );
         out << std::endl;
      }
   }
}

// =================================================================================
#include "lib/matrix.h"

void matrix_invertion ( double I[3][3] ) {
   MatInv ( (double*)I, 3 );
}
