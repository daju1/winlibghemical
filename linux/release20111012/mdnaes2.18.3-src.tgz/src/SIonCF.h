#ifndef SIonCF_H
#define SIonCF_H

extern int KIon_Cvv;
extern int KIon_Cww;
extern int KIon_Cff;
extern int KIon_Cnn;
extern int KIon_Cll;

extern int KIon_Cfc;

extern int KIon_Cwc;
extern int KIon_Cvw;

extern int KIon_WcWc;
extern int KIon_VcVc;
extern int KIon_VcWc;

extern int KIon_Cii;

void ShortIonCF_Calc ();

#endif
