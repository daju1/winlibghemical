#ifndef BASIC_PARTICLE_H
#define BASIC_PARTICLE_H

#include <vector>
#include <string>
#include <cstddef>

#include "lib/vect.h"
#include "atom.h"
#include "atomtbl.h"
#include "mylist.h"

using namespace mdnaes;


class basic_particle_type {
protected:
   basic_particle_type ( mylist_const_iterator& );
public:
   using size_type = atom_ref::size_type;//std::size_t;
   
   virtual ~basic_particle_type ();
   
   size_type natoms () const { return num_atoms; }
   const std::string& name () const { return particle_name; }
   size_type id () const { return particle_id; }
   
public:
   const atom_type& get_atom_type ( int i ) const { return Atom_types[atom_ids[i]]; }
   const std::vector<int>& get_atom_ids () const { return atom_ids; }
   
   const vect& init_pos ( size_type i ) const { return initial_positions[i]; }
   
   double mass () const { return particle_mass; }
   
   const std::vector<size_type>& get_Grt_view () const { return view_STCF; }
   const std::vector<size_type>& get_Fkt_view () const { return view_STCF; }
   
private:
   size_type num_atoms = 0;
protected:
   std::vector<int> atom_ids;
   std::vector<vect> initial_positions;
private:
   std::string particle_name;
   const size_type particle_id;
   
protected:
   std::vector<size_type> view_STCF;
   
private:
   double particle_mass;
private:
   static size_type next_id;
};

// ================================================================================================

class basic_particle {
protected:
   basic_particle ( const basic_particle_type& t, vect origin );
   basic_particle ( const basic_particle &src, vect cmpos );
   
   ~basic_particle () {}
   // no deep copy. shallow copy is ok. destructor will not delete state.
   // effectively has reference semantics.
   
public:
   using size_type = basic_particle_type::size_type;
   
   using reference = atom_ref;             // use it instead of atom&
   using const_reference = const_atom_ref; // use it instead of const atom&

   class iterator {
   public:
      using size_type = configuration_space::size_type;
      
      explicit iterator ( size_type i ) noexcept : index(i) {}
      
      iterator operator ++ () { return static_cast<iterator>(++index); }
      bool operator == ( iterator other ) const { return index == other.index; }
      bool operator != ( iterator other ) const { return index != other.index; }
      
      reference operator *() const { return static_cast<reference>(index); }

   private:
       size_type index;
   };
   
   class const_iterator {
   public:
      using size_type = configuration_space::size_type;
      
      explicit const_iterator ( size_type i ) noexcept : index(i) {}
      
      const_iterator operator ++ () { return static_cast<const_iterator>(++index); }
      bool operator == ( const_iterator other ) const { return index == other.index; }
      bool operator != ( const_iterator other ) const { return index != other.index; }
      
      const_reference operator *() const { return static_cast<const_reference>(index); }
      
   private:
      size_type index;
   };

public:
   class const_view {
   public:
      using size_type = basic_particle_type::size_type;
      using const_reference = basic_particle::const_reference;
      
      const_view ( size_type first_id, const std::vector<size_type>& v ) noexcept
      : atom_ids(v), first_index(first_id) {}
      
      size_type size () const { return natoms(); }
      size_type natoms () const { return atom_ids.size(); }
      const_reference operator [] ( size_type i ) const { return static_cast<const_reference>(first_index + atom_ids[i]); }
      
      class const_iterator {
      public:
         using size_type = const_view::size_type;
         
         const_iterator ( size_type i, const std::vector<size_type>& at_ids, size_type base_id ) noexcept
         : atom_ids(at_ids), first_index(base_id), index(i) {}
         
         const_iterator operator ++ () {
            if ( index < atom_ids.size() ) {
               ++index;
            }
            return const_iterator (index, atom_ids, first_index);
         }
         
         bool operator == ( const_iterator other ) const { return index == other.index; } // dangerous!
         bool operator != ( const_iterator other ) const { return index != other.index; } // dangerous!
         
         const_reference operator *() const { return static_cast<const_reference>(first_index + atom_ids[index]); }
         
      private:
         const std::vector<size_type>& atom_ids;
         size_type first_index;
         size_type index;
      };
      
      
      const_iterator begin () const {
         return const_iterator ( 0, atom_ids, first_index );
      }
      const_iterator end () const {
         return const_iterator ( atom_ids.size(), atom_ids, first_index );
      }
      
   private:
      const std::vector<size_type>& atom_ids;
      size_type first_index;
   };
   
   const_view Grt_view () const { return const_view(first_index, type.get_Grt_view()); }
   const_view Fkt_view () const { return const_view(first_index, type.get_Fkt_view()); }

public:
   size_type size () const { return natoms(); }
   size_type natoms () const { return numatoms; }
   reference operator [] ( size_type i ) { return static_cast<reference>(first_index + i); }
   const_reference operator [] ( size_type i ) const { return static_cast<const_reference>(first_index + i); }
   
   iterator begin () { return static_cast<iterator>(first_index); }
   const_iterator begin () const { return static_cast<const_iterator>(first_index); }
   iterator end () { return static_cast<iterator>( first_index + natoms() ); }
   const_iterator end () const { return static_cast<const_iterator>( first_index + natoms() ); }
   
   virtual void swap ( basic_particle& other );
   
public:
   const std::string& name () const { return type.name(); }
   size_type id () const { return type.id(); }
   
   void save ( std::ostream& out ) const { save_v2_0(out); }
   
   //this functions added for compatibility with previous versions
   virtual void read_v2_0 ( std::istream& );
   void save_v2_0 ( std::ostream& ) const;
   //end

   void print ( std::ostream& , const vect origin = 0.0, const vect origin_pos = 0.0 ) const;
   int DLPOLY_Out ( std::ostream&, int num_of_first_atom, int mode ) const;
   
public:
   double mass () const { return type.mass(); }
   virtual vect getCMPos () const;
   vect getUnPBC_CMPos () const { return unPBC_CMPos; }
   
public:
   auto getAtomPos ( size_type a ) const { return global_cspace.r(first_index+a); }
   
private:
   const basic_particle_type& type;
protected:
   size_type numatoms;
   size_type first_index;

   vect unPBC_CMPos;
};

#endif
