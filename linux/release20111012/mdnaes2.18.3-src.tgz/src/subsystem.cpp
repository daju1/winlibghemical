#include "subsystem.h"

#include "globals.h"
#include "all_particles.h"

#include <vector>
#include <thread>

// ============================================== SHELLS DEFINITION =========================================
std::unique_ptr<subsystem<particle*> > AllParticles;
std::unique_ptr<subsystem<molecule*> > AllMolecules;
std::unique_ptr<subsystem<ion*> > AllIons;
std::unique_ptr<subsystem<ion*> > AllCations;
std::unique_ptr<subsystem<ion*> > AllAnions;

std::vector<subsystem<molecule*>*> shells;

static std::unique_ptr<subsystem<molecule*> > shell_1Bulk;
static std::unique_ptr<subsystem<molecule*> > shell_1Kt1;
static std::unique_ptr<subsystem<molecule*> > shell_1Kt2;
static std::unique_ptr<subsystem<molecule*> > shell_1An1;
static std::unique_ptr<subsystem<molecule*> > shell_1An2;
static std::unique_ptr<subsystem<molecule*> > shell_1KA;
static std::unique_ptr<subsystem<molecule*> > shell_2Bulk;
static std::unique_ptr<subsystem<molecule*> > shell_2Kt1;
static std::unique_ptr<subsystem<molecule*> > shell_2Kt2;
static std::unique_ptr<subsystem<molecule*> > shell_2An1;
static std::unique_ptr<subsystem<molecule*> > shell_2An2;
static std::unique_ptr<subsystem<molecule*> > shell_2KA;

static void shells_init () {
   shell_1Bulk = std::make_unique<subsystem<molecule*> > ( "1Bulk", SimSystem.all_molecules1 );
   shell_1Kt1  = std::make_unique<subsystem<molecule*> > ( "1Kt1",  SimSystem.all_molecules1 );
   shell_1Kt2  = std::make_unique<subsystem<molecule*> > ( "1Kt2",  SimSystem.all_molecules1 );
   shell_1An1  = std::make_unique<subsystem<molecule*> > ( "1An1",  SimSystem.all_molecules1 );
   shell_1An2  = std::make_unique<subsystem<molecule*> > ( "1An2",  SimSystem.all_molecules1 );
   shell_1KA   = std::make_unique<subsystem<molecule*> > ( "1KA",   SimSystem.all_molecules1 );
   shell_2Bulk = std::make_unique<subsystem<molecule*> > ( "2Bulk", SimSystem.all_molecules2 );
   shell_2Kt1  = std::make_unique<subsystem<molecule*> > ( "2Kt1",  SimSystem.all_molecules2 );
   shell_2Kt2  = std::make_unique<subsystem<molecule*> > ( "2Kt2",  SimSystem.all_molecules2 );
   shell_2An1  = std::make_unique<subsystem<molecule*> > ( "2An1",  SimSystem.all_molecules2 );
   shell_2An2  = std::make_unique<subsystem<molecule*> > ( "2An2",  SimSystem.all_molecules2 );
   shell_2KA   = std::make_unique<subsystem<molecule*> > ( "2KA",   SimSystem.all_molecules2 );
   
   AllParticles = std::make_unique<subsystem<particle*> > ( "_all_particles", SimSystem.all_particles );
   AllIons      = std::make_unique<subsystem<ion*> >      ( "_all_ions",      SimSystem.all_ions );
   AllCations   = std::make_unique<subsystem<ion*> >      ( SimSystem.cation_types.size()>0 ? SimSystem.cation_types[0]->name() : "Kt", SimSystem.all_cations );
   AllAnions    = std::make_unique<subsystem<ion*> >      ( SimSystem.anion_types.size()>0  ? SimSystem.anion_types[0]->name()  : "An", SimSystem.all_anions );
   AllMolecules = std::make_unique<subsystem<molecule*> > ( "_all_molecules", SimSystem.all_molecules );
   
   if ( SimSystem.all_ions.size() == 0 ) {
      if ( SimSystem.all_molecules1.size() > 0 ) {
         shells.push_back( shell_1Bulk.get() );
      }
      if ( SimSystem.all_molecules2.size() > 0 ) {
         shells.push_back( shell_2Bulk.get() );
      }
   }
   else if ( SimSystem.all_cations.size() == 1 && SimSystem.all_anions.size() == 0 )  {
      if ( SimSystem.all_molecules1.size() > 0 ) {
         shells.push_back( shell_1Bulk.get() );
         shells.push_back( shell_1Kt2.get() );
         shells.push_back( shell_1Kt1.get() );
      }
      if ( SimSystem.all_molecules2.size() > 0 ) {
         shells.push_back( shell_2Bulk.get() );
         shells.push_back( shell_2Kt2.get() );
         shells.push_back( shell_2Kt1.get() );
      }
   }
   else if ( SimSystem.all_cations.size() == 0 && SimSystem.all_anions.size() == 1 )  {
      if ( SimSystem.all_molecules1.size() > 0 ) {
         shells.push_back( shell_1Bulk.get() );
         shells.push_back( shell_1An2.get() );
         shells.push_back( shell_1An1.get() );
      }
      if ( SimSystem.all_molecules2.size() > 0 ) {
         shells.push_back( shell_2Bulk.get() );
         shells.push_back( shell_2An2.get() );
         shells.push_back( shell_2An1.get() );
      }
   }
   else {
      if ( SimSystem.all_molecules1.size() > 0 ) {
         shells.push_back( shell_1Bulk.get() );
         shells.push_back( shell_1Kt1.get() );
         shells.push_back( shell_1An1.get() );
         shells.push_back( shell_1KA.get() );
      }
      if ( SimSystem.all_molecules2.size() > 0 ) {
         shells.push_back( shell_2Bulk.get() );
         shells.push_back( shell_2Kt1.get() );
         shells.push_back( shell_2An1.get() );
         shells.push_back( shell_2KA.get() );
      }
   }
}

static void do_shells ( int thread_no ) {
   if ( SimSystem.all_cations.size() == 1 && SimSystem.all_anions.size() == 0 )  { // single cation
      const std::vector<vect> ion_cc = SimSystem.all_ions[0]->getCoordinationCenters ();
      for ( int i = thread_no; i < SimSystem.all_molecules1.size(); i += NTHREADS ) {
         const double r = SimSystem.all_molecules1[i]->getMinCationCoordinationCenterDistance (ion_cc);
         if ( r > RSHL[1] )    shell_1Bulk->add (i);
         else
            if ( r > RSHL[0] ) shell_1Kt2->add (i);
            else               shell_1Kt1->add (i);
      }
      for ( int i = thread_no; i < SimSystem.all_molecules2.size(); i += NTHREADS ) {
         const double r = SimSystem.all_molecules2[i]->getMinCationCoordinationCenterDistance (ion_cc);
         if ( r > RSHL[6] )    shell_2Bulk->add (i);
         else
            if ( r > RSHL[5] ) shell_2Kt2->add (i);
            else               shell_2Kt1->add (i);
      }
   }
   else if ( SimSystem.all_cations.size() == 0 && SimSystem.all_anions.size() == 1 )  { // single anion
      const std::vector<vect> ion_cc = SimSystem.all_ions[0]->getCoordinationCenters ();
      for ( int i = thread_no; i < SimSystem.all_molecules1.size(); i += NTHREADS ) {
         const double r = SimSystem.all_molecules1[i]->getMinAnionCoordinationCenterDistance (ion_cc);
         if ( r > RSHL[3] )    shell_1Bulk->add (i);
         else
            if ( r > RSHL[2] ) shell_1An2->add (i);
            else               shell_1An1->add (i);
      }
      for ( int i = thread_no; i < SimSystem.all_molecules2.size(); i += NTHREADS ) {
         const double r = SimSystem.all_molecules2[i]->getMinAnionCoordinationCenterDistance (ion_cc);
         if ( r > RSHL[8] )    shell_2Bulk->add (i);
         else
            if ( r > RSHL[7] ) shell_2An2->add (i);
            else               shell_2An1->add (i);
      }
   }
   else {
      for ( auto pion: SimSystem.all_cations ) { // initialise Kt1 shell(s)
         const std::vector<vect> ion_cc = pion->getCoordinationCenters ();
         
         for ( int i = thread_no; i < SimSystem.all_molecules1.size(); i += NTHREADS ) {
            const double r = SimSystem.all_molecules1[i]->getMinCationCoordinationCenterDistance (ion_cc);
            if ( r < RSHL[0] ) shell_1Kt1->add (i);
         }
         for ( int i = thread_no; i < SimSystem.all_molecules2.size(); i += NTHREADS ) {
            const double r = SimSystem.all_molecules2[i]->getMinCationCoordinationCenterDistance (ion_cc);
            if ( r < RSHL[5] ) shell_2Kt1->add (i);
         }
      }
      
      for ( auto pion: SimSystem.all_anions ) { // initialise An1 shell(s)
         const std::vector<vect> ion_cc = pion->getCoordinationCenters ();
         
         for ( int i = thread_no; i < SimSystem.all_molecules1.size(); i += NTHREADS ) {
            const double r = SimSystem.all_molecules1[i]->getMinAnionCoordinationCenterDistance (ion_cc);
            if ( r < RSHL[2] ) shell_1An1->add (i);
         }
         for ( int i = thread_no; i < SimSystem.all_molecules2.size(); i += NTHREADS ) {
            const double r = SimSystem.all_molecules2[i]->getMinAnionCoordinationCenterDistance (ion_cc);
            if ( r < RSHL[7] ) shell_2An1->add (i);
         }
      }

      for ( int i = thread_no; i < SimSystem.all_molecules1.size(); i += NTHREADS ) {
         if ( shell_1Kt1->has(i) && shell_1An1->has(i) ) {
            shell_1Kt1->remove (i);
            shell_1An1->remove (i);
            shell_1KA->add (i);
         }
         if ( !shell_1Kt1->has(i) && !shell_1An1->has(i) && !shell_1KA->has(i) ) {
            shell_1Bulk->add (i);
         }
      }
      for ( int i = thread_no; i < SimSystem.all_molecules2.size(); i += NTHREADS ) {
         if ( shell_2Kt1->has(i) && shell_2An1->has(i) ) {
            shell_2Kt1->remove (i);
            shell_2An1->remove (i);
            shell_2KA->add (i);
         }
         if ( !shell_2Kt1->has(i) && !shell_2An1->has(i) && !shell_2KA->has(i) ) {
            shell_2Bulk->add (i);
         }
      }
   }
}

void ShellsDefinition () {
   static bool init = true;
   if ( init ) {
      shells_init ();
      init = false;
   }

   if ( SimSystem.all_ions.size() == 0 ) { // no ions
      // shells already include all molecules.
      return;
   }
   
   for ( auto pshl: shells) {
      pshl->removeall ();
   }
   std::vector<std::thread> threads;
   for ( int thread_no = 1; thread_no < NTHREADS; ++thread_no ) {
      threads.emplace_back (do_shells,  thread_no);
   }
   do_shells ( 0 );
   for ( auto& th : threads ) {
      th.join();
   }
}
