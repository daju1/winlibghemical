#ifndef LIonCF_H
#define LIonCF_H

extern int KIon_Axes; // Ex, Ey and Ez
extern int KIon_RCM;  // <|R(t)|> and <|R(t)|^2>

void LongIonCF_Calc ();

#endif
