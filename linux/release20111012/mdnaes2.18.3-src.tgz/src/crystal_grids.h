#ifndef CRYSTAL_GRIDS_H
#define CRYSTAL_GRIDS_H

#include <cstddef>

#include "lib/vect.h"
using namespace mdnaes;

class crystal_grid {
public:
   using size_type = std::size_t;
   
   virtual ~crystal_grid ();
   
   virtual size_type size () const = 0; // number of points in grid
   virtual vect operator [] ( size_type i ) const = 0;
   
   class const_iterator {
   private:
      size_type index;
      const crystal_grid& grid;
      
   public:
      const_iterator ( const crystal_grid& g, size_type i ) : grid(g), index(i) {}
      
      const_iterator& operator ++() { ++index; return *this; }
      bool operator == ( const_iterator& other ) const { return index == other.index; }
      bool operator != ( const_iterator& other ) const { return index != other.index; }
      
      vect operator *() const { return grid[index]; }
   };
   
   const_iterator begin () const { return const_iterator{*this, 0}; }
   const_iterator end   () const { return const_iterator{*this, size()}; }
   
public:
   double lbox () const { return m_lbox; }

   crystal_grid::size_type find_nearest ( vect position ) const;
   
protected:
   crystal_grid ( double lbox_ ) : m_lbox(lbox_) {}
   
   double m_lbox;
};

class Pcubic_grid : public crystal_grid {
public:
   Pcubic_grid ( size_type requested_size, double lbox );
   
   virtual ~Pcubic_grid ();
   
   virtual size_type size () const override;
   virtual vect operator [] ( size_type i) const override;
   
private:
   size_type n;
};

class FCC_grid : public crystal_grid {
public:
   FCC_grid ( size_type requested_size, double lbox );
   
   virtual ~FCC_grid ();
   
   virtual size_type size () const override;
   virtual vect operator [] ( size_type i) const override;
   
private:
   size_type n;
};


#endif
