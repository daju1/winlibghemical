// WinGhemicalCommandLine.cpp

// Copyright (C) 2005 Dana Tenneson, Brown University.

// This program is free software; you can redistribute it and/or modify it
// under the terms of the license (GNU GPL) which comes with this package.

// This is a demo program of using the winlibghemical dll in windows.  If additional functionality
// needs to be exported from the dll for an application, look at the modifications to the .h files
// included here for an indication of what to do.

// Please note that the c3d2 file formats that are input and output here ARE NOT STANDARD C3D2.
// The output file contains no bonds and the bonds in the input file indicate higher order by
// repeating the bond connection number rather than changing the valency value.
/*################################################################################################*/


#include "stdafx.h"
#include <stdlib.h>
#include "../winlibghemical/src/notice.h"
#include "../winlibghemical/src/model.h"
#include "../winlibghemical/src/geomopt.h"

// The commands this app can take.
const char* OPTIMIZE = "GEOMOPT";
const char* ENERGY = "ENERGY";

const double SCALE = 10;// Not sure what is wrong here, but coords appear off by a factor of 10.


// Sets the model using the c3d2 file format.
// Note: currently doesn't use exactly the c3d2 file format.  Handles double, triple bonds a little differently.
void SetModel(const char* file, model* m)
{
	// Open the file.
	ifstream inFile;
	inFile.open(file);

	// Clean out the model of any existing data
	m->ClearModel();
	// Copy the input into a string we can work with.
	char* buffer = new char[50000];
	inFile.getline(buffer,50000);
	// First, grab the first token which indicates the number of atoms.
	char* token;
	token = strtok(buffer,"\n");
	int lines = atoi(token);
	char** atomStrings = new char*[lines];
	char** bondStrings = new char*[lines];
	vector<atom *> atomVector;
	vector<bond *> bondVector;
	// Go through and split up the lines.
	for(int i=0;i<lines;i++)
	{
		inFile.getline(buffer,50000);
		atomStrings[i] = new char[strlen(buffer)+1];
		strcpy(atomStrings[i],buffer);
	}
	
	// Now create each atom.
	for(int i=0;i<lines;i++)
	{
		// Create the element
		token = strtok(atomStrings[i]," \n");
		element theElement(token);
		// Skip the index
		token = strtok(NULL," \n");
		// Create the location
		fGL location[3];
		token = strtok(NULL," \n");
		location[0] = (fGL)(atof(token))/SCALE;
		token = strtok(NULL," \n");
		location[1] = (fGL)(atof(token))/SCALE;
		token = strtok(NULL," \n");
		location[2] = (fGL)(atof(token))/SCALE;

		// Add the atom in.
		atom tempAtom(theElement, location, m->GetCRDSetCount());
		m->AddAtom(tempAtom);
		atomVector.push_back(&(m->GetLastAtom()));
		// Skip ahead to the bonds.
		token = strtok(NULL," \n");
		bondStrings[i] = token + strlen(token) +1;
		
	}
	
	// Now create the full list of bonds.
	for(int i=0;i<lines;i++)
	{
		// Find the first bond.
		token = strtok(bondStrings[i]," \n");
		while(token != NULL)
		{
			int target = atoi(token);
			// Make sure we only add each bond once.
			if(target > (i+1))
			{
				// Create a bond
				bondtype singleBond(1); // Fix this later
				bond tempBond(atomVector[i], atomVector[target-1], singleBond);
				
				// Check if the last bond was also between these two atoms
				// This is a hack on the c3d2 file format.  They're version sucks.
				bool bondHandled = false;
				if(!bondVector.empty())
				{
					bond* lastBond = bondVector.back();
					if(lastBond->atmr[0]->index == i && lastBond->atmr[1]->index == target-1)
					{
						// Just increment the old bond
						lastBond->bt++;
						bondHandled = true;
					}
				}
				// If the above did not handle the bond, we should
				if(!bondHandled)
				{
					m->AddBond(tempBond);
					bondVector.push_back(&(m->GetLastBond()));
				}
			}
			token = strtok(NULL," \n");
		}
	}
	// Try adding atoms.
	m->AddHydrogens();
	
	for(int i=0;i<lines;i++)
	{
		delete[] atomStrings[i];
	}
	delete[] atomStrings;
	delete[] bondStrings;
	delete[] buffer;
	inFile.close();
}

// Gets the model and returns it as a C3D2 file.  
// Currently does not return the full file, just info ChemPad needs.
void WriteModel(const char* file, model* m)
{
	// Create the output file
	ofstream outFile;
	outFile.open(file);
	
	// Create a buffer for inputting numbers into the string
	char buffer[100];
	// Add in the number of atoms
	sprintf(buffer,"%d",m->GetAtomCount());
	outFile<<buffer<<"\n";
	
	// Start adding the atoms.
	for (i32u n1 = 0;n1 < m->GetCRDSetCount();n1++)
	{
		// Loop through on an iterator.
		for (iter_al it1 = m->GetAtomsBegin();it1 != m->GetAtomsEnd();it1++)
		{
			// Get the coordinates.
			const fGL * cdata = (* it1).GetCRD(n1);
			
			// Format the line.
			int typeNum =  (* it1).el.GetAtomicNumber() * 10 + 0; // Hack ignoring valence
			// Next line jacked from the OpenBabel Code
			sprintf(buffer,"%-3s %-5d %8.4f  %8.4f  %8.4f %5d",(* it1).el.GetSymbol(),((* it1).index)+1,cdata[0]*SCALE,cdata[1]*SCALE,cdata[2]*SCALE,typeNum);
			outFile<<buffer<<"\n";
		}
	}
	// For now, ignore the bonds
	outFile.close();
}

// Performas Geometry Optimization of the set mode.
void GeomOpt(model* m)
{
	
	geomopt_param param(NULL);
		
	param.enable_nsteps = true;
	param.treshold_nsteps = 500;
	param.enable_grad = true;
	param.treshold_grad = 1.0e-3;
	param.enable_delta_e = true;
	param.treshold_delta_e = 1.0e-7;

	m->DoGeomOpt(param,false);
}

// Runs the energy calculation code.
void CalculateEnergy(model* m)
{
	m->DoEnergy();
}

int _tmain(int argc, _TCHAR* argv[])
{
	// Print Notification.
	std::cout<<"Starting "<<argv[0]<<" a derivative work of libghemical.\nhttp://http://www.uku.fi/~thassine/ghemical/\nModifications Copyright: Dana Tenneson, Brown University. 2005\n";
	print_lib_intro_notice();
	print_copyright_notice();
	
	// Check the arguments
	if(argc != 4)
	{
		std::cout<<"Usage: "<<argv[0]<<" {"<<OPTIMIZE<<","<<ENERGY<<"} <InFileName.c3d2> <OutFileName.c3d2>";
		return 0;
	}
	// Build our model
	model m;
	SetModel(argv[2],&m);
	
	// Run the requested algorithm
	if(strcmp(argv[1],OPTIMIZE) == 0)
	{
		GeomOpt(&m);
	}
	else if(strcmp(argv[1],ENERGY) == 0)
	{
		CalculateEnergy(&m);
	}
	
	// Write the model back.
	WriteModel(argv[3], &m);
	std::cout<<"Done!\n";
	return 0;
}

