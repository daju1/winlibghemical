/* src/libconfig.h.in.  Would normally be generated from configure.in by autoheader.  */
/* This version hand modified for Windows compiles by Dana Tenneson 2005

 Part of the Ghemical package
 Copyright (c) 2000 Geoff Hutchison
 For copyright details, see the file COPYING in your distribution
 or the GNU General Public License version 2 or later
 <http://www.gnu.org/copyleft/gpl.html>

*/

/* Set up math recognition */
#ifndef M_PI
#define _USE_MATH_DEFINES
#include <math.h>
#endif

/* Define if you are building a version with a GUI */
#undef ENABLE_GRAPHICS

/* Define if you are building a version with the project manager */
#undef ENABLE_TREELIST_VIEW

/* Define if you are building a version that interfaces directly with MPQC */
#undef ENABLE_MPQC

/* This is the version of Ghemical to be built--it is set in the configure.in */
#undef VERSION

/* *** Additional configure options added by autoheader *** */

/* Define if you are building a version that interfaces directly with MPQC */
#undef ENABLE_MPQC

/* Define to 1 if you have the <dlfcn.h> header file. */
#undef HAVE_DLFCN_H

/* Define to 1 if you have the <inttypes.h> header file. */
#undef HAVE_INTTYPES_H

/* Define to 1 if you have the `blas' library (-lblas). */
#undef HAVE_LIBBLAS

/* Define to 1 if you have the `g2c' library (-lg2c). */
#undef HAVE_LIBG2C

/* Define to 1 if you have the `lapack' library (-llapack). */
#undef HAVE_LIBLAPACK

/* Define to 1 if you have the `m' library (-lm). */
#undef HAVE_LIBM

/* Define to 1 if you have the `Xmu' library (-lXmu). */
#undef HAVE_LIBXMU

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#undef HAVE_STDINT_H

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#undef HAVE_STRINGS_H

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#undef HAVE_UNISTD_H

/* Where the data files are ; set in the configure.in */
#define LIBDATA_PATH "datadir/libghemical"

/* This is the version of libghemical to be built--it is set in the
   configure.in */
#define LIBRELEASEDATE "2005-07-01"

/* This is the version of libghemical to be built--it is set in the
   configure.in */
#define LIBVERSION "1.9"

/* Name of package */
#undef PACKAGE

/* Define to the address where bug reports for this package should be sent. */
#undef PACKAGE_BUGREPORT

/* Define to the full name of this package. */
#undef PACKAGE_NAME

/* Define to the full name and version of this package. */
#undef PACKAGE_STRING

/* Define to the one symbol short name of this package. */
#undef PACKAGE_TARNAME

/* Define to the version of this package. */
#undef PACKAGE_VERSION

/* This is the major version of SC (MPQC's underlying library) found by
   configure */
#undef SC_MAJOR_VERSION

/* This is the micro version of SC (MPQC's underlying library) found by
   configure */
#undef SC_MICRO_VERSION

/* This is the minor version of SC (MPQC's underlying library) found by
   configure */
#undef SC_MINOR_VERSION

/* Define to 1 if you have the ANSI C header files. */
#undef STDC_HEADERS

/* Version number of package */
#undef VERSION

/* Define to empty if `const' does not conform to ANSI C. */
#undef const

/* Define to `__inline__' or `__inline' if that's what the C compiler
   calls it, or to nothing if 'inline' is not supported under any name.  */
#ifndef __cplusplus
#undef inline
#endif
