// RESONANCE.CPP

// Copyright (C) 2004 Tommi Hassinen, Juha Jungman

// This program is free software; you can redistribute it and/or modify it
// under the terms of the license (GNU GPL) which comes with this package.

/*################################################################################################*/

#include "resonance.h"

/*################################################################################################*/

resonance_structures::resonance_structures(model * p1)
{
	mdl = p1;
}

resonance_structures::~resonance_structures(void)
{
}

void resonance_structures::MakeStructures(void)
{
}

void resonance_structures::CycleStructures(void)
{
}

/*################################################################################################*/

// eof
