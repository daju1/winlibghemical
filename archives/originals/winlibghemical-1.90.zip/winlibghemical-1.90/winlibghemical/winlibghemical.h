// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the WINLIBGHEMICAL_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// WINLIBGHEMICAL_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef WINLIBGHEMICAL_EXPORTS
#define WINLIBGHEMICAL_API __declspec(dllexport)
#else
#define WINLIBGHEMICAL_API __declspec(dllimport)
#endif

/*
// This class is exported from the winlibghemical.dll
class WINLIBGHEMICAL_API Cwinlibghemical {
public:
	Cwinlibghemical(void);
	// TODO: add your methods here.
};

extern WINLIBGHEMICAL_API int nwinlibghemical;

WINLIBGHEMICAL_API int fnwinlibghemical(void);
*/
